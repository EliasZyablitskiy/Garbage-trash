#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для запуска синхронизации данных подписок между SQL и JSON базами данных
Можно запустить вручную или по расписанию
"""

import os
import sys
import logging
import asyncio
from datetime import datetime

# Настраиваем логирование
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def main():
    """
    Запускает синхронизацию подписок один раз
    """
    # Проверка наличия переменной окружения DATABASE_URL
    DATABASE_URL = os.environ.get("DATABASE_URL")
    if not DATABASE_URL:
        logger.error("DATABASE_URL environment variable not set. Exiting.")
        sys.exit(1)
    
    logger.info(f"Starting subscription synchronization at {datetime.now().isoformat()}")
    
    try:
        # Получаем Flask-приложение
        from db_config import get_flask_app
        flask_app = get_flask_app()
        
        # Запускаем синхронизацию асинхронно
        from services.subscription_synchronizer import run_one_time_sync
        
        # Запускаем и ждем завершения
        async def run_sync():
            results = await run_one_time_sync(flask_app)
            processed, updated, errors = results
            logger.info(f"Synchronization completed: {processed} processed, {updated} updated, {errors} errors")
            return results
        
        # Создаем и выполняем задачу в цикле событий
        loop = asyncio.get_event_loop()
        results = loop.run_until_complete(run_sync())
        
        # Выводим результаты
        processed, updated, errors = results
        print(f"Subscription synchronization completed.")
        print(f"Processed: {processed} records")
        print(f"Updated: {updated} records")
        print(f"Errors: {errors}")
        
        if errors > 0:
            sys.exit(1)
        
    except Exception as e:
        logger.error(f"Error during subscription synchronization: {e}")
        sys.exit(1)
    
    logger.info("Subscription synchronization finished successfully")

if __name__ == "__main__":
    main()