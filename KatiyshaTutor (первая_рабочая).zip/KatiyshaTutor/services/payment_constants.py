#!/usr/bin/env python
# coding: utf-8

"""
Файл с константами платежной системы
Позволяет избежать циклических импортов
"""
from enum import Enum

# Константы статусов платежей унифицированной системы
PAYMENT_STATUS = {
    'INITIATED': 'initiated',    # Платеж создан, но еще не оплачен
    'PENDING': 'pending',        # Платеж в процессе обработки
    'COMPLETED': 'completed',    # Платеж успешно выполнен
    'FAILED': 'failed',          # Ошибка при обработке платежа
    'CANCELLED': 'cancelled',    # Платеж отменен пользователем
    'EXPIRED': 'expired',        # Время ожидания платежа истекло
    'REFUNDED': 'refunded'       # Платеж возвращен
}

# Константы типов платежных систем унифицированной системы
PAYMENT_SYSTEMS = {
    'ROBOKASSA': 'robokassa',             # Платежи через Robokassa
    'SBP_LINK': 'sbp_link'                # Платежи через СБП (унифицированный метод)
}

# Унифицированные коды результатов проверки платежей
class PaymentResultCode(Enum):
    """Коды результатов проверки платежа унифицированной системы"""
    SUCCESS = 'success'                  # Успешный платеж
    PENDING = 'pending'                  # Платеж в процессе обработки
    FAILED = 'failed'                    # Ошибка обработки платежа
    INVALID_AMOUNT = 'invalid_amount'    # Неверная сумма платежа
    SECURITY_ERROR = 'security_error'    # Ошибка безопасности (подпись не верна)
    DUPLICATE = 'duplicate'              # Дубликат платежа
    ALREADY_PROCESSED = 'already_processed'  # Платеж уже обработан
    EXPIRED = 'expired'                  # Время ожидания платежа истекло
    PAYMENT_NOT_FOUND = 'payment_not_found'  # Платеж не найден
    DATABASE_ERROR = 'database_error'    # Ошибка базы данных
    SYSTEM_ERROR = 'system_error'        # Системная ошибка
    UNKNOWN = 'unknown'                  # Неизвестная ошибка

# Псевдоним для обратной совместимости (сохраняем пока не обновим все импорты)
ResultCode = PaymentResultCode

# Константы типов уведомлений
class NotificationType(Enum):
    """Типы уведомлений системы"""
    GENERAL = 'general'                # Общее уведомление
    PAYMENT_SUCCESS = 'payment_success'  # Успешный платеж
    PAYMENT_FAILURE = 'payment_failure'  # Ошибка платежа
    PAYMENT_PENDING = 'payment_pending'  # Платеж в ожидании
    PAYMENT_DUPLICATE = 'payment_duplicate'  # Дубликат платежа
    SUBSCRIPTION_ACTIVATED = 'subscription_activated'  # Активация подписки
    SUBSCRIPTION_EXPIRED = 'subscription_expired'  # Истечение подписки
    SUBSCRIPTION_REMINDER = 'subscription_reminder'  # Напоминание о подписке
    REFERRAL_REWARD = 'referral_reward'  # Реферальная награда
    REWARD_PAYOUT = 'reward_payout'  # Выплата награды
    SYSTEM_NOTIFICATION = 'system_notification'  # Системное уведомление
    ERROR_NOTIFICATION = 'error_notification'  # Уведомление об ошибке
    PLATFORM_FEEDBACK = 'platform_feedback'  # Отзыв о платформе
    RECOVERY_NOTIFICATION = 'recovery_notification'  # Уведомление о восстановлении платежа
    ADMIN_ALERT = 'admin_alert'  # Уведомление для администраторов
    DEBUG = 'debug'  # Отладочное уведомление

# Типы платежей в системе
class PaymentType(Enum):
    """Типы платежей в системе"""
    SUBSCRIPTION = 'subscription'  # Оплата подписки
    REFERRAL_REWARD = 'referral_reward'  # Реферальное вознаграждение
    PAYOUT = 'payout'  # Выплата средств пользователю
    ACCUMULATED = 'accumulated'  # Накопленные средства
    MANUAL = 'manual'  # Ручное пополнение/списание администратором