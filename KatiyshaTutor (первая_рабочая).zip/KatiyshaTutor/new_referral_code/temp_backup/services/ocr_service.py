#!/usr/bin/env python
# coding: utf-8

"""
Service for extracting text from images using Free Online OCR API
"""

import logging
import aiohttp
import config
import os

logger = logging.getLogger(__name__)

async def extract_text_from_image(image_path: str) -> str:
    """
    Extract text from an image using Free Online OCR API
    
    Args:
        image_path: Path to the image file
        
    Returns:
        str: The extracted text from the image
    """
    if not config.OCR_API_KEY:
        raise ValueError("OCR API key not found. Please set the OCR_API_KEY environment variable.")
    
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image file not found: {image_path}")
    
    url = config.OCR_API_URL
    
    headers = {
        "Authorization": f"Bearer {config.OCR_API_KEY}"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            # Read image file as binary
            with open(image_path, "rb") as f:
                image_data = f.read()
            
            # Create form data with the image file
            form_data = aiohttp.FormData()
            form_data.add_field('file', 
                               image_data, 
                               filename=os.path.basename(image_path),
                               content_type='image/jpeg')
            form_data.add_field('language', 'eng')  # English language
            form_data.add_field('detectOrientation', 'true')
            
            # Post the request
            async with session.post(url, headers=headers, data=form_data) as response:
                if response.status == 200:
                    data = await response.json()
                    extracted_text = data.get('text', '')
                    return extracted_text
                else:
                    error_text = await response.text()
                    logger.error(f"OCR API error: {response.status} - {error_text}")
                    
                    # Fallback to alternative OCR method if the API fails
                    return await fallback_ocr(image_path)
    except Exception as e:
        logger.error(f"Error in OCR processing: {e}")
        # Fallback to alternative OCR method if the API fails
        return await fallback_ocr(image_path)

async def fallback_ocr(image_path: str) -> str:
    """
    Fallback OCR method using pytesseract if available
    
    Args:
        image_path: Path to the image file
        
    Returns:
        str: The extracted text or empty string if fails
    """
    try:
        # Try to import pytesseract and PIL for local OCR
        import pytesseract
        from PIL import Image
        
        # Preprocess the image to improve OCR accuracy
        img = Image.open(image_path)
        
        # Extract text
        extracted_text = pytesseract.image_to_string(img)
        return extracted_text
    except ImportError:
        logger.error("Pytesseract not available for fallback OCR")
        return ""
    except Exception as e:
        logger.error(f"Fallback OCR error: {e}")
        return ""
