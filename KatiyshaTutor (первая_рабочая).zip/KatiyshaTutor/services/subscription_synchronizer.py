#!/usr/bin/env python
# coding: utf-8

"""
Сервис для периодической синхронизации данных подписок между базами данных SQL и JSON
"""

import os
import logging
import datetime
import json
from typing import Dict, Any, List, Tuple, Optional
import asyncio

from db_models import db, User as DbUser
from database import get_all_users, update_user_data, get_user
from services.subscription_service import (
    safe_parse_date,
    log_subscription_audit,
    synchronize_subscription_fields
)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Создаем и настраиваем обработчик файлового логирования
file_handler = logging.FileHandler("logs/subscription_sync.log")
file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logger.addHandler(file_handler)

class SubscriptionSynchronizer:
    """Класс для синхронизации данных подписок между SQL и JSON"""
    
    def __init__(self, app=None):
        """
        Инициализация синхронизатора подписок
        
        Args:
            app: Экземпляр Flask-приложения
        """
        self.app = app
        self.sync_interval = 3600  # 1 час по умолчанию
        self.is_running = False
        self.task = None
    
    async def start(self, interval: int = 3600):
        """
        Запуск периодической синхронизации
        
        Args:
            interval: Интервал синхронизации в секундах
        """
        if self.is_running:
            logger.warning("Synchronizer is already running")
            return
        
        self.sync_interval = interval
        self.is_running = True
        
        # Создаем и запускаем асинхронную задачу
        self.task = asyncio.create_task(self._run_periodic_sync())
        logger.info(f"Subscription synchronizer started with interval {interval} seconds")
    
    async def stop(self):
        """Остановка синхронизации"""
        if not self.is_running:
            logger.warning("Synchronizer is not running")
            return
        
        self.is_running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            self.task = None
        
        logger.info("Subscription synchronizer stopped")
    
    async def _run_periodic_sync(self):
        """Периодический запуск синхронизации в фоновом режиме"""
        try:
            while self.is_running:
                # Немедленно выполняем первую синхронизацию
                await self.synchronize_all_subscriptions()
                
                # Ждем указанный интервал перед следующей синхронизацией
                for _ in range(self.sync_interval):
                    if not self.is_running:
                        break
                    await asyncio.sleep(1)
        except asyncio.CancelledError:
            logger.info("Periodic subscription synchronization cancelled")
            raise
        except Exception as e:
            logger.error(f"Error in periodic subscription synchronization: {e}")
            # Перезапускаем задачу в случае неожиданной ошибки
            if self.is_running:
                self.task = asyncio.create_task(self._run_periodic_sync())
    
    async def synchronize_all_subscriptions(self) -> Tuple[int, int, int]:
        """
        Синхронизирует данные о подписках между SQL и JSON базами данных
        
        Returns:
            Tuple[int, int, int]: (кол-во обработанных, кол-во обновленных, кол-во ошибок)
        """
        # Счетчики для отслеживания результатов
        processed_count = 0
        updated_count = 0
        error_count = 0
        
        if not self.app:
            logger.error("Cannot synchronize subscriptions: Flask app not provided")
            return processed_count, updated_count, error_count
        
        try:
            # Получаем всех пользователей из JSON
            json_users = get_all_users()
            json_user_ids = {int(user.get('id', 0)) for user in json_users if user.get('id')}
            
            # Используем контекст Flask-приложения для работы с SQL базой данных
            with self.app.app_context():
                # Получаем всех пользователей из SQL
                sql_users = DbUser.query.all()
                sql_user_ids = {user.id for user in sql_users}
                
                # 1. Синхронизируем пользователей, которые есть в обеих базах
                common_user_ids = json_user_ids.intersection(sql_user_ids)
                for user_id in common_user_ids:
                    processed_count += 1
                    
                    # Получаем данные пользователя из обеих баз
                    json_user = get_user(user_id)
                    sql_user = DbUser.query.filter_by(id=user_id).first()
                    
                    # Проверяем наличие данных подписки
                    json_has_subscription = ('subscription_expiry' in json_user or 'subscription_end' in json_user)
                    sql_has_subscription = (sql_user.subscription_expiry is not None or sql_user.subscription_end is not None)
                    
                    if json_has_subscription and sql_has_subscription:
                        # Получаем даты подписки из обоих источников
                        json_expiry = safe_parse_date(json_user.get('subscription_expiry')) if 'subscription_expiry' in json_user else None
                        json_end = safe_parse_date(json_user.get('subscription_end')) if 'subscription_end' in json_user else None
                        sql_expiry = sql_user.subscription_expiry
                        sql_end = sql_user.subscription_end
                        
                        # Определяем наиболее позднюю дату из всех доступных
                        valid_dates = [d for d in [json_expiry, json_end, sql_expiry, sql_end] if d is not None]
                        if valid_dates:
                            latest_date = max(valid_dates)
                            
                            # Проверяем необходимость обновления в каждой из баз
                            json_needs_update = (json_expiry != latest_date) or (json_end != latest_date)
                            sql_needs_update = (sql_expiry != latest_date) or (sql_end != latest_date)
                            
                            # Обновляем данные в обоих источниках, если необходимо
                            if json_needs_update or sql_needs_update:
                                updated_count += 1
                                
                                # Обновляем данные в JSON
                                if json_needs_update:
                                    old_value = f"expiry={json_expiry}, end={json_end}"
                                    json_user['subscription_expiry'] = latest_date.isoformat()
                                    json_user['subscription_end'] = latest_date.isoformat()
                                    update_user_data(user_id, json_user)
                                    logger.info(f"Updated JSON subscription for user {user_id} to {latest_date.isoformat()}")
                                
                                # Обновляем данные в SQL
                                if sql_needs_update:
                                    old_value = f"expiry={sql_expiry}, end={sql_end}"
                                    sql_user.subscription_expiry = latest_date
                                    sql_user.subscription_end = latest_date
                                    db.session.commit()
                                    logger.info(f"Updated SQL subscription for user {user_id} to {latest_date.isoformat()}")
                                
                                # Логируем операцию в аудите
                                log_subscription_audit(
                                    user_id=user_id,
                                    action="sync",
                                    old_value=old_value,
                                    new_value=latest_date.isoformat(),
                                    reason="data_sync",
                                    details={
                                        "json_had_expiry": json_expiry is not None,
                                        "json_had_end": json_end is not None,
                                        "sql_had_expiry": sql_expiry is not None,
                                        "sql_had_end": sql_end is not None,
                                    }
                                )
                    elif json_has_subscription and not sql_has_subscription:
                        # Есть данные только в JSON - копируем в SQL
                        json_expiry = safe_parse_date(json_user.get('subscription_expiry', json_user.get('subscription_end')))
                        if json_expiry:
                            updated_count += 1
                            sql_user.subscription_expiry = json_expiry
                            sql_user.subscription_end = json_expiry
                            db.session.commit()
                            logger.info(f"Copied subscription data from JSON to SQL for user {user_id}: {json_expiry.isoformat()}")
                            
                            # Логируем операцию в аудите
                            log_subscription_audit(
                                user_id=user_id,
                                action="sync_json_to_sql",
                                old_value="None",
                                new_value=json_expiry.isoformat(),
                                reason="data_sync",
                                details={"source": "json"}
                            )
                    elif sql_has_subscription and not json_has_subscription:
                        # Есть данные только в SQL - копируем в JSON
                        sql_expiry = sql_user.subscription_expiry or sql_user.subscription_end
                        if sql_expiry:
                            updated_count += 1
                            json_user['subscription_expiry'] = sql_expiry.isoformat()
                            json_user['subscription_end'] = sql_expiry.isoformat()
                            update_user_data(user_id, json_user)
                            logger.info(f"Copied subscription data from SQL to JSON for user {user_id}: {sql_expiry.isoformat()}")
                            
                            # Логируем операцию в аудите
                            log_subscription_audit(
                                user_id=user_id,
                                action="sync_sql_to_json",
                                old_value="None",
                                new_value=sql_expiry.isoformat(),
                                reason="data_sync",
                                details={"source": "sql"}
                            )
                
                # 2. Добавляем пользователей, которые есть только в SQL, в JSON
                sql_only_user_ids = sql_user_ids - json_user_ids
                for user_id in sql_only_user_ids:
                    processed_count += 1
                    try:
                        sql_user = DbUser.query.filter_by(id=user_id).first()
                        if sql_user:
                            # Создаем базовую структуру пользователя для JSON
                            new_json_user = {
                                "id": sql_user.id,
                                "username": sql_user.username or "",
                                "first_name": sql_user.first_name or "",
                                "last_name": sql_user.last_name or "",
                                "free_request_used": sql_user.free_request_used,
                                "registration_date": datetime.datetime.now().isoformat()
                            }
                            
                            # Добавляем данные подписки, если они есть
                            if sql_user.subscription_expiry:
                                new_json_user["subscription_expiry"] = sql_user.subscription_expiry.isoformat()
                                new_json_user["subscription_end"] = sql_user.subscription_expiry.isoformat()
                            
                            # Сохраняем в JSON БД
                            update_user_data(user_id, new_json_user)
                            updated_count += 1
                            logger.info(f"Created JSON record for SQL-only user {user_id}")
                    except Exception as e:
                        error_count += 1
                        logger.error(f"Error creating JSON record for SQL-only user {user_id}: {e}")
                
                # 3. Создаем записи в SQL для пользователей, которые есть только в JSON
                json_only_user_ids = json_user_ids - sql_user_ids
                for user_id in json_only_user_ids:
                    processed_count += 1
                    try:
                        json_user = get_user(user_id)
                        if json_user:
                            # Создаем объект пользователя для SQL
                            new_sql_user = DbUser(
                                id=user_id,
                                username=json_user.get('username', ''),
                                first_name=json_user.get('first_name', ''),
                                last_name=json_user.get('last_name', ''),
                                free_request_used=json_user.get('free_request_used', False)
                            )
                            
                            # Добавляем данные подписки, если они есть
                            json_expiry = None
                            if 'subscription_expiry' in json_user:
                                json_expiry = safe_parse_date(json_user['subscription_expiry'])
                            elif 'subscription_end' in json_user:
                                json_expiry = safe_parse_date(json_user['subscription_end'])
                                
                            if json_expiry:
                                new_sql_user.subscription_expiry = json_expiry
                                new_sql_user.subscription_end = json_expiry
                            
                            # Сохраняем в SQL БД
                            db.session.add(new_sql_user)
                            db.session.commit()
                            updated_count += 1
                            logger.info(f"Created SQL record for JSON-only user {user_id}")
                    except Exception as e:
                        error_count += 1
                        logger.error(f"Error creating SQL record for JSON-only user {user_id}: {e}")
        
        except Exception as e:
            error_count += 1
            logger.error(f"Error during subscription data synchronization: {e}")
        
        # Возвращаем статистику обработки
        sync_stats = (processed_count, updated_count, error_count)
        logger.info(f"Subscription synchronization completed: {processed_count} processed, {updated_count} updated, {error_count} errors")
        return sync_stats


# Создаем глобальный экземпляр синхронизатора
subscription_synchronizer = None

def init_subscription_synchronizer(app, auto_start: bool = True, interval: int = 3600) -> SubscriptionSynchronizer:
    """
    Инициализирует и возвращает глобальный экземпляр синхронизатора подписок
    
    Args:
        app: Экземпляр Flask-приложения
        auto_start: Автоматически запускать синхронизацию
        interval: Интервал синхронизации в секундах
        
    Returns:
        SubscriptionSynchronizer: Экземпляр синхронизатора
    """
    global subscription_synchronizer
    
    if subscription_synchronizer is None:
        subscription_synchronizer = SubscriptionSynchronizer(app)
        
        if auto_start:
            # Запускаем синхронизацию асинхронно
            loop = asyncio.get_event_loop()
            loop.create_task(subscription_synchronizer.start(interval))
    
    return subscription_synchronizer

async def run_one_time_sync(app) -> Tuple[int, int, int]:
    """
    Выполняет однократную синхронизацию подписок
    
    Args:
        app: Экземпляр Flask-приложения
        
    Returns:
        Tuple[int, int, int]: (кол-во обработанных, кол-во обновленных, кол-во ошибок)
    """
    # Создаем временный экземпляр синхронизатора
    temp_synchronizer = SubscriptionSynchronizer(app)
    return await temp_synchronizer.synchronize_all_subscriptions()