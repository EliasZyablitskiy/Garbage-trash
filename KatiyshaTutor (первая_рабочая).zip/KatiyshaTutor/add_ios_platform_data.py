#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для добавления информации о платформе пользователя iPhone
"""

import os
import sys
import logging
from datetime import datetime

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Добавляем текущую директорию в путь
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from db_config import db, flask_app
from db_models import UserPlatform, User

# Константы из platform_detection_service.py
PLATFORM_UNKNOWN = "unknown"
PLATFORM_IOS = "ios"
PLATFORM_ANDROID = "android" 
PLATFORM_DESKTOP = "desktop"
PLATFORM_WEB = "web"

def add_ios_platform_info():
    """
    Добавляет информацию о платформе для пользователя iPhone
    """
    try:
        with flask_app.app_context():
            # Проверяем существование пользователя
            user_id = 852123125
            user = User.query.filter_by(id=user_id).first()
            
            if not user:
                logger.error(f"Пользователь с ID {user_id} не найден в базе данных")
                return False
                
            # Проверяем существование записи в таблице платформ
            platform_record = UserPlatform.query.filter_by(user_id=user_id).first()
            
            if platform_record:
                logger.info(f"Запись о платформе для пользователя {user_id} уже существует")
                # Обновляем данные
                platform_record.platform_type = PLATFORM_IOS
                platform_record.platform_version = "16.5"  # Усредненная версия iOS
                platform_record.device_model = "iPhone"
                platform_record.last_seen = datetime.now()
                logger.info(f"Обновлена информация о платформе для пользователя {user_id}")
            else:
                # Создаем новую запись
                platform_record = UserPlatform(
                    user_id=user_id,
                    platform_type=PLATFORM_IOS,
                    platform_version="16.5",  # Усредненная версия iOS
                    device_model="iPhone",
                    last_seen=datetime.now()
                )
                db.session.add(platform_record)
                logger.info(f"Добавлена информация о платформе для пользователя {user_id}")
            
            db.session.commit()
            logger.info(f"Успешно сохранена информация о платформе для пользователя {user_id}")
            return True
    except Exception as e:
        logger.error(f"Ошибка при добавлении информации о платформе: {e}")
        try:
            with flask_app.app_context():
                db.session.rollback()
        except:
            pass
        return False

def main():
    """
    Основная функция
    """
    logger.info("Запуск скрипта добавления информации о платформе для пользователя iPhone")
    result = add_ios_platform_info()
    
    if result:
        logger.info("Скрипт выполнен успешно")
    else:
        logger.error("Скрипт завершился с ошибкой")

if __name__ == "__main__":
    main()