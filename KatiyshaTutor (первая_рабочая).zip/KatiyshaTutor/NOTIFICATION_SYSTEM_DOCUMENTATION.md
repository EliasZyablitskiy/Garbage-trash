# Документация по системе уведомлений

## Обзор

Система уведомлений предоставляет унифицированный интерфейс для отправки различных типов уведомлений пользователям через Telegram бота. Система построена на основе классификации уведомлений по типам и поддерживает обратную совместимость со старыми шаблонами.

## Основные компоненты

1. **NotificationService** - основной класс для работы с уведомлениями
2. **NotificationType** - перечисление доступных типов уведомлений
3. **NotificationTemplates** - устаревшее перечисление шаблонов уведомлений (для обратной совместимости)

## Типы уведомлений

Система поддерживает следующие типы уведомлений:

| Тип уведомления | Описание | Ключевые поля контекста |
|----------------|----------|------------------------|
| PAYMENT_PENDING | Ожидание оплаты подписки | amount, subscription_type |
| PAYMENT_SUCCESSFUL | Успешная оплата подписки | subscription_end_date |
| PAYMENT_FAILED | Ошибка при оплате | reason |
| SUBSCRIPTION_EXPIRING | Подписка скоро истекает | days_left |
| SUBSCRIPTION_EXPIRED | Подписка истекла | - |
| REFERRAL_REWARD | Получено реферальное вознаграждение | amount, level, percent |
| PAYOUT_AVAILABLE | Доступна выплата реферального вознаграждения | amount |
| PAYOUT_PROCESSING | Выплата в обработке | amount, payout_id |
| PAYOUT_COMPLETED | Выплата успешно завершена | amount, payout_id, date |
| PAYOUT_FAILED | Ошибка при обработке выплаты | amount, payout_id, reason |
| SYSTEM | Системное уведомление | message |
| RECOVERY_ATTEMPT | Уведомление о восстановлении транзакции | transaction_id, status, reason |

## Как использовать

### Основной способ отправки уведомлений

```python
from services.notification_service import NotificationService, NotificationType

# Получаем экземпляр сервиса уведомлений
notification_service = NotificationService.get_instance(bot)

# Отправляем уведомление
await notification_service.send_notification(
    user_id=user_id,
    notification_type=NotificationType.PAYMENT_SUCCESSFUL,
    context={
        'subscription_end_date': '2025-06-07'
    }
)
```

### Обратная совместимость со старыми шаблонами

```python
from services.notification_service import NotificationService, NotificationTemplates

# Получаем экземпляр сервиса уведомлений
notification_service = NotificationService.get_instance(bot)

# Отправляем уведомление по старому шаблону
await notification_service.send_template(
    user_id=user_id,
    template=NotificationTemplates.PAYMENT_SUCCESS,
    context={
        'subscription_end_date': '2025-06-07'
    }
)
```

## Механизм работы

1. Метод `send_notification` принимает ID пользователя, тип уведомления и дополнительный контекст
2. Внутри метода вызывается `_format_notification` для форматирования текста уведомления на основе типа и контекста
3. Отформатированное сообщение отправляется пользователю через Telegram API
4. Метод `send_template` для обратной совместимости преобразует старый шаблон в новый тип уведомления и вызывает `send_notification`

## Дополнительные функциональные возможности

Система уведомлений также предоставляет методы для:

1. **notify_users_about_available_payouts** - уведомление пользователей о доступных выплатах
2. **notify_users_about_expiring_subscriptions** - уведомление пользователей об истекающих подписках
3. **log_admin_action** - логирование действий администраторов в базу данных

## Советы по использованию

1. Всегда используйте `NotificationService.get_instance()` для получения экземпляра сервиса
2. Предоставляйте осмысленный контекст с правильными ключами для каждого типа уведомления
3. Для новой разработки всегда используйте новый метод `send_notification` вместо `send_template`
4. При добавлении новых типов уведомлений, обновляйте перечисление `NotificationType` и метод `_format_notification`

## Логирование

Система уведомлений включает подробное логирование:
- Успешные отправки уведомлений логируются на уровне INFO
- Ошибки при отправке уведомлений логируются на уровне ERROR
- Неизвестные типы уведомлений логируются на уровне WARNING