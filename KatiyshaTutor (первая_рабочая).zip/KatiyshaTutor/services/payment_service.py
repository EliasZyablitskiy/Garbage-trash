#!/usr/bin/env python
# coding: utf-8

"""
Service for handling payment processing
Адаптирован для кросс-платформенной совместимости с различными клиентами
"""

import os
import logging
import hashlib
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Tuple
import aiohttp
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

import config
from services.db_service import get_user, update_user_subscription, add_transaction
from keyboards import get_main_keyboard
from services.platform_detection_service import get_user_platform, get_platform_from_update, store_user_platform, get_platform_compatibility_flags, PLATFORM_IOS, PLATFORM_ANDROID, PLATFORM_DESKTOP, PLATFORM_WEB, PLATFORM_UNKNOWN
from services.platform_data_service import get_payment_settings, get_platform_settings, get_emoji, get_message_format_settings, EMOJI_COMPATIBILITY

logger = logging.getLogger(__name__)

def is_subscription_active(user_data: Optional[Dict[str, Any]], platform_type: str = PLATFORM_UNKNOWN) -> bool:
    """Check if a user has an active subscription with platform-specific adaptations.
    
    Args:
        user_data: User data dictionary
        platform_type: The platform type (ios, android, desktop, web, unknown)
        
    Returns:
        bool: True if subscription is active, False otherwise
    """
    if not user_data:
        return False
    
    if 'subscription_expiry' not in user_data or not user_data['subscription_expiry']:
        return False
    
    try:
        expiry_date = datetime.fromisoformat(user_data['subscription_expiry'])
        now = datetime.now()
        
        # Стандартное поведение - проверка даты
        is_active = now < expiry_date
        
        # Платформо-зависимая логика
        if platform_type == PLATFORM_IOS:
            # Для iOS добавляем небольшой буфер времени (15 минут) для устранения возможных проблем синхронизации
            is_active = now < (expiry_date + timedelta(minutes=15))
            logger.debug(f"iOS platform subscription check with buffer: {is_active}")
        elif platform_type == PLATFORM_ANDROID:
            # Для Android стандартная проверка, но с логированием
            logger.debug(f"Android platform subscription check: {is_active}")
        elif platform_type == PLATFORM_DESKTOP:
            # Для Desktop стандартная проверка
            pass
        
        return is_active
    except (ValueError, TypeError) as e:
        logger.error(f"Error in is_subscription_active: {e}, platform: {platform_type}")
        return False

async def create_external_payment_link(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Create and send an external payment link for subscription using Robokassa iFrame
    Адаптирует платежную ссылку в соответствии с платформой пользователя
    
    Args:
        update: Telegram update object
        context: Telegram context object
    """
    # Получаем ID пользователя
    user_id = update.effective_user.id
    
    # Определяем платформу пользователя
    platform_info = get_platform_from_update(update)
    platform_type = platform_info.get("platform", PLATFORM_UNKNOWN)
    platform_version = platform_info.get("version")
    
    # Сохраняем информацию о платформе пользователя, если она определена
    if platform_type != PLATFORM_UNKNOWN:
        store_result = store_user_platform(user_id, platform_info)
        logger.debug(f"Platform info stored for user {user_id}: {platform_type} {platform_version}, result: {store_result}")
    
    # Получаем флаги совместимости для данной платформы
    compatibility_flags = get_platform_compatibility_flags(user_id)
    
    # Получаем настройки платежей для данной платформы
    payment_settings = get_payment_settings(platform_type, platform_version)
    
    # Получаем BASE_URL из окружения (URL веб-сервера)
    base_url = config.get_base_url()
    
    # Формируем URL нашей страницы оплаты с iframe Robokassa
    payment_url = f"{base_url}/payment/{user_id}"
    
    # Добавляем параметр для мобильного устройства, если необходимо
    if payment_settings.get("robokassa_mobile_param") == "true":
        payment_url += "?mobile=true"
    
    # Получаем эмодзи для платежа в соответствии с платформой
    payment_emoji = get_emoji("payment", platform_type)
    
    # Проверяем, поддерживает ли платформа кнопку subscribe
    supports_subscribe_button = compatibility_flags.get("supports_subscribe_button", True)
    
    # Создаем инлайн-клавиатуру с кнопкой для перехода на страницу оплаты,
    # но только если платформа поддерживает кнопку subscribe
    keyboard_buttons = []
    
    if supports_subscribe_button:
        keyboard_buttons.append([InlineKeyboardButton(f"{payment_emoji} Оплатить 199₽", url=payment_url)])
    
    # В любом случае добавляем кнопку для ручной активации
    keyboard_buttons.append([InlineKeyboardButton("✅ Активировать подписку", callback_data="manual_activate")])
    
    keyboard = InlineKeyboardMarkup(keyboard_buttons)
    
    # Адаптируем сообщение для платформы
    if supports_subscribe_button:
        message = (
            "Для оплаты подписки нажмите на кнопку ниже. "
            "После успешной оплаты подписка должна активироваться автоматически.\n\n"
            "Если этого не произошло, отправьте команду /activate_subscription, "
            "чтобы активировать подписку вручную."
        )
    else:
        # Для Android и других платформ, которые не поддерживают кнопку subscribe
        message = (
            "Для оплаты подписки скопируйте ссылку ниже и откройте её в браузере:\n\n"
            f"{payment_url}\n\n"
            "После успешной оплаты вернитесь в бот и нажмите на кнопку 'Активировать подписку' "
            "или отправьте команду /activate_subscription."
        )
    
    # Получаем форматированное сообщение для конкретной платформы
    from services.platform_data_service import adapt_message_for_platform
    adapted_message = adapt_message_for_platform(message, platform_type, platform_version)
    
    await update.effective_message.reply_text(
        adapted_message,
        reply_markup=keyboard
    )
    
    # Сохраняем информацию о запросе платежа
    payment_info = {
        "platform_type": platform_type,
        "platform_version": platform_version,
        "payment_url": payment_url,
        "timestamp": datetime.now().isoformat()
    }
    
    try:
        # Создаем запись о транзакции для отслеживания намерения оплаты
        notes = f"Создана платежная ссылка. Платформа: {platform_type}, версия: {platform_version}"
        if not supports_subscribe_button:
            notes += ", не поддерживает кнопку subscribe"
            
        add_transaction(
            transaction_type="payment_link_created",
            user_id=user_id,
            amount=199.0,
            description=f"Создана платежная ссылка (платформа: {platform_type})",
            status="pending",
            payment_data=payment_info,
            notes=notes
        )
    except Exception as e:
        logger.error(f"Ошибка при создании записи о транзакции: {e}")
    
    logger.debug(f"Отправлена ссылка на оплату через iFrame пользователю {user_id} с URL: {payment_url}, платформа: {platform_type} {platform_version}")

async def create_manual_activation(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Создание кнопки для ручной активации подписки
    Адаптировано для разных платформ с учетом совместимости
    
    Args:
        update: Telegram update object
        context: Telegram context object
    """
    user_id = update.effective_user.id
    
    # Определяем платформу пользователя
    platform_info = get_platform_from_update(update)
    platform_type = platform_info.get("platform", PLATFORM_UNKNOWN)
    platform_version = platform_info.get("version")
    
    # Сохраняем информацию о платформе пользователя, если она определена
    if platform_type != PLATFORM_UNKNOWN:
        store_result = store_user_platform(user_id, platform_info)
        logger.debug(f"Platform info stored for user {user_id}: {platform_type} {platform_version}, result: {store_result}")
    
    # Получаем флаги совместимости для данной платформы
    compatibility_flags = get_platform_compatibility_flags(user_id)
    
    # Получаем настройки платежей и форматирования для данной платформы
    payment_settings = get_payment_settings(platform_type, platform_version)
    format_settings = get_message_format_settings(platform_type, platform_version)
    
    # Проверяем, есть ли уже подписка
    user_data = get_user(user_id)
    if user_data and 'subscription_expiry' in user_data and user_data['subscription_expiry']:
        try:
            expiry_date = datetime.fromisoformat(user_data['subscription_expiry'])
            if datetime.now() < expiry_date:
                # Используем адаптацию для платформы
                message = (
                    f"✅ У вас уже есть *активная подписка* до {expiry_date.strftime('%d.%m.%Y')}.\n\n"
                    "Вы можете продолжать пользоваться всеми функциями бота Катюша!"
                )
                
                from services.platform_data_service import adapt_message_for_platform
                adapted_message = adapt_message_for_platform(message, platform_type, platform_version)
                
                # Используем соответствующий метод форматирования для платформы
                parse_mode = format_settings.get("preferred", "Markdown")
                
                await update.message.reply_text(
                    adapted_message,
                    reply_markup=get_main_keyboard(),
                    parse_mode=parse_mode
                )
                return
        except Exception as e:
            logger.error(f"Error checking subscription: {e}")
    
    # Получение платежной ссылки Robokassa с учетом мобильной платформы
    payment_url = "https://telegrampay.robokassa.ru/Pay/19296?culture=ru"
    
    # Добавляем параметр для мобильного устройства, если необходимо
    if payment_settings.get("robokassa_mobile_param") == "true":
        payment_url += "&mobile=true"
    
    # Получаем эмодзи, оптимизированные для платформы
    payment_emoji = get_emoji("payment", platform_type)
    check_emoji = get_emoji("success", platform_type)
    
    # Проверяем поддержку различных элементов интерфейса
    supports_subscribe_button = compatibility_flags.get("supports_subscribe_button", True)
    
    # Создаем кнопки в зависимости от совместимости платформы
    keyboard_buttons = []
    
    # Добавляем кнопку оплаты только если платформа поддерживает кнопку subscribe
    if supports_subscribe_button:
        keyboard_buttons.append([InlineKeyboardButton(f"{payment_emoji} Оплатить через СБП", url=payment_url)])
    else:
        # Для Android предоставляем текстовую инструкцию вместо кнопки
        logger.info(f"Using text-based payment instructions for user {user_id} on platform {platform_type}")
    
    # Кнопка QR-кода отключена - функциональность удалена
    logger.debug(f"QR-код отключен для пользователя {user_id} - используется только прямая оплата")
    
    # Кнопка активации - общая для всех платформ
    keyboard_buttons.append([InlineKeyboardButton(f"{check_emoji} Активировать подписку после оплаты", callback_data="manual_activate")])
    
    keyboard = InlineKeyboardMarkup(keyboard_buttons)
    
    # Формируем основное сообщение с учетом поддержки платформы
    message = (
        "🔐 *Покупка подписки на бот Катюша* 🔐\n\n"
        "Стоимость подписки: *199₽ за 1 месяц*\n\n"
    )
    
    # Разные инструкции в зависимости от поддержки кнопки subscribe
    if supports_subscribe_button:
        message += "1️⃣ Выберите удобный способ оплаты:\n"
        message += "• Нажмите кнопку *Оплатить через СБП* для оплаты по ссылке\n"
    else:
        # Для Android и других платформ, которые не поддерживают subscribe_button
        message += "⚠️ Обнаружены ограничения на вашем устройстве ⚠️\n\n"
        message += f"1️⃣ Для оплаты используйте следующую ссылку:\n{payment_url}\n\n"
        message += "2️⃣ Инструкция по оплате:\n"
        message += "• Скопируйте ссылку и откройте её в браузере\n"
        message += "• Выполните оплату через СБП или банковской картой\n"
        message += "• После оплаты вернитесь в бот и нажмите кнопку 'Активировать подписку'\n\n"
    
    # Информация о QR-кодах удалена
    message += "\n"
    
    message += (
        "2️⃣ После оплаты вернитесь в бот и нажмите *Активировать подписку после оплаты*\n\n"
        "✨ Подписка дает неограниченный доступ ко всем функциям бота:\n"
        "• Решение математических задач с подробным объяснением\n"
        "• Распознавание и обработка фотографий с заданиями\n"
        "• Обработка голосовых сообщений с задачами\n\n"
        "_Активируя подписку, вы подтверждаете, что произвели оплату. Активация без оплаты является нарушением правил._"
    )
    
    # Адаптируем сообщение для конкретной платформы
    from services.platform_data_service import adapt_message_for_platform
    adapted_message = adapt_message_for_platform(message, platform_type, platform_version)
    
    # Используем соответствующий метод форматирования для платформы
    parse_mode = format_settings.get("preferred", "Markdown")
    
    await update.effective_message.reply_text(
        adapted_message,
        reply_markup=keyboard,
        parse_mode=parse_mode
    )
    
    # Логируем информацию о платформе в контексте платежа
    logger.debug(f"Отправлено предложение по оплате подписки пользователю {user_id} (платформа: {platform_type} {platform_version})")

def generate_robokassa_signature(merchant_login: str, outsum: float, inv_id: int, 
                                secret_key: str, user_id: int) -> str:
    """
    Generate a signature for Robokassa payment request
    
    Args:
        merchant_login: Robokassa merchant login
        outsum: Payment amount
        inv_id: Invoice ID
        secret_key: Secret key for Robokassa
        user_id: User ID to include in signature
        
    Returns:
        str: Generated signature
    """
    signature_str = f"{merchant_login}:{outsum}:{inv_id}:{secret_key}:Shp_user={user_id}"
    return hashlib.md5(signature_str.encode()).hexdigest()

def verify_robokassa_signature(inv_id: str, outsum: str, signature: str, 
                              user_id: str) -> bool:
    """
    Verify the signature from Robokassa payment notification
    
    Args:
        inv_id: Invoice ID from notification
        outsum: Payment amount from notification
        signature: Signature from notification
        user_id: User ID from notification
        
    Returns:
        bool: True if signature is valid, False otherwise
    """
    # Получаем секретный ключ №2 (для уведомлений о платежах)
    secret_key = config.ROBOKASSA_SECRET_KEY
    
    # Формируем строку для проверки подписи
    check_str = f"{outsum}:{inv_id}:{secret_key}:Shp_user={user_id}"
    
    # Формируем контрольную подпись
    check_signature = hashlib.md5(check_str.encode()).hexdigest().lower()
    
    # Логируем детали проверки для отладки (без отображения секретного ключа)
    logger.debug(f"Verifying signature for inv_id={inv_id}, outsum={outsum}, user_id={user_id}")
    logger.debug(f"Expected signature: {check_signature}, received: {signature.lower()}")
    
    # Сравниваем подписи (не учитывая регистр)
    return check_signature == signature.lower()

def verify_payment_notification(notification_data: Dict[str, Any], payment_system: str) -> bool:
    """
    Проверяет подпись уведомления от платежной системы через унифицированный сервис верификации
    
    Args:
        notification_data: Данные уведомления
        payment_system: Идентификатор платежной системы (например, 'robokassa', 'sbp')
        
    Returns:
        bool: True если проверка успешна, False в противном случае
    """
    try:
        from services.payment_verification_service_v2 import payment_verification_service_v2, PAYMENT_SYSTEMS
        
        # Определяем правильный ID платежной системы для verification_service
        if payment_system.lower() == 'robokassa':
            system_id = PAYMENT_SYSTEMS['ROBOKASSA']
        elif payment_system.lower() == 'sbp':
            system_id = PAYMENT_SYSTEMS['SBP_LINK']
        elif payment_system.lower() == 'yoomoney':
            system_id = PAYMENT_SYSTEMS['YOOMONEY']
        else:
            logger.error(f"Неизвестная платежная система: {payment_system}")
            return False
        
        # Проверяем уведомление через сервис верификации
        payment_result = payment_verification_service_v2.verify_payment_unified(
            notification_data=notification_data,
            payment_system=system_id
        )
        
        logger.info(f"Результат проверки от verification_service: success={payment_result.success}, " 
                   f"code={payment_result.result_code.name if payment_result.result_code else 'None'}, "
                   f"message={payment_result.message}")
        
        return payment_result.success
    
    except Exception as e:
        logger.error(f"Ошибка при проверке уведомления через verification_service: {str(e)}", exc_info=True)
        
        # В случае ошибки используем прямую проверку для Robokassa
        if payment_system.lower() == 'robokassa' and 'InvId' in notification_data and 'OutSum' in notification_data and 'SignatureValue' in notification_data and 'Shp_user' in notification_data:
            return verify_robokassa_signature(
                inv_id=notification_data['InvId'],
                outsum=notification_data['OutSum'],
                signature=notification_data['SignatureValue'],
                user_id=notification_data['Shp_user']
            )
        
        return False


def generate_payment_link(payment_url: str, user_id: int) -> Optional[str]:
    """
    Подготавливает платежную ссылку для пользователя
    
    Args:
        payment_url: URL для платежного сервиса
        user_id: ID пользователя
        
    Returns:
        str: Платежная ссылка или None в случае ошибки
    """
    try:
        # Добавляем метку пользователя к ссылке для отслеживания
        if '?' in payment_url:
            payment_url += f"&user_id={user_id}"
        else:
            payment_url += f"?user_id={user_id}"
        
        # Добавляем временную метку
        current_time = datetime.now().strftime('%Y%m%d%H%M%S')
        payment_url += f"&t={current_time}"
        
        logger.info(f"Платёжная ссылка создана для пользователя {user_id}")
        return payment_url
    except Exception as e:
        logger.error(f"Ошибка при создании платежной ссылки: {e}")
        return None


async def send_direct_payment_info(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Отправляет информацию о прямой оплате через СБП
    
    Args:
        update: Telegram update object
        context: Telegram context object
    """
    # Импортируем зависимости для корректной обработки сообщений
    from services.message_formatter_service import format_adaptive_message
    
    user_id = update.effective_user.id
    
    # Определяем платформу пользователя
    platform_info = get_platform_from_update(update)
    platform_type = platform_info.get("platform", PLATFORM_UNKNOWN)
    platform_version = platform_info.get("version")
    
    # Сохраняем информацию о платформе пользователя
    if platform_type != PLATFORM_UNKNOWN:
        store_result = store_user_platform(user_id, platform_info)
        logger.debug(f"Platform info stored for user {user_id}: {platform_type} {platform_version}, result: {store_result}")
    
    # Получаем настройки для данной платформы
    payment_settings = get_payment_settings(platform_type, platform_version)
    format_settings = get_message_format_settings(platform_type, platform_version)
    
    # Получаем эмодзи, оптимизированные для платформы
    payment_emoji = get_emoji("payment", platform_type)
    check_emoji = get_emoji("success", platform_type)
    bank_emoji = get_emoji("bank", platform_type)
    card_emoji = get_emoji("card", platform_type)
    help_emoji = get_emoji("help", platform_type)
    
    # Получаем флаги совместимости для пользователя
    compatibility_flags = get_platform_compatibility_flags(user_id)
    
    # Проверяем поддержку платформой различных функций
    supports_subscribe_button = compatibility_flags.get("supports_subscribe_button", True)
    
    # Проверяем, является ли это проблемным устройством iOS
    problematic_ios_device = platform_type == PLATFORM_IOS and is_problematic_ios(platform_version)
    
    # URL для оплаты через СБП
    payment_url = "https://telegrampay.robokassa.ru/Pay/19296?culture=ru"
    
    # Добавляем параметр для мобильного устройства, если необходимо
    if payment_settings.get("robokassa_mobile_param") == "true":
        payment_url += "&mobile=true"
    
    # Формируем клавиатуру с основными кнопками оплаты
    keyboard_buttons = []
    
    # Добавляем кнопку оплаты только если платформа поддерживает кнопки subscribe
    if supports_subscribe_button:
        keyboard_buttons.append([InlineKeyboardButton(f"{payment_emoji} Оплатить через СБП", url=payment_url)])
    else:
        # Для устройств без поддержки subscribe, предоставляем текстовые инструкции
        logger.info(f"Using text-based payment instructions for user {user_id} on platform {platform_type}")
    
    # Для всех пользователей добавляем альтернативные способы оплаты
    keyboard_buttons.append([
        InlineKeyboardButton(f"{bank_emoji} Оплата картой", url=f"{payment_url}&method=card")
    ])
    
    # Для iOS 16.5 добавляем дополнительную кнопку с прямой ссылкой на оплату
    if platform_type == PLATFORM_IOS and platform_version == "16.5":
        keyboard_buttons.append([
            InlineKeyboardButton(f"📱 Прямая оплата (iOS 16.5)", url=f"{payment_url}&ios=true")
        ])
    
    # Добавляем кнопку активации подписки после оплаты
    keyboard_buttons.append([
        InlineKeyboardButton(f"{check_emoji} Активировать подписку после оплаты", callback_data="manual_activate")
    ])
    
    # Добавляем кнопку помощи с оплатой для всех платформ
    keyboard_buttons.append([
        InlineKeyboardButton(f"{help_emoji} Помощь с оплатой", callback_data="payment_help")
    ])
    
    # Формируем клавиатуру из кнопок
    keyboard = InlineKeyboardMarkup(keyboard_buttons)
    
    # Используем соответствующий метод форматирования для платформы
    parse_mode = format_settings.get("preferred", "Markdown")
    
    # Формируем сообщение о прямой оплате
    payment_message = "🔐 *Оплата подписки* 🔐\n\n" + \
        "Стоимость подписки: *199₽ за 1 месяц*\n\n" + \
        "Для оплаты подписки:\n" + \
        "1️⃣ Нажмите кнопку *Оплатить через СБП* или *Оплата картой* ниже\n" + \
        "2️⃣ Выполните оплату в открывшемся окне\n" + \
        "3️⃣ Вернитесь в бот и нажмите *Активировать подписку после оплаты*\n\n" + \
        "_Активируя подписку, вы подтверждаете, что произвели оплату._"
    
    # Для iOS 16.5 и других проблемных устройств добавляем специальную инструкцию
    if platform_type == PLATFORM_IOS and problematic_ios_device:
        special_instructions = "\n*Для пользователей iOS 16.5:*\n" + \
            "Если у вас возникают проблемы с оплатой, используйте кнопку 'Прямая оплата (iOS 16.5)'."
        payment_message += special_instructions
    
    # Адаптируем сообщение для конкретной платформы
    adapted_message = format_adaptive_message(payment_message, platform_type, platform_version)
    
    # Отправляем информацию о прямой оплате
    await update.effective_message.reply_text(
        adapted_message,
        reply_markup=keyboard,
        parse_mode=parse_mode
    )
    
    # Записываем информацию о транзакции для аналитики
    try:
        add_transaction(
            transaction_type="subscription_intent",
            user_id=user_id,
            amount=199.0,
            description=f"Намерение оплаты подписки через прямую оплату (платформа: {platform_type})",
            status="pending",
            payment_data={
                "payment_method": "direct_link",
                "payment_url": payment_url,
                "platform_type": platform_type, 
                "platform_version": platform_version,
                "timestamp": datetime.now().isoformat()
            }
        )
    except Exception as e:
        logger.error(f"Ошибка при создании записи о транзакции: {e}")
        return
    
    # Добавляем информацию о транзакции
    try:
        # Создаем запись о транзакции (не об оплате!) - для отслеживания
        add_transaction(
            transaction_type="subscription_intent",
            user_id=user_id,
            amount=199.0,
            description=f"Намерение оплаты подписки через прямую оплату (платформа: {platform_type})",
            status="pending",
            payment_data={
                "payment_method": "direct_link",
                "payment_url": payment_url,
                "platform_type": platform_type, 
                "platform_version": platform_version,
                "timestamp": datetime.now().isoformat()
            }
        )
    except Exception as e:
        logger.error(f"Ошибка при создании записи о транзакции: {e}")
        
    # Отправляем пользователю подтверждение об успешном создании платежной ссылки
    success_message = "✅ *Успешно!* Информация о способах оплаты отправлена.\n\n" + \
        "После оплаты не забудьте вернуться в бот и нажать кнопку _Активировать подписку после оплаты_."
    
    # Адаптируем сообщение для конкретной платформы
    adapted_success = format_adaptive_message(success_message, platform_type, platform_version)
    
    # Используем соответствующий метод форматирования для платформы
    parse_mode = format_settings.get("preferred", "Markdown")
    
    # Отправляем подтверждение пользователю
    try:
        await context.bot.send_message(
            chat_id=user_id,
            text=adapted_success,
            parse_mode=parse_mode
        )
        logger.info(f"Пользователю {user_id} отправлено подтверждение об отправке платежной информации")
    except Exception as e:
        logger.error(f"Ошибка при отправке подтверждения: {e}")
    

def is_problematic_ios(platform_version: Optional[str]) -> bool:
    """
    Проверяет, является ли версия iOS проблемной для оплаты
    
    Args:
        platform_version: Строка с версией iOS
        
    Returns:
        bool: True если версия iOS считается проблемной для платёжного интерфейса, False в противном случае
    """
    if not platform_version:
        return False
    
    try:
        # Разбиваем версию на основную и дополнительную части
        version_parts = platform_version.split('.')
        if not version_parts[0].isdigit():
            return False
            
        major_version = int(version_parts[0])
        
        # Известные проблемные версии iOS для QR-кодов:
        # 1. iOS < 11 - старые устройства с проблемным сканированием QR
        # 2. Определенные версии iOS 13, которые имели баги с камерой
        # 3. Некоторые версии iOS 16 также имеют проблемы со сканированием QR через Telegram
        if major_version < 11:
            return True
            
        # Проблемы наблюдались в ранних версиях iOS 13
        if major_version == 13 and len(version_parts) > 1:
            if version_parts[1].isdigit() and int(version_parts[1]) < 4:
                return True
        
        # Проблемы со сканированием QR в Telegram для некоторых версий iOS 16
        if major_version == 16 and len(version_parts) > 1:
            if version_parts[1].isdigit() and int(version_parts[1]) in [5, 6]:
                return True
                
        return False
    except Exception:
        # В случае ошибки парсинга, возвращаем False
        return False


def get_platform_aware_subscription_status(user_id: int, user_data: Optional[Dict[str, Any]] = None) -> bool:
    """Проверяет статус подписки пользователя с учетом его платформы.
    
    Args:
        user_id: ID пользователя
        user_data: Данные пользователя (если уже загружены)
        
    Returns:
        bool: True если подписка активна, False если нет
    """
    if user_data is None:
        user_data = get_user(user_id)
    
    # Получаем информацию о платформе пользователя
    try:
        from db_models import UserPlatform, db
        
        platform_info = UserPlatform.query.filter_by(user_id=user_id).order_by(
            UserPlatform.last_seen.desc()
        ).first()
        
        platform_type = PLATFORM_UNKNOWN
        if platform_info:
            platform_type = platform_info.platform_type
            logger.debug(f"Platform detected for user {user_id}: {platform_type}")
        
        # Проверяем статус подписки с учетом платформы
        return is_subscription_active(user_data, platform_type)
    except Exception as e:
        logger.error(f"Error getting platform-aware subscription status: {e}")
        # В случае ошибки используем стандартную проверку
        return is_subscription_active(user_data)
    # Лог-сообщение о QR-коде удалено, так как функциональность QR-кодов больше не используется