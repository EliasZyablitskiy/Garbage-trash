-- Database Backup created on 2025-05-02T11:00:10.276145
-- Database: neondb
-- Type: Schema only
-- Created by Katiysha Bot Backup Script

