#!/usr/bin/env python3
# show_routes.py
from flask import url_for
from db_config import get_flask_app
import urllib.parse

def list_routes():
    """Lists all available routes in the Flask app"""
    app = get_flask_app()
    output = []
    
    with app.test_request_context():
        for rule in app.url_map.iter_rules():
            options = {}
            for arg in rule.arguments:
                options[arg] = f"[{arg}]"
            
            url = url_for(rule.endpoint, **options)
            line = f"{rule.endpoint:50s} {url}"
            output.append(line)
    
    return sorted(output)

if __name__ == "__main__":
    print("Available routes:")
    for route in list_routes():
        print(route)