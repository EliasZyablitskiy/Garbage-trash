#!/usr/bin/env python
# coding: utf-8

"""
Сервис для очистки временных файлов
Обеспечивает автоматическую очистку старых временных файлов
"""

import os
import time
import logging
from logging.handlers import RotatingFileHandler
import schedule
from typing import List, Optional

# Настройка оптимизированного логирования
logger = logging.getLogger(__name__)

# Определяем уровень логирования в зависимости от среды
is_production = os.environ.get('ENVIRONMENT') == 'production'
log_level = logging.INFO if is_production else logging.DEBUG
logger.setLevel(log_level)

# Создаем обработчик для вывода в консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(log_level)

# Создаем обработчик для ротации файлов логов
log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')
os.makedirs(log_dir, exist_ok=True)
file_handler = RotatingFileHandler(
    os.path.join(log_dir, 'cleanup_service.log'),
    maxBytes=10*1024*1024,  # 10 МБ
    backupCount=5
)
file_handler.setLevel(log_level)

# Определяем формат сообщений
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)

# Добавляем обработчики к логгеру
logger.addHandler(console_handler)
logger.addHandler(file_handler)

# Пути к директориям с временными файлами
DEFAULT_TEMP_DIRS = [
    'temp_images',
    'temp_voices'
]

def cleanup_old_files(temp_dir: str, max_age_hours: int = 24, file_extensions: Optional[List[str]] = None) -> int:
    """
    Удаляет временные файлы старше указанного возраста
    
    Args:
        temp_dir: Путь к директории с временными файлами
        max_age_hours: Максимальный возраст файлов в часах
        file_extensions: Список расширений файлов для удаления (None для всех файлов)
        
    Returns:
        int: Количество удаленных файлов
    """
    try:
        if not os.path.exists(temp_dir):
            logger.warning(f"Directory {temp_dir} does not exist, skipping cleanup")
            return 0
            
        now = time.time()
        max_age_seconds = max_age_hours * 3600
        removed_count = 0
        
        logger.info(f"Cleaning up files in {temp_dir} older than {max_age_hours} hours")
        
        for filename in os.listdir(temp_dir):
            file_path = os.path.join(temp_dir, filename)
            
            # Проверяем, что это файл и он старше max_age_hours
            if os.path.isfile(file_path):
                # Проверяем расширение, если указано
                if file_extensions:
                    extension = os.path.splitext(filename)[1].lower()
                    if extension not in file_extensions:
                        continue
                        
                # Проверяем возраст файла
                file_age = now - os.path.getmtime(file_path)
                if file_age > max_age_seconds:
                    try:
                        os.unlink(file_path)
                        removed_count += 1
                        logger.debug(f"Removed old file: {file_path}")
                    except Exception as e:
                        logger.error(f"Error removing file {file_path}: {e}")
        
        logger.info(f"Cleanup complete. Removed {removed_count} files from {temp_dir}")
        return removed_count
        
    except Exception as e:
        logger.error(f"Error during cleanup of {temp_dir}: {e}")
        return 0

def cleanup_all_temp_directories(max_age_hours: int = 24) -> None:
    """
    Очищает все временные директории
    
    Args:
        max_age_hours: Максимальный возраст файлов в часах
    """
    logger.info(f"Starting cleanup of all temporary directories (max age: {max_age_hours} hours)")
    
    total_removed = 0
    for temp_dir in DEFAULT_TEMP_DIRS:
        # Получаем полный путь (относительно корня проекта)
        full_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), temp_dir)
        
        # Определяем расширения файлов для каждой директории
        if 'temp_images' in temp_dir:
            extensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp']
        elif 'temp_voices' in temp_dir:
            extensions = ['.ogg', '.oga', '.wav', '.mp3', '.m4a']
        # temp_qr больше не используется, так как мы перешли на прямые СБП-платежи
        else:
            extensions = None
            
        # Очищаем директорию
        removed = cleanup_old_files(full_path, max_age_hours, extensions)
        total_removed += removed
        
    logger.info(f"Total files removed: {total_removed}")

def schedule_daily_cleanup(hour: int = 3, minute: int = 0, max_age_hours: int = 24) -> None:
    """
    Планирует ежедневную очистку временных файлов
    
    Args:
        hour: Час для запуска очистки (0-23)
        minute: Минута для запуска очистки (0-59)
        max_age_hours: Максимальный возраст файлов в часах
    """
    logger.info(f"Scheduling daily cleanup at {hour:02d}:{minute:02d}")
    
    # Планируем ежедневную очистку в указанное время
    schedule.every().day.at(f"{hour:02d}:{minute:02d}").do(
        cleanup_all_temp_directories, 
        max_age_hours=max_age_hours
    )
    
    logger.info("Cleanup scheduler initialized")

# Функции для удобного запуска по требованию

def run_cleanup_now(max_age_hours: int = 24) -> None:
    """
    Запускает очистку временных файлов немедленно
    
    Args:
        max_age_hours: Максимальный возраст файлов в часах
    """
    logger.info("Running immediate cleanup")
    cleanup_all_temp_directories(max_age_hours)