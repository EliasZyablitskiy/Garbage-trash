#!/usr/bin/env python
# coding: utf-8

"""
Service for extracting text from images using Free Online OCR API
"""

import os
import base64
import logging
import aiohttp
import config
import pytesseract
from PIL import Image

# Настройка оптимизированного логирования
import os
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)

# Определяем уровень логирования в зависимости от среды
is_production = os.environ.get('ENVIRONMENT') == 'production'
log_level = logging.INFO if is_production else logging.DEBUG
logger.setLevel(log_level)

# Создаем обработчик для вывода в консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(log_level)

# Создаем обработчик для ротации файлов логов (10 МБ, макс. 5 файлов)
log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')
os.makedirs(log_dir, exist_ok=True)
file_handler = RotatingFileHandler(
    os.path.join(log_dir, 'ocr_service.log'),
    maxBytes=10*1024*1024,  # 10 МБ
    backupCount=5
)
file_handler.setLevel(log_level)

# Определяем формат сообщений
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)

# Добавляем обработчики к логгеру
logger.addHandler(console_handler)
logger.addHandler(file_handler)

# API конфигурация для Free Online OCR API
OCR_API_URL = config.OCR_API_URL
OCR_API_KEY = config.OCR_API_KEY

async def extract_text_from_image(image_path: str, language: str = None) -> str:
    """
    Extract text from an image using Free Online OCR API
    
    Args:
        image_path: Path to the image file
        language: Язык для распознавания (если None, определяется автоматически)
        
    Returns:
        str: The extracted text from the image
    """
    logger.info(f"Extracting text from image: {image_path}")
    
    try:
        # Кодируем изображение в base64
        with open(image_path, "rb") as img_file:
            base64_image = base64.b64encode(img_file.read()).decode('utf-8')
        
        # Определяем язык для распознавания если он не указан
        if language is None:
            from services.language_detection import get_ocr_language_code
            language = get_ocr_language_code()
            logger.info(f"Automatically selected OCR language: {language}")
        
        # Параметры запроса к OCR API
        headers = {
            "Content-Type": "application/json",
            "apikey": OCR_API_KEY
        }
        
        payload = {
            "base64Image": base64_image,
            "language": language
        }
        
        # Отправляем запрос к API
        async with aiohttp.ClientSession() as session:
            async with session.post(OCR_API_URL, headers=headers, json=payload) as response:
                if response.status != 200:
                    logger.error(f"OCR API error: {response.status} - {await response.text()}")
                    return await fallback_ocr(image_path, language)
                
                response_data = await response.json()
                extracted_text = response_data.get("text", "")
                
                if not extracted_text:
                    logger.warning("Empty text extracted by OCR API")
                    return await fallback_ocr(image_path, language)
                
                # Пробуем определить язык по полученному тексту для будущих запросов
                try:
                    from services.language_detection import detect_language
                    detected_lang, confidence = detect_language(extracted_text[:200])
                    logger.info(f"Detected language from OCR result: {detected_lang} (confidence: {confidence:.2f})")
                except Exception as e:
                    logger.error(f"Error detecting language from OCR result: {e}")
                
                return extracted_text
                
    except Exception as e:
        logger.error(f"Error extracting text from image: {e}")
        return await fallback_ocr(image_path, language)

async def fallback_ocr(image_path: str, language: str = 'rus') -> str:
    """
    Fallback OCR method using pytesseract if available
    
    Args:
        image_path: Path to the image file
        language: Язык для распознавания (по умолчанию русский)
        
    Returns:
        str: The extracted text or empty string if fails
    """
    logger.info(f"Using fallback OCR (pytesseract) with language: {language}")
    
    try:
        # Используем pytesseract как резервный метод OCR
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img, lang=language)
        return text if text else "Не удалось распознать текст на изображении."
    except Exception as e:
        logger.error(f"Fallback OCR error: {e}")
        return "Не удалось распознать текст на изображении."