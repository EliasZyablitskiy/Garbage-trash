#!/bin/bash

# Запуск тестов в Docker-контейнере

# Создаем директорию для отчетов
mkdir -p test-reports

# Цвета для вывода
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Запуск тестов в Docker-контейнере...${NC}"

# Собираем образ и запускаем контейнер
docker-compose -f docker-compose.test.yml build && \
docker-compose -f docker-compose.test.yml up --abort-on-container-exit

# Проверяем результат
if [ $? -eq 0 ]; then
    echo -e "${GREEN}Тесты завершены успешно!${NC}"
    exit 0
else
    echo -e "${RED}Тесты завершены с ошибками!${NC}"
    exit 1
fi 