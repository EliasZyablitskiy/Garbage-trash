"""
Обработчики административных команд для мониторинга платежей
"""
import logging
import json
import os
import io
import matplotlib.pyplot as plt
import matplotlib
import datetime
from typing import Dict, List, Tuple, Any, Optional, Union, cast
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from services.payment_monitoring_service import PaymentMonitoringService
from db_config import async_session_maker
from db_models import Transaction

# Задаем стиль для matplotlib (без графического интерфейса)
matplotlib.use('Agg')

logger = logging.getLogger(__name__)

# Словарь статических обработчиков callback-данных
payment_stats_handlers = {}

# Словарь шаблонов callback-данных для динамических обработчиков
payment_stats_patterns = {}

def register_handler(callback_data: str):
    """
    Декоратор для регистрации обработчиков callback-данных
    
    Args:
        callback_data: Строка callback_data, для которой регистрируется обработчик
    """
    def decorator(func):
        payment_stats_handlers[callback_data] = func
        return func
    return decorator

def register_pattern(pattern: str):
    """
    Декоратор для регистрации шаблонов callback-данных
    
    Args:
        pattern: Шаблон начала callback_data, для которой регистрируется обработчик
    """
    def decorator(func):
        payment_stats_patterns[pattern] = func
        return func
    return decorator

def is_admin(user_id: int) -> bool:
    """
    Проверка, является ли пользователь администратором
    
    Args:
        user_id: ID пользователя для проверки
        
    Returns:
        bool: True, если пользователь администратор, False в противном случае
    """
    admin_ids = os.environ.get('ADMIN_IDS', '').split(',')
    try:
        admin_ids = [int(admin_id.strip()) for admin_id in admin_ids if admin_id.strip()]
        return user_id in admin_ids
    except (ValueError, TypeError):
        logger.error(f"Ошибка при проверке администратора {user_id}: неверный формат ADMIN_IDS")
        return False

@register_handler('admin_payment_stats')
async def admin_payment_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения меню статистики платежей
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    if not query:
        return
    
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text(
            "У вас нет прав доступа к этому разделу."
        )
        return
    
    keyboard = [
        [
            InlineKeyboardButton("Общая статистика", callback_data='payment_general_stats'),
            InlineKeyboardButton("Проблемные платежи", callback_data='payment_problem_stats')
        ],
        [
            InlineKeyboardButton("История платежей", callback_data='payment_history'),
            InlineKeyboardButton("Графики платежей", callback_data='payment_charts')
        ],
        [
            InlineKeyboardButton("Назад", callback_data='admin_back')
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        "📊 *Статистика платежей*\n\n"
        "Выберите раздел для просмотра информации о платежах:",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

@register_handler('payment_general_stats')
async def payment_general_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения общей статистики платежей
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    if not query:
        return
    
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text(
            "У вас нет прав доступа к этому разделу."
        )
        return
    
    # Получаем период из контекста или используем значение по умолчанию
    days = context.user_data.get('payment_stats_days', 30)
    
    # Получаем статистику платежей
    async with async_session_maker() as session:
        statistics = await PaymentMonitoringService.get_payment_statistics(session, days=days)
    
    # Форматируем вывод статистики
    stats_text = (
        f"📊 *Статистика платежей за {days} дней*\n\n"
        f"*Общая информация:*\n"
        f"• Всего транзакций: {statistics['total_transactions']}\n"
        f"• Успешных платежей: {statistics['successful_transactions']}\n"
        f"• Неудачных платежей: {statistics['failed_transactions']}\n"
        f"• Ожидающих платежей: {statistics['pending_transactions']}\n"
        f"• Конверсия платежей: {statistics['conversion_rate']}%\n\n"
    )
    
    # Добавляем статистику по платежным системам
    stats_text += "*Статистика по платежным системам:*\n"
    payment_systems = statistics.get('payment_systems', {})
    if payment_systems:
        for payment_system, count in payment_systems.items():
            if payment_system:
                stats_text += f"• {payment_system}: {count} платежей\n"
    else:
        stats_text += "• Нет данных о платежных системах\n"
    
    # Кнопки для выбора периода
    keyboard = [
        [
            InlineKeyboardButton("7 дней", callback_data='payment_period_7'),
            InlineKeyboardButton("30 дней", callback_data='payment_period_30'),
            InlineKeyboardButton("90 дней", callback_data='payment_period_90'),
        ],
        [
            InlineKeyboardButton("Назад", callback_data='admin_payment_stats')
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        stats_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

@register_handler('payment_problem_stats')
async def payment_problem_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения проблемных платежей
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    if not query:
        return
    
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text(
            "У вас нет прав доступа к этому разделу."
        )
        return
    
    # Получаем период для поиска проблемных транзакций
    hours = context.user_data.get('payment_problem_hours', 24)
    
    # Получаем список проблемных транзакций
    async with async_session_maker() as session:
        problem_transactions = await PaymentMonitoringService.get_problem_transactions(session, hours=hours)
    
    # Форматируем вывод проблемных транзакций
    if problem_transactions:
        stats_text = (
            f"⚠️ *Проблемные платежи (за последние {hours} часов)*\n\n"
            f"Найдено проблемных платежей: {len(problem_transactions)}\n\n"
        )
        
        # Ограничиваем количество выводимых транзакций для телеграм-сообщения
        max_transactions = 5
        for i, tx in enumerate(problem_transactions[:max_transactions], 1):
            problem_type_text = "Неизвестная проблема"
            if tx['problem_type'] == 'stalled':
                problem_type_text = f"Зависший платеж ({tx['hours_pending']} ч.)"
            elif tx['problem_type'] == 'error':
                problem_type_text = "Ошибка платежа"
            
            tx_info = (
                f"*{i}. Транзакция #{tx['id']}*\n"
                f"• Пользователь: {tx['username']} (ID: {tx['user_id']})\n"
                f"• Сумма: {tx['amount']} {tx['currency']}\n"
                f"• Статус: {tx['status']}\n"
                f"• Тип проблемы: {problem_type_text}\n"
                f"• Создана: {tx['created_at']}\n"
                f"• Метод оплаты: {tx['payment_method'] or 'Не указан'}\n"
            )
            stats_text += tx_info + "\n"
        
        if len(problem_transactions) > max_transactions:
            stats_text += f"\n...и еще {len(problem_transactions) - max_transactions} проблемных платежей."
    else:
        stats_text = "✅ *Проблемных платежей не обнаружено*\n\nВсе платежи обрабатываются в штатном режиме."
    
    # Кнопки для выбора периода поиска проблемных транзакций
    keyboard = [
        [
            InlineKeyboardButton("12 часов", callback_data='payment_problem_period_12'),
            InlineKeyboardButton("24 часа", callback_data='payment_problem_period_24'),
            InlineKeyboardButton("48 часов", callback_data='payment_problem_period_48'),
        ],
        [
            InlineKeyboardButton("Восстановить платежи", callback_data='payment_recover_all'),
            InlineKeyboardButton("Назад", callback_data='admin_payment_stats')
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        stats_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

@register_handler('payment_recover_all')
async def payment_recover_all_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для запуска восстановления всех проблемных платежей
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    if not query:
        return
    
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text(
            "У вас нет прав доступа к этому разделу."
        )
        return
    
    # Запускаем процесс восстановления платежей
    from services.recovery_service import manual_recovery
    
    await query.edit_message_text(
        "♻️ *Запущен процесс восстановления платежей*\n\n"
        "Пожалуйста, подождите...",
        parse_mode='Markdown'
    )
    
    try:
        # Получаем бота из контекста
        bot = context.bot
        
        # Запускаем процесс восстановления
        result = await manual_recovery(bot)
        
        # Форматируем результат восстановления
        if result:
            payments_result = result.get('payments', {})
            payments_total = payments_result.get('total_transactions', 0)
            payments_recovered = payments_result.get('recovered', 0)
            payments_failed = payments_result.get('failed', 0)
            payments_skipped = payments_result.get('skipped', 0)
            
            payouts_result = result.get('payouts', {})
            payouts_total = payouts_result.get('total', 0)
            payouts_recovered = payouts_result.get('recovered', 0)
            
            batches_result = result.get('batches', {})
            batches_total = batches_result.get('total', 0)
            batches_recovered = batches_result.get('recovered', 0)
            
            result_text = (
                "✅ *Восстановление платежей завершено*\n\n"
                f"*Результаты восстановления платежей:*\n"
                f"• Всего проверено: {payments_total}\n"
                f"• Успешно восстановлено: {payments_recovered}\n"
                f"• Не удалось восстановить: {payments_failed}\n"
                f"• Пропущено: {payments_skipped}\n\n"
                f"*Результаты восстановления выплат:*\n"
                f"• Проверено выплат: {payouts_total}\n"
                f"• Восстановлено выплат: {payouts_recovered}\n"
                f"• Проверено пакетных выплат: {batches_total}\n"
                f"• Восстановлено пакетных выплат: {batches_recovered}\n"
            )
        else:
            result_text = (
                "❓ *Восстановление платежей завершено*\n\n"
                "Не удалось получить информацию о результатах восстановления."
            )
    except Exception as e:
        logger.error(f"Ошибка при восстановлении платежей: {e}", exc_info=True)
        result_text = (
            "❌ *Ошибка при восстановлении платежей*\n\n"
            f"Произошла ошибка: {str(e)[:200]}"
        )
    
    # Кнопки для возврата
    keyboard = [
        [
            InlineKeyboardButton("К проблемным платежам", callback_data='payment_problem_stats'),
            InlineKeyboardButton("К статистике", callback_data='admin_payment_stats')
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        result_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

@register_handler('payment_history')
async def payment_history_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения истории платежей
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    if not query:
        return
    
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text(
            "У вас нет прав доступа к этому разделу."
        )
        return
    
    # Получаем параметры из контекста или используем значения по умолчанию
    days = context.user_data.get('payment_history_days', 30)
    status = context.user_data.get('payment_history_status', None)
    payment_method = context.user_data.get('payment_history_method', None)
    page = context.user_data.get('payment_history_page', 1)
    page_size = 5  # Количество записей на странице
    
    # Рассчитываем смещение для пагинации
    offset = (page - 1) * page_size
    
    # Получаем историю платежей
    async with async_session_maker() as session:
        transactions, total_count = await PaymentMonitoringService.get_payment_history(
            session,
            days=days,
            status=status,
            payment_method=payment_method,
            limit=page_size,
            offset=offset
        )
    
    # Форматируем вывод истории платежей
    history_text = f"📜 *История платежей (за {days} дней)*\n\n"
    
    # Добавляем информацию о фильтрах
    filters_info = []
    if status:
        filters_info.append(f"статус: {status}")
    if payment_method:
        filters_info.append(f"метод: {payment_method}")
    
    if filters_info:
        history_text += f"*Фильтры:* {', '.join(filters_info)}\n\n"
    
    # Добавляем информацию о платежах
    if transactions:
        for tx in transactions:
            tx_info = (
                f"*Транзакция #{tx['id']}*\n"
                f"• Пользователь: {tx['username']} (ID: {tx['user_id']})\n"
                f"• Сумма: {tx['amount']} {tx['currency']}\n"
                f"• Статус: {tx['status']}\n"
                f"• Дата: {tx['created_at']}\n"
                f"• Метод: {tx['payment_method'] or 'Не указан'}\n"
            )
            history_text += tx_info + "\n"
        
        # Добавляем информацию о пагинации
        total_pages = (total_count + page_size - 1) // page_size
        history_text += f"\n*Страница {page} из {total_pages}* (всего записей: {total_count})"
    else:
        history_text += "Платежи не найдены за указанный период."
    
    # Кнопки для пагинации и фильтрации
    keyboard = []
    
    # Кнопки пагинации
    pagination_buttons = []
    total_pages = (total_count + page_size - 1) // page_size
    
    if page > 1:
        pagination_buttons.append(InlineKeyboardButton("◀️ Назад", callback_data=f'payment_history_page_{page-1}'))
    
    if page < total_pages:
        pagination_buttons.append(InlineKeyboardButton("Вперед ▶️", callback_data=f'payment_history_page_{page+1}'))
    
    if pagination_buttons:
        keyboard.append(pagination_buttons)
    
    # Кнопки фильтрации по статусу
    status_buttons = [
        InlineKeyboardButton("Все", callback_data='payment_history_status_all'),
        InlineKeyboardButton("Успешные", callback_data='payment_history_status_completed'),
        InlineKeyboardButton("Ожидающие", callback_data='payment_history_status_pending')
    ]
    keyboard.append(status_buttons)
    
    # Кнопки периода
    period_buttons = [
        InlineKeyboardButton("7 дней", callback_data='payment_history_days_7'),
        InlineKeyboardButton("30 дней", callback_data='payment_history_days_30'),
        InlineKeyboardButton("90 дней", callback_data='payment_history_days_90')
    ]
    keyboard.append(period_buttons)
    
    # Кнопка назад
    keyboard.append([InlineKeyboardButton("Назад", callback_data='admin_payment_stats')])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        history_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

@register_handler('payment_charts')
async def payment_charts_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения графиков платежей
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    if not query:
        return
    
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text(
            "У вас нет прав доступа к этому разделу."
        )
        return
    
    # Получаем параметры из контекста или используем значения по умолчанию
    days = context.user_data.get('payment_charts_days', 30)
    chart_type = context.user_data.get('payment_charts_type', 'daily')
    
    # Получаем данные для графиков
    async with async_session_maker() as session:
        daily_data = await PaymentMonitoringService.get_daily_stats(session, days=days)
    
    # Создаем график
    plt.figure(figsize=(10, 6))
    plt.clf()
    
    # Настраиваем цвета для темной темы Telegram
    plt.style.use('dark_background')
    
    dates = daily_data['dates'][-days:]  # Берем только последние N дней
    
    # Форматируем даты для удобного отображения
    formatted_dates = []
    for date_str in dates:
        dt = datetime.datetime.strptime(date_str, '%Y-%m-%d')
        formatted_dates.append(dt.strftime('%d.%m'))
    
    # В зависимости от типа графика, отображаем разные данные
    if chart_type == 'daily':
        # График ежедневных платежей
        successful = daily_data['successful'][-days:]
        failed = daily_data['failed'][-days:]
        pending = daily_data['pending'][-days:]
        
        plt.bar(formatted_dates, successful, label='Успешные', color='green', alpha=0.7)
        plt.bar(formatted_dates, failed, bottom=successful, label='Неудачные', color='red', alpha=0.7)
        plt.bar(formatted_dates, pending, bottom=[s + f for s, f in zip(successful, failed)], label='Ожидающие', color='orange', alpha=0.7)
        
        plt.title('Ежедневная статистика платежей')
        plt.xlabel('Дата')
        plt.ylabel('Количество платежей')
        plt.legend()
        
        # Поворачиваем метки дат для лучшей читаемости
        plt.xticks(rotation=45)
        plt.tight_layout()
        
    elif chart_type == 'amount':
        # График сумм платежей
        amounts = daily_data['amount'][-days:]
        
        plt.plot(formatted_dates, amounts, marker='o', linestyle='-', color='#1e88e5', linewidth=2)
        plt.fill_between(formatted_dates, amounts, alpha=0.2, color='#1e88e5')
        
        plt.title('Суммы успешных платежей по дням')
        plt.xlabel('Дата')
        plt.ylabel('Сумма платежей')
        
        # Поворачиваем метки дат для лучшей читаемости
        plt.xticks(rotation=45)
        plt.tight_layout()
        
    elif chart_type == 'conversion':
        # График конверсии
        successful = daily_data['successful'][-days:]
        total = daily_data['total'][-days:]
        
        # Вычисляем конверсию для каждого дня
        conversion = []
        for s, t in zip(successful, total):
            if t > 0:
                conversion.append((s / t) * 100)
            else:
                conversion.append(0)
        
        plt.plot(formatted_dates, conversion, marker='o', linestyle='-', color='#43a047', linewidth=2)
        plt.fill_between(formatted_dates, conversion, alpha=0.2, color='#43a047')
        
        plt.title('Конверсия платежей по дням')
        plt.xlabel('Дата')
        plt.ylabel('Конверсия (%)')
        
        # Поворачиваем метки дат для лучшей читаемости
        plt.xticks(rotation=45)
        plt.tight_layout()
    
    # Сохраняем график в байтовый поток
    buf = io.BytesIO()
    plt.savefig(buf, format='png', dpi=100)
    buf.seek(0)
    
    # Отправляем график
    await context.bot.send_photo(
        chat_id=query.message.chat_id,
        photo=buf,
        caption=f"📊 *График платежей за {days} дней*",
        parse_mode='Markdown'
    )
    
    # Кнопки для выбора периода и типа графика
    keyboard = [
        [
            InlineKeyboardButton("7 дней", callback_data='payment_charts_days_7'),
            InlineKeyboardButton("30 дней", callback_data='payment_charts_days_30'),
            InlineKeyboardButton("90 дней", callback_data='payment_charts_days_90')
        ],
        [
            InlineKeyboardButton("Количество", callback_data='payment_charts_type_daily'),
            InlineKeyboardButton("Суммы", callback_data='payment_charts_type_amount'),
            InlineKeyboardButton("Конверсия", callback_data='payment_charts_type_conversion')
        ],
        [
            InlineKeyboardButton("Назад", callback_data='admin_payment_stats')
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Обновляем сообщение с кнопками
    await query.edit_message_text(
        f"📊 *Графики платежей*\n\n"
        f"Выберите период и тип графика для анализа платежей.",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

@register_pattern('payment_period_')
async def payment_period_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик для изменения периода статистики платежей
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    if not query:
        return
    
    callback_data = query.data
    
    # Извлекаем количество дней из callback_data
    days_str = callback_data.replace('payment_period_', '')
    try:
        days = int(days_str)
        context.user_data['payment_stats_days'] = days
    except ValueError:
        days = 30
    
    # Возвращаемся к отображению общей статистики с обновленным периодом
    await payment_general_stats_callback(update, context)

@register_pattern('payment_problem_period_')
async def payment_problem_period_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик для изменения периода поиска проблемных платежей
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    if not query:
        return
    
    callback_data = query.data
    
    # Извлекаем количество часов из callback_data
    hours_str = callback_data.replace('payment_problem_period_', '')
    try:
        hours = int(hours_str)
        context.user_data['payment_problem_hours'] = hours
    except ValueError:
        hours = 24
    
    # Возвращаемся к отображению проблемных платежей с обновленным периодом
    await payment_problem_stats_callback(update, context)

@register_pattern('payment_history_page_')
async def payment_history_page_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик для пагинации истории платежей
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    if not query:
        return
    
    callback_data = query.data
    
    # Извлекаем номер страницы из callback_data
    page_str = callback_data.replace('payment_history_page_', '')
    try:
        page = int(page_str)
        context.user_data['payment_history_page'] = page
    except ValueError:
        page = 1
    
    # Возвращаемся к отображению истории платежей с обновленной страницей
    await payment_history_callback(update, context)

@register_pattern('payment_history_status_')
async def payment_history_status_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик для фильтрации истории платежей по статусу
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    if not query:
        return
    
    callback_data = query.data
    
    # Извлекаем статус из callback_data
    status = callback_data.replace('payment_history_status_', '')
    
    # Если выбран "all", сбрасываем фильтр
    if status == 'all':
        context.user_data['payment_history_status'] = None
    else:
        context.user_data['payment_history_status'] = status
    
    # Сбрасываем страницу на первую при смене фильтра
    context.user_data['payment_history_page'] = 1
    
    # Возвращаемся к отображению истории платежей с обновленным фильтром
    await payment_history_callback(update, context)

@register_pattern('payment_history_days_')
async def payment_history_days_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик для изменения периода истории платежей
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    if not query:
        return
    
    callback_data = query.data
    
    # Извлекаем количество дней из callback_data
    days_str = callback_data.replace('payment_history_days_', '')
    try:
        days = int(days_str)
        context.user_data['payment_history_days'] = days
    except ValueError:
        days = 30
    
    # Сбрасываем страницу на первую при смене периода
    context.user_data['payment_history_page'] = 1
    
    # Возвращаемся к отображению истории платежей с обновленным периодом
    await payment_history_callback(update, context)

@register_pattern('payment_charts_days_')
async def payment_charts_days_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик для изменения периода графиков платежей
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    if not query:
        return
    
    callback_data = query.data
    
    # Извлекаем количество дней из callback_data
    days_str = callback_data.replace('payment_charts_days_', '')
    try:
        days = int(days_str)
        context.user_data['payment_charts_days'] = days
    except ValueError:
        days = 30
    
    # Возвращаемся к отображению графиков с обновленным периодом
    await payment_charts_callback(update, context)

@register_pattern('payment_charts_type_')
async def payment_charts_type_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик для изменения типа графика платежей
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    if not query:
        return
    
    callback_data = query.data
    
    # Извлекаем тип графика из callback_data
    chart_type = callback_data.replace('payment_charts_type_', '')
    context.user_data['payment_charts_type'] = chart_type
    
    # Возвращаемся к отображению графиков с обновленным типом
    await payment_charts_callback(update, context)

def get_payment_handlers() -> Tuple[Dict[str, callable], Dict[str, callable]]:
    """
    Получение словарей обработчиков административных команд для мониторинга платежей
    
    Returns:
        Tuple[Dict, Dict]: Кортеж из двух словарей:
            1. Словарь статических обработчиков {callback_data: handler_function}
            2. Словарь динамических обработчиков {prefix: handler_function}
    """
    return payment_stats_handlers, payment_stats_patterns