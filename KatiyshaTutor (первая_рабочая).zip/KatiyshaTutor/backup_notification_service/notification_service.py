#!/usr/bin/env python
# coding: utf-8

"""
Сервис для отправки уведомлений пользователям
"""

import os
import logging
import datetime
import json
from typing import Dict, List, Any, Optional, Tuple, Union, Set
from enum import Enum

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func, or_, and_, desc, asc, text
from telegram import Bot

import config
from db_models import User, Transaction, WeeklyPayout

# Определение модели для логирования действий администраторов (если она еще не определена в db_models.py)
try:
    from db_models import AdminActionLog
except ImportError:
    from sqlalchemy import Column, Integer, String, DateTime, Text
    from db_models import Base
    
    class AdminActionLog(Base):
        """Модель для логирования действий администраторов"""
        __tablename__ = 'admin_action_logs'
        
        id = Column(Integer, primary_key=True)
        admin_id = Column(Integer, nullable=False, index=True)
        action_type = Column(String(50), nullable=False)
        action_data = Column(Text, nullable=True)
        created_at = Column(DateTime, nullable=False, default=datetime.datetime.utcnow)

logger = logging.getLogger(__name__)

class NotificationTemplates(Enum):
    """Шаблоны уведомлений для пользователей"""
    PAYMENT_SUCCESS = "payment_success"
    PAYMENT_ERROR = "payment_error"
    REFERRAL_REWARD = "referral_reward"
    PAYOUT_INITIATED = "payout_initiated"
    PAYOUT_COMPLETED = "payout_completed"
    PAYOUT_FAILED = "payout_failed"
    SYSTEM_NOTIFICATION = "system_notification"
    RECOVERY_ATTEMPT = "recovery_attempt"
    SUBSCRIPTION_EXPIRY = "subscription_expiry"

class NotificationType:
    """Типы уведомлений для пользователей"""
    PAYMENT_PENDING = "payment_pending"  # Ожидается оплата подписки
    PAYMENT_SUCCESSFUL = "payment_successful"  # Успешная оплата подписки
    PAYMENT_FAILED = "payment_failed"  # Ошибка оплаты подписки
    SUBSCRIPTION_EXPIRING = "subscription_expiring"  # Подписка скоро истекает
    SUBSCRIPTION_EXPIRED = "subscription_expired"  # Подписка истекла
    REFERRAL_REWARD = "referral_reward"  # Получено реферальное вознаграждение
    PAYOUT_AVAILABLE = "payout_available"  # Доступна выплата реферального вознаграждения
    PAYOUT_PROCESSING = "payout_processing"  # Выплата в обработке
    PAYOUT_COMPLETED = "payout_completed"  # Выплата завершена
    PAYOUT_FAILED = "payout_failed"  # Ошибка выплаты
    SYSTEM = "system"  # Системное уведомление

class NotificationManager:
    """Менеджер уведомлений для пользователей (стандартная имплементация)"""
    
    def __init__(self, bot: Bot = None):
        self.bot = bot
        
    async def send_template(self, user_id: int, template: NotificationTemplates, context: Dict[str, Any] = None) -> bool:
        """Отправляет уведомление по шаблону"""
        if not context:
            context = {}
            
        try:
            message = self._format_template(template, context)
            
            if not message:
                logger.warning(f"Unknown template: {template}")
                return False
                
            if self.bot:
                await self.bot.send_message(
                    chat_id=user_id,
                    text=message,
                    parse_mode="Markdown"
                )
                
            logger.info(f"Template notification sent to user {user_id}, template: {template}")
            return True
        except Exception as e:
            logger.error(f"Error sending template notification to user {user_id}: {e}")
            return False
            
    def _format_template(self, template: NotificationTemplates, context: Dict[str, Any]) -> str:
        """Форматирует сообщение по шаблону"""
        if template == NotificationTemplates.PAYMENT_SUCCESS:
            return (
                "✅ *Успешная оплата*\n\n"
                f"Сумма: *{context.get('amount', 0)}₽*\n"
                f"Дата: *{context.get('date', 'Сегодня')}*\n\n"
                "Спасибо за использование нашего сервиса!"
            )
        elif template == NotificationTemplates.PAYMENT_ERROR:
            return (
                "❌ *Ошибка оплаты*\n\n"
                f"Причина: *{context.get('reason', 'Неизвестная ошибка')}*\n\n"
                "Пожалуйста, повторите попытку позже или свяжитесь с нами для получения помощи."
            )
        elif template == NotificationTemplates.REFERRAL_REWARD:
            return (
                "💰 *Реферальное вознаграждение*\n\n"
                f"Вы получили *{context.get('amount', 0)}₽* за приглашенного пользователя."
            )
        elif template == NotificationTemplates.PAYOUT_INITIATED:
            return (
                "⏳ *Выплата инициирована*\n\n"
                f"Сумма: *{context.get('amount', 0)}₽*\n"
                f"ID выплаты: `{context.get('payout_id', 'N/A')}`\n\n"
                "Ваша заявка на выплату принята и находится в обработке."
            )
        elif template == NotificationTemplates.PAYOUT_COMPLETED:
            return (
                "✅ *Выплата завершена*\n\n"
                f"Сумма: *{context.get('amount', 0)}₽*\n"
                f"ID выплаты: `{context.get('payout_id', 'N/A')}`\n"
                f"Дата: *{context.get('date', 'Сегодня')}*"
            )
        elif template == NotificationTemplates.PAYOUT_FAILED:
            return (
                "❌ *Ошибка выплаты*\n\n"
                f"Сумма: *{context.get('amount', 0)}₽*\n"
                f"ID выплаты: `{context.get('payout_id', 'N/A')}`\n"
                f"Причина: *{context.get('reason', 'Неизвестная ошибка')}*"
            )
        elif template == NotificationTemplates.SYSTEM_NOTIFICATION:
            return context.get('message', 'Системное уведомление')
        elif template == NotificationTemplates.RECOVERY_ATTEMPT:
            return (
                "🔄 *Восстановление транзакции*\n\n"
                f"ID транзакции: `{context.get('transaction_id', 'N/A')}`\n"
                f"Статус: *{context.get('status', 'В процессе')}*\n"
                f"Причина: *{context.get('reason', 'Автоматическое восстановление')}*"
            )
        elif template == NotificationTemplates.SUBSCRIPTION_EXPIRY:
            return (
                "⏳ *Окончание подписки*\n\n"
                f"Ваша подписка истекает *{context.get('expiry_date', 'скоро')}*.\n\n"
                "Не забудьте продлить подписку для продолжения использования сервиса."
            )
        return ""

# Глобальный экземпляр менеджера уведомлений
_notification_manager = None

def get_notification_manager(bot: Bot = None) -> NotificationManager:
    """
    Получение экземпляра менеджера уведомлений
    
    Args:
        bot: Экземпляр бота Telegram
        
    Returns:
        NotificationManager: Экземпляр менеджера уведомлений
    """
    global _notification_manager
    if _notification_manager is None:
        _notification_manager = NotificationManager(bot)
    return _notification_manager

async def log_admin_action(
    admin_id: int, 
    action: str, 
    details: Dict[str, Any] = None, 
    bot: Bot = None, 
    session: AsyncSession = None
) -> None:
    """
    Логирование действий администратора
    
    Args:
        admin_id: ID администратора в Telegram
        action: Краткое описание действия
        details: Дополнительные данные о действии
        bot: Экземпляр бота Telegram
        session: Активная сессия базы данных
    """
    if not details:
        details = {}
        
    logger.info(f"Admin action by {admin_id}: {action}, details: {str(details)}")
    
    # Логирование в базу данных
    if session:
        try:
            # Создание записи в журнале действий администратора
            log_entry = AdminActionLog(
                admin_id=admin_id,
                action_type=action,
                action_data=json.dumps(details, ensure_ascii=False),
                created_at=datetime.datetime.now()
            )
            session.add(log_entry)
            await session.commit()
        except Exception as e:
            logger.error(f"Failed to log admin action to database: {e}")
            
    # Отправка уведомления в канал мониторинга
    if bot and config.MONITORING_CHANNEL_ID:
        try:
            admin_info = f"Admin ID: {admin_id}"
            
            if 'username' in details:
                admin_info += f", @{details['username']}"
                
            message = (
                f"🔐 *Admin Action*\n\n"
                f"👤 {admin_info}\n"
                f"🔹 Action: *{action}*\n"
                f"🕒 Time: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            )
            
            # Добавляем детали, если они есть
            if details:
                message += "📋 *Details:*\n"
                for key, value in details.items():
                    if key != 'username':  # Имя пользователя уже добавлено выше
                        message += f"- {key}: {value}\n"
            
            await bot.send_message(
                chat_id=config.MONITORING_CHANNEL_ID,
                text=message,
                parse_mode="Markdown"
            )
        except Exception as e:
            logger.error(f"Failed to send admin action notification: {e}")

class NotificationService:
    """Сервис для отправки уведомлений пользователям"""
    
    def __init__(self, bot: Bot):
        """
        Инициализация сервиса
        
        Args:
            bot: Экземпляр бота Telegram
        """
        self.bot = bot
    
    async def send_notification(self, 
                              user_id: int, 
                              notification_type: str, 
                              context: Dict[str, Any] = None) -> bool:
        """
        Отправка уведомления пользователю
        
        Args:
            user_id: ID пользователя в Telegram
            notification_type: Тип уведомления
            context: Дополнительные данные для уведомления
            
        Returns:
            bool: True в случае успеха, False в случае ошибки
        """
        try:
            if not context:
                context = {}
            
            message = self._format_notification(notification_type, context)
            
            if not message:
                logger.warning(f"Unknown notification type: {notification_type}")
                return False
            
            # Добавляем задержку, чтобы не превысить лимиты Telegram API
            await self.bot.send_message(
                chat_id=user_id,
                text=message,
                parse_mode="Markdown"
            )
            
            logger.info(f"Notification sent to user {user_id}, type: {notification_type}")
            return True
        except Exception as e:
            logger.error(f"Error sending notification to user {user_id}: {e}")
            return False
    
    def _format_notification(self, notification_type: str, context: Dict[str, Any]) -> str:
        """
        Форматирование текста уведомления на основе типа и контекста
        
        Args:
            notification_type: Тип уведомления
            context: Дополнительные данные для уведомления
            
        Returns:
            str: Текст уведомления или пустая строка, если тип неизвестен
        """
        if notification_type == NotificationType.PAYMENT_PENDING:
            return (
                "💳 *Ожидается оплата подписки*\n\n"
                "Мы создали запрос на оплату подписки. "
                "Вы можете завершить процесс оплаты в любое удобное время.\n\n"
                f"Сумма: *{context.get('amount', 199)}₽*\n"
                f"Срок действия: *{context.get('duration', 30)} дней*\n\n"
                "Для завершения оплаты используйте команду /activate_subscription"
            )
        
        elif notification_type == NotificationType.PAYMENT_SUCCESSFUL:
            return (
                "✅ *Оплата прошла успешно!*\n\n"
                "Спасибо за оплату подписки на бота Катюша!\n\n"
                f"Ваша подписка активна до: *{context.get('expiry_date', 'N/A')}*\n\n"
                "Теперь у вас есть неограниченный доступ к решению "
                "математических задач. Просто отправьте боту вашу задачу "
                "текстом, фотографией или голосовым сообщением."
            )
        
        elif notification_type == NotificationType.PAYMENT_FAILED:
            return (
                "❌ *Ошибка оплаты*\n\n"
                "К сожалению, произошла ошибка при обработке вашего платежа.\n\n"
                f"Причина: *{context.get('reason', 'Неизвестная ошибка')}*\n\n"
                "Пожалуйста, попробуйте оплатить подписку еще раз, используя "
                "команду /subscribe, или свяжитесь с нами для получения помощи."
            )
        
        elif notification_type == NotificationType.SUBSCRIPTION_EXPIRING:
            return (
                "⏳ *Срок действия подписки истекает*\n\n"
                f"Ваша подписка истекает *{context.get('expiry_date', 'скоро')}*.\n\n"
                "Чтобы продолжить пользоваться ботом Катюша без ограничений, "
                "пожалуйста, продлите подписку, используя команду /subscribe."
            )
        
        elif notification_type == NotificationType.SUBSCRIPTION_EXPIRED:
            return (
                "⌛ *Подписка истекла*\n\n"
                "Срок действия вашей подписки истек.\n\n"
                "Чтобы продолжить пользоваться ботом Катюша, пожалуйста, "
                "приобретите новую подписку, используя команду /subscribe."
            )
        
        elif notification_type == NotificationType.REFERRAL_REWARD:
            return (
                "💰 *Получено реферальное вознаграждение!*\n\n"
                f"Вы получили *{context.get('amount', 0)}₽* реферального вознаграждения!\n\n"
                f"Уровень реферала: *{context.get('level', 1)}*\n"
                f"Процент вознаграждения: *{context.get('percent', '5%')}*\n\n"
                "Спасибо за участие в реферальной программе Катюши! "
                "Продолжайте приглашать друзей, чтобы зарабатывать больше.\n\n"
                "Используйте команду /rewards, чтобы узнать о всех ваших вознаграждениях."
            )
        
        elif notification_type == NotificationType.PAYOUT_AVAILABLE:
            return (
                "💸 *Доступна выплата реферального вознаграждения*\n\n"
                f"У вас есть *{context.get('amount', 0)}₽* доступных для выплаты.\n\n"
                "Минимальная сумма для выплаты составляет 1000₽.\n\n"
                "Чтобы запросить выплату, используйте команду /rewards и "
                "выберите опцию 'Запросить выплату'."
            )
        
        elif notification_type == NotificationType.PAYOUT_PROCESSING:
            return (
                "⏳ *Ваша выплата в обработке*\n\n"
                f"Сумма: *{context.get('amount', 0)}₽*\n"
                f"ID выплаты: `{context.get('payout_id', 'N/A')}`\n\n"
                "Мы обрабатываем вашу выплату. Это может занять до 3 рабочих дней.\n"
                "Мы уведомим вас, когда выплата будет завершена."
            )
        
        elif notification_type == NotificationType.PAYOUT_COMPLETED:
            return (
                "✅ *Выплата успешно завершена*\n\n"
                f"Сумма: *{context.get('amount', 0)}₽*\n"
                f"ID выплаты: `{context.get('payout_id', 'N/A')}`\n"
                f"Дата: *{context.get('date', 'Сегодня')}*\n\n"
                "Благодарим вас за участие в реферальной программе Катюши!"
            )
        
        elif notification_type == NotificationType.PAYOUT_FAILED:
            return (
                "❌ *Ошибка при обработке выплаты*\n\n"
                f"Сумма: *{context.get('amount', 0)}₽*\n"
                f"ID выплаты: `{context.get('payout_id', 'N/A')}`\n"
                f"Причина: *{context.get('reason', 'Неизвестная ошибка')}*\n\n"
                "Пожалуйста, проверьте ваши платежные реквизиты и попробуйте запросить "
                "выплату снова. Если проблема сохраняется, пожалуйста, свяжитесь с нами."
            )
        
        elif notification_type == NotificationType.SYSTEM:
            return context.get('message', 'Системное уведомление')
        
        return ""
    
    async def notify_users_about_available_payouts(self, session: AsyncSession) -> int:
        """
        Уведомление пользователей о доступных выплатах
        
        Args:
            session: Активная сессия базы данных
            
        Returns:
            int: Количество отправленных уведомлений
        """
        # Получаем пользователей с балансом выше минимального порога выплаты
        stmt = select(User).where(
            User.referral_balance >= config.MIN_PAYOUT_AMOUNT
        )
        users_result = await session.execute(stmt)
        users = users_result.scalars().all()
        
        # Проверяем, когда последний раз отправлялись уведомления
        current_time = datetime.datetime.now()
        notification_count = 0
        
        for user in users:
            # Проверяем, было ли уведомление в течение последних 7 дней
            should_notify = True
            
            if user.last_payout_notification:
                days_since_notification = (current_time - user.last_payout_notification).days
                if days_since_notification < 7:
                    should_notify = False
            
            if should_notify:
                # Отправляем уведомление
                notification_sent = await self.send_notification(
                    user_id=user.id,
                    notification_type=NotificationType.PAYOUT_AVAILABLE,
                    context={
                        'amount': user.referral_balance
                    }
                )
                
                if notification_sent:
                    # Обновляем время последнего уведомления
                    user.last_payout_notification = current_time
                    notification_count += 1
        
        # Сохраняем изменения в базе данных
        await session.commit()
        
        logger.info(f"Sent {notification_count} payout availability notifications")
        return notification_count
    
    async def notify_users_about_expiring_subscriptions(self, session: AsyncSession, days_threshold: int = 3) -> int:
        """
        Уведомление пользователей об истекающих подписках
        
        Args:
            session: Активная сессия базы данных
            days_threshold: За сколько дней до истечения отправлять уведомление
            
        Returns:
            int: Количество отправленных уведомлений
        """
        # Текущая дата
        current_date = datetime.datetime.now().date()
        
        # Дата истечения для проверки
        expiry_date = current_date + datetime.timedelta(days=days_threshold)
        
        # Получаем пользователей с истекающими подписками
        stmt = select(User).where(
            and_(
                # Подписка активна
                User.is_subscribed == True,
                # Подписка истекает через days_threshold дней
                func.date(User.subscription_expiry) == expiry_date,
                # Не было отправлено уведомление (или отправлено более 24 часов назад)
                or_(
                    User.last_subscription_notification.is_(None),
                    User.last_subscription_notification < datetime.datetime.now() - datetime.timedelta(hours=24)
                )
            )
        )
        users_result = await session.execute(stmt)
        users = users_result.scalars().all()
        
        notification_count = 0
        
        for user in users:
            # Форматируем дату истечения для уведомления
            expiry_date_str = user.subscription_expiry.strftime("%d.%m.%Y")
            
            # Отправляем уведомление
            notification_sent = await self.send_notification(
                user_id=user.id,
                notification_type=NotificationType.SUBSCRIPTION_EXPIRING,
                context={
                    'expiry_date': expiry_date_str
                }
            )
            
            if notification_sent:
                # Обновляем время последнего уведомления
                user.last_subscription_notification = datetime.datetime.now()
                notification_count += 1
        
        # Сохраняем изменения в базе данных
        await session.commit()
        
        logger.info(f"Sent {notification_count} subscription expiry notifications")
        return notification_count