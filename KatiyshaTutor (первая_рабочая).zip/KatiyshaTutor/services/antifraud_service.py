#!/usr/bin/env python
# coding: utf-8

"""
Сервис обнаружения мошеннических действий в реферальной системе
"""

import re
import json
import time
import logging
import datetime
import ipaddress
from typing import Dict, List, Any, Optional, Tuple, Union, Set
from enum import Enum
import asyncio

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func, or_, and_, desc, asc, text, distinct, not_

from db_models import (
    db, User, Transaction, WeeklyPayout, BatchPayout, 
    AdminActionLog, ReferralNetwork
)

logger = logging.getLogger(__name__)

# Настройки для обнаружения аномалий с разными уровнями безопасности
ANOMALY_SETTINGS = {
    # Базовые настройки (нормальный режим работы)
    "default": {
        # Максимальное количество рефералов для одного пользователя за день
        "max_referrals_per_day": 10,
        
        # Минимальный возраст аккаунта для получения реферальных вознаграждений (в днях)
        "min_account_age_days": 3,
        
        # Максимальное количество аккаунтов с одного IP-адреса
        "max_accounts_per_ip": 5,
    },
    
    # Усиленные настройки (при обнаружении подозрительной активности)
    "enhanced": {
        "max_referrals_per_day": 5,
        "min_account_age_days": 7,
        "max_accounts_per_ip": 3,
    },
    
    # Экстремальные настройки (при активной атаке)
    "extreme": {
        "max_referrals_per_day": 2,
        "min_account_age_days": 14,
        "max_accounts_per_ip": 1,
    }
}

# Текущий уровень защиты (можно менять динамически)
CURRENT_SECURITY_LEVEL = "default"

# Функция для получения текущих настроек безопасности
def get_current_anomaly_settings():
    """
    Возвращает текущие настройки обнаружения аномалий в зависимости от уровня безопасности
    
    Returns:
        dict: Словарь с настройками безопасности
    """
    settings = ANOMALY_SETTINGS.get(CURRENT_SECURITY_LEVEL, ANOMALY_SETTINGS["default"]).copy()
    
    # Дополнительные параметры, общие для всех уровней
    settings.update({
        # Максимальное количество неудачных попыток входа
        "max_failed_login_attempts": 10,
        
        # Минимальное время между регистрациями рефералов (в секундах)
        "min_referral_registration_interval_sec": 60,
        
        # Максимальное количество подписок с одной карты
        "max_subscriptions_per_card": 3,
        
        # Периоды для анализа активности (в днях)
        "activity_analysis_periods": [1, 7, 30],
        
        # Максимальное количество отмененных транзакций для блокировки
        "max_cancelled_transactions": 5,
        
        # Блокировать циклические реферальные цепочки
        "block_circular_referrals": True,
        
        # Пороговое значение для подозрительной активности (0.0 - 1.0)
        "suspicious_activity_threshold": 0.7,
        
        # Пороговое значение для автоматической блокировки (0.0 - 1.0)
        "auto_block_threshold": 0.9
    })
    
    return settings

class FraudRiskLevel(Enum):
    """Уровни риска мошенничества"""
    LOW = "low"  # Низкий риск
    MEDIUM = "medium"  # Средний риск
    HIGH = "high"  # Высокий риск
    CRITICAL = "critical"  # Критический риск

class FraudRuleType(Enum):
    """Типы правил обнаружения мошенничества"""
    REGISTRATION = "registration"  # Правила для регистрации
    REFERRAL = "referral"  # Правила для реферальной системы
    PAYMENT = "payment"  # Правила для платежей
    PATTERN = "pattern"  # Правила для паттернов поведения
    NETWORK = "network"  # Правила для сетевого анализа

class FraudDetectionRule:
    """Базовый класс для правил обнаружения мошенничества"""
    
    def __init__(self, 
                 name: str, 
                 description: str, 
                 rule_type: FraudRuleType, 
                 risk_level: FraudRiskLevel, 
                 weight: float = 1.0,
                 enabled: bool = True):
        """
        Инициализация правила
        
        Args:
            name: Название правила
            description: Описание правила
            rule_type: Тип правила
            risk_level: Уровень риска
            weight: Вес правила при расчете общего риска (0.0 - 1.0)
            enabled: Активно ли правило
        """
        self.name = name
        self.description = description
        self.rule_type = rule_type
        self.risk_level = risk_level
        self.weight = weight
        self.enabled = enabled
    
    async def check(self, session: AsyncSession, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Проверка данных на соответствие правилу
        
        Args:
            session: Активная сессия базы данных
            data: Словарь с данными для проверки
            
        Returns:
            dict: Результаты проверки {triggered: bool, risk_score: float, details: dict}
        """
        raise NotImplementedError("Subclasses must implement this method")
    
    def get_info(self) -> Dict[str, Any]:
        """
        Получение информации о правиле
        
        Returns:
            dict: Информация о правиле
        """
        return {
            "name": self.name,
            "description": self.description,
            "rule_type": self.rule_type.value,
            "risk_level": self.risk_level.value,
            "weight": self.weight,
            "enabled": self.enabled
        }

class MultipleRegistrationsFromIPRule(FraudDetectionRule):
    """Правило для обнаружения множественных регистраций с одного IP-адреса"""
    
    def __init__(self):
        super().__init__(
            name="multiple_registrations_from_ip",
            description="Обнаружение множественных регистраций с одного IP-адреса",
            rule_type=FraudRuleType.REGISTRATION,
            risk_level=FraudRiskLevel.MEDIUM,
            weight=0.7
        )
    
    async def check(self, session: AsyncSession, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Проверка на множественные регистрации с одного IP-адреса
        
        Args:
            session: Активная сессия базы данных
            data: Словарь с данными для проверки
            
        Returns:
            dict: Результаты проверки
        """
        result = {
            "triggered": False,
            "risk_score": 0.0,
            "details": {}
        }
        
        ip_address = data.get("ip_address")
        if not ip_address:
            result["details"]["error"] = "IP address not provided"
            return result
        
        # В этой версии мы используем AdminActionLog для отслеживания IP
        # В идеале, нужно добавить поле ip_address в модель User или создать отдельную таблицу для хранения IP
        stmt = select(func.count(distinct(AdminActionLog.admin_id))).where(
            AdminActionLog.ip_address == ip_address
        )
        count_result = await session.execute(stmt)
        accounts_count = count_result.scalar() or 0
        
        max_accounts = ANOMALY_SETTINGS["max_accounts_per_ip"]
        
        if accounts_count >= max_accounts:
            result["triggered"] = True
            risk_factor = min(1.0, accounts_count / (max_accounts * 2))  # Нормализация риска
            result["risk_score"] = risk_factor * self.weight
            result["details"] = {
                "ip_address": ip_address,
                "accounts_count": accounts_count,
                "max_allowed": max_accounts,
                "risk_factor": risk_factor
            }
        
        return result

class RapidReferralRegistrationsRule(FraudDetectionRule):
    """Правило для обнаружения быстрых регистраций рефералов"""
    
    def __init__(self):
        super().__init__(
            name="rapid_referral_registrations",
            description="Обнаружение подозрительно быстрых регистраций рефералов",
            rule_type=FraudRuleType.REFERRAL,
            risk_level=FraudRiskLevel.HIGH,
            weight=0.8
        )
    
    async def check(self, session: AsyncSession, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Проверка на быстрые регистрации рефералов
        
        Args:
            session: Активная сессия базы данных
            data: Словарь с данными для проверки
            
        Returns:
            dict: Результаты проверки
        """
        result = {
            "triggered": False,
            "risk_score": 0.0,
            "details": {}
        }
        
        user_id = data.get("user_id")
        if not user_id:
            result["details"]["error"] = "User ID not provided"
            return result
        
        # Получаем последних N рефералов пользователя
        stmt = select(User).where(User.referrer_id == user_id).order_by(desc(User.joined_at)).limit(20)
        referrals_result = await session.execute(stmt)
        referrals = referrals_result.scalars().all()
        
        if len(referrals) < 2:
            return result  # Недостаточно рефералов для анализа
        
        # Анализируем интервалы между регистрациями
        intervals = []
        previous_time = None
        for referral in referrals:
            if previous_time:
                interval = (previous_time - referral.joined_at).total_seconds()
                intervals.append(interval)
            previous_time = referral.joined_at
        
        # Проверяем, есть ли слишком короткие интервалы
        min_interval = ANOMALY_SETTINGS["min_referral_registration_interval_sec"]
        suspicious_intervals = [i for i in intervals if i < min_interval]
        
        if suspicious_intervals:
            result["triggered"] = True
            avg_interval = sum(suspicious_intervals) / len(suspicious_intervals)
            risk_factor = min(1.0, min_interval / (avg_interval + 1))  # Чем меньше интервал, тем выше риск
            result["risk_score"] = risk_factor * self.weight
            result["details"] = {
                "user_id": user_id,
                "suspicious_intervals_count": len(suspicious_intervals),
                "total_intervals": len(intervals),
                "average_suspicious_interval": avg_interval,
                "min_allowed_interval": min_interval,
                "risk_factor": risk_factor
            }
        
        return result

class CircularReferralChainRule(FraudDetectionRule):
    """Правило для обнаружения циклических реферальных цепочек"""
    
    def __init__(self):
        super().__init__(
            name="circular_referral_chain",
            description="Обнаружение циклических реферальных цепочек",
            rule_type=FraudRuleType.NETWORK,
            risk_level=FraudRiskLevel.CRITICAL,
            weight=1.0
        )
    
    async def check(self, session: AsyncSession, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Проверка на циклические реферальные цепочки
        
        Args:
            session: Активная сессия базы данных
            data: Словарь с данными для проверки
            
        Returns:
            dict: Результаты проверки
        """
        result = {
            "triggered": False,
            "risk_score": 0.0,
            "details": {}
        }
        
        user_id = data.get("user_id")
        if not user_id:
            result["details"]["error"] = "User ID not provided"
            return result
        
        # Получаем цепочку рефералов
        chain = []
        visited = set()
        current_id = user_id
        
        # Строим цепочку рефералов
        while current_id and current_id not in visited:
            visited.add(current_id)
            chain.append(current_id)
            
            # Получаем реферера для текущего пользователя
            user_result = await session.execute(select(User).where(User.id == current_id))
            user = user_result.scalars().first()
            
            if not user or not user.referrer_id:
                break
            
            current_id = user.referrer_id
        
        # Если последний элемент цепочки уже был посещен, значит, есть цикл
        if current_id in visited:
            # Находим начало цикла
            cycle_start = chain.index(current_id)
            cycle = chain[cycle_start:]
            
            result["triggered"] = True
            result["risk_score"] = 1.0 * self.weight  # Максимальный риск для циклических цепочек
            result["details"] = {
                "user_id": user_id,
                "cycle_detected": True,
                "cycle": cycle,
                "cycle_length": len(cycle)
            }
        
        return result

class UnusualTransactionPatternRule(FraudDetectionRule):
    """Правило для обнаружения необычных паттернов транзакций"""
    
    def __init__(self):
        super().__init__(
            name="unusual_transaction_pattern",
            description="Обнаружение необычных паттернов транзакций",
            rule_type=FraudRuleType.PATTERN,
            risk_level=FraudRiskLevel.MEDIUM,
            weight=0.6
        )
    
    async def check(self, session: AsyncSession, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Проверка на необычные паттерны транзакций
        
        Args:
            session: Активная сессия базы данных
            data: Словарь с данными для проверки
            
        Returns:
            dict: Результаты проверки
        """
        result = {
            "triggered": False,
            "risk_score": 0.0,
            "details": {}
        }
        
        user_id = data.get("user_id")
        if not user_id:
            result["details"]["error"] = "User ID not provided"
            return result
        
        # Получаем все транзакции пользователя
        stmt = select(Transaction).where(Transaction.user_id == user_id).order_by(asc(Transaction.created_at))
        tx_result = await session.execute(stmt)
        transactions = tx_result.scalars().all()
        
        if len(transactions) < 5:
            return result  # Недостаточно транзакций для анализа
        
        # Анализируем паттерны транзакций
        cancelled_count = sum(1 for tx in transactions if tx.status == 'cancelled')
        failed_count = sum(1 for tx in transactions if tx.status == 'failed')
        
        # Считаем количество транзакций каждого типа
        tx_types = {}
        for tx in transactions:
            tx_type = tx.transaction_type
            tx_types[tx_type] = tx_types.get(tx_type, 0) + 1
        
        # Проверяем, есть ли необычные паттерны
        anomalies = []
        
        # Проверка на большое количество отмененных транзакций
        max_cancelled = ANOMALY_SETTINGS["max_cancelled_transactions"]
        if cancelled_count > max_cancelled:
            anomalies.append({
                "type": "high_cancellation_rate",
                "description": f"Высокий уровень отмененных транзакций: {cancelled_count} из {len(transactions)}",
                "severity": 0.7
            })
        
        # Проверка на большое количество неудачных транзакций
        if failed_count > max_cancelled:
            anomalies.append({
                "type": "high_failure_rate",
                "description": f"Высокий уровень неудачных транзакций: {failed_count} из {len(transactions)}",
                "severity": 0.6
            })
        
        # Проверка на необычное соотношение типов транзакций
        if 'subscription' in tx_types and 'referral_reward' in tx_types:
            subscription_count = tx_types.get('subscription', 0)
            reward_count = tx_types.get('referral_reward', 0)
            
            if reward_count > subscription_count * 3:
                anomalies.append({
                    "type": "unusual_reward_ratio",
                    "description": f"Необычно высокое соотношение реферальных вознаграждений ({reward_count}) к подпискам ({subscription_count})",
                    "severity": 0.8
                })
        
        if anomalies:
            # Вычисляем общий риск на основе обнаруженных аномалий
            max_severity = max(a["severity"] for a in anomalies)
            result["triggered"] = True
            result["risk_score"] = max_severity * self.weight
            result["details"] = {
                "user_id": user_id,
                "transaction_count": len(transactions),
                "cancelled_count": cancelled_count,
                "failed_count": failed_count,
                "transaction_types": tx_types,
                "anomalies": anomalies,
                "max_severity": max_severity
            }
        
        return result

class NewAccountHighRewardRule(FraudDetectionRule):
    """Правило для обнаружения новых аккаунтов с высокими реферальными вознаграждениями"""
    
    def __init__(self):
        super().__init__(
            name="new_account_high_reward",
            description="Обнаружение новых аккаунтов с высокими реферальными вознаграждениями",
            rule_type=FraudRuleType.REFERRAL,
            risk_level=FraudRiskLevel.HIGH,
            weight=0.9
        )
    
    async def check(self, session: AsyncSession, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Проверка на новые аккаунты с высокими реферальными вознаграждениями
        
        Args:
            session: Активная сессия базы данных
            data: Словарь с данными для проверки
            
        Returns:
            dict: Результаты проверки
        """
        result = {
            "triggered": False,
            "risk_score": 0.0,
            "details": {}
        }
        
        user_id = data.get("user_id")
        if not user_id:
            result["details"]["error"] = "User ID not provided"
            return result
        
        # Получаем информацию о пользователе
        user_result = await session.execute(select(User).where(User.id == user_id))
        user = user_result.scalars().first()
        
        if not user:
            result["details"]["error"] = f"User with ID {user_id} not found"
            return result
        
        # Вычисляем возраст аккаунта в днях
        account_age_days = (datetime.datetime.now() - user.joined_at).days
        min_age = ANOMALY_SETTINGS["min_account_age_days"]
        
        if account_age_days < min_age:
            # Получаем сумму реферальных вознаграждений
            stmt = select(func.sum(Transaction.amount)).where(
                and_(
                    Transaction.user_id == user_id,
                    Transaction.transaction_type == 'referral_reward',
                    Transaction.status.in_(['completed', 'pending', 'processing'])
                )
            )
            reward_result = await session.execute(stmt)
            total_rewards = reward_result.scalar() or 0
            
            # Определяем пороговое значение для новых аккаунтов
            # Для примера: 1000 рублей для аккаунтов моложе 3 дней
            threshold = 1000
            
            if total_rewards > threshold:
                result["triggered"] = True
                risk_factor = min(1.0, total_rewards / (threshold * 2))  # Нормализация риска
                result["risk_score"] = risk_factor * self.weight
                result["details"] = {
                    "user_id": user_id,
                    "account_age_days": account_age_days,
                    "min_age_required": min_age,
                    "total_rewards": total_rewards,
                    "threshold": threshold,
                    "risk_factor": risk_factor
                }
        
        return result

class AntiFraudService:
    """Сервис обнаружения мошеннических действий в реферальной системе"""
    
    def __init__(self):
        """Инициализация сервиса"""
        self.rules = [
            MultipleRegistrationsFromIPRule(),
            RapidReferralRegistrationsRule(),
            CircularReferralChainRule(),
            UnusualTransactionPatternRule(),
            NewAccountHighRewardRule()
        ]
    
    async def check_user(self, session: AsyncSession, user_id: int, ip_address: Optional[str] = None) -> Dict[str, Any]:
        """
        Проверка пользователя на подозрительную активность
        
        Args:
            session: Активная сессия базы данных
            user_id: ID пользователя
            ip_address: IP-адрес пользователя (опционально)
            
        Returns:
            dict: Результаты проверки
        """
        results = {
            "user_id": user_id,
            "ip_address": ip_address,
            "timestamp": datetime.datetime.now().isoformat(),
            "fraud_score": 0.0,
            "risk_level": FraudRiskLevel.LOW.value,
            "rules_triggered": [],
            "details": {}
        }
        
        # Проверяем, существует ли пользователь
        user_result = await session.execute(select(User).where(User.id == user_id))
        user = user_result.scalars().first()
        
        if not user:
            results["error"] = f"User with ID {user_id} not found"
            return results
        
        # Данные для проверки
        check_data = {
            "user_id": user_id,
            "ip_address": ip_address,
            "user": user
        }
        
        # Применяем все правила
        total_score = 0.0
        total_weight = 0.0
        max_rule_score = 0.0
        
        for rule in self.rules:
            if not rule.enabled:
                continue
                
            try:
                rule_result = await rule.check(session, check_data)
                
                if rule_result["triggered"]:
                    results["rules_triggered"].append({
                        "rule_name": rule.name,
                        "rule_type": rule.rule_type.value,
                        "risk_level": rule.risk_level.value,
                        "risk_score": rule_result["risk_score"],
                        "details": rule_result["details"]
                    })
                    
                    total_score += rule_result["risk_score"]
                    total_weight += rule.weight
                    max_rule_score = max(max_rule_score, rule_result["risk_score"])
            
            except Exception as e:
                logger.error(f"Error applying rule {rule.name}: {str(e)}")
                results["details"][f"error_{rule.name}"] = str(e)
        
        # Вычисляем общую оценку риска
        if total_weight > 0:
            results["fraud_score"] = total_score / total_weight
        
        # Определяем уровень риска
        if results["fraud_score"] >= ANOMALY_SETTINGS["auto_block_threshold"]:
            results["risk_level"] = FraudRiskLevel.CRITICAL.value
        elif results["fraud_score"] >= ANOMALY_SETTINGS["suspicious_activity_threshold"]:
            results["risk_level"] = FraudRiskLevel.HIGH.value
        elif max_rule_score > 0.5:
            results["risk_level"] = FraudRiskLevel.MEDIUM.value
        else:
            results["risk_level"] = FraudRiskLevel.LOW.value
        
        # Добавляем дополнительную информацию о пользователе
        results["user_info"] = {
            "joined_at": user.joined_at.isoformat(),
            "account_age_days": (datetime.datetime.now() - user.joined_at).days,
            "has_referrer": user.referrer_id is not None
        }
        
        return results
    
    async def check_transaction(self, session: AsyncSession, transaction_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Проверка транзакции на подозрительную активность
        
        Args:
            session: Активная сессия базы данных
            transaction_data: Данные транзакции
            
        Returns:
            dict: Результаты проверки
        """
        user_id = transaction_data.get("user_id")
        if not user_id:
            return {
                "error": "User ID not provided in transaction data",
                "fraud_score": 0.0,
                "risk_level": FraudRiskLevel.LOW.value,
                "allow_transaction": True
            }
        
        # Проверяем пользователя
        user_check_result = await self.check_user(session, user_id)
        
        # Проверяем, нужно ли блокировать транзакцию
        allow_transaction = True
        
        if user_check_result["risk_level"] == FraudRiskLevel.CRITICAL.value:
            allow_transaction = False
        elif (user_check_result["risk_level"] == FraudRiskLevel.HIGH.value and 
              transaction_data.get("amount", 0) > 5000):
            allow_transaction = False
        
        # Формируем результат
        result = {
            "transaction_id": transaction_data.get("transaction_id", ""),
            "user_id": user_id,
            "timestamp": datetime.datetime.now().isoformat(),
            "fraud_score": user_check_result["fraud_score"],
            "risk_level": user_check_result["risk_level"],
            "allow_transaction": allow_transaction,
            "rules_triggered": user_check_result["rules_triggered"],
            "details": user_check_result["details"]
        }
        
        # Если транзакция заблокирована, логируем это
        if not allow_transaction:
            await self._log_blocked_transaction(session, transaction_data, result)
        
        return result
    
    async def _log_blocked_transaction(self, session: AsyncSession, transaction_data: Dict[str, Any], check_result: Dict[str, Any]) -> None:
        """
        Логирование заблокированной транзакции
        
        Args:
            session: Активная сессия базы данных
            transaction_data: Данные транзакции
            check_result: Результаты проверки
        """
        log_entry = AdminActionLog(
            admin_id=0,  # 0 означает системную запись
            action_type="antifraud_block_transaction",
            details=json.dumps({
                "transaction_data": transaction_data,
                "check_result": check_result,
                "timestamp": datetime.datetime.now().isoformat()
            })
        )
        session.add(log_entry)
        await session.commit()
    
    async def get_high_risk_users(self, session: AsyncSession, min_risk_score: float = 0.7) -> List[Dict[str, Any]]:
        """
        Получение списка пользователей с высоким уровнем риска
        
        Args:
            session: Активная сессия базы данных
            min_risk_score: Минимальная оценка риска для отбора пользователей
            
        Returns:
            list: Список пользователей с высоким уровнем риска
        """
        # В этой версии просто проверяем всех пользователей с рефералами
        result = await session.execute(
            select(User)
            .where(User.referrer_id != None)  # noqa: E711
            .order_by(desc(User.joined_at))
            .limit(100)
        )
        users = result.scalars().all()
        
        high_risk_users = []
        
        for user in users:
            check_result = await self.check_user(session, user.id)
            if check_result["fraud_score"] >= min_risk_score:
                high_risk_users.append({
                    "user_id": user.id,
                    "fraud_score": check_result["fraud_score"],
                    "risk_level": check_result["risk_level"],
                    "rules_triggered": check_result["rules_triggered"]
                })
                
                # Небольшая задержка, чтобы не перегружать систему
                await asyncio.sleep(0.1)
        
        return high_risk_users
    
    async def get_fraud_statistics(self, session: AsyncSession) -> Dict[str, Any]:
        """
        Получение статистики по обнаружению мошенничества
        
        Args:
            session: Активная сессия базы данных
            
        Returns:
            dict: Статистика по обнаружению мошенничества
        """
        # Получаем количество заблокированных транзакций
        blocked_result = await session.execute(
            select(func.count())
            .where(AdminActionLog.action_type == "antifraud_block_transaction")
        )
        blocked_count = blocked_result.scalar() or 0
        
        # Получаем количество предупреждений
        warning_result = await session.execute(
            select(func.count())
            .where(AdminActionLog.action_type == "antifraud_warning")
        )
        warning_count = warning_result.scalar() or 0
        
        # Статистика по дням
        date_result = await session.execute(
            select(
                func.date_trunc('day', AdminActionLog.timestamp).label('date'),
                func.count().label('count')
            )
            .where(AdminActionLog.action_type.in_(["antifraud_block_transaction", "antifraud_warning"]))
            .group_by(text("date"))
            .order_by(text("date"))
            .limit(30)
        )
        daily_stats = [{"date": row[0].isoformat(), "count": row[1]} for row in date_result]
        
        return {
            "total_blocked_transactions": blocked_count,
            "total_warnings": warning_count,
            "daily_stats": daily_stats,
            "top_rules": await self._get_top_triggered_rules(session)
        }
    
    async def _get_top_triggered_rules(self, session: AsyncSession) -> List[Dict[str, Any]]:
        """
        Получение топ правил, которые чаще всего срабатывают
        
        Args:
            session: Активная сессия базы данных
            
        Returns:
            list: Список правил с количеством срабатываний
        """
        # В этой версии просто возвращаем информацию о правилах
        # В реальном приложении здесь нужно анализировать логи и подсчитывать статистику
        rules_info = []
        
        for rule in self.rules:
            rules_info.append({
                "rule_name": rule.name,
                "rule_type": rule.rule_type.value,
                "risk_level": rule.risk_level.value,
                "enabled": rule.enabled
            })
        
        return rules_info

# Создаем глобальный экземпляр сервиса
async def get_antifraud_service():
    """
    Получение экземпляра сервиса обнаружения мошенничества
    
    Returns:
        AntiFraudService: Экземпляр сервиса
    """
    return AntiFraudService()