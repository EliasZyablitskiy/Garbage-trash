#!/usr/bin/env python
# coding: utf-8

"""
Инструмент для инициализации и проверки работоспособности оптимизированной реферальной системы
Может использоваться для тестирования новой реализации или миграции данных из старой системы
"""

import logging
import random
import time
from datetime import datetime, timedelta
from typing import List, Dict, Any, Tuple

from db_config import get_flask_app
from db_models import db, User, Transaction, WeeklyPayout
from new_referral_models import ReferralCode, ReferralRelation, ReferralReward
from new_referral_code.optimized_referral_manager import OptimizedReferralManager

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


class ReferralSystemInitializer:
    """Инструмент для инициализации и тестирования реферальной системы"""
    
    def __init__(self):
        self.app = get_flask_app()
        self.referral_manager = OptimizedReferralManager()
        
    def _ensure_tables_exist(self) -> None:
        """Проверка существования необходимых таблиц, создание если отсутствуют"""
        with self.app.app_context():
            db.create_all()
            logger.info("Database tables checked")
    
    def cleanup_test_data(self) -> None:
        """Очистка тестовых данных"""
        with self.app.app_context():
            # Удаляем созданные тестовые данные в правильном порядке (с учетом внешних ключей)
            ReferralReward.query.delete()
            ReferralRelation.query.delete()
            ReferralCode.query.delete()
            db.session.commit()
            logger.info("Test data cleaned up")
    
    def create_test_users(self, count: int = 10) -> List[int]:
        """
        Создание тестовых пользователей
        
        Args:
            count: Количество пользователей для создания
            
        Returns:
            List[int]: Список ID созданных пользователей
        """
        with self.app.app_context():
            user_ids = []
            
            for i in range(count):
                user = User(
                    id=1000000 + i,  # Большие ID для отличия от реальных пользователей
                    username=f"test_user_{i}",
                    first_name=f"Test{i}",
                    last_name=f"User{i}",
                    created_at=datetime.now()
                )
                db.session.add(user)
                user_ids.append(user.id)
            
            db.session.commit()
            logger.info(f"Created {len(user_ids)} test users")
            return user_ids
    
    def create_referral_hierarchy(self, user_ids: List[int], levels: int = 4) -> Dict[int, List[int]]:
        """
        Создание реферальной иерархии между пользователями
        
        Args:
            user_ids: Список ID пользователей
            levels: Количество уровней иерархии
            
        Returns:
            Dict[int, List[int]]: Словарь {user_id: [referral_ids]}
        """
        with self.app.app_context():
            # Создаем словарь с реферальной иерархией
            hierarchy = {user_id: [] for user_id in user_ids}
            
            # Создаем реферальные коды для всех пользователей
            codes = {}
            for user_id in user_ids:
                code = self.referral_manager.get_or_create_referral_code(user_id)
                codes[user_id] = code
                
            # Распределяем пользователей по уровням
            level_users = []
            users_per_level = max(1, len(user_ids) // (levels + 1))
            
            # Первый уровень - верхушка иерархии
            top_users = user_ids[:users_per_level]
            level_users.append(top_users)
            
            # Распределяем остальных по уровням
            remaining_users = user_ids[users_per_level:]
            for level in range(1, levels):
                level_size = min(users_per_level, len(remaining_users))
                if level_size == 0:
                    break
                    
                level_users.append(remaining_users[:level_size])
                remaining_users = remaining_users[level_size:]
            
            # Если остались нераспределенные пользователи, добавляем их в последний уровень
            if remaining_users:
                if len(level_users) < levels:
                    level_users.append(remaining_users)
                else:
                    level_users[-1].extend(remaining_users)
            
            # Создаем реферальные отношения
            for level in range(1, len(level_users)):
                for user_id in level_users[level]:
                    # Выбираем случайного реферера из предыдущего уровня
                    referrer_id = random.choice(level_users[level-1])
                    referrer_code = codes[referrer_id]
                    
                    # Создаем реферальное отношение
                    success = self.referral_manager.add_referral(user_id, referrer_code)
                    
                    if success:
                        hierarchy[referrer_id].append(user_id)
                        logger.debug(f"Created referral relation: {user_id} <- {referrer_id}")
                    else:
                        logger.warning(f"Failed to create referral relation: {user_id} <- {referrer_id}")
            
            logger.info(f"Created referral hierarchy with {len(level_users)} levels")
            return hierarchy
    
    def create_test_payments(self, user_ids: List[int], min_amount: float = 150.0, 
                           max_amount: float = 250.0, count_per_user: int = 1) -> List[int]:
        """
        Создание тестовых платежей и начисление реферальных вознаграждений
        
        Args:
            user_ids: Список ID пользователей
            min_amount: Минимальная сумма платежа
            max_amount: Максимальная сумма платежа
            count_per_user: Количество платежей на пользователя
            
        Returns:
            List[int]: Список ID созданных транзакций
        """
        with self.app.app_context():
            transaction_ids = []
            
            for user_id in user_ids:
                for _ in range(count_per_user):
                    # Создаем транзакцию платежа
                    amount = round(random.uniform(min_amount, max_amount), 2)
                    
                    transaction = Transaction(
                        user_id=user_id,
                        type="subscription",
                        amount=amount,
                        status="completed",
                        description="Test subscription payment",
                        created_at=datetime.now()
                    )
                    db.session.add(transaction)
                    db.session.flush()  # Получаем ID транзакции
                    
                    transaction_ids.append(transaction.id)
                    
                    # Начисляем реферальные вознаграждения
                    rewards = self.referral_manager.process_payment_rewards(
                        user_id=user_id,
                        amount=amount,
                        transaction_id=transaction.id
                    )
                    
                    if rewards:
                        logger.debug(f"Created {len(rewards)} rewards for transaction {transaction.id}")
            
            db.session.commit()
            logger.info(f"Created {len(transaction_ids)} test transactions with rewards")
            return transaction_ids
    
    def create_test_weekly_payout(self, admin_id: int) -> Tuple[int, bool]:
        """
        Создание и обработка тестовой еженедельной выплаты
        
        Args:
            admin_id: ID администратора
            
        Returns:
            Tuple[int, bool]: ID выплаты и статус обработки
        """
        with self.app.app_context():
            # Создаем еженедельную выплату
            payout_id = self.referral_manager.create_weekly_payout(
                admin_id=admin_id,
                description="Test weekly payout"
            )
            
            if not payout_id:
                logger.error("Failed to create weekly payout")
                return 0, False
                
            logger.info(f"Created weekly payout {payout_id}")
            
            # Обрабатываем выплату
            total_processed = 0
            for _ in range(10):  # Максимум 10 итераций
                success, message, processed = self.referral_manager.process_payout_batch(
                    payout_id=payout_id,
                    batch_size=50
                )
                
                logger.info(f"Batch processing: {message}")
                total_processed += processed
                
                if not success or processed == 0:
                    break
                    
                # Пауза между батчами
                time.sleep(0.5)
            
            logger.info(f"Processed total of {total_processed} rewards in payout {payout_id}")
            return payout_id, total_processed > 0
    
    def performance_test(self, user_count: int = 100, transactions_per_user: int = 2) -> Dict[str, Any]:
        """
        Проведение тестирования производительности оптимизированной реферальной системы
        
        Args:
            user_count: Количество тестовых пользователей
            transactions_per_user: Количество транзакций на пользователя
            
        Returns:
            Dict[str, Any]: Результаты теста производительности
        """
        # Проверяем существование таблиц
        self._ensure_tables_exist()
        
        results = {
            "setup": {
                "user_count": user_count,
                "transactions_per_user": transactions_per_user,
                "total_transactions": user_count * transactions_per_user
            },
            "timing": {},
            "counts": {}
        }
        
        # Замеряем время создания пользователей
        start_time = time.time()
        user_ids = self.create_test_users(user_count)
        results["timing"]["create_users"] = time.time() - start_time
        results["counts"]["users"] = len(user_ids)
        
        # Замеряем время создания реферальной иерархии
        start_time = time.time()
        hierarchy = self.create_referral_hierarchy(user_ids)
        results["timing"]["create_hierarchy"] = time.time() - start_time
        
        # Подсчитываем количество реферальных отношений
        with self.app.app_context():
            relation_count = ReferralRelation.query.count()
            results["counts"]["relations"] = relation_count
        
        # Замеряем время создания платежей и вознаграждений
        start_time = time.time()
        transaction_ids = self.create_test_payments(
            user_ids, 
            count_per_user=transactions_per_user
        )
        results["timing"]["create_payments"] = time.time() - start_time
        results["counts"]["transactions"] = len(transaction_ids)
        
        # Подсчитываем количество вознаграждений
        with self.app.app_context():
            reward_count = ReferralReward.query.count()
            results["counts"]["rewards"] = reward_count
        
        # Замеряем время получения ожидающих выплат
        start_time = time.time()
        with self.app.app_context():
            for page in range(1, 4):
                rewards, total = self.referral_manager.get_pending_rewards(page=page, page_size=25)
        results["timing"]["get_pending_rewards"] = time.time() - start_time
        results["counts"]["pending_rewards"] = total
        
        # Замеряем время создания и обработки еженедельной выплаты
        start_time = time.time()
        payout_id, success = self.create_test_weekly_payout(admin_id=user_ids[0])
        results["timing"]["process_payout"] = time.time() - start_time
        results["success"] = {
            "payout_created": payout_id > 0,
            "payout_processed": success
        }
        
        logger.info(f"Performance test completed: {results}")
        return results
    
    def run_sanity_check(self, admin_id: int) -> Dict[str, bool]:
        """
        Проведение базовой проверки работоспособности системы
        
        Args:
            admin_id: ID администратора для создания выплаты
            
        Returns:
            Dict[str, bool]: Результаты проверки
        """
        results = {}
        
        # 1. Проверка создания реферального кода
        try:
            code = self.referral_manager.get_or_create_referral_code(admin_id)
            results["create_code"] = bool(code)
        except Exception as e:
            logger.error(f"Error creating referral code: {e}")
            results["create_code"] = False
        
        # 2. Проверка доступа к списку ожидающих выплат
        try:
            pending_rewards, _ = self.referral_manager.get_pending_rewards()
            results["get_pending_rewards"] = True
        except Exception as e:
            logger.error(f"Error getting pending rewards: {e}")
            results["get_pending_rewards"] = False
        
        # 3. Проверка доступа к статистике рефералов
        try:
            stats = self.referral_manager.get_referral_stats(admin_id)
            results["get_stats"] = isinstance(stats, dict)
        except Exception as e:
            logger.error(f"Error getting referral stats: {e}")
            results["get_stats"] = False
        
        # Общий результат
        results["overall"] = all(results.values())
        
        logger.info(f"Sanity check results: {results}")
        return results


def main():
    """Основная функция для запуска инициализации и тестирования"""
    import argparse
    parser = argparse.ArgumentParser(description='Referral System Initializer')
    parser.add_argument('--test', action='store_true', help='Run performance test')
    parser.add_argument('--count', type=int, default=100, help='Number of test users')
    parser.add_argument('--admin-id', type=int, required=False, help='Admin ID for testing')
    parser.add_argument('--cleanup', action='store_true', help='Clean up test data')
    parser.add_argument('--sanity-check', action='store_true', help='Run sanity check')
    
    args = parser.parse_args()
    
    initializer = ReferralSystemInitializer()
    
    if args.cleanup:
        initializer.cleanup_test_data()
        
    if args.sanity_check:
        if not args.admin_id:
            print("Error: --admin-id is required for sanity check")
            return
            
        results = initializer.run_sanity_check(args.admin_id)
        print(f"Sanity check results: {'SUCCESS' if results['overall'] else 'FAILED'}")
        
    if args.test:
        results = initializer.performance_test(user_count=args.count)
        print("Performance test results:")
        for category, data in results.items():
            print(f"- {category}:")
            for key, value in data.items():
                print(f"  - {key}: {value}")


if __name__ == "__main__":
    main()