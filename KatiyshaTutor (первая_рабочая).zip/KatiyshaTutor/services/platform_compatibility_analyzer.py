#!/usr/bin/env python
# coding: utf-8

"""
Сервис анализа результатов тестирования кросс-платформенной совместимости
Позволяет агрегировать и визуализировать данные о совместимости бота
с различными платформами и версиями клиентов Telegram
"""

import logging
import json
import os
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import matplotlib
import numpy as np
from io import BytesIO
import time
from collections import defaultdict

from db_models import PlatformTestResult, db
from services.platform_detection_service import (
    PLATFORM_IOS, PLATFORM_ANDROID, PLATFORM_DESKTOP, 
    PLATFORM_WEB, PLATFORM_UNKNOWN
)

# Настройка для работы с matplotlib без GUI
matplotlib.use('Agg')

# Настройка логгера
logger = logging.getLogger(__name__)

# Список всех проверяемых функций в тестах
TEST_CATEGORIES = [
    "message_formatting", 
    "emoji_compatibility", 
    "qr_code_generation", 
    "payment_settings", 
    "ai_compatibility"
]

# Названия платформ для отображения
PLATFORM_DISPLAY_NAMES = {
    PLATFORM_IOS: "iOS",
    PLATFORM_ANDROID: "Android",
    PLATFORM_DESKTOP: "Desktop",
    PLATFORM_WEB: "Web",
    PLATFORM_UNKNOWN: "Unknown"
}

class PlatformCompatibilityAnalyzer:
    """
    Класс для анализа результатов тестирования кросс-платформенной совместимости
    """
    
    @staticmethod
    def get_compatibility_summary(days: int = 30) -> Dict[str, Any]:
        """
        Получает общую статистику совместимости за указанный период
        
        Args:
            days: Количество дней для анализа (по умолчанию 30)
            
        Returns:
            Dict[str, Any]: Статистика совместимости
        """
        try:
            # Определяем дату начала периода
            start_date = datetime.now() - timedelta(days=days)
            
            # Получаем все результаты тестов за указанный период
            with db.Session() as session:
                test_results = session.query(PlatformTestResult).filter(
                    PlatformTestResult.timestamp >= start_date
                ).all()
                
                if not test_results:
                    return {
                        "status": "no_data",
                        "message": f"Нет данных о тестировании за последние {days} дней",
                        "period": {
                            "days": days,
                            "start_date": start_date.isoformat(),
                            "end_date": datetime.now().isoformat()
                        }
                    }
                
                # Подготавливаем структуры для анализа
                platform_stats = defaultdict(lambda: {
                    "total_tests": 0,
                    "passed_tests": 0,
                    "failed_tests": 0,
                    "pass_rate": 0,
                    "versions": defaultdict(lambda: {
                        "total_tests": 0,
                        "passed_tests": 0,
                        "failed_tests": 0,
                        "pass_rate": 0,
                        "test_details": defaultdict(lambda: {
                            "passed": 0,
                            "failed": 0,
                            "pass_rate": 0
                        })
                    })
                })
                
                overall_stats = {
                    "total_tests": 0,
                    "passed_tests": 0,
                    "failed_tests": 0,
                    "pass_rate": 0,
                    "unique_users": set(),
                    "unique_platforms": set(),
                    "unique_versions": defaultdict(set)
                }
                
                # Проходим по всем результатам тестов
                for result in test_results:
                    platform_type = result.platform_type
                    platform_version = result.platform_version or "unknown"
                    
                    # Общая статистика
                    overall_stats["total_tests"] += 1
                    overall_stats["passed_tests"] += result.tests_passed
                    overall_stats["failed_tests"] += result.tests_failed
                    overall_stats["unique_users"].add(result.user_id)
                    overall_stats["unique_platforms"].add(platform_type)
                    overall_stats["unique_versions"][platform_type].add(platform_version)
                    
                    # Статистика по платформам
                    platform_stats[platform_type]["total_tests"] += 1
                    platform_stats[platform_type]["passed_tests"] += result.tests_passed
                    platform_stats[platform_type]["failed_tests"] += result.tests_failed
                    
                    # Статистика по версиям платформ
                    platform_stats[platform_type]["versions"][platform_version]["total_tests"] += 1
                    platform_stats[platform_type]["versions"][platform_version]["passed_tests"] += result.tests_passed
                    platform_stats[platform_type]["versions"][platform_version]["failed_tests"] += result.tests_failed
                    
                    # Детализация по конкретным тестам
                    if result.results_json:
                        try:
                            results_data = json.loads(result.results_json)
                            
                            for test_category, test_result in results_data.items():
                                if isinstance(test_result, dict) and "status" in test_result:
                                    status = test_result["status"]
                                    if status == "passed":
                                        platform_stats[platform_type]["versions"][platform_version]["test_details"][test_category]["passed"] += 1
                                    else:
                                        platform_stats[platform_type]["versions"][platform_version]["test_details"][test_category]["failed"] += 1
                        except (json.JSONDecodeError, TypeError) as e:
                            logger.warning(f"Ошибка при анализе JSON результатов: {e}")
                
                # Рассчитываем проценты успешности
                if overall_stats["passed_tests"] + overall_stats["failed_tests"] > 0:
                    overall_stats["pass_rate"] = round(
                        overall_stats["passed_tests"] / 
                        (overall_stats["passed_tests"] + overall_stats["failed_tests"]) * 100,
                        2
                    )
                
                # Преобразуем структуру данных для удобства использования
                result_dict = {
                    "status": "success",
                    "period": {
                        "days": days,
                        "start_date": start_date.isoformat(),
                        "end_date": datetime.now().isoformat()
                    },
                    "overall": {
                        "total_tests": overall_stats["total_tests"],
                        "passed_tests": overall_stats["passed_tests"],
                        "failed_tests": overall_stats["failed_tests"],
                        "pass_rate": overall_stats["pass_rate"],
                        "unique_users": len(overall_stats["unique_users"]),
                        "unique_platforms": len(overall_stats["unique_platforms"]),
                        "platforms": list(overall_stats["unique_platforms"])
                    },
                    "platforms": {}
                }
                
                # Заполняем данные по платформам
                for platform, stats in platform_stats.items():
                    # Рассчитываем процент успешности для платформы
                    platform_pass_rate = 0
                    if stats["passed_tests"] + stats["failed_tests"] > 0:
                        platform_pass_rate = round(
                            stats["passed_tests"] / 
                            (stats["passed_tests"] + stats["failed_tests"]) * 100,
                            2
                        )
                    
                    # Преобразуем defaultdict в обычный словарь для версий
                    versions_dict = {}
                    for version, version_stats in stats["versions"].items():
                        # Рассчитываем процент успешности для версии
                        version_pass_rate = 0
                        if version_stats["passed_tests"] + version_stats["failed_tests"] > 0:
                            version_pass_rate = round(
                                version_stats["passed_tests"] / 
                                (version_stats["passed_tests"] + version_stats["failed_tests"]) * 100,
                                2
                            )
                        
                        # Преобразуем test_details в обычный словарь
                        test_details_dict = {}
                        for test, test_stats in version_stats["test_details"].items():
                            # Рассчитываем процент успешности для теста
                            test_pass_rate = 0
                            total_test_runs = test_stats["passed"] + test_stats["failed"]
                            if total_test_runs > 0:
                                test_pass_rate = round(
                                    test_stats["passed"] / total_test_runs * 100,
                                    2
                                )
                            
                            test_details_dict[test] = {
                                "passed": test_stats["passed"],
                                "failed": test_stats["failed"],
                                "pass_rate": test_pass_rate
                            }
                        
                        versions_dict[version] = {
                            "total_tests": version_stats["total_tests"],
                            "passed_tests": version_stats["passed_tests"],
                            "failed_tests": version_stats["failed_tests"],
                            "pass_rate": version_pass_rate,
                            "test_details": test_details_dict
                        }
                    
                    result_dict["platforms"][platform] = {
                        "display_name": PLATFORM_DISPLAY_NAMES.get(platform, platform),
                        "total_tests": stats["total_tests"],
                        "passed_tests": stats["passed_tests"],
                        "failed_tests": stats["failed_tests"],
                        "pass_rate": platform_pass_rate,
                        "versions": versions_dict,
                        "unique_versions": len(overall_stats["unique_versions"][platform])
                    }
                
                return result_dict
                
        except Exception as e:
            logger.error(f"Ошибка при анализе результатов тестирования: {e}")
            return {
                "status": "error",
                "message": f"Ошибка при анализе результатов: {str(e)}",
                "period": {
                    "days": days,
                    "start_date": start_date.isoformat() if 'start_date' in locals() else None,
                    "end_date": datetime.now().isoformat()
                }
            }
    
    @staticmethod
    def generate_platform_chart(days: int = 30) -> Tuple[Optional[BytesIO], str]:
        """
        Создает графическое представление совместимости по платформам
        
        Args:
            days: Количество дней для анализа
            
        Returns:
            Tuple[BytesIO, str]: Изображение графика в формате PNG и путь к файлу
        """
        try:
            # Получаем статистику совместимости
            summary = PlatformCompatibilityAnalyzer.get_compatibility_summary(days)
            
            if summary["status"] != "success":
                logger.warning(f"Не удалось получить данные для графика: {summary['message']}")
                return None, "Нет данных для построения графика"
            
            # Создаем временный файл для графика
            timestamp = int(time.time())
            chart_filename = f"temp_charts/platform_compatibility_{timestamp}.png"
            os.makedirs("temp_charts", exist_ok=True)
            
            # Настройка графика
            plt.figure(figsize=(12, 8))
            plt.style.use('dark_background')
            
            # Данные для графика
            platforms = []
            pass_rates = []
            
            for platform, stats in summary["platforms"].items():
                platforms.append(PLATFORM_DISPLAY_NAMES.get(platform, platform))
                pass_rates.append(stats["pass_rate"])
            
            # Создаем цветовую схему
            colors = []
            for rate in pass_rates:
                if rate >= 90:
                    colors.append('green')
                elif rate >= 70:
                    colors.append('yellow')
                else:
                    colors.append('red')
            
            # Сортируем данные по проценту успешности
            sorted_data = sorted(zip(platforms, pass_rates, colors), key=lambda x: x[1])
            platforms = [x[0] for x in sorted_data]
            pass_rates = [x[1] for x in sorted_data]
            colors = [x[2] for x in sorted_data]
            
            # Строим горизонтальный бар-чарт
            y_pos = np.arange(len(platforms))
            bars = plt.barh(y_pos, pass_rates, align='center', color=colors)
            plt.yticks(y_pos, platforms, fontsize=12)
            plt.xlabel('Процент успешности (%)', fontsize=12)
            plt.title(f'Совместимость по платформам за последние {days} дней', fontsize=14)
            
            # Добавляем значения на график
            for i, bar in enumerate(bars):
                plt.text(bar.get_width() + 1, bar.get_y() + bar.get_height()/2, 
                        f'{pass_rates[i]}%', va='center', fontsize=10)
            
            # Настройки графика
            plt.xlim(0, 105)  # Шкала от 0 до 105% для отображения текста
            plt.grid(axis='x', linestyle='--', alpha=0.6)
            plt.tight_layout()
            
            # Сохраняем график в файл и в память
            plt.savefig(chart_filename, dpi=100, bbox_inches='tight')
            
            # Создаем объект BytesIO для передачи данных
            img_data = BytesIO()
            plt.savefig(img_data, format='png', dpi=100, bbox_inches='tight')
            img_data.seek(0)
            
            plt.close()
            
            return img_data, chart_filename
            
        except Exception as e:
            logger.error(f"Ошибка при создании графика платформ: {e}")
            return None, f"Ошибка при создании графика: {str(e)}"
    
    @staticmethod
    def generate_feature_chart(days: int = 30) -> Tuple[Optional[BytesIO], str]:
        """
        Создает графическое представление совместимости по функциям
        
        Args:
            days: Количество дней для анализа
            
        Returns:
            Tuple[BytesIO, str]: Изображение графика в формате PNG и путь к файлу
        """
        try:
            # Получаем статистику совместимости
            summary = PlatformCompatibilityAnalyzer.get_compatibility_summary(days)
            
            if summary["status"] != "success":
                logger.warning(f"Не удалось получить данные для графика функций: {summary['message']}")
                return None, "Нет данных для построения графика"
            
            # Создаем временный файл для графика
            timestamp = int(time.time())
            chart_filename = f"temp_charts/feature_compatibility_{timestamp}.png"
            os.makedirs("temp_charts", exist_ok=True)
            
            # Настройка графика
            plt.figure(figsize=(12, 8))
            plt.style.use('dark_background')
            
            # Собираем данные по категориям тестов
            test_categories = TEST_CATEGORIES
            platforms = [PLATFORM_DISPLAY_NAMES.get(platform, platform) for platform in summary["platforms"].keys()]
            
            # Матрица данных
            data = np.zeros((len(platforms), len(test_categories)))
            
            # Заполняем матрицу данными
            for i, platform in enumerate(summary["platforms"].keys()):
                platform_stats = summary["platforms"][platform]
                for version, version_stats in platform_stats["versions"].items():
                    for j, category in enumerate(test_categories):
                        if category in version_stats["test_details"]:
                            test_data = version_stats["test_details"][category]
                            # Если есть данные по этой категории, добавляем процент успешности
                            total_runs = test_data["passed"] + test_data["failed"]
                            if total_runs > 0:
                                # Добавляем взвешенное значение к текущему
                                weight = version_stats["total_tests"] / platform_stats["total_tests"]
                                data[i, j] += (test_data["pass_rate"] * weight)
            
            # Создаем heatmap
            fig, ax = plt.subplots(figsize=(12, 8))
            im = ax.imshow(data, cmap='RdYlGn')
            
            # Настройки осей
            ax.set_xticks(np.arange(len(test_categories)))
            ax.set_yticks(np.arange(len(platforms)))
            ax.set_xticklabels(test_categories, fontsize=12)
            ax.set_yticklabels(platforms, fontsize=12)
            
            # Поворачиваем подписи категорий для лучшей читаемости
            plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")
            
            # Подписи значений в ячейках
            for i in range(len(platforms)):
                for j in range(len(test_categories)):
                    text = ax.text(j, i, f"{data[i, j]:.1f}%",
                                  ha="center", va="center", color="black" if data[i, j] > 60 else "white")
            
            # Заголовок и цветовая шкала
            ax.set_title(f"Совместимость функций по платформам за последние {days} дней", fontsize=14)
            cbar = fig.colorbar(im, ax=ax)
            cbar.set_label('Процент успешности (%)', fontsize=12)
            
            plt.tight_layout()
            
            # Сохраняем график в файл и в память
            plt.savefig(chart_filename, dpi=100, bbox_inches='tight')
            
            # Создаем объект BytesIO для передачи данных
            img_data = BytesIO()
            plt.savefig(img_data, format='png', dpi=100, bbox_inches='tight')
            img_data.seek(0)
            
            plt.close()
            
            return img_data, chart_filename
            
        except Exception as e:
            logger.error(f"Ошибка при создании графика функций: {e}")
            return None, f"Ошибка при создании графика: {str(e)}"
    
    @staticmethod
    def generate_compatibility_report(days: int = 30, format: str = "text") -> str:
        """
        Генерирует отчет о совместимости в указанном формате
        
        Args:
            days: Количество дней для анализа
            format: Формат отчета ("text", "html", "markdown")
            
        Returns:
            str: Отчет о совместимости
        """
        try:
            # Получаем статистику совместимости
            summary = PlatformCompatibilityAnalyzer.get_compatibility_summary(days)
            
            if summary["status"] != "success":
                return f"Не удалось сформировать отчет: {summary.get('message', 'неизвестная ошибка')}"
            
            # Формируем текстовый отчет
            if format == "text":
                report = [
                    f"ОТЧЕТ О КРОСС-ПЛАТФОРМЕННОЙ СОВМЕСТИМОСТИ БОТА",
                    f"Период: последние {days} дней ({summary['period']['start_date']} - {summary['period']['end_date']})",
                    f"",
                    f"ОБЩАЯ СТАТИСТИКА:",
                    f"- Всего тестов: {summary['overall']['total_tests']}",
                    f"- Успешно пройдено: {summary['overall']['passed_tests']}",
                    f"- Не пройдено: {summary['overall']['failed_tests']}",
                    f"- Процент успешности: {summary['overall']['pass_rate']}%",
                    f"- Уникальных пользователей: {summary['overall']['unique_users']}",
                    f"- Уникальных платформ: {summary['overall']['unique_platforms']}",
                    f"",
                    f"СТАТИСТИКА ПО ПЛАТФОРМАМ:"
                ]
                
                # Сортируем платформы по проценту успешности (по убыванию)
                sorted_platforms = sorted(
                    summary["platforms"].items(), 
                    key=lambda x: x[1]["pass_rate"], 
                    reverse=True
                )
                
                for platform, stats in sorted_platforms:
                    report.append(f"")
                    report.append(f"{stats['display_name']} ({platform}):")
                    report.append(f"- Всего тестов: {stats['total_tests']}")
                    report.append(f"- Успешно пройдено: {stats['passed_tests']}")
                    report.append(f"- Не пройдено: {stats['failed_tests']}")
                    report.append(f"- Процент успешности: {stats['pass_rate']}%")
                    report.append(f"- Уникальных версий: {stats['unique_versions']}")
                    
                    # Добавляем информацию по версиям
                    if stats["versions"]:
                        report.append(f"  Основные версии:")
                        
                        # Сортируем версии по количеству тестов (по убыванию)
                        sorted_versions = sorted(
                            stats["versions"].items(), 
                            key=lambda x: x[1]["total_tests"], 
                            reverse=True
                        )
                        
                        # Выводим топ-5 версий
                        for i, (version, version_stats) in enumerate(sorted_versions[:5]):
                            report.append(f"  {i+1}. Версия {version}: {version_stats['pass_rate']}% " +
                                         f"({version_stats['passed_tests']}/{version_stats['total_tests']} тестов)")
                
                # Формируем рекомендации на основе результатов
                report.append(f"")
                report.append(f"РЕКОМЕНДАЦИИ:")
                
                # Проверяем платформы с низкой совместимостью
                problematic_platforms = [
                    (platform, stats) for platform, stats in summary["platforms"].items()
                    if stats["pass_rate"] < 80
                ]
                
                if problematic_platforms:
                    report.append(f"1. Обратить внимание на следующие платформы с низкой совместимостью:")
                    for platform, stats in problematic_platforms:
                        report.append(f"   - {stats['display_name']}: {stats['pass_rate']}% успешности")
                        
                        # Ищем проблемные версии
                        problematic_versions = [
                            (version, v_stats) for version, v_stats in stats["versions"].items()
                            if v_stats["pass_rate"] < 70 and v_stats["total_tests"] >= 3
                        ]
                        
                        if problematic_versions:
                            for version, v_stats in problematic_versions[:3]:
                                report.append(f"     * Версия {version}: {v_stats['pass_rate']}% успешности")
                                
                                # Ищем проблемные функции
                                problematic_features = [
                                    (feature, f_stats) for feature, f_stats in v_stats["test_details"].items()
                                    if f_stats["pass_rate"] < 70
                                ]
                                
                                if problematic_features:
                                    for feature, f_stats in problematic_features:
                                        report.append(f"       - {feature}: {f_stats['pass_rate']}% успешности")
                
                # Формируем общие рекомендации
                report.append(f"2. Общие рекомендации по повышению совместимости:")
                report.append(f"   - Регулярный мониторинг новых версий клиентов Telegram")
                report.append(f"   - Тестирование бота на различных устройствах и версиях ОС")
                report.append(f"   - Адаптивное форматирование сообщений в зависимости от платформы")
                report.append(f"   - Оптимизация размера и качества медиа-контента")
                
                return "\n".join(report)
                
            elif format == "markdown":
                # Формируем отчет в формате Markdown
                report = [
                    f"# Отчет о кросс-платформенной совместимости бота",
                    f"Период: последние {days} дней ({summary['period']['start_date']} - {summary['period']['end_date']})",
                    f"",
                    f"## Общая статистика",
                    f"- **Всего тестов:** {summary['overall']['total_tests']}",
                    f"- **Успешно пройдено:** {summary['overall']['passed_tests']}",
                    f"- **Не пройдено:** {summary['overall']['failed_tests']}",
                    f"- **Процент успешности:** {summary['overall']['pass_rate']}%",
                    f"- **Уникальных пользователей:** {summary['overall']['unique_users']}",
                    f"- **Уникальных платформ:** {summary['overall']['unique_platforms']}",
                    f"",
                    f"## Статистика по платформам"
                ]
                
                # Сортируем платформы по проценту успешности (по убыванию)
                sorted_platforms = sorted(
                    summary["platforms"].items(), 
                    key=lambda x: x[1]["pass_rate"], 
                    reverse=True
                )
                
                for platform, stats in sorted_platforms:
                    report.append(f"")
                    report.append(f"### {stats['display_name']} ({platform})")
                    report.append(f"- **Всего тестов:** {stats['total_tests']}")
                    report.append(f"- **Успешно пройдено:** {stats['passed_tests']}")
                    report.append(f"- **Не пройдено:** {stats['failed_tests']}")
                    report.append(f"- **Процент успешности:** {stats['pass_rate']}%")
                    report.append(f"- **Уникальных версий:** {stats['unique_versions']}")
                    
                    # Добавляем информацию по версиям
                    if stats["versions"]:
                        report.append(f"#### Основные версии:")
                        
                        # Сортируем версии по количеству тестов (по убыванию)
                        sorted_versions = sorted(
                            stats["versions"].items(), 
                            key=lambda x: x[1]["total_tests"], 
                            reverse=True
                        )
                        
                        # Создаем таблицу для топ-5 версий
                        report.append(f"| Версия | Успешность | Пройдено/Всего |")
                        report.append(f"|--------|------------|---------------|")
                        
                        for version, version_stats in sorted_versions[:5]:
                            report.append(f"| {version} | {version_stats['pass_rate']}% | " + 
                                         f"{version_stats['passed_tests']}/{version_stats['total_tests']} |")
                
                # Формируем рекомендации на основе результатов
                report.append(f"")
                report.append(f"## Рекомендации")
                
                # Проверяем платформы с низкой совместимостью
                problematic_platforms = [
                    (platform, stats) for platform, stats in summary["platforms"].items()
                    if stats["pass_rate"] < 80
                ]
                
                if problematic_platforms:
                    report.append(f"### 1. Обратить внимание на следующие платформы с низкой совместимостью:")
                    for platform, stats in problematic_platforms:
                        report.append(f"- **{stats['display_name']}**: {stats['pass_rate']}% успешности")
                        
                        # Ищем проблемные версии
                        problematic_versions = [
                            (version, v_stats) for version, v_stats in stats["versions"].items()
                            if v_stats["pass_rate"] < 70 and v_stats["total_tests"] >= 3
                        ]
                        
                        if problematic_versions:
                            for version, v_stats in problematic_versions[:3]:
                                report.append(f"  - Версия **{version}**: {v_stats['pass_rate']}% успешности")
                                
                                # Ищем проблемные функции
                                problematic_features = [
                                    (feature, f_stats) for feature, f_stats in v_stats["test_details"].items()
                                    if f_stats["pass_rate"] < 70
                                ]
                                
                                if problematic_features:
                                    report.append(f"    - Проблемные функции:")
                                    for feature, f_stats in problematic_features:
                                        report.append(f"      - *{feature}*: {f_stats['pass_rate']}% успешности")
                
                # Формируем общие рекомендации
                report.append(f"### 2. Общие рекомендации по повышению совместимости:")
                report.append(f"- Регулярный мониторинг новых версий клиентов Telegram")
                report.append(f"- Тестирование бота на различных устройствах и версиях ОС")
                report.append(f"- Адаптивное форматирование сообщений в зависимости от платформы")
                report.append(f"- Оптимизация размера и качества медиа-контента")
                
                return "\n".join(report)
                
            elif format == "html":
                # Формируем отчет в формате HTML
                report = [
                    f"<!DOCTYPE html>",
                    f"<html>",
                    f"<head>",
                    f"<meta charset='utf-8'>",
                    f"<title>Отчет о кросс-платформенной совместимости бота</title>",
                    f"<style>",
                    f"body {{ font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }}",
                    f"h1, h2, h3 {{ color: #2c3e50; }}",
                    f"table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}",
                    f"th, td {{ text-align: left; padding: 8px; border: 1px solid #ddd; }}",
                    f"th {{ background-color: #f2f2f2; }}",
                    f"tr:nth-child(even) {{ background-color: #f9f9f9; }}",
                    f".good {{ color: green; }}",
                    f".warning {{ color: orange; }}",
                    f".bad {{ color: red; }}",
                    f".summary-box {{ background-color: #f8f9fa; border: 1px solid #ddd; padding: 15px; border-radius: 5px; margin: 20px 0; }}",
                    f"</style>",
                    f"</head>",
                    f"<body>",
                    f"<h1>Отчет о кросс-платформенной совместимости бота</h1>",
                    f"<p>Период: последние {days} дней ({summary['period']['start_date']} - {summary['period']['end_date']})</p>",
                    f"",
                    f"<div class='summary-box'>",
                    f"<h2>Общая статистика</h2>",
                    f"<ul>",
                    f"<li><strong>Всего тестов:</strong> {summary['overall']['total_tests']}</li>",
                    f"<li><strong>Успешно пройдено:</strong> {summary['overall']['passed_tests']}</li>",
                    f"<li><strong>Не пройдено:</strong> {summary['overall']['failed_tests']}</li>"
                ]
                
                # Определяем класс для выделения цветом
                overall_class = "good" if summary['overall']['pass_rate'] >= 90 else ("warning" if summary['overall']['pass_rate'] >= 70 else "bad")
                report.append(f"<li><strong>Процент успешности:</strong> <span class='{overall_class}'>{summary['overall']['pass_rate']}%</span></li>")
                
                report.extend([
                    f"<li><strong>Уникальных пользователей:</strong> {summary['overall']['unique_users']}</li>",
                    f"<li><strong>Уникальных платформ:</strong> {summary['overall']['unique_platforms']}</li>",
                    f"</ul>",
                    f"</div>",
                    f"",
                    f"<h2>Статистика по платформам</h2>"
                ])
                
                # Сортируем платформы по проценту успешности (по убыванию)
                sorted_platforms = sorted(
                    summary["platforms"].items(), 
                    key=lambda x: x[1]["pass_rate"], 
                    reverse=True
                )
                
                for platform, stats in sorted_platforms:
                    # Определяем класс для выделения цветом
                    platform_class = "good" if stats['pass_rate'] >= 90 else ("warning" if stats['pass_rate'] >= 70 else "bad")
                    
                    report.extend([
                        f"<div class='platform-box'>",
                        f"<h3>{stats['display_name']} ({platform})</h3>",
                        f"<ul>",
                        f"<li><strong>Всего тестов:</strong> {stats['total_tests']}</li>",
                        f"<li><strong>Успешно пройдено:</strong> {stats['passed_tests']}</li>",
                        f"<li><strong>Не пройдено:</strong> {stats['failed_tests']}</li>",
                        f"<li><strong>Процент успешности:</strong> <span class='{platform_class}'>{stats['pass_rate']}%</span></li>",
                        f"<li><strong>Уникальных версий:</strong> {stats['unique_versions']}</li>",
                        f"</ul>"
                    ])
                    
                    # Добавляем информацию по версиям
                    if stats["versions"]:
                        report.append(f"<h4>Основные версии:</h4>")
                        
                        # Сортируем версии по количеству тестов (по убыванию)
                        sorted_versions = sorted(
                            stats["versions"].items(), 
                            key=lambda x: x[1]["total_tests"], 
                            reverse=True
                        )
                        
                        # Создаем таблицу для топ-5 версий
                        report.extend([
                            f"<table>",
                            f"<tr>",
                            f"<th>Версия</th>",
                            f"<th>Успешность</th>",
                            f"<th>Пройдено/Всего</th>",
                            f"<th>Подробности</th>",
                            f"</tr>"
                        ])
                        
                        for version, version_stats in sorted_versions[:5]:
                            # Определяем класс для выделения цветом
                            version_class = "good" if version_stats['pass_rate'] >= 90 else ("warning" if version_stats['pass_rate'] >= 70 else "bad")
                            
                            # Формируем подробности в виде списка проблемных тестов
                            details = []
                            for test, test_stats in version_stats["test_details"].items():
                                if test_stats["pass_rate"] < 70:
                                    details.append(f"{test}: {test_stats['pass_rate']}%")
                            
                            details_html = "<ul>" + "".join([f"<li>{d}</li>" for d in details]) + "</ul>" if details else "Все тесты успешны"
                            
                            report.append(f"<tr>")
                            report.append(f"<td>{version}</td>")
                            report.append(f"<td class='{version_class}'>{version_stats['pass_rate']}%</td>")
                            report.append(f"<td>{version_stats['passed_tests']}/{version_stats['total_tests']}</td>")
                            report.append(f"<td>{details_html}</td>")
                            report.append(f"</tr>")
                        
                        report.append(f"</table>")
                    
                    report.append(f"</div>")
                
                # Формируем рекомендации на основе результатов
                report.extend([
                    f"<h2>Рекомендации</h2>",
                    f"<div class='recommendations-box'>"
                ])
                
                # Проверяем платформы с низкой совместимостью
                problematic_platforms = [
                    (platform, stats) for platform, stats in summary["platforms"].items()
                    if stats["pass_rate"] < 80
                ]
                
                if problematic_platforms:
                    report.append(f"<h3>1. Обратить внимание на следующие платформы с низкой совместимостью:</h3>")
                    report.append(f"<ul>")
                    
                    for platform, stats in problematic_platforms:
                        report.append(f"<li><strong>{stats['display_name']}</strong>: <span class='bad'>{stats['pass_rate']}%</span> успешности")
                        
                        # Ищем проблемные версии
                        problematic_versions = [
                            (version, v_stats) for version, v_stats in stats["versions"].items()
                            if v_stats["pass_rate"] < 70 and v_stats["total_tests"] >= 3
                        ]
                        
                        if problematic_versions:
                            report.append(f"<ul>")
                            for version, v_stats in problematic_versions[:3]:
                                report.append(f"<li>Версия <strong>{version}</strong>: <span class='bad'>{v_stats['pass_rate']}%</span> успешности")
                                
                                # Ищем проблемные функции
                                problematic_features = [
                                    (feature, f_stats) for feature, f_stats in v_stats["test_details"].items()
                                    if f_stats["pass_rate"] < 70
                                ]
                                
                                if problematic_features:
                                    report.append(f"<ul>")
                                    for feature, f_stats in problematic_features:
                                        report.append(f"<li><em>{feature}</em>: <span class='bad'>{f_stats['pass_rate']}%</span> успешности</li>")
                                    report.append(f"</ul>")
                                
                                report.append(f"</li>")
                            report.append(f"</ul>")
                        
                        report.append(f"</li>")
                    
                    report.append(f"</ul>")
                
                # Формируем общие рекомендации
                report.extend([
                    f"<h3>2. Общие рекомендации по повышению совместимости:</h3>",
                    f"<ul>",
                    f"<li>Регулярный мониторинг новых версий клиентов Telegram</li>",
                    f"<li>Тестирование бота на различных устройствах и версиях ОС</li>",
                    f"<li>Адаптивное форматирование сообщений в зависимости от платформы</li>",
                    f"<li>Оптимизация размера и качества медиа-контента</li>",
                    f"</ul>",
                    f"</div>",
                    f"</body>",
                    f"</html>"
                ])
                
                return "\n".join(report)
            
            else:
                return f"Неподдерживаемый формат отчета: {format}"
            
        except Exception as e:
            logger.error(f"Ошибка при формировании отчета: {e}")
            return f"Не удалось сформировать отчет: {str(e)}"

# Функция для получения статистики совместимости
def get_platform_compatibility_summary(days: int = 30) -> Dict[str, Any]:
    """
    Получает сводную статистику о совместимости платформ
    
    Args:
        days: Количество дней для анализа
        
    Returns:
        Dict[str, Any]: Статистика совместимости
    """
    return PlatformCompatibilityAnalyzer.get_compatibility_summary(days)

# Функция для генерации отчета о совместимости
def generate_compatibility_report(days: int = 30, format: str = "text") -> str:
    """
    Генерирует отчет о совместимости в указанном формате
    
    Args:
        days: Количество дней для анализа
        format: Формат отчета ("text", "html", "markdown")
        
    Returns:
        str: Отчет о совместимости
    """
    return PlatformCompatibilityAnalyzer.generate_compatibility_report(days, format)

# Функция для генерации графика совместимости платформ
def generate_platform_chart(days: int = 30) -> Tuple[Optional[BytesIO], str]:
    """
    Создает графическое представление совместимости по платформам
    
    Args:
        days: Количество дней для анализа
        
    Returns:
        Tuple[Optional[BytesIO], str]: Изображение графика и путь к файлу
    """
    return PlatformCompatibilityAnalyzer.generate_platform_chart(days)

# Функция для генерации графика совместимости функций
def generate_feature_chart(days: int = 30) -> Tuple[Optional[BytesIO], str]:
    """
    Создает графическое представление совместимости по функциям
    
    Args:
        days: Количество дней для анализа
        
    Returns:
        Tuple[Optional[BytesIO], str]: Изображение графика и путь к файлу
    """
    return PlatformCompatibilityAnalyzer.generate_feature_chart(days)