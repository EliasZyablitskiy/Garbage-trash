from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, HiddenField
from wtforms.validators import DataRequired, Length, Optional, ValidationError
import re

class LoginForm(FlaskForm):
    """Форма для входа администратора"""
    telegram_id = StringField('Telegram ID', validators=[DataRequired(message="Введите Telegram ID")])
    password = PasswordField('Пароль', validators=[DataRequired(message="Введите пароль")])
    remember = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')

class Verify2FAForm(FlaskForm):
    """Форма для проверки двухфакторной аутентификации"""
    code = StringField('Код 2FA', validators=[
        DataRequired(message="Введите код 2FA"), 
        Length(min=6, max=6, message="Код должен содержать 6 цифр")
    ])
    admin_id = HiddenField('ID администратора')
    submit = SubmitField('Проверить')

class ChangePasswordForm(FlaskForm):
    """Форма для изменения пароля администратора"""
    current_password = PasswordField('Текущий пароль', validators=[DataRequired(message="Введите текущий пароль")])
    new_password = PasswordField('Новый пароль', validators=[
        DataRequired(message="Введите новый пароль"),
        Length(min=10, message="Пароль должен содержать не менее 10 символов")
    ])
    confirm_password = PasswordField('Подтвердите пароль', validators=[
        DataRequired(message="Подтвердите новый пароль")
    ])
    submit = SubmitField('Изменить пароль')
    
    def validate_new_password(self, field):
        """Проверка сложности пароля"""
        password = field.data
        
        if not re.search(r'[A-Z]', password):
            raise ValidationError('Пароль должен содержать хотя бы одну заглавную букву')
        
        if not re.search(r'[a-z]', password):
            raise ValidationError('Пароль должен содержать хотя бы одну строчную букву')
        
        if not re.search(r'\d', password):
            raise ValidationError('Пароль должен содержать хотя бы одну цифру')
        
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            raise ValidationError('Пароль должен содержать хотя бы один специальный символ')
    
    def validate_confirm_password(self, field):
        """Проверка совпадения паролей"""
        if field.data != self.new_password.data:
            raise ValidationError('Пароли не совпадают')

class Setup2FAForm(FlaskForm):
    """Форма для настройки двухфакторной аутентификации"""
    verification_code = StringField('Код подтверждения', validators=[
        DataRequired(message="Введите код подтверждения"), 
        Length(min=6, max=6, message="Код должен содержать 6 цифр")
    ])
    current_password = PasswordField('Текущий пароль', validators=[
        DataRequired(message="Введите текущий пароль для подтверждения")
    ])
    submit = SubmitField('Активировать 2FA')

class Disable2FAForm(FlaskForm):
    """Форма для отключения двухфакторной аутентификации"""
    verification_code = StringField('Код подтверждения', validators=[
        DataRequired(message="Введите текущий код 2FA"), 
        Length(min=6, max=6, message="Код должен содержать 6 цифр")
    ])
    current_password = PasswordField('Текущий пароль', validators=[
        DataRequired(message="Введите текущий пароль для подтверждения")
    ])
    submit = SubmitField('Отключить 2FA')

class UserBlockForm(FlaskForm):
    """Форма для блокировки/разблокировки пользователя"""
    reason = StringField('Причина', validators=[
        Optional()
    ])
    submit = SubmitField('Подтвердить')

class ConfirmActionForm(FlaskForm):
    """Форма для подтверждения действий, требующих дополнительной проверки"""
    confirm = BooleanField('Подтверждаю', validators=[DataRequired(message="Вы должны подтвердить это действие")])
    action_id = HiddenField('ID действия')
    submit = SubmitField('Выполнить')

class SearchForm(FlaskForm):
    """Форма для поиска"""
    query = StringField('Поиск', validators=[DataRequired(message="Введите поисковый запрос")])
    submit = SubmitField('Найти')

class DateRangeForm(FlaskForm):
    """Форма для выбора диапазона дат"""
    start_date = StringField('Дата начала', validators=[DataRequired(message="Выберите дату начала")])
    end_date = StringField('Дата окончания', validators=[DataRequired(message="Выберите дату окончания")])
    submit = SubmitField('Применить')