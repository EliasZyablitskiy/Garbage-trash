#!/usr/bin/env python
# coding: utf-8

"""
Service for speech-to-text conversion
"""

import logging
import os
import tempfile
from pydub import AudioSegment
import speech_recognition as sr

logger = logging.getLogger(__name__)

async def convert_voice_to_text(voice_file_path: str, language: str = "ru-RU") -> str:
    """
    Convert a voice message to text
    
    Args:
        voice_file_path: Path to the voice file (.oga format from Telegram)
        language: Language code for recognition (default: ru-RU)
        
    Returns:
        str: The extracted text from the voice message
    """
    try:
        # Convert OGA to WAV since speech_recognition works best with WAV
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_wav:
            wav_file_path = temp_wav.name
        
        # Convert the file
        voice = AudioSegment.from_file(voice_file_path)
        voice.export(wav_file_path, format="wav")
        
        # Create a recognizer
        recognizer = sr.Recognizer()
        
        # Load the audio file
        with sr.AudioFile(wav_file_path) as source:
            # Record audio from the file
            audio = recognizer.record(source)
            
            # Use Google's speech recognition service
            text = recognizer.recognize_google(audio, language=language)
            
            logger.info(f"Successfully converted voice to text: {text}")
            return text
    except sr.UnknownValueError:
        logger.warning("Speech recognition could not understand audio")
        return ""
    except sr.RequestError as e:
        logger.error(f"Could not request results from speech recognition service: {e}")
        return ""
    except Exception as e:
        logger.error(f"Error processing voice message: {e}")
        return ""
    finally:
        # Clean up temporary files
        if 'wav_file_path' in locals() and os.path.exists(wav_file_path):
            os.remove(wav_file_path)