#!/usr/bin/env python
# coding: utf-8

"""
Страницы платежей для пользователей
Предоставляет страницы для оплаты и проверки статуса платежей
"""

import os
import json
import logging
import hashlib
from functools import wraps
from datetime import datetime
from typing import Dict, Any, Tuple, Optional, List, Union

from flask import request, render_template_string, jsonify, abort, Blueprint, redirect

from db_models import db, Transaction, User
from services.payment_verification_service import payment_verification_service, PAYMENT_STATUS, PAYMENT_SYSTEMS
from services.payment_processor_facade import payment_processor_facade

# Настройка логирования
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Создание обработчика для вывода в консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

# Создание файлового обработчика
import os
os.makedirs('logs', exist_ok=True)
file_handler = logging.FileHandler('logs/payment_pages.log')
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

# Создаем Blueprint для регистрации маршрутов
payment_pages_bp = Blueprint('payment_pages', __name__)

def register_payment_pages(app):
    """
    Регистрация маршрутов для страниц платежей
    
    Args:
        app: Flask-приложение
    """
    # Регистрируем Blueprint
    app.register_blueprint(payment_pages_bp)
    
    logger.info("Зарегистрированы маршруты для страниц платежей")
    
    return app

@payment_pages_bp.route('/payment/sbp/<int:user_id>/<order_id>', methods=['GET'])
def sbp_payment_page(user_id, order_id):
    """
    Страница оплаты через СБП
    
    Args:
        user_id: ID пользователя
        order_id: ID заказа
        
    Returns:
        HTML-страница оплаты через СБП
    """
    # Получаем ID транзакции из параметров запроса
    transaction_id = request.args.get('transaction_id')
    
    # Если ID транзакции не указан, пытаемся найти транзакцию по user_id и order_id
    if not transaction_id:
        try:
            transactions = Transaction.query.filter_by(user_id=user_id).order_by(Transaction.created_at.desc()).all()
            
            for transaction in transactions:
                if transaction.metadata and transaction.metadata.get('order_id') == order_id:
                    transaction_id = transaction.id
                    break
            
            if not transaction_id:
                return render_template_string(
                    _get_error_page_template("Транзакция не найдена", 
                                         "Не удалось найти информацию о платеже. Пожалуйста, вернитесь в бота и создайте новый платеж.")
                ), 404
        except Exception as e:
            logger.error(f"Ошибка при поиске транзакции для пользователя {user_id} и заказа {order_id}: {str(e)}")
            return render_template_string(
                _get_error_page_template("Ошибка при поиске транзакции", 
                                     f"Произошла ошибка при поиске информации о платеже. Пожалуйста, вернитесь в бота и создайте новый платеж.")
            ), 500
    
    # Получаем информацию о транзакции
    try:
        transaction = Transaction.query.get(transaction_id)
        
        if not transaction:
            return render_template_string(
                _get_error_page_template("Транзакция не найдена", 
                                     "Не удалось найти информацию о платеже. Пожалуйста, вернитесь в бота и создайте новый платеж.")
            ), 404
        
        # Проверяем, принадлежит ли транзакция пользователю
        if transaction.user_id != user_id:
            return render_template_string(
                _get_error_page_template("Доступ запрещен", 
                                     "У вас нет доступа к этому платежу. Пожалуйста, вернитесь в бота и создайте новый платеж.")
            ), 403
            
        # Проверяем статус транзакции
        if transaction.status == PAYMENT_STATUS['COMPLETED']:
            return redirect(f"/payment/success?transaction_id={transaction_id}")
        
        elif transaction.status == PAYMENT_STATUS['FAILED'] or transaction.status == PAYMENT_STATUS['CANCELLED']:
            return redirect(f"/payment/fail?transaction_id={transaction_id}")
        
        elif transaction.status == PAYMENT_STATUS['EXPIRED']:
            return render_template_string(
                _get_error_page_template("Платеж просрочен", 
                                     "Время ожидания платежа истекло. Пожалуйста, вернитесь в бота и создайте новый платеж.")
            ), 400
        
        # Получаем данные пользователя
        user = User.query.get(user_id)
        
        if not user:
            return render_template_string(
                _get_error_page_template("Пользователь не найден", 
                                     "Не удалось найти информацию о пользователе. Пожалуйста, вернитесь в бота и создайте новый платеж.")
            ), 404
        
        # Формируем шаблон страницы оплаты
        template = _get_sbp_payment_template(
            user_id=user_id,
            user_name=user.username or "Пользователь",
            transaction_id=transaction_id,
            order_id=order_id,
            amount=transaction.amount,
            expire_time=transaction.payment_expires_at.isoformat() if transaction.payment_expires_at else None
        )
        
        return render_template_string(template)
        
    except Exception as e:
        logger.error(f"Ошибка при получении информации о транзакции {transaction_id}: {str(e)}")
        return render_template_string(
            _get_error_page_template("Ошибка при обработке платежа", 
                                 f"Произошла ошибка при обработке платежа. Пожалуйста, вернитесь в бота и создайте новый платеж.")
        ), 500

@payment_pages_bp.route('/payment/manual/<int:user_id>/<payment_id>', methods=['GET'])
def manual_payment_page(user_id, payment_id):
    """
    Страница с инструкциями по ручной оплате
    
    Args:
        user_id: ID пользователя
        payment_id: ID платежа
        
    Returns:
        HTML-страница с инструкциями по ручной оплате
    """
    # Получаем ID транзакции из параметров запроса
    transaction_id = request.args.get('transaction_id')
    
    # Если ID транзакции не указан, пытаемся найти транзакцию по user_id и payment_id
    if not transaction_id:
        try:
            transactions = Transaction.query.filter_by(user_id=user_id).order_by(Transaction.created_at.desc()).all()
            
            for transaction in transactions:
                if transaction.metadata and transaction.metadata.get('payment_id') == payment_id:
                    transaction_id = transaction.id
                    break
            
            if not transaction_id:
                return render_template_string(
                    _get_error_page_template("Транзакция не найдена", 
                                         "Не удалось найти информацию о платеже. Пожалуйста, вернитесь в бота и создайте новый платеж.")
                ), 404
        except Exception as e:
            logger.error(f"Ошибка при поиске транзакции для пользователя {user_id} и платежа {payment_id}: {str(e)}")
            return render_template_string(
                _get_error_page_template("Ошибка при поиске транзакции", 
                                     f"Произошла ошибка при поиске информации о платеже. Пожалуйста, вернитесь в бота и создайте новый платеж.")
            ), 500
    
    # Получаем информацию о транзакции
    try:
        transaction = Transaction.query.get(transaction_id)
        
        if not transaction:
            return render_template_string(
                _get_error_page_template("Транзакция не найдена", 
                                     "Не удалось найти информацию о платеже. Пожалуйста, вернитесь в бота и создайте новый платеж.")
            ), 404
        
        # Проверяем, принадлежит ли транзакция пользователю
        if transaction.user_id != user_id:
            return render_template_string(
                _get_error_page_template("Доступ запрещен", 
                                     "У вас нет доступа к этому платежу. Пожалуйста, вернитесь в бота и создайте новый платеж.")
            ), 403
            
        # Проверяем статус транзакции
        if transaction.status == PAYMENT_STATUS['COMPLETED']:
            return redirect(f"/payment/success?transaction_id={transaction_id}")
        
        elif transaction.status == PAYMENT_STATUS['FAILED'] or transaction.status == PAYMENT_STATUS['CANCELLED']:
            return redirect(f"/payment/fail?transaction_id={transaction_id}")
        
        elif transaction.status == PAYMENT_STATUS['EXPIRED']:
            return render_template_string(
                _get_error_page_template("Платеж просрочен", 
                                     "Время ожидания платежа истекло. Пожалуйста, вернитесь в бота и создайте новый платеж.")
            ), 400
        
        # Получаем данные пользователя
        user = User.query.get(user_id)
        
        if not user:
            return render_template_string(
                _get_error_page_template("Пользователь не найден", 
                                     "Не удалось найти информацию о пользователе. Пожалуйста, вернитесь в бота и создайте новый платеж.")
            ), 404
        
        # Получаем информацию о банковских реквизитах
        bank_details = transaction.metadata.get('bank_details', {})
        
        # Формируем шаблон страницы с инструкциями по оплате
        template = _get_manual_payment_template(
            user_id=user_id,
            user_name=user.username or "Пользователь",
            transaction_id=transaction_id,
            payment_id=payment_id,
            amount=transaction.amount,
            bank_details=bank_details,
            expire_time=transaction.payment_expires_at.isoformat() if transaction.payment_expires_at else None
        )
        
        return render_template_string(template)
        
    except Exception as e:
        logger.error(f"Ошибка при получении информации о транзакции {transaction_id}: {str(e)}")
        return render_template_string(
            _get_error_page_template("Ошибка при обработке платежа", 
                                 f"Произошла ошибка при обработке платежа. Пожалуйста, вернитесь в бота и создайте новый платеж.")
        ), 500

@payment_pages_bp.route('/payment/status/<int:transaction_id>', methods=['GET'])
def payment_status_page(transaction_id):
    """
    Страница с информацией о статусе платежа
    
    Args:
        transaction_id: ID транзакции
        
    Returns:
        HTML-страница с информацией о статусе платежа
    """
    try:
        # Получаем информацию о транзакции
        success, message, transaction_data = payment_verification_service.verify_transaction_by_id(transaction_id)
        
        if not success:
            return render_template_string(
                _get_error_page_template("Транзакция не найдена", 
                                     "Не удалось найти информацию о платеже. Пожалуйста, вернитесь в бота и создайте новый платеж.")
            ), 404
        
        # Получаем данные пользователя
        user_id = transaction_data.get('user_id')
        user = User.query.get(user_id)
        
        if not user:
            return render_template_string(
                _get_error_page_template("Пользователь не найден", 
                                     "Не удалось найти информацию о пользователе. Пожалуйста, вернитесь в бота и создайте новый платеж.")
            ), 404
        
        # Формируем шаблон страницы с информацией о статусе платежа
        template = _get_payment_status_template(
            user_id=user_id,
            user_name=user.username or "Пользователь",
            transaction_id=transaction_id,
            amount=transaction_data.get('amount', 0),
            status=transaction_data.get('status', 'unknown'),
            created_at=transaction_data.get('created_at'),
            updated_at=transaction_data.get('updated_at'),
            completed_at=transaction_data.get('completed_at'),
            payment_method=transaction_data.get('payment_method', '')
        )
        
        return render_template_string(template)
        
    except Exception as e:
        logger.error(f"Ошибка при получении информации о статусе транзакции {transaction_id}: {str(e)}")
        return render_template_string(
            _get_error_page_template("Ошибка при получении статуса платежа", 
                                 f"Произошла ошибка при получении информации о статусе платежа. Пожалуйста, вернитесь в бота и создайте новый платеж.")
        ), 500

@payment_pages_bp.route('/payment/api/status/<int:transaction_id>', methods=['GET'])
def payment_status_api(transaction_id):
    """
    API для получения статуса платежа
    
    Args:
        transaction_id: ID транзакции
        
    Returns:
        JSON с информацией о статусе платежа
    """
    try:
        # Получаем информацию о статусе платежа
        success, message, transaction_data = payment_processor_facade.check_payment_status(transaction_id)
        
        if not success:
            return jsonify({
                'success': False,
                'message': message
            }), 404
        
        # Формируем ответ
        return jsonify({
            'success': True,
            'message': message,
            'status': transaction_data.get('status', 'unknown'),
            'data': transaction_data
        })
        
    except Exception as e:
        logger.error(f"Ошибка при получении информации о статусе транзакции {transaction_id}: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Внутренняя ошибка сервера: {str(e)}"
        }), 500

@payment_pages_bp.route('/payment/api/notify/<int:transaction_id>', methods=['POST'])
def payment_notify_api(transaction_id):
    """
    API для отправки уведомления о статусе платежа
    
    Args:
        transaction_id: ID транзакции
        
    Returns:
        JSON с результатом отправки уведомления
    """
    try:
        # Получаем данные из запроса
        data = request.json
        
        if not data:
            return jsonify({
                'success': False,
                'message': "Отсутствуют данные в запросе"
            }), 400
        
        # Получаем новый статус платежа
        new_status = data.get('status')
        
        if not new_status:
            return jsonify({
                'success': False,
                'message': "Отсутствует статус платежа"
            }), 400
        
        # Получаем информацию о транзакции
        transaction = Transaction.query.get(transaction_id)
        
        if not transaction:
            return jsonify({
                'success': False,
                'message': f"Транзакция {transaction_id} не найдена"
            }), 404
        
        # Обновляем статус платежа
        success, message = payment_verification_service.update_payment_status(
            transaction_id,
            new_status,
            additional_data={
                'source': 'api',
                'remote_addr': request.remote_addr,
                'additional_data': data
            }
        )
        
        if not success:
            return jsonify({
                'success': False,
                'message': message
            }), 500
        
        # Формируем ответ
        return jsonify({
            'success': True,
            'message': message
        })
        
    except Exception as e:
        logger.error(f"Ошибка при отправке уведомления о статусе транзакции {transaction_id}: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Внутренняя ошибка сервера: {str(e)}"
        }), 500

def _get_sbp_payment_template(user_id, user_name, transaction_id, order_id, amount, expire_time=None):
    """
    Формирование шаблона страницы оплаты через СБП
    
    Args:
        user_id: ID пользователя
        user_name: Имя пользователя
        transaction_id: ID транзакции
        order_id: ID заказа
        amount: Сумма платежа
        expire_time: Время истечения платежа
        
    Returns:
        str: HTML-шаблон страницы оплаты через СБП
    """
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Оплата подписки через СБП</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {{
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
            }}
            .payment-container {{
                margin-top: 30px;
                padding: 20px;
                background-color: #f5f5f5;
                border-radius: 10px;
            }}
            h1 {{
                color: #4a76a8;
            }}
            .details {{
                margin: 20px 0;
                text-align: left;
                padding: 15px;
                background-color: #fff;
                border-radius: 5px;
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            }}
            .detail-row {{
                margin: 10px 0;
                display: flex;
                justify-content: space-between;
            }}
            .detail-label {{
                font-weight: bold;
                color: #666;
            }}
            .detail-value {{
                color: #333;
            }}
            .cta-button {{
                display: inline-block;
                padding: 12px 24px;
                background-color: #4a76a8;
                color: white;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                margin: 20px 0;
            }}
            .alternative-button {{
                display: inline-block;
                padding: 12px 24px;
                background-color: #f0f0f0;
                color: #333;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                margin: 10px 0;
            }}
            .timer {{
                margin: 20px 0;
                font-size: 18px;
                color: #e74c3c;
            }}
            .instructions {{
                margin: 20px 0;
                text-align: left;
                background-color: #e8f4fd;
                padding: 15px;
                border-radius: 5px;
            }}
            .instructions ol {{
                margin-left: 20px;
                padding-left: 0;
            }}
            .instructions li {{
                margin-bottom: 10px;
            }}
            #qr-container {{
                margin: 20px auto;
                padding: 15px;
                background-color: white;
                border-radius: 5px;
                display: inline-block;
            }}
            #status-message {{
                margin: 10px 0;
                padding: 10px;
                border-radius: 5px;
                display: none;
            }}
            .success {{
                background-color: #d4edda;
                color: #155724;
            }}
            .error {{
                background-color: #f8d7da;
                color: #721c24;
            }}
            .warning {{
                background-color: #fff3cd;
                color: #856404;
            }}
            .info {{
                background-color: #d1ecf1;
                color: #0c5460;
            }}
        </style>
        
        <!-- Добавляем jQuery для AJAX-запросов -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        
        <!-- Добавляем QRCode.js для генерации QR-кодов -->
        <script src="https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js"></script>
        
        <script>
            // Функция для генерации QR-кода
            function generateQRCode(text, typeNumber, errorCorrectionLevel, cellSize) {{
                var qr = qrcode(typeNumber || 0, errorCorrectionLevel || 'L');
                qr.addData(text);
                qr.make();
                return qr.createImgTag(cellSize || 5);
            }}
            
            // Функция для проверки статуса платежа
            function checkPaymentStatus() {{
                $.ajax({{
                    url: '/payment/api/status/{transaction_id}',
                    type: 'GET',
                    success: function(response) {{
                        if (response.success) {{
                            // Обновляем статус платежа
                            if (response.status === '{PAYMENT_STATUS['COMPLETED']}') {{
                                // Платеж успешно выполнен
                                $('#status-message').text('Платеж успешно выполнен! Перенаправление на страницу успеха...');
                                $('#status-message').removeClass().addClass('success').show();
                                
                                // Перенаправляем на страницу успеха
                                setTimeout(function() {{
                                    window.location.href = '/payment/success?transaction_id={transaction_id}';
                                }}, 2000);
                            }} else if (response.status === '{PAYMENT_STATUS['PENDING']}') {{
                                // Платеж в процессе обработки
                                $('#status-message').text('Платеж в процессе обработки. Пожалуйста, подождите...');
                                $('#status-message').removeClass().addClass('info').show();
                                
                                // Продолжаем проверку через 5 секунд
                                setTimeout(checkPaymentStatus, 5000);
                            }} else if (response.status === '{PAYMENT_STATUS['FAILED']}') {{
                                // Платеж не удался
                                $('#status-message').text('Произошла ошибка при обработке платежа.');
                                $('#status-message').removeClass().addClass('error').show();
                                
                                // Перенаправляем на страницу ошибки
                                setTimeout(function() {{
                                    window.location.href = '/payment/fail?transaction_id={transaction_id}';
                                }}, 2000);
                            }} else if (response.status === '{PAYMENT_STATUS['EXPIRED']}') {{
                                // Платеж истек
                                $('#status-message').text('Время ожидания платежа истекло.');
                                $('#status-message').removeClass().addClass('warning').show();
                                
                                // Перенаправляем на страницу ошибки
                                setTimeout(function() {{
                                    window.location.href = '/payment/fail?transaction_id={transaction_id}';
                                }}, 2000);
                            }}
                        }} else {{
                            // Ошибка при получении статуса платежа
                            $('#status-message').text('Ошибка при получении статуса платежа: ' + response.message);
                            $('#status-message').removeClass().addClass('error').show();
                        }}
                    }},
                    error: function(xhr, status, error) {{
                        // Ошибка при отправке запроса
                        $('#status-message').text('Ошибка при проверке статуса платежа: ' + error);
                        $('#status-message').removeClass().addClass('error').show();
                    }}
                }});
            }}
            
            // Запускаем проверку статуса платежа при загрузке страницы
            $(document).ready(function() {{
                // Генерируем QR-код для оплаты
                var qrText = "https://qr.nspk.ru/AS10003P3J7KNJ9A8COP5AOLOC6ROT1M?type=01&bank=100000000111&sum={amount}&cur=RUB&crc=AB12&payment={transaction_id}";
                $('#qr-container').html(generateQRCode(qrText, 0, 'M', 10));
                
                // Запускаем проверку статуса платежа
                checkPaymentStatus();
                
                // Устанавливаем таймер для истечения платежа
                var expireTime = new Date('{expire_time}').getTime();
                var timer = setInterval(function() {{
                    var now = new Date().getTime();
                    var distance = expireTime - now;
                    
                    if (distance <= 0) {{
                        clearInterval(timer);
                        $('#timer').text('Время ожидания платежа истекло');
                        
                        // Перенаправляем на страницу ошибки
                        setTimeout(function() {{
                            window.location.href = '/payment/fail?transaction_id={transaction_id}';
                        }}, 2000);
                    }} else {{
                        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                        
                        $('#timer').text('Оплатите в течение: ' + 
                                        (minutes < 10 ? '0' + minutes : minutes) + ':' + 
                                        (seconds < 10 ? '0' + seconds : seconds));
                    }}
                }}, 1000);
            }});
        </script>
    </head>
    <body>
        <div class="payment-container">
            <h1>Оплата подписки через СБП</h1>
            
            <div class="instructions">
                <h3>Инструкции по оплате:</h3>
                <ol>
                    <li>Отсканируйте QR-код ниже через приложение вашего банка</li>
                    <li>Проверьте данные платежа (сумма: {amount} руб.)</li>
                    <li>Подтвердите оплату в приложении</li>
                    <li>Дождитесь подтверждения платежа на этой странице</li>
                </ol>
            </div>
            
            <div id="timer" class="timer">Оплатите в течение: 59:59</div>
            
            <div id="qr-container"></div>
            
            <div id="status-message"></div>
            
            <div class="details">
                <div class="detail-row">
                    <span class="detail-label">Пользователь:</span>
                    <span class="detail-value">{user_name}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Номер транзакции:</span>
                    <span class="detail-value">{transaction_id}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Сумма к оплате:</span>
                    <span class="detail-value">{amount} руб.</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Назначение платежа:</span>
                    <span class="detail-value">Подписка на бота Катюша</span>
                </div>
            </div>
            
            <a href="https://t.me/Katiysha_bot" class="alternative-button">Вернуться к боту</a>
            
            <p><small>При возникновении проблем с оплатой, пожалуйста, вернитесь в бота и создайте новый платеж или обратитесь в поддержку.</small></p>
        </div>
    </body>
    </html>
    """

def _get_manual_payment_template(user_id, user_name, transaction_id, payment_id, amount, bank_details, expire_time=None):
    """
    Формирование шаблона страницы с инструкциями по ручной оплате
    
    Args:
        user_id: ID пользователя
        user_name: Имя пользователя
        transaction_id: ID транзакции
        payment_id: ID платежа
        amount: Сумма платежа
        bank_details: Банковские реквизиты
        expire_time: Время истечения платежа
        
    Returns:
        str: HTML-шаблон страницы с инструкциями по ручной оплате
    """
    
    # Получаем банковские реквизиты
    account = bank_details.get('account', '')
    bank_name = bank_details.get('bank_name', '')
    recipient = bank_details.get('recipient', '')
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Инструкции по оплате подписки</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {{
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
            }}
            .payment-container {{
                margin-top: 30px;
                padding: 20px;
                background-color: #f5f5f5;
                border-radius: 10px;
            }}
            h1 {{
                color: #4a76a8;
            }}
            .instructions {{
                margin: 20px 0;
                text-align: left;
                background-color: #e8f4fd;
                padding: 15px;
                border-radius: 5px;
            }}
            .instructions ol {{
                margin-left: 20px;
                padding-left: 0;
            }}
            .instructions li {{
                margin-bottom: 10px;
            }}
            .bank-details {{
                margin: 20px 0;
                text-align: left;
                padding: 15px;
                background-color: #fff;
                border-radius: 5px;
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            }}
            .detail-row {{
                margin: 10px 0;
                display: flex;
                justify-content: space-between;
            }}
            .detail-label {{
                font-weight: bold;
                color: #666;
            }}
            .detail-value {{
                color: #333;
            }}
            .copy-button {{
                display: inline-block;
                padding: 5px 10px;
                background-color: #f0f0f0;
                color: #333;
                text-decoration: none;
                border-radius: 3px;
                font-size: 12px;
                margin-left: 10px;
                cursor: pointer;
            }}
            .copy-button:hover {{
                background-color: #e0e0e0;
            }}
            .cta-button {{
                display: inline-block;
                padding: 12px 24px;
                background-color: #4a76a8;
                color: white;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                margin: 20px 0;
            }}
            .alternative-button {{
                display: inline-block;
                padding: 12px 24px;
                background-color: #f0f0f0;
                color: #333;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                margin: 10px 0;
            }}
            .timer {{
                margin: 20px 0;
                font-size: 18px;
                color: #e74c3c;
            }}
            #status-message {{
                margin: 10px 0;
                padding: 10px;
                border-radius: 5px;
                display: none;
            }}
            .success {{
                background-color: #d4edda;
                color: #155724;
            }}
            .error {{
                background-color: #f8d7da;
                color: #721c24;
            }}
            .warning {{
                background-color: #fff3cd;
                color: #856404;
            }}
            .info {{
                background-color: #d1ecf1;
                color: #0c5460;
            }}
        </style>
        
        <!-- Добавляем jQuery для AJAX-запросов -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        
        <script>
            // Функция для копирования текста в буфер обмена
            function copyToClipboard(text, buttonId) {{
                navigator.clipboard.writeText(text).then(function() {{
                    // Текст успешно скопирован
                    $('#' + buttonId).text('Скопировано');
                    setTimeout(function() {{
                        $('#' + buttonId).text('Копировать');
                    }}, 1500);
                }}, function() {{
                    // Произошла ошибка
                    alert('Не удалось скопировать текст');
                }});
            }}
            
            // Функция для проверки статуса платежа
            function checkPaymentStatus() {{
                $.ajax({{
                    url: '/payment/api/status/{transaction_id}',
                    type: 'GET',
                    success: function(response) {{
                        if (response.success) {{
                            // Обновляем статус платежа
                            if (response.status === '{PAYMENT_STATUS['COMPLETED']}') {{
                                // Платеж успешно выполнен
                                $('#status-message').text('Платеж успешно выполнен! Перенаправление на страницу успеха...');
                                $('#status-message').removeClass().addClass('success').show();
                                
                                // Перенаправляем на страницу успеха
                                setTimeout(function() {{
                                    window.location.href = '/payment/success?transaction_id={transaction_id}';
                                }}, 2000);
                            }} else if (response.status === '{PAYMENT_STATUS['PENDING']}') {{
                                // Платеж в процессе обработки
                                $('#status-message').text('Платеж в процессе обработки. Пожалуйста, подождите...');
                                $('#status-message').removeClass().addClass('info').show();
                                
                                // Продолжаем проверку через 10 секунд
                                setTimeout(checkPaymentStatus, 10000);
                            }} else if (response.status === '{PAYMENT_STATUS['FAILED']}') {{
                                // Платеж не удался
                                $('#status-message').text('Произошла ошибка при обработке платежа.');
                                $('#status-message').removeClass().addClass('error').show();
                                
                                // Перенаправляем на страницу ошибки
                                setTimeout(function() {{
                                    window.location.href = '/payment/fail?transaction_id={transaction_id}';
                                }}, 2000);
                            }} else if (response.status === '{PAYMENT_STATUS['EXPIRED']}') {{
                                // Платеж истек
                                $('#status-message').text('Время ожидания платежа истекло.');
                                $('#status-message').removeClass().addClass('warning').show();
                                
                                // Перенаправляем на страницу ошибки
                                setTimeout(function() {{
                                    window.location.href = '/payment/fail?transaction_id={transaction_id}';
                                }}, 2000);
                            }}
                        }} else {{
                            // Ошибка при получении статуса платежа
                            $('#status-message').text('Ошибка при получении статуса платежа: ' + response.message);
                            $('#status-message').removeClass().addClass('error').show();
                        }}
                    }},
                    error: function(xhr, status, error) {{
                        // Ошибка при отправке запроса
                        $('#status-message').text('Ошибка при проверке статуса платежа: ' + error);
                        $('#status-message').removeClass().addClass('error').show();
                    }}
                }});
            }}
            
            // Запускаем проверку статуса платежа при загрузке страницы
            $(document).ready(function() {{
                // Запускаем проверку статуса платежа
                checkPaymentStatus();
                
                // Устанавливаем таймер для истечения платежа
                var expireTime = new Date('{expire_time}').getTime();
                var timer = setInterval(function() {{
                    var now = new Date().getTime();
                    var distance = expireTime - now;
                    
                    if (distance <= 0) {{
                        clearInterval(timer);
                        $('#timer').text('Время ожидания платежа истекло');
                        
                        // Перенаправляем на страницу ошибки
                        setTimeout(function() {{
                            window.location.href = '/payment/fail?transaction_id={transaction_id}';
                        }}, 2000);
                    }} else {{
                        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                        
                        $('#timer').text('Оплатите в течение: ' + 
                                        (minutes < 10 ? '0' + minutes : minutes) + ':' + 
                                        (seconds < 10 ? '0' + seconds : seconds));
                    }}
                }}, 1000);
            }});
        </script>
    </head>
    <body>
        <div class="payment-container">
            <h1>Инструкции по оплате подписки</h1>
            
            <div class="instructions">
                <h3>Инструкции по оплате:</h3>
                <ol>
                    <li>Откройте приложение вашего банка</li>
                    <li>Выберите "Перевод по реквизитам" или аналогичный пункт меню</li>
                    <li>Заполните реквизиты, указанные ниже</li>
                    <li>Обязательно укажите в назначении платежа: <strong>Оплата подписки {payment_id}</strong></li>
                    <li>Подтвердите перевод</li>
                    <li>После оплаты нажмите кнопку "Проверить статус платежа"</li>
                </ol>
            </div>
            
            <div id="timer" class="timer">Оплатите в течение: 59:59</div>
            
            <div class="bank-details">
                <h3>Реквизиты для оплаты:</h3>
                
                <div class="detail-row">
                    <span class="detail-label">Банк получателя:</span>
                    <span class="detail-value">
                        {bank_name}
                        <button id="copy-bank" class="copy-button" onclick="copyToClipboard('{bank_name}', 'copy-bank')">Копировать</button>
                    </span>
                </div>
                
                <div class="detail-row">
                    <span class="detail-label">Получатель:</span>
                    <span class="detail-value">
                        {recipient}
                        <button id="copy-recipient" class="copy-button" onclick="copyToClipboard('{recipient}', 'copy-recipient')">Копировать</button>
                    </span>
                </div>
                
                <div class="detail-row">
                    <span class="detail-label">Номер счета:</span>
                    <span class="detail-value">
                        {account}
                        <button id="copy-account" class="copy-button" onclick="copyToClipboard('{account}', 'copy-account')">Копировать</button>
                    </span>
                </div>
                
                <div class="detail-row">
                    <span class="detail-label">Сумма:</span>
                    <span class="detail-value">
                        {amount} руб.
                        <button id="copy-amount" class="copy-button" onclick="copyToClipboard('{amount}', 'copy-amount')">Копировать</button>
                    </span>
                </div>
                
                <div class="detail-row">
                    <span class="detail-label">Назначение платежа:</span>
                    <span class="detail-value">
                        Оплата подписки {payment_id}
                        <button id="copy-purpose" class="copy-button" onclick="copyToClipboard('Оплата подписки {payment_id}', 'copy-purpose')">Копировать</button>
                    </span>
                </div>
            </div>
            
            <div id="status-message"></div>
            
            <button class="cta-button" onclick="checkPaymentStatus()">Проверить статус платежа</button>
            
            <a href="https://t.me/Katiysha_bot" class="alternative-button">Вернуться к боту</a>
            
            <p><small>При возникновении проблем с оплатой, пожалуйста, вернитесь в бота и создайте новый платеж или обратитесь в поддержку.</small></p>
        </div>
    </body>
    </html>
    """

def _get_payment_status_template(user_id, user_name, transaction_id, amount, status, created_at=None, updated_at=None, completed_at=None, payment_method=''):
    """
    Формирование шаблона страницы с информацией о статусе платежа
    
    Args:
        user_id: ID пользователя
        user_name: Имя пользователя
        transaction_id: ID транзакции
        amount: Сумма платежа
        status: Статус платежа
        created_at: Дата создания платежа
        updated_at: Дата обновления платежа
        completed_at: Дата завершения платежа
        payment_method: Метод оплаты
        
    Returns:
        str: HTML-шаблон страницы с информацией о статусе платежа
    """
    
    # Определяем статус платежа на русском языке
    status_texts = {
        PAYMENT_STATUS['INITIATED']: "Платеж создан",
        PAYMENT_STATUS['PENDING']: "Платеж в обработке",
        PAYMENT_STATUS['COMPLETED']: "Платеж успешно выполнен",
        PAYMENT_STATUS['FAILED']: "Ошибка при обработке платежа",
        PAYMENT_STATUS['CANCELLED']: "Платеж отменен",
        PAYMENT_STATUS['EXPIRED']: "Время ожидания платежа истекло"
    }
    
    status_text = status_texts.get(status, f"Неизвестный статус: {status}")
    
    # Определяем цвет и иконку для статуса
    status_colors = {
        PAYMENT_STATUS['INITIATED']: "#3498db",
        PAYMENT_STATUS['PENDING']: "#f39c12",
        PAYMENT_STATUS['COMPLETED']: "#2ecc71",
        PAYMENT_STATUS['FAILED']: "#e74c3c",
        PAYMENT_STATUS['CANCELLED']: "#95a5a6",
        PAYMENT_STATUS['EXPIRED']: "#e67e22"
    }
    
    status_icons = {
        PAYMENT_STATUS['INITIATED']: "🔄",
        PAYMENT_STATUS['PENDING']: "⏳",
        PAYMENT_STATUS['COMPLETED']: "✅",
        PAYMENT_STATUS['FAILED']: "❌",
        PAYMENT_STATUS['CANCELLED']: "🚫",
        PAYMENT_STATUS['EXPIRED']: "⏰"
    }
    
    status_color = status_colors.get(status, "#3498db")
    status_icon = status_icons.get(status, "❓")
    
    # Определяем способ оплаты на русском языке
    payment_methods = {
        PAYMENT_SYSTEMS['ROBOKASSA']: "Robokassa",
        PAYMENT_SYSTEMS['SBP_LINK']: "Система быстрых платежей (СБП)",
        PAYMENT_SYSTEMS['SBP_LINK_AUTO']: "Система быстрых платежей (СБП)",
        PAYMENT_SYSTEMS['SBP_LINK_DESKTOP']: "Система быстрых платежей (СБП)",
        PAYMENT_SYSTEMS['SBP_MANUAL']: "Ручной перевод по реквизитам"
    }
    
    payment_method_text = payment_methods.get(payment_method, payment_method)
    
    # Форматируем даты
    def format_date(date_str):
        if not date_str:
            return "—"
        
        try:
            date = datetime.fromisoformat(date_str)
            return date.strftime("%d.%m.%Y %H:%M:%S")
        except:
            return date_str
    
    created_at_str = format_date(created_at)
    updated_at_str = format_date(updated_at)
    completed_at_str = format_date(completed_at)
    
    # Определяем кнопки в зависимости от статуса
    buttons = ""
    
    if status == PAYMENT_STATUS['INITIATED'] or status == PAYMENT_STATUS['PENDING']:
        buttons += f"""
        <button class="cta-button" onclick="checkPaymentStatus()">Обновить статус</button>
        """
    
    if status != PAYMENT_STATUS['COMPLETED']:
        buttons += f"""
        <a href="https://t.me/Katiysha_bot" class="alternative-button">Вернуться к боту</a>
        """
    else:
        buttons += f"""
        <a href="https://t.me/Katiysha_bot" class="cta-button">Вернуться к боту</a>
        """
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Статус платежа</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {{
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
            }}
            .status-container {{
                margin-top: 30px;
                padding: 20px;
                background-color: #f5f5f5;
                border-radius: 10px;
            }}
            h1 {{
                color: #4a76a8;
            }}
            .status-box {{
                margin: 20px 0;
                padding: 20px;
                border-radius: 10px;
                color: white;
                font-weight: bold;
                font-size: 24px;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
            }}
            .status-icon {{
                font-size: 48px;
                margin-bottom: 10px;
            }}
            .details {{
                margin: 20px 0;
                text-align: left;
                padding: 15px;
                background-color: #fff;
                border-radius: 5px;
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            }}
            .detail-row {{
                margin: 10px 0;
                display: flex;
                justify-content: space-between;
            }}
            .detail-label {{
                font-weight: bold;
                color: #666;
            }}
            .detail-value {{
                color: #333;
            }}
            .cta-button {{
                display: inline-block;
                padding: 12px 24px;
                background-color: #4a76a8;
                color: white;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                margin: 20px 10px;
                border: none;
                cursor: pointer;
            }}
            .alternative-button {{
                display: inline-block;
                padding: 12px 24px;
                background-color: #f0f0f0;
                color: #333;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                margin: 10px;
            }}
            #status-message {{
                margin: 10px 0;
                padding: 10px;
                border-radius: 5px;
                display: none;
            }}
            .success {{
                background-color: #d4edda;
                color: #155724;
            }}
            .error {{
                background-color: #f8d7da;
                color: #721c24;
            }}
            .info {{
                background-color: #d1ecf1;
                color: #0c5460;
            }}
        </style>
        
        <!-- Добавляем jQuery для AJAX-запросов -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        
        <script>
            // Функция для проверки статуса платежа
            function checkPaymentStatus() {{
                $('#status-message').text('Обновление статуса...').removeClass().addClass('info').show();
                
                $.ajax({{
                    url: '/payment/api/status/{transaction_id}',
                    type: 'GET',
                    success: function(response) {{
                        if (response.success) {{
                            // Обновляем страницу для отображения актуального статуса
                            location.reload();
                        }} else {{
                            // Ошибка при получении статуса платежа
                            $('#status-message').text('Ошибка при получении статуса платежа: ' + response.message).removeClass().addClass('error');
                        }}
                    }},
                    error: function(xhr, status, error) {{
                        // Ошибка при отправке запроса
                        $('#status-message').text('Ошибка при проверке статуса платежа: ' + error).removeClass().addClass('error');
                    }}
                }});
            }}
            
            // Запускаем проверку статуса платежа при загрузке страницы для платежей в обработке
            $(document).ready(function() {{
                if ('{status}' === '{PAYMENT_STATUS['PENDING']}') {{
                    // Запускаем автоматическую проверку каждые 5 секунд
                    setInterval(checkPaymentStatus, 5000);
                }}
            }});
        </script>
    </head>
    <body>
        <div class="status-container">
            <h1>Статус платежа</h1>
            
            <div class="status-box" style="background-color: {status_color}">
                <div class="status-icon">{status_icon}</div>
                <div>{status_text}</div>
            </div>
            
            <div id="status-message"></div>
            
            <div class="details">
                <div class="detail-row">
                    <span class="detail-label">Пользователь:</span>
                    <span class="detail-value">{user_name}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Номер транзакции:</span>
                    <span class="detail-value">{transaction_id}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Сумма:</span>
                    <span class="detail-value">{amount} руб.</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Способ оплаты:</span>
                    <span class="detail-value">{payment_method_text}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Создан:</span>
                    <span class="detail-value">{created_at_str}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Обновлен:</span>
                    <span class="detail-value">{updated_at_str}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Завершен:</span>
                    <span class="detail-value">{completed_at_str}</span>
                </div>
            </div>
            
            {buttons}
            
            <p><small>При возникновении проблем с оплатой, пожалуйста, обратитесь в поддержку.</small></p>
        </div>
    </body>
    </html>
    """

def _get_error_page_template(error_title, error_message):
    """
    Формирование шаблона страницы с ошибкой
    
    Args:
        error_title: Заголовок ошибки
        error_message: Сообщение об ошибке
        
    Returns:
        str: HTML-шаблон страницы с ошибкой
    """
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>{error_title}</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {{
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
            }}
            .error-container {{
                margin-top: 30px;
                padding: 20px;
                background-color: #f8d7da;
                border-radius: 10px;
            }}
            h1 {{
                color: #721c24;
            }}
            .error-icon {{
                font-size: 64px;
                margin-bottom: 20px;
            }}
            .error-message {{
                margin: 20px 0;
                font-size: 16px;
                color: #333;
            }}
            .cta-button {{
                display: inline-block;
                padding: 12px 24px;
                background-color: #4a76a8;
                color: white;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                margin: 20px 0;
            }}
        </style>
    </head>
    <body>
        <div class="error-container">
            <div class="error-icon">❌</div>
            <h1>{error_title}</h1>
            <div class="error-message">{error_message}</div>
            <a href="https://t.me/Katiysha_bot" class="cta-button">Вернуться к боту</a>
        </div>
    </body>
    </html>
    """