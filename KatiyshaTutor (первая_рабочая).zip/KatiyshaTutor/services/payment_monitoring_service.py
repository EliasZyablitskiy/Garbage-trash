"""
Сервис для мониторинга и отчетности по платежам
Предоставляет функционал для сбора и анализа метрик по платежам
"""
import logging
import datetime
from typing import Dict, List, Tuple, Any, Optional
from sqlalchemy import func, and_, or_, desc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import Session

from db_models import Transaction, User
from services.payment_constants import PaymentType

logger = logging.getLogger(__name__)

class PaymentMonitoringService:
    """
    Сервис для мониторинга и отчетности по платежам
    """
    
    @staticmethod
    async def get_payment_statistics(session: AsyncSession, days: int = 30) -> Dict[str, Any]:
        """
        Получает статистику платежей за указанный период
        
        Args:
            session: Сессия базы данных
            days: Количество дней для анализа (по умолчанию 30)
            
        Returns:
            Dict[str, Any]: Словарь со статистикой платежей
        """
        start_date = datetime.datetime.now() - datetime.timedelta(days=days)
        
        # Общее количество транзакций
        total_query = select(func.count(Transaction.id)).where(
            and_(
                Transaction.created_at >= start_date,
                Transaction.type.in_(['payment', 'subscription'])
            )
        )
        total_transactions = await session.execute(total_query)
        total_count = total_transactions.scalar() or 0
        
        # Успешные транзакции
        success_query = select(func.count(Transaction.id)).where(
            and_(
                Transaction.created_at >= start_date,
                Transaction.type.in_(['payment', 'subscription']),
                Transaction.status == 'completed'
            )
        )
        success_transactions = await session.execute(success_query)
        success_count = success_transactions.scalar() or 0
        
        # Неудачные транзакции
        failed_query = select(func.count(Transaction.id)).where(
            and_(
                Transaction.created_at >= start_date,
                Transaction.type.in_(['payment', 'subscription']),
                Transaction.status.in_(['failed', 'error', 'cancelled'])
            )
        )
        failed_transactions = await session.execute(failed_query)
        failed_count = failed_transactions.scalar() or 0
        
        # Ожидающие транзакции
        pending_query = select(func.count(Transaction.id)).where(
            and_(
                Transaction.created_at >= start_date,
                Transaction.type.in_(['payment', 'subscription']),
                Transaction.status.in_(['pending', 'processing'])
            )
        )
        pending_transactions = await session.execute(pending_query)
        pending_count = pending_transactions.scalar() or 0
        
        # Статистика по платежным системам
        payment_systems_query = select(
            Transaction.payment_method, 
            func.count(Transaction.id).label('count')
        ).where(
            and_(
                Transaction.created_at >= start_date,
                Transaction.type.in_(['payment', 'subscription'])
            )
        ).group_by(Transaction.payment_method)
        
        payment_systems_result = await session.execute(payment_systems_query)
        payment_systems_stats = {
            str(payment_method): int(count) 
            for payment_method, count in payment_systems_result.all()
        }
        
        # Конверсия
        conversion_rate = (success_count / total_count * 100) if total_count > 0 else 0
        
        # Строим итоговую статистику
        statistics = {
            'period_days': days,
            'total_transactions': total_count,
            'successful_transactions': success_count,
            'failed_transactions': failed_count,
            'pending_transactions': pending_count,
            'conversion_rate': round(conversion_rate, 2),
            'payment_systems': payment_systems_stats,
        }
        
        return statistics
    
    @staticmethod
    async def get_payment_history(
        session: AsyncSession, 
        days: int = 30, 
        status: Optional[str] = None, 
        payment_method: Optional[str] = None,
        limit: int = 50,
        offset: int = 0
    ) -> Tuple[List[Dict[str, Any]], int]:
        """
        Получает историю платежей за указанный период с возможностью фильтрации
        
        Args:
            session: Сессия базы данных
            days: Количество дней для анализа (по умолчанию 30)
            status: Фильтр по статусу платежа (опционально)
            payment_method: Фильтр по методу оплаты (опционально)
            limit: Ограничение количества записей (пагинация)
            offset: Смещение (пагинация)
            
        Returns:
            Tuple[List[Dict[str, Any]], int]: Кортеж из списка платежей и общего количества
        """
        start_date = datetime.datetime.now() - datetime.timedelta(days=days)
        
        # Базовое условие для всех запросов
        base_condition = and_(
            Transaction.created_at >= start_date,
            Transaction.type.in_(['payment', 'subscription'])
        )
        
        # Добавляем фильтры, если они указаны
        if status:
            base_condition = and_(base_condition, Transaction.status == status)
        
        if payment_method:
            base_condition = and_(base_condition, Transaction.payment_method == payment_method)
        
        # Запрос на получение общего количества записей для пагинации
        count_query = select(func.count(Transaction.id)).where(base_condition)
        count_result = await session.execute(count_query)
        total_count = count_result.scalar() or 0
        
        # Запрос на получение данных о транзакциях с присоединением данных пользователей
        query = select(
            Transaction, 
            User.username,
            User.email,
            User.wallet_address
        ).join(
            User, Transaction.user_id == User.id, isouter=True
        ).where(
            base_condition
        ).order_by(
            desc(Transaction.created_at)
        ).offset(offset).limit(limit)
        
        result = await session.execute(query)
        
        # Формируем список платежей с нужными полями
        transactions = []
        for transaction, username, email, wallet_address in result.all():
            payment_data = {
                'id': transaction.id,
                'user_id': transaction.user_id,
                'username': username or "Неизвестный",
                'email': email,
                'wallet': wallet_address,
                'amount': transaction.amount,
                'currency': transaction.currency,
                'status': transaction.status,
                'payment_method': transaction.payment_method,
                'created_at': transaction.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                'updated_at': transaction.updated_at.strftime('%Y-%m-%d %H:%M:%S') if transaction.updated_at else None,
                'transaction_id': transaction.transaction_id,
                'payment_data': transaction.payment_data,
                'notes': transaction.notes if hasattr(transaction, 'notes') else None,
            }
            transactions.append(payment_data)
        
        return transactions, total_count
    
    @staticmethod
    async def get_daily_stats(session: AsyncSession, days: int = 30) -> Dict[str, List[Any]]:
        """
        Получает ежедневную статистику платежей для построения графиков
        
        Args:
            session: Сессия базы данных
            days: Количество дней для анализа (по умолчанию 30)
            
        Returns:
            Dict[str, List[Any]]: Словарь с данными по дням
        """
        start_date = datetime.datetime.now() - datetime.timedelta(days=days)
        
        # Подготавливаем словарь для хранения дат
        date_format = '%Y-%m-%d'
        dates = [(start_date + datetime.timedelta(days=i)).strftime(date_format) for i in range(days + 1)]
        
        # Базовый словарь с данными по дням
        daily_data = {
            'dates': dates,
            'successful': [0] * (days + 1),
            'failed': [0] * (days + 1),
            'pending': [0] * (days + 1),
            'total': [0] * (days + 1),
            'amount': [0] * (days + 1)
        }
        
        # Получаем ежедневную статистику успешных платежей
        success_query = select(
            func.date_trunc('day', Transaction.created_at).label('day'),
            func.count(Transaction.id).label('count'),
            func.sum(Transaction.amount).label('amount')
        ).where(
            and_(
                Transaction.created_at >= start_date,
                Transaction.type.in_(['payment', 'subscription']),
                Transaction.status == 'completed'
            )
        ).group_by(
            func.date_trunc('day', Transaction.created_at)
        ).order_by(
            func.date_trunc('day', Transaction.created_at)
        )
        
        success_result = await session.execute(success_query)
        
        for day, count, amount in success_result.all():
            day_str = day.strftime(date_format)
            if day_str in dates:
                idx = dates.index(day_str)
                daily_data['successful'][idx] = int(count)
                daily_data['amount'][idx] = float(amount or 0)
                daily_data['total'][idx] += int(count)
        
        # Получаем ежедневную статистику неудачных платежей
        failed_query = select(
            func.date_trunc('day', Transaction.created_at).label('day'),
            func.count(Transaction.id).label('count')
        ).where(
            and_(
                Transaction.created_at >= start_date,
                Transaction.type.in_(['payment', 'subscription']),
                Transaction.status.in_(['failed', 'error', 'cancelled'])
            )
        ).group_by(
            func.date_trunc('day', Transaction.created_at)
        ).order_by(
            func.date_trunc('day', Transaction.created_at)
        )
        
        failed_result = await session.execute(failed_query)
        
        for day, count in failed_result.all():
            day_str = day.strftime(date_format)
            if day_str in dates:
                idx = dates.index(day_str)
                daily_data['failed'][idx] = int(count)
                daily_data['total'][idx] += int(count)
        
        # Получаем ежедневную статистику ожидающих платежей
        pending_query = select(
            func.date_trunc('day', Transaction.created_at).label('day'),
            func.count(Transaction.id).label('count')
        ).where(
            and_(
                Transaction.created_at >= start_date,
                Transaction.type.in_(['payment', 'subscription']),
                Transaction.status.in_(['pending', 'processing'])
            )
        ).group_by(
            func.date_trunc('day', Transaction.created_at)
        ).order_by(
            func.date_trunc('day', Transaction.created_at)
        )
        
        pending_result = await session.execute(pending_query)
        
        for day, count in pending_result.all():
            day_str = day.strftime(date_format)
            if day_str in dates:
                idx = dates.index(day_str)
                daily_data['pending'][idx] = int(count)
                daily_data['total'][idx] += int(count)
        
        return daily_data
    
    @staticmethod
    async def get_problem_transactions(session: AsyncSession, hours: int = 24) -> List[Dict[str, Any]]:
        """
        Получает список проблемных транзакций, которые требуют внимания
        
        Args:
            session: Сессия базы данных
            hours: Количество часов для поиска зависших транзакций (по умолчанию 24)
            
        Returns:
            List[Dict[str, Any]]: Список проблемных транзакций
        """
        # Время, после которого транзакция считается зависшей
        stall_threshold = datetime.datetime.now() - datetime.timedelta(hours=hours)
        
        # Запрос на поиск проблемных транзакций
        query = select(
            Transaction, 
            User.username,
            User.email
        ).join(
            User, Transaction.user_id == User.id, isouter=True
        ).where(
            and_(
                Transaction.type.in_(['payment', 'subscription']),
                or_(
                    # Зависшие транзакции в статусе pending/processing более hours часов
                    and_(
                        Transaction.status.in_(['pending', 'processing']),
                        Transaction.created_at <= stall_threshold
                    ),
                    # Транзакции с ошибками за последние 7 дней
                    and_(
                        Transaction.status == 'error',
                        Transaction.created_at >= datetime.datetime.now() - datetime.timedelta(days=7)
                    )
                )
            )
        ).order_by(
            desc(Transaction.created_at)
        )
        
        result = await session.execute(query)
        
        # Формируем список проблемных транзакций
        problem_transactions = []
        for transaction, username, email in result.all():
            # Определяем тип проблемы
            problem_type = "unknown"
            if transaction.status in ['pending', 'processing'] and transaction.created_at <= stall_threshold:
                problem_type = "stalled"
            elif transaction.status == 'error':
                problem_type = "error"
            
            # Время, прошедшее с момента создания транзакции
            time_since_creation = datetime.datetime.now() - transaction.created_at
            hours_pending = time_since_creation.total_seconds() / 3600
            
            problem_data = {
                'id': transaction.id,
                'user_id': transaction.user_id,
                'username': username or "Неизвестный",
                'email': email,
                'amount': transaction.amount,
                'currency': transaction.currency,
                'status': transaction.status,
                'payment_method': transaction.payment_method,
                'created_at': transaction.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                'transaction_id': transaction.transaction_id,
                'problem_type': problem_type,
                'hours_pending': round(hours_pending, 1),
                'payment_data': transaction.payment_data,
                'notes': transaction.notes if hasattr(transaction, 'notes') else None,
            }
            problem_transactions.append(problem_data)
        
        return problem_transactions