#!/usr/bin/env python
# coding: utf-8

"""
Сервис для мониторинга и отчетности по выплатам реферальных вознаграждений
"""

import os
import json
import csv
import logging
import datetime
from io import StringIO
from typing import Dict, List, Any, Optional, Tuple, Union, Iterable
from enum import Enum

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func, or_, and_, desc, asc, text, distinct, not_
from sqlalchemy.orm import joinedload

from db_models import (
    db, User, Transaction, WeeklyPayout, BatchPayout, 
    PayoutOperationLog, AdminActionLog
)
from config import ADMIN_IDS

logger = logging.getLogger(__name__)

class ReportFormat(Enum):
    """Форматы отчетов"""
    JSON = "json"  # JSON формат
    CSV = "csv"    # CSV формат
    TEXT = "text"  # Текстовый формат
    HTML = "html"  # HTML формат
    PDF = "pdf"    # PDF формат
    EXCEL = "excel"  # Excel формат

class PayoutMonitoringService:
    """Сервис для мониторинга и отчетности по выплатам реферальных вознаграждений"""
    
    @staticmethod
    async def get_fraud_detection_statistics(session: AsyncSession, period_days: int = 30) -> Dict[str, Any]:
        """
        Получение статистики по обнаружению мошенничества
        
        Args:
            session: Активная сессия базы данных
            period_days: Период в днях для анализа (по умолчанию 30 дней)
            
        Returns:
            dict: Статистика по обнаружению мошенничества
        """
        # Определяем начало периода
        period_start = datetime.datetime.now() - datetime.timedelta(days=period_days)
        
        # Запрос на получение статистики по заблокированным пользователям
        blocked_users_result = await session.execute(
            select(User)
            .where(
                and_(
                    User.is_blocked == True,
                    User.block_date >= period_start
                )
            )
        )
        blocked_users = blocked_users_result.scalars().all()
        
        # Запрос на получение статистики по подозрительным транзакциям
        suspicious_transactions_result = await session.execute(
            select(Transaction)
            .where(
                and_(
                    Transaction.created_at >= period_start,
                    Transaction.fraud_score > 50
                )
            )
        )
        suspicious_transactions = suspicious_transactions_result.scalars().all()
        
        # Формирование статистики
        fraud_stats = {
            "period_days": period_days,
            "period_start": period_start.isoformat(),
            "period_end": datetime.datetime.now().isoformat(),
            "blocked_users_count": len(blocked_users),
            "suspicious_transactions_count": len(suspicious_transactions),
            "blocked_users": [
                {
                    "id": user.id,
                    "block_date": user.block_date.isoformat() if user.block_date else None,
                    "block_reason": user.block_reason or "Неизвестно"
                }
                for user in blocked_users[:20]  # Ограничиваем список для отчета
            ],
            "suspicious_transactions": [
                {
                    "id": transaction.id,
                    "user_id": transaction.user_id,
                    "amount": float(transaction.amount),
                    "fraud_score": transaction.fraud_score,
                    "created_at": transaction.created_at.isoformat()
                }
                for transaction in suspicious_transactions[:20]  # Ограничиваем список для отчета
            ]
        }
        
        return fraud_stats
    
    @staticmethod
    async def get_referral_program_statistics(session: AsyncSession, period_days: int = 30) -> Dict[str, Any]:
        """
        Получение статистики по реферальной программе
        
        Args:
            session: Активная сессия базы данных
            period_days: Период в днях для анализа (по умолчанию 30 дней)
            
        Returns:
            dict: Статистика по реферальной программе
        """
        # Определяем начало периода
        period_start = datetime.datetime.now() - datetime.timedelta(days=period_days)
        
        # Запрос на получение статистики по рефералам
        referrals_result = await session.execute(
            select(User)
            .where(
                and_(
                    User.referrer_id != None,
                    User.created_at >= period_start
                )
            )
        )
        referrals = referrals_result.scalars().all()
        
        # Запрос на получение статистики по реферальным вознаграждениям
        rewards_result = await session.execute(
            select(Transaction)
            .where(
                and_(
                    Transaction.transaction_type == 'referral_reward',
                    Transaction.created_at >= period_start
                )
            )
        )
        rewards = rewards_result.scalars().all()
        
        # Формирование статистики
        referral_stats = {
            "period_days": period_days,
            "period_start": period_start.isoformat(),
            "period_end": datetime.datetime.now().isoformat(),
            "new_referrals_count": len(referrals),
            "rewards_count": len(rewards),
            "total_rewards_amount": sum(float(reward.amount) for reward in rewards),
            "referral_levels": {},
            "top_referrers": []
        }
        
        # Распределение рефералов по уровням
        for referral in referrals:
            level = referral.referral_level or 1
            if str(level) not in referral_stats["referral_levels"]:
                referral_stats["referral_levels"][str(level)] = 0
            referral_stats["referral_levels"][str(level)] += 1
        
        # Запрос на получение топ рефереров
        top_referrers_result = await session.execute(
            select(User.id, User.username, func.count(User.id).label('referral_count'))
            .join(User, User.referrer_id == User.id)
            .where(User.created_at >= period_start)
            .group_by(User.id, User.username)
            .order_by(desc('referral_count'))
            .limit(10)
        )
        
        for user_id, username, referral_count in top_referrers_result:
            referral_stats["top_referrers"].append({
                "user_id": user_id,
                "username": username,
                "referral_count": referral_count
            })
        
        return referral_stats
    
    @staticmethod
    async def get_user_activity_statistics(session: AsyncSession, period_days: int = 30) -> Dict[str, Any]:
        """
        Получение статистики по активности пользователей
        
        Args:
            session: Активная сессия базы данных
            period_days: Период в днях для анализа (по умолчанию 30 дней)
            
        Returns:
            dict: Статистика по активности пользователей
        """
        # Определяем начало периода
        period_start = datetime.datetime.now() - datetime.timedelta(days=period_days)
        
        # Запрос на получение новых пользователей
        new_users_result = await session.execute(
            select(func.count())
            .select_from(User)
            .where(User.created_at >= period_start)
        )
        new_users_count = new_users_result.scalar() or 0
        
        # Запрос на получение активных пользователей
        active_users_result = await session.execute(
            select(func.count())
            .select_from(User)
            .where(User.last_activity_date >= period_start)
        )
        active_users_count = active_users_result.scalar() or 0
        
        # Запрос на получение платящих пользователей
        paying_users_result = await session.execute(
            select(func.count(func.distinct(Transaction.user_id)))
            .select_from(Transaction)
            .where(
                and_(
                    Transaction.created_at >= period_start,
                    Transaction.transaction_type == 'subscription_payment',
                    Transaction.status == 'completed'
                )
            )
        )
        paying_users_count = paying_users_result.scalar() or 0
        
        # Формирование статистики
        activity_stats = {
            "period_days": period_days,
            "period_start": period_start.isoformat(),
            "period_end": datetime.datetime.now().isoformat(),
            "new_users_count": new_users_count,
            "active_users_count": active_users_count,
            "paying_users_count": paying_users_count,
            "conversion_rate": round(paying_users_count / active_users_count * 100, 2) if active_users_count > 0 else 0,
            "daily_activity": []
        }
        
        # Получение ежедневной активности
        daily_activity_result = await session.execute(
            select(
                func.date_trunc('day', User.last_activity_date).label('date'),
                func.count().label('count')
            )
            .where(User.last_activity_date >= period_start)
            .group_by(text("date"))
            .order_by(text("date"))
        )
        
        for date, count in daily_activity_result:
            activity_stats["daily_activity"].append({
                "date": date.isoformat(),
                "active_users": count
            })
        
        return activity_stats

    @staticmethod
    async def get_payout_statistics(session: AsyncSession, period_days: int = 30) -> Dict[str, Any]:
        """
        Получение статистики по выплатам за указанный период
        
        Args:
            session: Активная сессия базы данных
            period_days: Период в днях для анализа (по умолчанию 30 дней)
            
        Returns:
            dict: Статистика по выплатам
        """
        # Определяем начало периода
        period_start = datetime.datetime.now() - datetime.timedelta(days=period_days)
        
        # Статистика по еженедельным выплатам
        weekly_stats = await PayoutMonitoringService._get_weekly_payout_stats(session, period_start)
        
        # Статистика по пакетным выплатам
        batch_stats = await PayoutMonitoringService._get_batch_payout_stats(session, period_start)
        
        # Статистика по транзакциям
        transaction_stats = await PayoutMonitoringService._get_transaction_stats(session, period_start)
        
        # Статистика по времени обработки
        processing_stats = await PayoutMonitoringService._get_processing_time_stats(session, period_start)
        
        # Формируем общую статистику
        return {
            "period_days": period_days,
            "period_start": period_start.isoformat(),
            "period_end": datetime.datetime.now().isoformat(),
            "weekly_payouts": weekly_stats,
            "batch_payouts": batch_stats,
            "transactions": transaction_stats,
            "processing_times": processing_stats
        }
    
    @staticmethod
    async def _get_weekly_payout_stats(session: AsyncSession, period_start: datetime.datetime) -> Dict[str, Any]:
        """
        Получение статистики по еженедельным выплатам
        
        Args:
            session: Активная сессия базы данных
            period_start: Начало периода для анализа
            
        Returns:
            dict: Статистика по еженедельным выплатам
        """
        # Общее количество выплат
        count_result = await session.execute(
            select(func.count())
            .where(WeeklyPayout.created_at >= period_start)
        )
        total_count = count_result.scalar() or 0
        
        # Статистика по статусам
        status_result = await session.execute(
            select(WeeklyPayout.status, func.count())
            .where(WeeklyPayout.created_at >= period_start)
            .group_by(WeeklyPayout.status)
        )
        status_stats = {status: count for status, count in status_result}
        
        # Общая сумма выплат
        amount_result = await session.execute(
            select(func.sum(WeeklyPayout.total_amount))
            .where(
                and_(
                    WeeklyPayout.created_at >= period_start,
                    WeeklyPayout.status.in_(["completed", "processing"])
                )
            )
        )
        total_amount = amount_result.scalar() or 0
        
        # Статистика по дням
        daily_result = await session.execute(
            select(
                func.date_trunc('day', WeeklyPayout.created_at).label('date'),
                func.count().label('count'),
                func.sum(WeeklyPayout.total_amount).label('amount')
            )
            .where(WeeklyPayout.created_at >= period_start)
            .group_by(text("date"))
            .order_by(text("date"))
        )
        daily_stats = [
            {
                "date": row[0].isoformat(),
                "count": row[1],
                "amount": float(row[2] or 0)
            } 
            for row in daily_result
        ]
        
        return {
            "total_count": total_count,
            "total_amount": float(total_amount),
            "status_distribution": status_stats,
            "daily_stats": daily_stats
        }
    
    @staticmethod
    async def _get_batch_payout_stats(session: AsyncSession, period_start: datetime.datetime) -> Dict[str, Any]:
        """
        Получение статистики по пакетным выплатам
        
        Args:
            session: Активная сессия базы данных
            period_start: Начало периода для анализа
            
        Returns:
            dict: Статистика по пакетным выплатам
        """
        # Общее количество пакетных выплат
        count_result = await session.execute(
            select(func.count())
            .where(BatchPayout.created_at >= period_start)
        )
        total_count = count_result.scalar() or 0
        
        # Статистика по статусам
        status_result = await session.execute(
            select(BatchPayout.status, func.count())
            .where(BatchPayout.created_at >= period_start)
            .group_by(BatchPayout.status)
        )
        status_stats = {status: count for status, count in status_result}
        
        # Общая сумма пакетных выплат
        amount_result = await session.execute(
            select(func.sum(BatchPayout.total_amount))
            .where(
                and_(
                    BatchPayout.created_at >= period_start,
                    BatchPayout.status.in_(["completed", "processing"])
                )
            )
        )
        total_amount = amount_result.scalar() or 0
        
        # Статистика по группам
        tier_result = await session.execute(
            select(BatchPayout.tier_name, func.count(), func.sum(BatchPayout.total_amount))
            .where(BatchPayout.created_at >= period_start)
            .group_by(BatchPayout.tier_name)
        )
        tier_stats = [
            {
                "tier_name": row[0],
                "count": row[1],
                "amount": float(row[2] or 0)
            } 
            for row in tier_result
        ]
        
        return {
            "total_count": total_count,
            "total_amount": float(total_amount),
            "status_distribution": status_stats,
            "tier_stats": tier_stats
        }
    
    @staticmethod
    async def _get_transaction_stats(session: AsyncSession, period_start: datetime.datetime) -> Dict[str, Any]:
        """
        Получение статистики по транзакциям
        
        Args:
            session: Активная сессия базы данных
            period_start: Начало периода для анализа
            
        Returns:
            dict: Статистика по транзакциям
        """
        # Общее количество транзакций
        count_result = await session.execute(
            select(func.count())
            .where(
                and_(
                    Transaction.created_at >= period_start,
                    Transaction.transaction_type == 'referral_reward'
                )
            )
        )
        total_count = count_result.scalar() or 0
        
        # Статистика по статусам
        status_result = await session.execute(
            select(Transaction.status, func.count())
            .where(
                and_(
                    Transaction.created_at >= period_start,
                    Transaction.transaction_type == 'referral_reward'
                )
            )
            .group_by(Transaction.status)
        )
        status_stats = {status: count for status, count in status_result}
        
        # Общая сумма транзакций
        amount_result = await session.execute(
            select(func.sum(Transaction.amount))
            .where(
                and_(
                    Transaction.created_at >= period_start,
                    Transaction.transaction_type == 'referral_reward',
                    Transaction.status.in_(["completed", "processing", "pending"])
                )
            )
        )
        total_amount = amount_result.scalar() or 0
        
        # Распределение по размеру транзакций
        amount_distribution_result = await session.execute(
            select(
                case(
                    (Transaction.amount < 1000, "0-1000"),
                    (Transaction.amount < 3000, "1000-3000"),
                    (Transaction.amount < 5000, "3000-5000"),
                    (Transaction.amount < 10000, "5000-10000"),
                    else_="10000+"
                ).label("range"),
                func.count()
            )
            .where(
                and_(
                    Transaction.created_at >= period_start,
                    Transaction.transaction_type == 'referral_reward'
                )
            )
            .group_by(text("range"))
            .order_by(text("range"))
        )
        amount_distribution = {range_: count for range_, count in amount_distribution_result}
        
        return {
            "total_count": total_count,
            "total_amount": float(total_amount),
            "status_distribution": status_stats,
            "amount_distribution": amount_distribution
        }
    
    @staticmethod
    async def _get_processing_time_stats(session: AsyncSession, period_start: datetime.datetime) -> Dict[str, Any]:
        """
        Получение статистики по времени обработки выплат
        
        Args:
            session: Активная сессия базы данных
            period_start: Начало периода для анализа
            
        Returns:
            dict: Статистика по времени обработки
        """
        # Получаем данные о времени выполнения операций
        time_result = await session.execute(
            select(PayoutOperationLog.operation_type, 
                   func.avg(PayoutOperationLog.execution_time_ms),
                   func.min(PayoutOperationLog.execution_time_ms),
                   func.max(PayoutOperationLog.execution_time_ms))
            .where(
                and_(
                    PayoutOperationLog.created_at >= period_start,
                    PayoutOperationLog.execution_time_ms != None  # noqa: E711
                )
            )
            .group_by(PayoutOperationLog.operation_type)
        )
        
        operation_stats = [
            {
                "operation_type": op_type,
                "avg_time_ms": float(avg_time or 0),
                "min_time_ms": float(min_time or 0),
                "max_time_ms": float(max_time or 0)
            }
            for op_type, avg_time, min_time, max_time in time_result
        ]
        
        # Статистика по ошибкам
        error_result = await session.execute(
            select(PayoutOperationLog.operation_type, func.count())
            .where(
                and_(
                    PayoutOperationLog.created_at >= period_start,
                    PayoutOperationLog.status == 'failed'
                )
            )
            .group_by(PayoutOperationLog.operation_type)
        )
        
        error_stats = {op_type: count for op_type, count in error_result}
        
        # Статистика по повторным попыткам
        retry_result = await session.execute(
            select(func.avg(PayoutOperationLog.retry_count))
            .where(
                and_(
                    PayoutOperationLog.created_at >= period_start,
                    PayoutOperationLog.retry_count > 0
                )
            )
        )
        
        avg_retry_count = retry_result.scalar() or 0
        
        return {
            "operation_stats": operation_stats,
            "error_stats": error_stats,
            "avg_retry_count": float(avg_retry_count)
        }
    
    @staticmethod
    async def get_payout_report(session: AsyncSession, payout_id: int, format: ReportFormat = ReportFormat.JSON) -> Tuple[str, bytes]:
        """
        Генерация отчета по конкретной выплате
        
        Args:
            session: Активная сессия базы данных
            payout_id: ID выплаты
            format: Формат отчета
            
        Returns:
            tuple: (mime_type, content)
        """
        # Получаем информацию о выплате
        payout_result = await session.execute(
            select(WeeklyPayout).where(WeeklyPayout.id == payout_id)
        )
        payout = payout_result.scalars().first()
        
        if not payout:
            raise ValueError(f"Weekly payout with ID {payout_id} not found")
        
        # Получаем информацию о транзакциях
        transactions_result = await session.execute(
            select(Transaction)
            .where(Transaction.payout_id == payout_id)
            .order_by(Transaction.user_id)
        )
        transactions = transactions_result.scalars().all()
        
        # Получаем информацию о пакетных выплатах
        batches_result = await session.execute(
            select(BatchPayout)
            .where(BatchPayout.weekly_payout_id == payout_id)
            .order_by(BatchPayout.created_at)
        )
        batches = batches_result.scalars().all()
        
        # Формируем данные для отчета
        report_data = {
            "payout_id": payout.id,
            "status": payout.status,
            "total_amount": float(payout.total_amount),
            "total_users": payout.total_users,
            "created_at": payout.created_at.isoformat(),
            "processed_at": payout.processed_at.isoformat() if payout.processed_at else None,
            "admin_id": payout.admin_id,
            "description": payout.description,
            "transaction_count": len(transactions),
            "transactions": [
                {
                    "transaction_id": tx.transaction_id,
                    "user_id": tx.user_id,
                    "amount": float(tx.amount),
                    "status": tx.status,
                    "created_at": tx.created_at.isoformat(),
                    "updated_at": tx.updated_at.isoformat() if tx.updated_at else None,
                    "error_message": tx.error_message
                }
                for tx in transactions
            ],
            "batch_count": len(batches),
            "batches": [
                {
                    "batch_id": batch.id,
                    "tier_name": batch.tier_name,
                    "status": batch.status,
                    "total_amount": float(batch.total_amount),
                    "transaction_count": batch.transaction_count,
                    "created_at": batch.created_at.isoformat(),
                    "processed_at": batch.processed_at.isoformat() if batch.processed_at else None
                }
                for batch in batches
            ]
        }
        
        # Генерируем отчет в указанном формате
        if format == ReportFormat.JSON:
            content = json.dumps(report_data, ensure_ascii=False, indent=2).encode('utf-8')
            return "application/json", content
        
        elif format == ReportFormat.CSV:
            output = StringIO()
            writer = csv.writer(output)
            
            # Заголовок отчета
            writer.writerow([f"Отчет по выплате #{payout.id}"])
            writer.writerow([f"Статус: {payout.status}"])
            writer.writerow([f"Общая сумма: {payout.total_amount}₽"])
            writer.writerow([f"Количество пользователей: {payout.total_users}"])
            writer.writerow([f"Дата создания: {payout.created_at.strftime('%d.%m.%Y %H:%M:%S')}"])
            if payout.processed_at:
                writer.writerow([f"Дата обработки: {payout.processed_at.strftime('%d.%m.%Y %H:%M:%S')}"])
            writer.writerow([])
            
            # Информация о транзакциях
            writer.writerow(["Транзакции:"])
            writer.writerow(["ID транзакции", "ID пользователя", "Сумма", "Статус", "Дата создания", "Ошибка"])
            for tx in transactions:
                writer.writerow([
                    tx.transaction_id,
                    tx.user_id,
                    f"{tx.amount}₽",
                    tx.status,
                    tx.created_at.strftime("%d.%m.%Y %H:%M:%S"),
                    tx.error_message or ""
                ])
            writer.writerow([])
            
            # Информация о пакетных выплатах
            writer.writerow(["Пакетные выплаты:"])
            writer.writerow(["ID пакета", "Название тира", "Статус", "Общая сумма", "Количество транзакций", "Дата создания"])
            for batch in batches:
                writer.writerow([
                    batch.id,
                    batch.tier_name,
                    batch.status,
                    f"{batch.total_amount}₽",
                    batch.transaction_count,
                    batch.created_at.strftime("%d.%m.%Y %H:%M:%S")
                ])
            
            content = output.getvalue().encode('utf-8')
            return "text/csv", content
        
        elif format == ReportFormat.TEXT:
            lines = [
                f"Отчет по выплате #{payout.id}",
                f"Статус: {payout.status}",
                f"Общая сумма: {payout.total_amount}₽",
                f"Количество пользователей: {payout.total_users}",
                f"Дата создания: {payout.created_at.strftime('%d.%m.%Y %H:%M:%S')}",
            ]
            
            if payout.processed_at:
                lines.append(f"Дата обработки: {payout.processed_at.strftime('%d.%m.%Y %H:%M:%S')}")
            
            lines.append("")
            lines.append(f"Транзакции ({len(transactions)}):")
            
            for i, tx in enumerate(transactions[:50], 1):  # Первые 50 транзакций
                lines.append(f"{i}. ID: {tx.transaction_id}, Пользователь: {tx.user_id}, Сумма: {tx.amount}₽, Статус: {tx.status}")
                if tx.error_message:
                    lines.append(f"   Ошибка: {tx.error_message}")
            
            if len(transactions) > 50:
                lines.append(f"... и еще {len(transactions) - 50} транзакций")
            
            lines.append("")
            lines.append(f"Пакетные выплаты ({len(batches)}):")
            
            for i, batch in enumerate(batches, 1):
                lines.append(f"{i}. ID: {batch.id}, Тир: {batch.tier_name}, Сумма: {batch.total_amount}₽, Транзакций: {batch.transaction_count}, Статус: {batch.status}")
            
            content = "\n".join(lines).encode('utf-8')
            return "text/plain", content
        
        elif format == ReportFormat.HTML:
            html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Отчет по выплате #{payout.id}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        h1, h2 {{ color: #333; }}
        table {{ border-collapse: collapse; width: 100%; margin-bottom: 20px; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #f2f2f2; }}
        tr:nth-child(even) {{ background-color: #f9f9f9; }}
        .error {{ color: red; }}
        .success {{ color: green; }}
        .warning {{ color: orange; }}
    </style>
</head>
<body>
    <h1>Отчет по выплате #{payout.id}</h1>
    
    <table>
        <tr>
            <th>Параметр</th>
            <th>Значение</th>
        </tr>
        <tr>
            <td>Статус</td>
            <td class="{payout.status}">{payout.status}</td>
        </tr>
        <tr>
            <td>Общая сумма</td>
            <td>{payout.total_amount}₽</td>
        </tr>
        <tr>
            <td>Количество пользователей</td>
            <td>{payout.total_users}</td>
        </tr>
        <tr>
            <td>Дата создания</td>
            <td>{payout.created_at.strftime('%d.%m.%Y %H:%M:%S')}</td>
        </tr>"""
            
            if payout.processed_at:
                html += f"""
        <tr>
            <td>Дата обработки</td>
            <td>{payout.processed_at.strftime('%d.%m.%Y %H:%M:%S')}</td>
        </tr>"""
            
            html += f"""
    </table>
    
    <h2>Пакетные выплаты ({len(batches)})</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Название тира</th>
            <th>Статус</th>
            <th>Общая сумма</th>
            <th>Транзакций</th>
            <th>Дата создания</th>
        </tr>"""
            
            for batch in batches:
                html += f"""
        <tr>
            <td>{batch.id}</td>
            <td>{batch.tier_name}</td>
            <td class="{batch.status}">{batch.status}</td>
            <td>{batch.total_amount}₽</td>
            <td>{batch.transaction_count}</td>
            <td>{batch.created_at.strftime('%d.%m.%Y %H:%M:%S')}</td>
        </tr>"""
            
            html += f"""
    </table>
    
    <h2>Транзакции ({len(transactions)})</h2>
    <table>
        <tr>
            <th>ID транзакции</th>
            <th>ID пользователя</th>
            <th>Сумма</th>
            <th>Статус</th>
            <th>Дата создания</th>
            <th>Ошибка</th>
        </tr>"""
            
            for tx in transactions[:100]:  # Показываем первые 100 транзакций
                html += f"""
        <tr>
            <td>{tx.transaction_id}</td>
            <td>{tx.user_id}</td>
            <td>{tx.amount}₽</td>
            <td class="{tx.status}">{tx.status}</td>
            <td>{tx.created_at.strftime('%d.%m.%Y %H:%M:%S')}</td>
            <td class="error">{tx.error_message or ""}</td>
        </tr>"""
            
            if len(transactions) > 100:
                html += f"""
        <tr>
            <td colspan="6">... и еще {len(transactions) - 100} транзакций</td>
        </tr>"""
            
            html += """
    </table>
</body>
</html>"""
            
            content = html.encode('utf-8')
            return "text/html", content
        
        else:
            raise ValueError(f"Unsupported report format: {format}")
    
    @staticmethod
    async def get_referral_dashboard_data(session: AsyncSession, period_days: int = 30) -> Dict[str, Any]:
        """
        Получение данных для дашборда по реферальной программе
        
        Args:
            session: Активная сессия базы данных
            period_days: Период в днях для анализа (по умолчанию 30 дней)
            
        Returns:
            dict: Данные для дашборда
        """
        # Определяем начало периода
        period_start = datetime.datetime.now() - datetime.timedelta(days=period_days)
        
        # Суммарная статистика
        total_result = await session.execute(
            select(
                func.count(distinct(User.id)).label('total_users'),
                func.count(distinct(User.id)).filter(User.is_subscriber == True).label('total_subscribers'),  # noqa: E712
                func.count(distinct(User.id)).filter(User.referrer_id != None).label('total_referrals')  # noqa: E711
            )
        )
        
        total_row = total_result.fetchone()
        total_users = total_row[0] if total_row else 0
        total_subscribers = total_row[1] if total_row else 0
        total_referrals = total_row[2] if total_row else 0
        
        # Статистика за выбранный период
        period_result = await session.execute(
            select(
                func.count(distinct(User.id)).filter(User.joined_at >= period_start).label('new_users'),
                func.count(distinct(User.id)).filter(
                    and_(User.is_subscriber == True, User.joined_at >= period_start)  # noqa: E712
                ).label('new_subscribers'),
                func.count(distinct(User.id)).filter(
                    and_(User.referrer_id != None, User.joined_at >= period_start)  # noqa: E711
                ).label('new_referrals')
            )
        )
        
        period_row = period_result.fetchone()
        new_users = period_row[0] if period_row else 0
        new_subscribers = period_row[1] if period_row else 0
        new_referrals = period_row[2] if period_row else 0
        
        # Статистика по выплатам
        payment_result = await session.execute(
            select(
                func.sum(Transaction.amount).filter(
                    and_(
                        Transaction.transaction_type == 'referral_reward',
                        Transaction.status.in_(["completed", "processing", "pending"]),
                        Transaction.created_at >= period_start
                    )
                ).label('period_rewards'),
                func.sum(Transaction.amount).filter(
                    and_(
                        Transaction.transaction_type == 'referral_reward',
                        Transaction.status.in_(["completed", "processing", "pending"])
                    )
                ).label('total_rewards'),
                func.sum(Transaction.amount).filter(
                    and_(
                        Transaction.transaction_type == 'subscription',
                        Transaction.status == 'completed',
                        Transaction.created_at >= period_start
                    )
                ).label('period_revenue'),
                func.sum(Transaction.amount).filter(
                    and_(
                        Transaction.transaction_type == 'subscription',
                        Transaction.status == 'completed'
                    )
                ).label('total_revenue')
            )
        )
        
        payment_row = payment_result.fetchone()
        period_rewards = float(payment_row[0] or 0) if payment_row else 0
        total_rewards = float(payment_row[1] or 0) if payment_row else 0
        period_revenue = float(payment_row[2] or 0) if payment_row else 0
        total_revenue = float(payment_row[3] or 0) if payment_row else 0
        
        # Статистика по дням
        daily_result = await session.execute(
            select(
                func.date_trunc('day', User.joined_at).label('date'),
                func.count(distinct(User.id)).label('new_users'),
                func.count(distinct(User.id)).filter(User.is_subscriber == True).label('new_subscribers'),  # noqa: E712
                func.count(distinct(User.id)).filter(User.referrer_id != None).label('new_referrals')  # noqa: E711
            )
            .where(User.joined_at >= period_start)
            .group_by(text("date"))
            .order_by(text("date"))
        )
        
        daily_user_stats = [
            {
                "date": row[0].isoformat(),
                "new_users": row[1],
                "new_subscribers": row[2],
                "new_referrals": row[3]
            }
            for row in daily_result
        ]
        
        # Статистика по выплатам по дням
        daily_payment_result = await session.execute(
            select(
                func.date_trunc('day', Transaction.created_at).label('date'),
                func.sum(Transaction.amount).filter(
                    and_(
                        Transaction.transaction_type == 'referral_reward',
                        Transaction.status.in_(["completed", "processing", "pending"])
                    )
                ).label('rewards'),
                func.sum(Transaction.amount).filter(
                    and_(
                        Transaction.transaction_type == 'subscription',
                        Transaction.status == 'completed'
                    )
                ).label('revenue')
            )
            .where(Transaction.created_at >= period_start)
            .group_by(text("date"))
            .order_by(text("date"))
        )
        
        daily_payment_stats = [
            {
                "date": row[0].isoformat(),
                "rewards": float(row[1] or 0),
                "revenue": float(row[2] or 0)
            }
            for row in daily_payment_result
        ]
        
        # Топ рефереров
        top_referrers_result = await session.execute(
            select(
                User.referrer_id,
                func.count().label('referral_count')
            )
            .where(User.referrer_id != None)  # noqa: E711
            .group_by(User.referrer_id)
            .order_by(text("referral_count DESC"))
            .limit(10)
        )
        
        top_referrers = [
            {
                "user_id": row[0],
                "referral_count": row[1]
            }
            for row in top_referrers_result
        ]
        
        # Формируем данные для дашборда
        return {
            "period_days": period_days,
            "period_start": period_start.isoformat(),
            "period_end": datetime.datetime.now().isoformat(),
            "summary": {
                "total_users": total_users,
                "total_subscribers": total_subscribers,
                "total_referrals": total_referrals,
                "new_users": new_users,
                "new_subscribers": new_subscribers,
                "new_referrals": new_referrals,
                "period_rewards": period_rewards,
                "total_rewards": total_rewards,
                "period_revenue": period_revenue,
                "total_revenue": total_revenue,
                "reward_ratio": round(total_rewards / total_revenue * 100, 2) if total_revenue > 0 else 0
            },
            "daily_user_stats": daily_user_stats,
            "daily_payment_stats": daily_payment_stats,
            "top_referrers": top_referrers
        }
    
    @staticmethod
    async def export_user_data(session: AsyncSession, user_id: int, format: ReportFormat = ReportFormat.JSON) -> Tuple[str, bytes]:
        """
        Экспорт данных пользователя
        
        Args:
            session: Активная сессия базы данных
            user_id: ID пользователя
            format: Формат экспорта
            
        Returns:
            tuple: (mime_type, content)
        """
        # Получаем информацию о пользователе
        user_result = await session.execute(
            select(User).where(User.id == user_id)
        )
        user = user_result.scalars().first()
        
        if not user:
            raise ValueError(f"User with ID {user_id} not found")
        
        # Получаем транзакции пользователя
        transactions_result = await session.execute(
            select(Transaction)
            .where(Transaction.user_id == user_id)
            .order_by(desc(Transaction.created_at))
        )
        transactions = transactions_result.scalars().all()
        
        # Получаем рефералов пользователя
        referrals_result = await session.execute(
            select(User)
            .where(User.referrer_id == user_id)
            .order_by(User.joined_at)
        )
        referrals = referrals_result.scalars().all()
        
        # Формируем данные для экспорта
        user_data = {
            "user_id": user.id,
            "username": user.username,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "language_code": user.language_code,
            "is_subscriber": user.is_subscriber,
            "subscription_expires": user.subscription_expires.isoformat() if user.subscription_expires else None,
            "joined_at": user.joined_at.isoformat(),
            "referrer_id": user.referrer_id,
            "is_banned": user.is_banned,
            "ban_reason": user.ban_reason,
            "transactions": [
                {
                    "transaction_id": tx.transaction_id,
                    "transaction_type": tx.transaction_type,
                    "amount": float(tx.amount),
                    "status": tx.status,
                    "description": tx.description,
                    "created_at": tx.created_at.isoformat(),
                    "updated_at": tx.updated_at.isoformat() if tx.updated_at else None,
                    "payment_method": tx.payment_method,
                    "payment_id": tx.payment_id,
                    "payout_id": tx.payout_id,
                    "error_message": tx.error_message
                }
                for tx in transactions
            ],
            "referrals": [
                {
                    "user_id": ref.id,
                    "username": ref.username,
                    "first_name": ref.first_name,
                    "last_name": ref.last_name,
                    "is_subscriber": ref.is_subscriber,
                    "joined_at": ref.joined_at.isoformat()
                }
                for ref in referrals
            ]
        }
        
        # Генерируем отчет в указанном формате
        if format == ReportFormat.JSON:
            content = json.dumps(user_data, ensure_ascii=False, indent=2).encode('utf-8')
            return "application/json", content
        
        elif format == ReportFormat.CSV:
            output = StringIO()
            writer = csv.writer(output)
            
            # Информация о пользователе
            writer.writerow(["Информация о пользователе"])
            writer.writerow(["ID", "Имя пользователя", "Имя", "Фамилия", "Язык", "Подписчик", "Дата регистрации", "ID реферера"])
            writer.writerow([
                user.id,
                user.username,
                user.first_name,
                user.last_name,
                user.language_code,
                "Да" if user.is_subscriber else "Нет",
                user.joined_at.strftime("%d.%m.%Y %H:%M:%S"),
                user.referrer_id or ""
            ])
            writer.writerow([])
            
            # Транзакции пользователя
            writer.writerow(["Транзакции"])
            writer.writerow(["ID транзакции", "Тип", "Сумма", "Статус", "Описание", "Дата создания", "Метод оплаты"])
            for tx in transactions:
                writer.writerow([
                    tx.transaction_id,
                    tx.transaction_type,
                    f"{tx.amount}₽",
                    tx.status,
                    tx.description,
                    tx.created_at.strftime("%d.%m.%Y %H:%M:%S"),
                    tx.payment_method or ""
                ])
            writer.writerow([])
            
            # Рефералы пользователя
            writer.writerow(["Рефералы"])
            writer.writerow(["ID", "Имя пользователя", "Имя", "Фамилия", "Подписчик", "Дата регистрации"])
            for ref in referrals:
                writer.writerow([
                    ref.id,
                    ref.username,
                    ref.first_name,
                    ref.last_name,
                    "Да" if ref.is_subscriber else "Нет",
                    ref.joined_at.strftime("%d.%m.%Y %H:%M:%S")
                ])
            
            content = output.getvalue().encode('utf-8')
            return "text/csv", content
        
        elif format == ReportFormat.TEXT:
            lines = [
                f"Информация о пользователе {user.id}",
                f"Имя пользователя: {user.username}",
                f"Имя: {user.first_name}",
                f"Фамилия: {user.last_name}",
                f"Язык: {user.language_code}",
                f"Подписчик: {'Да' if user.is_subscriber else 'Нет'}",
                f"Дата регистрации: {user.joined_at.strftime('%d.%m.%Y %H:%M:%S')}",
                f"ID реферера: {user.referrer_id or 'Нет'}",
                "",
                f"Транзакции ({len(transactions)}):"
            ]
            
            for i, tx in enumerate(transactions[:20], 1):  # Первые 20 транзакций
                lines.append(f"{i}. {tx.transaction_type}: {tx.amount}₽, Статус: {tx.status}, Дата: {tx.created_at.strftime('%d.%m.%Y')}")
            
            if len(transactions) > 20:
                lines.append(f"... и еще {len(transactions) - 20} транзакций")
            
            lines.append("")
            lines.append(f"Рефералы ({len(referrals)}):")
            
            for i, ref in enumerate(referrals[:20], 1):  # Первые 20 рефералов
                lines.append(f"{i}. {ref.username} (ID: {ref.id}), Дата регистрации: {ref.joined_at.strftime('%d.%m.%Y')}")
            
            if len(referrals) > 20:
                lines.append(f"... и еще {len(referrals) - 20} рефералов")
            
            content = "\n".join(lines).encode('utf-8')
            return "text/plain", content
        
        elif format == ReportFormat.HTML:
            html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Данные пользователя {user.id}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        h1, h2 {{ color: #333; }}
        table {{ border-collapse: collapse; width: 100%; margin-bottom: 20px; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #f2f2f2; }}
        tr:nth-child(even) {{ background-color: #f9f9f9; }}
        .yes {{ color: green; }}
        .no {{ color: red; }}
    </style>
</head>
<body>
    <h1>Данные пользователя {user.id}</h1>
    
    <h2>Основная информация</h2>
    <table>
        <tr>
            <th>Параметр</th>
            <th>Значение</th>
        </tr>
        <tr>
            <td>ID</td>
            <td>{user.id}</td>
        </tr>
        <tr>
            <td>Имя пользователя</td>
            <td>{user.username}</td>
        </tr>
        <tr>
            <td>Имя</td>
            <td>{user.first_name}</td>
        </tr>
        <tr>
            <td>Фамилия</td>
            <td>{user.last_name}</td>
        </tr>
        <tr>
            <td>Язык</td>
            <td>{user.language_code}</td>
        </tr>
        <tr>
            <td>Подписчик</td>
            <td class="{'yes' if user.is_subscriber else 'no'}">{'Да' if user.is_subscriber else 'Нет'}</td>
        </tr>
        <tr>
            <td>Дата регистрации</td>
            <td>{user.joined_at.strftime('%d.%m.%Y %H:%M:%S')}</td>
        </tr>
        <tr>
            <td>ID реферера</td>
            <td>{user.referrer_id or 'Нет'}</td>
        </tr>
    </table>
    
    <h2>Транзакции ({len(transactions)})</h2>
    <table>
        <tr>
            <th>ID транзакции</th>
            <th>Тип</th>
            <th>Сумма</th>
            <th>Статус</th>
            <th>Описание</th>
            <th>Дата создания</th>
            <th>Метод оплаты</th>
        </tr>"""
            
            for tx in transactions[:50]:  # Первые 50 транзакций
                html += f"""
        <tr>
            <td>{tx.transaction_id}</td>
            <td>{tx.transaction_type}</td>
            <td>{tx.amount}₽</td>
            <td>{tx.status}</td>
            <td>{tx.description}</td>
            <td>{tx.created_at.strftime('%d.%m.%Y %H:%M:%S')}</td>
            <td>{tx.payment_method or ''}</td>
        </tr>"""
            
            if len(transactions) > 50:
                html += f"""
        <tr>
            <td colspan="7">... и еще {len(transactions) - 50} транзакций</td>
        </tr>"""
            
            html += f"""
    </table>
    
    <h2>Рефералы ({len(referrals)})</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Имя пользователя</th>
            <th>Имя</th>
            <th>Фамилия</th>
            <th>Подписчик</th>
            <th>Дата регистрации</th>
        </tr>"""
            
            for ref in referrals[:50]:  # Первые 50 рефералов
                html += f"""
        <tr>
            <td>{ref.id}</td>
            <td>{ref.username}</td>
            <td>{ref.first_name}</td>
            <td>{ref.last_name}</td>
            <td class="{'yes' if ref.is_subscriber else 'no'}">{'Да' if ref.is_subscriber else 'Нет'}</td>
            <td>{ref.joined_at.strftime('%d.%m.%Y %H:%M:%S')}</td>
        </tr>"""
            
            if len(referrals) > 50:
                html += f"""
        <tr>
            <td colspan="6">... и еще {len(referrals) - 50} рефералов</td>
        </tr>"""
            
            html += """
    </table>
</body>
</html>"""
            
            content = html.encode('utf-8')
            return "text/html", content
        
        else:
            raise ValueError(f"Unsupported export format: {format}")

# Функция для получения сервиса мониторинга
async def get_monitoring_service():
    """
    Получение экземпляра сервиса мониторинга
    
    Returns:
        PayoutMonitoringService: Экземпляр сервиса
    """
    return PayoutMonitoringService()