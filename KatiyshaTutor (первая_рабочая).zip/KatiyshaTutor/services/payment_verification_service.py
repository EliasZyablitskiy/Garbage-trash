#!/usr/bin/env python
# coding: utf-8

"""
Централизованный сервис проверки платежей
Предоставляет единый интерфейс для верификации платежей различных типов
"""

import os
import json
import logging
import hashlib
import hmac
import time
from datetime import datetime, timedelta
from typing import Dict, Any, Tuple, Optional, List, Union
from flask import current_app, Flask

from db_models import db, Transaction, User
from config import SUBSCRIPTION_DURATION_DAYS as SUBSCRIPTION_DAYS, SUBSCRIPTION_PRICE
# Импортируем здесь, чтобы избежать циклических импортов
# Используем импорт в методах, а не на уровне модуля

# Настройка логирования
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Создание обработчика для вывода в консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

# Создание файлового обработчика
import os
os.makedirs('logs', exist_ok=True)
file_handler = logging.FileHandler('logs/payment_verification.log')
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

# Импортируем константы из централизованного модуля
from services.payment_constants import PAYMENT_STATUS, ResultCode, NotificationType
from services.payment_result import PaymentResult

# Импортируем константы типов платежных систем
from services.payment_constants import PAYMENT_SYSTEMS

# Получаем секреты для платежных систем
ROBOKASSA_SECRET_KEY = os.environ.get('ROBOKASSA_SECRET_KEY', '')
ROBOKASSA_LOGIN = os.environ.get('ROBOKASSA_LOGIN', 'test_shop')
ROBOKASSA_PASSWORD1 = os.environ.get('ROBOKASSA_PASSWORD1', '')
ROBOKASSA_PASSWORD2 = os.environ.get('ROBOKASSA_PASSWORD2', '')

class PaymentVerificationService:
    """
    Сервис верификации платежей
    """
    
    def __init__(self):
        """
        Инициализация сервиса
        """
        self.app = None
        
    def init_app(self, app: Flask):
        """
        Инициализация приложения Flask
        
        Args:
            app: Flask-приложение
        """
        self.app = app
        
        with app.app_context():
            logger.info("Payment verification service initialized with Flask application context")
    
    def validate_robokassa_notification(self, notification_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Валидация уведомления от Robokassa без обновления статуса платежа
        
        Args:
            notification_data: Данные уведомления от Robokassa
            
        Returns:
            Dict[str, Any]: Словарь с результатами валидации для создания PaymentResult
        """
        result = {
            'success': False,
            'message': '',
            'transaction_id': None,
            'user_id': None,
            'amount': None
        }
        
        try:
            # Получаем данные из уведомления
            inv_id = notification_data.get('InvId', '')
            out_sum = notification_data.get('OutSum', '')
            signature = notification_data.get('SignatureValue', '')
            
            if not inv_id or not out_sum or not signature:
                logger.warning(f"Incomplete Robokassa notification: {notification_data}")
                result['message'] = "Incomplete notification data"
                return result
            
            # Проверяем подпись
            is_valid = self._verify_robokassa_signature(
                inv_id=inv_id,
                outsum=out_sum,
                signature=signature
            )
            
            if not is_valid:
                logger.warning(f"Invalid Robokassa signature: {notification_data}")
                result['message'] = "Invalid signature"
                return result
            
            # Находим транзакцию по InvId
            try:
                # Используем строковое сравнение для metadata, совместимое с SQLAlchemy
                transaction = Transaction.query.filter(
                    Transaction.metadata.contains({"robokassa_inv_id": inv_id})
                ).first()
            except Exception as db_error:
                logger.error(f"Database error when finding transaction: {str(db_error)}")
                result['message'] = f"Database error: {str(db_error)}"
                return result
            
            if not transaction:
                # Пробуем найти по external_id
                transaction = Transaction.query.filter_by(
                    external_id=f"robokassa_{inv_id}"
                ).first()
                
                if not transaction:
                    logger.warning(f"Transaction for Robokassa InvId {inv_id} not found")
                    result['message'] = f"Transaction for InvId {inv_id} not found"
                    return result
            
            # Проверяем сумму платежа
            if float(out_sum) < transaction.amount:
                logger.warning(f"Amount mismatch: expected {transaction.amount}, got {out_sum}")
                result['message'] = f"Amount mismatch: expected {transaction.amount}, got {out_sum}"
                result['transaction_id'] = transaction.id
                result['user_id'] = transaction.user_id
                result['amount'] = float(out_sum)
                return result
            
            # Проверяем, не был ли уже обработан этот платёж
            if transaction.status == PAYMENT_STATUS['COMPLETED']:
                logger.info(f"Payment already processed: InvId={inv_id}, transaction_id={transaction.id}")
                result['success'] = True
                result['message'] = "Payment already processed"
                result['transaction_id'] = transaction.id
                result['user_id'] = transaction.user_id
                result['amount'] = float(out_sum)
                return result
            
            # Все проверки прошли успешно
            result['success'] = True
            result['message'] = "Notification successfully validated"
            result['transaction_id'] = transaction.id
            result['user_id'] = transaction.user_id
            result['amount'] = float(out_sum)
            
            return result
            
        except Exception as e:
            logger.error(f"Error validating Robokassa notification: {str(e)}")
            result['message'] = f"Error validating notification: {str(e)}"
            return result
    
    def verify_sbp_notification(self, notification_data: Dict[str, Any]) -> Tuple[bool, str, Optional[int]]:
        """
        Проверка уведомления от СБП
        
        Args:
            notification_data: Данные уведомления от СБП
            
        Returns:
            Tuple[bool, str, Optional[int]]: Кортеж (успех, сообщение, ID транзакции)
        """
        try:
            # Получаем данные из уведомления
            order_id = notification_data.get('order_id', '')
            payment_id = notification_data.get('payment_id', '')
            status = notification_data.get('status', '')
            amount = notification_data.get('amount', 0)
            
            if not order_id and not payment_id:
                logger.warning(f"Incomplete SBP notification: {notification_data}")
                return False, "Missing order_id or payment_id", None
            
            # Находим транзакцию по order_id или payment_id
            transaction = None
            
            if order_id:
                transaction = Transaction.query.filter(
                    Transaction.metadata.contains({'order_id': order_id})
                ).first()
            
            if not transaction and payment_id:
                transaction = Transaction.query.filter(
                    Transaction.metadata.contains({'payment_id': payment_id})
                ).first()
            
            if not transaction:
                logger.warning(f"Transaction for SBP order_id {order_id} or payment_id {payment_id} not found")
                return False, f"Transaction not found", None
            
            # Маппинг статусов СБП на наши статусы
            status_mapping = {
                'pending': PAYMENT_STATUS['PENDING'],
                'processing': PAYMENT_STATUS['PENDING'],
                'completed': PAYMENT_STATUS['COMPLETED'],
                'success': PAYMENT_STATUS['COMPLETED'],
                'failed': PAYMENT_STATUS['FAILED'],
                'error': PAYMENT_STATUS['FAILED'],
                'canceled': PAYMENT_STATUS['CANCELLED'],
                'cancelled': PAYMENT_STATUS['CANCELLED'],
                'expired': PAYMENT_STATUS['EXPIRED']
            }
            
            new_status = status_mapping.get(status.lower(), transaction.status)
            
            # Обновляем статус платежа
            additional_data = {
                'sbp_notification': notification_data,
                'updated_at': datetime.now().isoformat()
            }
            
            if new_status == PAYMENT_STATUS['COMPLETED']:
                additional_data['completed_at'] = datetime.now().isoformat()
            
            success, message = self.update_payment_status(
                transaction_id=transaction.id,
                new_status=new_status,
                additional_data=additional_data
            )
            
            if not success:
                logger.error(f"Failed to update payment status: {message}")
                return False, message, transaction.id
            
            return True, f"Payment status updated to {new_status}", transaction.id
            
        except Exception as e:
            logger.error(f"Error verifying SBP notification: {str(e)}")
            return False, f"Error verifying notification: {str(e)}", None
    
    def process_payment(self, payment_result) -> Any:
        """
        Обработка платежа на основе результата проверки
        
        Args:
            payment_result: Объект PaymentResult с результатом проверки
            
        Returns:
            PaymentResult: Обновленный результат обработки платежа
        """
        # Обновляем статус обработки платежа
        payment_result.add_log("Starting payment processing")
        
        # Проверяем, успешен ли результат проверки
        if not payment_result.success:
            payment_result.add_log(f"Payment processing skipped: verification failed with code {payment_result.result_code.name}")
            return payment_result
            
        # Начинаем детальное логирование процесса
        logger.info(f"Processing payment for transaction_id={payment_result.transaction_id}, "
                    f"user_id={payment_result.user_id}, amount={payment_result.amount}")
        payment_result.add_log(f"Processing payment for user_id={payment_result.user_id}")
        
        # Проверка существования транзакции
        if payment_result.transaction_id is None:
            payment_result.success = False
            payment_result.result_code = ResultCode.TRANSACTION_NOT_FOUND
            payment_result.message = "Transaction ID is missing"
            payment_result.add_log("Failed: Transaction ID is missing")
            return payment_result
        
        try:
            # Получаем транзакцию
            transaction = Transaction.query.get(payment_result.transaction_id)
            if not transaction:
                payment_result.success = False
                payment_result.result_code = ResultCode.TRANSACTION_NOT_FOUND
                payment_result.message = f"Transaction not found: {payment_result.transaction_id}"
                payment_result.add_log(payment_result.message)
                return payment_result
            
            # Проверяем, не обработан ли уже платеж
            if transaction.status == PAYMENT_STATUS['COMPLETED']:
                payment_result.add_log(f"Payment already processed: transaction_id={transaction.id}")
                return payment_result
            
            # Обновляем статус платежа
            old_status = transaction.status
            transaction.status = PAYMENT_STATUS['COMPLETED']
            transaction.updated_at = datetime.now()
            
            # Фиксируем время успешной обработки платежа
            transaction.completed_at = datetime.now()
            
            # Обновляем метаданные транзакции, если они есть в payment_result
            if payment_result.additional_data:
                # Объединяем существующие метаданные с новыми
                metadata = transaction.metadata or {}
                metadata.update(payment_result.additional_data)
                # Добавляем информацию о верификации платежа
                metadata['verification'] = {
                    'timestamp': datetime.now().isoformat(),
                    'payment_system': payment_result.payment_system,
                    'result_code': payment_result.result_code.name
                }
                transaction.metadata = metadata
            
            payment_result.add_log(f"Transaction status updated: {old_status} -> {PAYMENT_STATUS['COMPLETED']}")
            logger.info(f"Успешно обновлен статус транзакции #{transaction.id} для пользователя {transaction.user_id}: {old_status} -> {PAYMENT_STATUS['COMPLETED']}")
            
            # Сохраняем изменения в рамках транзакции БД
            try:
                db.session.commit()
                payment_result.add_log(f"Transaction #{transaction.id} updated in database")
            except Exception as db_error:
                db.session.rollback()
                payment_result.success = False
                payment_result.result_code = ResultCode.DATABASE_ERROR
                payment_result.message = f"Database error: {str(db_error)}"
                payment_result.add_log(f"Failed to update transaction: {str(db_error)}")
                logger.error(f"Ошибка БД при обновлении транзакции #{transaction.id}: {str(db_error)}")
                return payment_result
            
            # Активируем подписку пользователя, если это платеж за подписку
            if transaction.type == 'subscription_payment':
                payment_result.add_log(f"Activating subscription for user_id={transaction.user_id}")
                subscription_result = self._activate_user_subscription(transaction.user_id, transaction.id, payment_result)
                if not subscription_result:
                    payment_result.add_log(f"Failed to activate subscription for user_id={transaction.user_id}")
                    logger.warning(f"Не удалось активировать подписку для пользователя {transaction.user_id} после успешного платежа #{transaction.id}")
            
            # Обрабатываем реферальные вознаграждения, если применимо
            try:
                self._process_referral_reward(transaction.user_id, payment_result)
                payment_result.add_log(f"Referral rewards processed for transaction #{transaction.id}")
            except Exception as ref_error:
                logger.error(f"Ошибка при обработке реферальных вознаграждений для транзакции #{transaction.id}: {str(ref_error)}")
                payment_result.add_log(f"Error processing referral rewards: {str(ref_error)}")
            
            # Отправляем уведомление о успешной оплате, если не было отправлено в _activate_user_subscription
            if transaction.type != 'subscription_payment' and transaction.user_id:
                self._send_payment_notification(transaction.user_id, transaction, payment_result)
            
            payment_result.add_log(f"Payment status updated: {old_status} -> {PAYMENT_STATUS['COMPLETED']}")
            return payment_result
            
        except Exception as e:
            db.session.rollback()
            payment_result.success = False
            payment_result.result_code = ResultCode.PROCESSING_ERROR
            payment_result.message = f"Error processing payment: {str(e)}"
            payment_result.add_log(payment_result.message)
            return payment_result
    
    def update_payment_status(self, transaction_id: int, new_status: str,
                            additional_data: Optional[Dict[str, Any]] = None) -> Tuple[bool, str]:
        """
        Обновление статуса платежа
        
        Args:
            transaction_id: ID транзакции
            new_status: Новый статус платежа
            additional_data: Дополнительные данные для обновления
            
        Returns:
            Tuple[bool, str]: Кортеж (успех, сообщение)
        """
        try:
            # Получаем транзакцию по ID
            transaction = Transaction.query.get(transaction_id)
            
            if not transaction:
                logger.warning(f"Transaction {transaction_id} not found")
                return False, f"Transaction {transaction_id} not found"
            
            # Если статус уже "COMPLETED", не меняем его
            if transaction.status == PAYMENT_STATUS['COMPLETED'] and new_status != PAYMENT_STATUS['COMPLETED']:
                logger.info(f"Transaction {transaction_id} already completed, ignoring status change to {new_status}")
                return True, f"Transaction already completed"
            
            # Если статус уже соответствует new_status, ничего не делаем
            if transaction.status == new_status:
                logger.info(f"Transaction {transaction_id} already has status {new_status}")
                return True, f"Status already set to {new_status}"
            
            # Сохраняем старый статус для логирования
            old_status = transaction.status
            
            # Обновляем статус транзакции
            transaction.status = new_status
            transaction.updated_at = datetime.now()
            
            # Обновляем metadata, если предоставлены дополнительные данные
            if additional_data:
                metadata = transaction.metadata or {}
                metadata.update(additional_data)
                transaction.metadata = metadata
                
                # Если есть completed_at в дополнительных данных, устанавливаем его
                if 'completed_at' in additional_data:
                    try:
                        completed_at = datetime.fromisoformat(additional_data['completed_at'])
                        transaction.completed_at = completed_at
                    except:
                        transaction.completed_at = datetime.now()
            
            # Если новый статус "COMPLETED", активируем подписку пользователя
            if new_status == PAYMENT_STATUS['COMPLETED']:
                transaction.completed_at = transaction.completed_at or datetime.now()
                
                # Активируем подписку пользователя
                subscription_activated = self._activate_user_subscription(transaction.user_id)
                
                if not subscription_activated:
                    logger.error(f"Failed to activate subscription for user {transaction.user_id}")
                    # Статус все равно обновляем, но логируем ошибку
            
            # Сохраняем изменения в базе данных
            db.session.commit()
            
            # Логируем изменение статуса
            logger.info(f"Transaction {transaction_id} status updated: {old_status} -> {new_status}")
            
            # Отправляем асинхронное уведомление о статусе платежа
            try:
                # Импортируем тут, чтобы избежать циклических импортов
                from services.notification_service import NotificationService, NotificationType
                import asyncio
                
                # Создаем и запускаем корутину для отправки уведомления
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                # Получаем экземпляр сервиса уведомлений
                notification_service = NotificationService.get_instance()
                
                # Отправляем уведомление через сервис
                loop.run_until_complete(
                    notification_service.send_payment_notification(
                        user_id=transaction.user_id,
                        transaction_id=transaction_id,
                        status=new_status
                    )
                )
                
                loop.close()
                
                logger.info(f"Payment notification sent to user {transaction.user_id}")
                
            except Exception as e:
                logger.error(f"Error sending payment notification: {str(e)}")
                # Продолжаем выполнение, даже если не удалось отправить уведомление
            
            return True, f"Payment status updated to {new_status}"
            
        except Exception as e:
            logger.error(f"Error updating payment status: {str(e)}")
            
            # Откатываем транзакцию
            db.session.rollback()
            
            return False, f"Error updating payment status: {str(e)}"
    
    def verify_transaction_by_id(self, transaction_id: int) -> Tuple[bool, str, Dict[str, Any]]:
        """
        Проверка транзакции по ID
        
        Args:
            transaction_id: ID транзакции
            
        Returns:
            Tuple[bool, str, Dict[str, Any]]: Кортеж (успех, сообщение, данные о транзакции)
        """
        try:
            # Получаем транзакцию по ID
            transaction = Transaction.query.get(transaction_id)
            
            if not transaction:
                logger.warning(f"Transaction {transaction_id} not found")
                return False, f"Transaction {transaction_id} not found", {}
            
            # Формируем данные о транзакции
            transaction_data = {
                'id': transaction.id,
                'user_id': transaction.user_id,
                'amount': transaction.amount,
                'status': transaction.status,
                'payment_method': transaction.payment_method,
                'created_at': transaction.created_at.isoformat() if transaction.created_at else None,
                'updated_at': transaction.updated_at.isoformat() if transaction.updated_at else None,
                'completed_at': transaction.completed_at.isoformat() if transaction.completed_at else None,
                'metadata': transaction.metadata or {}
            }
            
            return True, f"Transaction information retrieved", transaction_data
            
        except Exception as e:
            logger.error(f"Error retrieving transaction information: {str(e)}")
            return False, f"Error retrieving transaction information: {str(e)}", {}
    
    def verify_payment_link(self, payment_link: str) -> Tuple[bool, str, Optional[int]]:
        """
        Проверка платежной ссылки
        
        Args:
            payment_link: Платежная ссылка
            
        Returns:
            Tuple[bool, str, Optional[int]]: Кортеж (успех, сообщение, ID транзакции)
        """
        try:
            # Извлекаем идентификатор транзакции из платежной ссылки
            transaction_id = None
            
            # Проверка ссылок различных типов
            if 'transaction_id=' in payment_link:
                # Ссылка вида: /payment/sbp/123456/order_id?transaction_id=789
                import re
                match = re.search(r'transaction_id=(\d+)', payment_link)
                if match:
                    transaction_id = int(match.group(1))
            
            elif '/payment/sbp/' in payment_link:
                # Ссылка вида: /payment/sbp/123456/789
                parts = payment_link.split('/')
                if len(parts) >= 5:
                    user_id = parts[-2]
                    order_id = parts[-1]
                    
                    # Ищем транзакцию по user_id и order_id
                    transaction = Transaction.query.filter(
                        Transaction.user_id == int(user_id),
                        Transaction.metadata.contains({'order_id': order_id})
                    ).first()
                    
                    if transaction:
                        transaction_id = transaction.id
            
            elif '/payment/manual/' in payment_link:
                # Ссылка вида: /payment/manual/123456/789
                parts = payment_link.split('/')
                if len(parts) >= 5:
                    user_id = parts[-2]
                    payment_id = parts[-1]
                    
                    # Ищем транзакцию по user_id и payment_id
                    transaction = Transaction.query.filter(
                        Transaction.user_id == int(user_id),
                        Transaction.metadata.contains({'payment_id': payment_id})
                    ).first()
                    
                    if transaction:
                        transaction_id = transaction.id
            
            # Если не удалось извлечь transaction_id, возвращаем ошибку
            if not transaction_id:
                logger.warning(f"Could not extract transaction ID from payment link: {payment_link}")
                return False, f"Invalid payment link format", None
            
            # Проверяем существование транзакции
            transaction = Transaction.query.get(transaction_id)
            
            if not transaction:
                logger.warning(f"Transaction {transaction_id} not found")
                return False, f"Transaction {transaction_id} not found", None
            
            # Возвращаем информацию о транзакции
            return True, f"Payment link verified", transaction_id
            
        except Exception as e:
            logger.error(f"Error verifying payment link: {str(e)}")
            return False, f"Error verifying payment link: {str(e)}", None
    
    def create_payment_transaction(self, user_id: int, amount: float, payment_method: str,
                                description: str = "Оплата подписки",
                                metadata: Optional[Dict[str, Any]] = None) -> Tuple[bool, str, Optional[int]]:
        """
        Создание транзакции платежа
        
        Args:
            user_id: ID пользователя
            amount: Сумма платежа
            payment_method: Метод оплаты
            description: Описание платежа
            metadata: Метаданные платежа
            
        Returns:
            Tuple[bool, str, Optional[int]]: Кортеж (успех, сообщение, ID транзакции)
        """
        try:
            # Проверяем существование пользователя
            user = User.query.get(user_id)
            
            if not user:
                logger.warning(f"User {user_id} not found")
                return False, f"User {user_id} not found", None
            
            # Создаем новую транзакцию
            transaction = Transaction(
                user_id=user_id,
                amount=amount,
                description=description,
                payment_method=payment_method,
                status=PAYMENT_STATUS['INITIATED'],
                created_at=datetime.now(),
                updated_at=datetime.now(),
                payment_expires_at=datetime.now() + timedelta(hours=1),  # Платеж действителен 1 час
                metadata=metadata or {}
            )
            
            # Сохраняем транзакцию в базе данных
            db.session.add(transaction)
            db.session.commit()
            
            logger.info(f"Created payment transaction {transaction.id} for user {user_id}")
            
            return True, f"Payment transaction created", transaction.id
            
        except Exception as e:
            logger.error(f"Error creating payment transaction: {str(e)}")
            
            # Откатываем транзакцию
            db.session.rollback()
            
            return False, f"Error creating payment transaction: {str(e)}", None
    
    def _send_subscription_notification(self, user, payment_result) -> None:
        """
        Отправка уведомления о активации подписки
        
        Args:
            user: Объект пользователя
            payment_result: Объект PaymentResult с результатом платежа
        """
        try:
            # Получаем экземпляр сервиса уведомлений из Flask app context
            notification_service = self._get_notification_service()
            
            # Проверяем, что сервис уведомлений инициализирован
            if not notification_service:
                payment_result.add_log("NotificationService not initialized, skipping notification")
                return
            
            # Получаем дату окончания подписки
            end_date = user.subscription_end
            if not end_date:
                payment_result.add_log("No subscription_end date found for user")
                return
            
            # Форматируем дату для отображения
            formatted_date = end_date.strftime("%d.%m.%Y")
            
            # Составляем сообщение
            message = f"✅ Подписка успешно активирована!\n\n"
            message += f"Ваша подписка будет действительна до {formatted_date}.\n"
            message += f"Теперь вы можете получать полные решения математических задач без ограничений."
            
            # Добавляем информацию о реферальной программе
            message += f"\n\nПриглашайте друзей и получайте вознаграждение за их подписки!"
            
            # Отправляем уведомление
            notification_result = notification_service.send_notification(
                user_id=user.id,
                text=message,
                notification_type=NotificationType.SUBSCRIPTION_REMINDER.value,
                metadata={
                    "transaction_id": payment_result.transaction_id,
                    "expires_at": end_date.isoformat(),
                    "status": "activated"
                }
            )
            
            payment_result.add_log(f"Subscription notification sent: {notification_result}")
            
        except Exception as e:
            payment_result.add_log(f"Error sending subscription notification: {str(e)}")
            logger.error(f"Error sending subscription notification: {str(e)}")
            
    def _get_notification_service(self):
        """
        Получает экземпляр сервиса уведомлений из app context
        
        Returns:
            NotificationService: Экземпляр сервиса уведомлений или None
        """
        try:
            app = current_app._get_current_object() if hasattr(current_app, '_get_current_object') else None
            if app and hasattr(app, 'notification_service'):
                return app.notification_service
                
            # Если не удалось получить из app context, пробуем из self.app
            if hasattr(self, 'app') and self.app and hasattr(self.app, 'notification_service'):
                return self.app.notification_service
                
            # Последняя попытка - импортировать напрямую
            try:
                from services.notification_service import notification_service
                return notification_service
            except (ImportError, AttributeError):
                logger.warning("Could not import notification_service")
                return None
        except Exception as e:
            logger.error(f"Error getting notification service: {str(e)}")
            return None
    
    def _send_payment_notification(self, user_id, transaction, payment_result) -> None:
        """
        Отправка уведомления о успешном платеже (не подписке)
        
        Args:
            user_id: ID пользователя
            transaction: Объект транзакции
            payment_result: Объект PaymentResult с результатом платежа
        """
        try:
            from services.notification_service import notification_service
            from db_models import User
            
            # Проверяем, что сервис уведомлений инициализирован
            if not notification_service:
                payment_result.add_log("NotificationService not initialized, skipping notification")
                return
                
            # Получаем пользователя
            user = User.query.get(user_id)
            if not user:
                payment_result.add_log(f"User {user_id} not found, skipping notification")
                return
            
            # Составляем сообщение
            message = f"✅ Платеж успешно выполнен!\n\n"
            message += f"Сумма: {transaction.amount} ₽\n"
            message += f"Тип: {transaction.type}\n"
            
            if transaction.description:
                message += f"Описание: {transaction.description}\n"
                
            # Отправляем уведомление
            notification_result = notification_service.send_notification(
                user_id=user_id,
                text=message,
                notification_type="payment_successful",
                metadata={
                    "transaction_id": transaction.id,
                    "amount": transaction.amount,
                    "payment_type": transaction.type
                }
            )
            
            payment_result.add_log(f"Payment notification sent: {notification_result}")
            
        except Exception as e:
            payment_result.add_log(f"Error sending payment notification: {str(e)}")
            logger.error(f"Error sending payment notification: {str(e)}")
                
    def _process_referral_reward(self, user, payment_result) -> None:
        """
        Обработка реферального вознаграждения
        
        Args:
            user: Объект пользователя
            payment_result: Объект PaymentResult с результатом платежа
        """
        try:
            # Проверяем, есть ли у пользователя реферер
            if not user.referrer_id:
                payment_result.add_log("No referrer found, skipping referral reward")
                return
                
            # Загружаем модуль обработки реферальных вознаграждений
            from services.payout_service import process_referral_commission
                
            # Обрабатываем вознаграждение
            result = process_referral_commission(
                user_id=user.id,
                transaction_id=payment_result.transaction_id,
                payment_amount=payment_result.amount or SUBSCRIPTION_PRICE
            )
            
            payment_result.add_log(f"Referral commission processed: {result}")
            
        except Exception as e:
            payment_result.add_log(f"Error processing referral reward: {str(e)}")
            logger.error(f"Error processing referral reward: {str(e)}")

    def _verify_robokassa_signature(self, inv_id: str, outsum: str, signature: str, 
                                user_id: Optional[str] = None) -> bool:
        """
        Проверка подписи Robokassa
        
        Args:
            inv_id: Номер счета
            outsum: Сумма платежа
            signature: Подпись
            user_id: ID пользователя (опционально)
            
        Returns:
            bool: True, если подпись верна, False в противном случае
        """
        try:
            # Формируем строку для проверки подписи
            signature_string = f"{outsum}:{inv_id}:{ROBOKASSA_PASSWORD2}"
            
            # Если указан user_id, добавляем его к строке подписи
            if user_id:
                signature_string += f":{user_id}"
            
            # Вычисляем MD5-хеш
            expected_signature = hashlib.md5(signature_string.encode()).hexdigest().lower()
            
            # Сравниваем с полученной подписью
            return expected_signature == signature.lower()
            
        except Exception as e:
            logger.error(f"Error verifying Robokassa signature: {str(e)}")
            return False
    
    def _activate_user_subscription(self, user_id: int, transaction_id: Optional[int] = None, payment_result = None) -> bool:
        """
        Активация подписки пользователя после успешного платежа
        
        Args:
            user_id: ID пользователя
            transaction_id: ID транзакции (опционально)
            payment_result: Объект PaymentResult с результатом обработки платежа (опционально)
            
        Returns:
            bool: True, если подписка активирована успешно, False в противном случае
        """
        try:
            # Получаем пользователя по ID
            user = User.query.get(user_id)
            
            if not user:
                logger.warning(f"User {user_id} not found")
                if payment_result:
                    payment_result.add_log(f"Failed to activate subscription: user {user_id} not found")
                return False
            
            # Вычисляем новую дату окончания подписки
            now = datetime.now()
            
            # Если подписка еще активна, добавляем SUBSCRIPTION_DAYS к текущей дате окончания
            if user.subscription_end and user.subscription_end > now:
                new_subscription_end = user.subscription_end + timedelta(days=SUBSCRIPTION_DAYS)
            else:
                # Иначе, добавляем SUBSCRIPTION_DAYS к текущей дате
                new_subscription_end = now + timedelta(days=SUBSCRIPTION_DAYS)
            
            # Обновляем дату окончания подписки
            user.subscription_end = new_subscription_end
            
            # Сохраняем изменения в базе данных
            db.session.commit()
            
            logger.info(f"Activated subscription for user {user_id} until {new_subscription_end}")
            
            return True
            
        except Exception as e:
            logger.error(f"Error activating subscription: {str(e)}")
            
            # Откатываем транзакцию
            db.session.rollback()
            
            return False


# Примечание: Этот класс не используется активно в коде,
# сохранен для обратной совместимости на случай будущей доработки платежной системы
class PaymentResult:
    """
    Класс для представления результата проверки платежа
    """
    
    def __init__(self, success: bool, message: str, transaction_id: Optional[int] = None,
                additional_data: Optional[Dict[str, Any]] = None):
        """
        Инициализация объекта результата платежа
        
        Args:
            success: Флаг успешности операции
            message: Сообщение о результате
            transaction_id: ID транзакции (опционально)
            additional_data: Дополнительные данные (опционально)
        """
        self.success = success
        self.message = message
        self.transaction_id = transaction_id
        self.additional_data = additional_data or {}


# Создаем единственный экземпляр сервиса
payment_verification_service = PaymentVerificationService()