#!/usr/bin/env python3
"""
Всесторонняя проверка компонентов системы
Проверяет взаимодействие с базой данных, безопасность, отчеты, начисления и оплаты
"""
import sys
import os
import logging
import json
import random
import time
import datetime
from sqlalchemy import func, desc
from sqlalchemy.exc import SQLAlchemyError
from db_config import db, get_flask_app
app = get_flask_app()
from db_models import User, MathProblem, Transaction, \
    AdminActionLog, WeeklyPayout
from services.security_service import SecurityService
from services.admin_roles import AdminRoleManager
from services.payment_service import PaymentService
from services.antifraud_service import AntiFraudService
from services.reporting_service import ReportingService
from services.notification_service import NotificationService
from services.subscription_service import SubscriptionService
from new_referral_code.optimized_referral_manager import OptimizedReferralManager
from new_referral_code.referral_adapter import get_or_create_referral_code, add_referral, \
    process_payment_rewards, get_pending_rewards, create_weekly_payout

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class SystemTester:
    def __init__(self):
        self.results = {
            "user_access": {},
            "referral_system": {},
            "payment_system": {},
            "security_system": {},
            "reporting_system": {},
            "subscription_system": {},
            "notification_system": {},
            "admin_system": {}
        }
        self.test_users = []
        self.admin_user_id = 5913639088  # ID администратора для тестирования
        self.referral_manager = OptimizedReferralManager()
        self.subscription_service = SubscriptionService()
        self.payment_service = PaymentService()
        self.security_service = SecurityService()
        self.reporting_service = ReportingService()
        self.notification_service = NotificationService()
        self.antifraud_service = AntiFraudService()
        self.admin_role_manager = AdminRoleManager()
    
    def setup_test_users(self):
        """Создание тестовых пользователей, если они не существуют"""
        test_user_ids = []
        
        try:
            with app.app_context():
                # Проверяем существующих тестовых пользователей
                existing_test_users = User.query.filter(
                    User.username.like('test_user_%')
                ).all()
                
                if len(existing_test_users) >= 5:
                    logger.info(f"Используем существующих тестовых пользователей: {len(existing_test_users)}")
                    self.test_users = existing_test_users[:5]
                    test_user_ids = [user.id for user in self.test_users]
                else:
                    # Создаем новых тестовых пользователей
                    for i in range(5):
                        random_suffix = random.randint(1000, 9999)
                        username = f"test_user_{i+1}_{random_suffix}"
                        user_id = random.randint(10000000, 99999999)
                        
                        # Проверяем, существует ли пользователь с таким ID
                        if User.query.get(user_id):
                            user_id = random.randint(10000000, 99999999)
                        
                        new_user = User(
                            id=user_id,
                            username=username,
                            first_name=f"Test{i+1}",
                            last_name="User",
                            created_at=datetime.datetime.now()
                        )
                        db.session.add(new_user)
                        logger.info(f"Создан тестовый пользователь: {username} с ID {user_id}")
                        
                        self.test_users.append(new_user)
                        test_user_ids.append(user_id)
                    
                    db.session.commit()
            
            self.results["user_access"]["setup_test_users"] = {
                "success": True,
                "user_ids": test_user_ids
            }
            return True
            
        except Exception as e:
            logger.error(f"Ошибка при создании тестовых пользователей: {e}")
            self.results["user_access"]["setup_test_users"] = {
                "success": False,
                "error": str(e)
            }
            return False
    
    def test_user_queries(self):
        """Тестирование запросов к таблице пользователей"""
        try:
            with app.app_context():
                # Проверка получения пользователя по ID
                user_id = self.test_users[0].id
                user = User.query.get(user_id)
                user_exists = user is not None
                
                # Проверка поиска пользователей по части имени
                users_by_name = User.query.filter(
                    User.first_name.like('Test%')
                ).all()
                name_search_works = len(users_by_name) > 0
                
                # Проверка сортировки и лимитирования
                recent_users = User.query.order_by(
                    desc(User.created_at)
                ).limit(10).all()
                sorting_works = len(recent_users) > 0
                
                # Проверка подсчета
                user_count = User.query.count()
                count_works = user_count > 0
                
                # Проверка агрегирующих функций
                subscription_stats = db.session.query(
                    func.count(User.id),
                    func.sum(case([(User.subscription_end > datetime.datetime.now(), 1)], else_=0))
                ).first()
                aggregation_works = subscription_stats is not None
            
            self.results["user_access"]["user_queries"] = {
                "success": user_exists and name_search_works and sorting_works and count_works and aggregation_works,
                "details": {
                    "user_by_id": user_exists,
                    "users_by_name": name_search_works,
                    "users_sorting": sorting_works,
                    "users_count": count_works,
                    "aggregation": aggregation_works,
                    "total_users": user_count,
                    "subscribed_users": subscription_stats[1] if aggregation_works else None
                }
            }
            
            return user_exists and name_search_works and sorting_works and count_works
            
        except Exception as e:
            logger.error(f"Ошибка при тестировании запросов к пользователям: {e}")
            self.results["user_access"]["user_queries"] = {
                "success": False,
                "error": str(e)
            }
            return False
    
    def test_referral_system(self):
        """Тестирование реферальной системы"""
        try:
            with app.app_context():
                # 1. Получение реферальных кодов
                user_id1 = self.test_users[0].id
                user_id2 = self.test_users[1].id
                user_id3 = self.test_users[2].id
                user_id4 = self.test_users[3].id
                
                # Получаем или создаем реферальные коды
                code1 = get_or_create_referral_code(user_id1)
                code2 = get_or_create_referral_code(user_id2)
                code3 = get_or_create_referral_code(user_id3)
                
                # 2. Проверка создания реферальной цепочки
                # user3 приглашает user2, user2 приглашает user1, user1 приглашает user4
                add_referral_result1 = add_referral(user_id2, code3)
                add_referral_result2 = add_referral(user_id1, code2)
                add_referral_result3 = add_referral(user_id4, code1)
                
                # 3. Проверка получения реферальной статистики через разные методы
                direct_stats1 = self.referral_manager.get_referral_stats(user_id1)
                direct_stats2 = self.referral_manager.get_referral_stats(user_id2)
                direct_stats3 = self.referral_manager.get_referral_stats(user_id3)
                
                # 4. Проверка получения реферальной цепочки
                chain1 = self.referral_manager.get_referral_chain(user_id1)
                chain2 = self.referral_manager.get_referral_chain(user_id2)
                chain3 = self.referral_manager.get_referral_chain(user_id3)
                chain4 = self.referral_manager.get_referral_chain(user_id4)
                
                # 5. Проверка обработки наград (тестовый платеж)
                test_payment_amount = 199.0  # стандартная сумма подписки
                rewards = process_payment_rewards(user_id4, test_payment_amount, "test_payment")
                
                # 6. Проверка получения ожидающих выплат
                pending_rewards, total_count = get_pending_rewards(page=1, page_size=50)
                
                # 7. Создание тестовой еженедельной выплаты
                now = datetime.datetime.now()
                test_payout_description = f"Test Payout {now.strftime('%Y-%m-%d %H:%M:%S')}"
                payout_id = create_weekly_payout(self.admin_user_id, test_payout_description)
                
                # Проверяем создание выплаты
                payout = WeeklyPayout.query.get(payout_id) if payout_id else None
                payout_created = payout is not None
                
                # 8. Проверка расчета комиссии по уровням
                level1_commission = 0.05  # 5%
                level2_commission = 0.02  # 2%
                level3_commission = 0.02  # 2%
                
                expected_level1_reward = test_payment_amount * level1_commission
                expected_level2_reward = test_payment_amount * level2_commission
                expected_level3_reward = test_payment_amount * level3_commission
                
                level_rewards = {}
                for reward in rewards:
                    level = reward.get('level', 0)
                    amount = reward.get('amount', 0)
                    level_rewards[level] = amount
                
                # Проверяем правильность расчета вознаграждений
                level1_correct = abs(level_rewards.get(1, 0) - expected_level1_reward) < 0.01
                level2_correct = abs(level_rewards.get(2, 0) - expected_level2_reward) < 0.01
                level3_correct = abs(level_rewards.get(3, 0) - expected_level3_reward) < 0.01
            
            self.results["referral_system"] = {
                "success": all([code1, code2, code3, add_referral_result1, add_referral_result2, 
                              add_referral_result3, direct_stats1, payout_created, 
                              level1_correct, level2_correct, level3_correct]),
                "details": {
                    "referral_codes": {
                        "user1_code": code1,
                        "user2_code": code2,
                        "user3_code": code3
                    },
                    "add_referral_results": {
                        "user2_invited_by_user3": add_referral_result1,
                        "user1_invited_by_user2": add_referral_result2,
                        "user4_invited_by_user1": add_referral_result3
                    },
                    "referral_stats": {
                        "user1_stats": direct_stats1,
                        "user2_stats": direct_stats2,
                        "user3_stats": direct_stats3
                    },
                    "referral_chains": {
                        "user1_chain": chain1,
                        "user2_chain": chain2,
                        "user3_chain": chain3,
                        "user4_chain": chain4
                    },
                    "payment_rewards": {
                        "rewards": rewards,
                        "level1_correct": level1_correct,
                        "level2_correct": level2_correct, 
                        "level3_correct": level3_correct
                    },
                    "pending_rewards": {
                        "count": total_count,
                        "first_page": [r.id for r in pending_rewards] if pending_rewards else []
                    },
                    "weekly_payout": {
                        "created": payout_created,
                        "id": payout_id if payout_created else None,
                        "description": test_payout_description
                    }
                }
            }
            
            return self.results["referral_system"]["success"]
            
        except Exception as e:
            logger.error(f"Ошибка при тестировании реферальной системы: {e}")
            self.results["referral_system"] = {
                "success": False,
                "error": str(e)
            }
            return False
    
    def test_payment_system(self):
        """Тестирование платежной системы"""
        try:
            with app.app_context():
                # 1. Создание тестовой транзакции
                user_id = self.test_users[0].id
                test_amount = 199.0
                
                transaction = Transaction(
                    user_id=user_id,
                    type="payment",
                    amount=test_amount,
                    status="pending",
                    currency="RUB",
                    created_at=datetime.datetime.now()
                )
                db.session.add(transaction)
                db.session.commit()
                
                # 2. Проверка создания транзакции
                transaction_created = Transaction.query.get(transaction.id) is not None
                
                # 3. Проверка обновления статуса транзакции
                transaction.status = "completed"
                db.session.commit()
                
                updated_transaction = Transaction.query.get(transaction.id)
                status_updated = updated_transaction.status == "completed"
                
                # 4. Проверка получения транзакций пользователя
                user_transactions = Transaction.query.filter_by(user_id=user_id).all()
                user_transactions_found = len(user_transactions) > 0
                
                # 5. Проверка унифицированной платежной системы
                # Создаем тестовые данные уведомления о платеже
                test_notification_data = {
                    "amount": "199.00",
                    "transaction_id": str(transaction.id),
                    "payment_system": "unified",
                    "status": "completed",
                    "signature": "test_signature"
                }
                
                # Импортируем необходимый сервис, только для тестирования
                from services.payment_verification_service_v2 import PaymentVerificationServiceV2
                verification_service = PaymentVerificationServiceV2()
                
                # Тестируем метод проверки платежа (в тестовом режиме)
                payment_result = verification_service.verify_payment_unified(
                    test_notification_data, "unified", is_test=True
                )
                signature_check = payment_result.success
                
                # 6. Проверка функциональности расчета стоимости подписки
                subscription_price = self.payment_service.get_subscription_price()
                price_calculation_works = subscription_price > 0
                
                # 7. Проверка создания метаданных для платежа
                payment_metadata = self.payment_service.create_payment_metadata(user_id)
                metadata_created = payment_metadata is not None
            
            self.results["payment_system"] = {
                "success": all([transaction_created, status_updated, user_transactions_found, 
                               signature_check, price_calculation_works, metadata_created]),
                "details": {
                    "transaction_created": transaction_created,
                    "status_updated": status_updated,
                    "user_transactions_found": user_transactions_found,
                    "transactions_count": len(user_transactions) if user_transactions_found else 0,
                    "unified_payment_verification": {
                        "success": signature_check,
                        "payment_system": "unified"
                    },
                    "price_calculation": {
                        "works": price_calculation_works,
                        "price": subscription_price
                    },
                    "payment_metadata": {
                        "created": metadata_created,
                        "data": payment_metadata
                    }
                }
            }
            
            return self.results["payment_system"]["success"]
            
        except Exception as e:
            logger.error(f"Ошибка при тестировании платежной системы: {e}")
            self.results["payment_system"] = {
                "success": False,
                "error": str(e)
            }
            return False
    
    def test_security_system(self):
        """Тестирование системы безопасности"""
        try:
            with app.app_context():
                # 1. Проверка функций авторизации администратора
                is_admin = self.security_service.is_admin(self.admin_user_id)
                is_not_admin = not self.security_service.is_admin(self.test_users[0].id)
                
                # 2. Проверка логирования действий администратора
                log_entry = AdminActionLog(
                    admin_id=self.admin_user_id,
                    action="test_action",
                    details=json.dumps({"test": "data"}),
                    created_at=datetime.datetime.now()
                )
                db.session.add(log_entry)
                db.session.commit()
                
                log_created = AdminActionLog.query.get(log_entry.id) is not None
                
                # 3. Проверка получения логов действий администратора
                admin_logs = AdminActionLog.query.filter_by(
                    admin_id=self.admin_user_id
                ).order_by(
                    desc(AdminActionLog.created_at)
                ).limit(10).all()
                
                logs_found = len(admin_logs) > 0
                
                # 4. Проверка антифрод системы
                # Создаем тестовую транзакцию для проверки
                test_transaction = Transaction(
                    user_id=self.test_users[0].id,
                    type="payment",
                    amount=199.0,
                    status="pending",
                    currency="RUB",
                    created_at=datetime.datetime.now()
                )
                db.session.add(test_transaction)
                db.session.commit()
                
                # Проверяем транзакцию на мошенничество
                fraud_check = self.antifraud_service.check_transaction(
                    test_transaction.id, is_test=True
                )
                
                # 5. Проверка уровней безопасности
                security_levels = self.security_service.get_security_levels()
                security_levels_defined = len(security_levels) > 0
                
                # 6. Проверка проверки реферальной цепочки на мошенничество
                user_id = self.test_users[0].id
                fraud_chain_check = self.antifraud_service.check_referral_chain(
                    user_id, is_test=True
                )
            
            self.results["security_system"] = {
                "success": all([is_admin, is_not_admin, log_created, logs_found, 
                              fraud_check is not None, security_levels_defined, 
                              fraud_chain_check is not None]),
                "details": {
                    "admin_authorization": {
                        "admin_check": is_admin,
                        "non_admin_check": is_not_admin
                    },
                    "admin_logging": {
                        "log_created": log_created,
                        "logs_found": logs_found,
                        "logs_count": len(admin_logs) if logs_found else 0
                    },
                    "antifraud": {
                        "transaction_check": fraud_check is not None,
                        "transaction_result": fraud_check,
                        "referral_chain_check": fraud_chain_check is not None,
                        "referral_chain_result": fraud_chain_check
                    },
                    "security_levels": {
                        "defined": security_levels_defined,
                        "levels": security_levels
                    }
                }
            }
            
            return self.results["security_system"]["success"]
            
        except Exception as e:
            logger.error(f"Ошибка при тестировании системы безопасности: {e}")
            self.results["security_system"] = {
                "success": False,
                "error": str(e)
            }
            return False
    
    def test_reporting_system(self):
        """Тестирование системы отчетов"""
        try:
            with app.app_context():
                # 1. Проверка генерации ежедневного отчета
                daily_report = self.reporting_service.generate_daily_report(is_test=True)
                daily_report_generated = daily_report is not None
                
                # 2. Проверка генерации еженедельного отчета
                weekly_report = self.reporting_service.generate_weekly_report(is_test=True)
                weekly_report_generated = weekly_report is not None
                
                # 3. Проверка генерации ежемесячного отчета
                monthly_report = self.reporting_service.generate_monthly_report(is_test=True)
                monthly_report_generated = monthly_report is not None
                
                # 4. Проверка генерации отчета по выплатам
                # Используем ранее созданную тестовую выплату если есть
                with app.app_context():
                    latest_payout = WeeklyPayout.query.order_by(
                        desc(WeeklyPayout.created_at)
                    ).first()
                
                if latest_payout:
                    payout_report = self.reporting_service.generate_payout_report(
                        latest_payout.id, is_test=True
                    )
                    payout_report_generated = payout_report is not None
                else:
                    payout_report_generated = False
                    payout_report = None
                
                # 5. Проверка генерации отчета по пользователю
                user_id = self.test_users[0].id
                user_report = self.reporting_service.generate_user_report(
                    user_id, is_test=True
                )
                user_report_generated = user_report is not None
            
            self.results["reporting_system"] = {
                "success": all([daily_report_generated, weekly_report_generated,
                                monthly_report_generated, user_report_generated]),
                "details": {
                    "daily_report": {
                        "generated": daily_report_generated,
                        "report_data": daily_report
                    },
                    "weekly_report": {
                        "generated": weekly_report_generated,
                        "report_data": weekly_report
                    },
                    "monthly_report": {
                        "generated": monthly_report_generated,
                        "report_data": monthly_report
                    },
                    "payout_report": {
                        "generated": payout_report_generated,
                        "report_data": payout_report
                    },
                    "user_report": {
                        "generated": user_report_generated,
                        "report_data": user_report
                    }
                }
            }
            
            return self.results["reporting_system"]["success"]
            
        except Exception as e:
            logger.error(f"Ошибка при тестировании системы отчетов: {e}")
            self.results["reporting_system"] = {
                "success": False,
                "error": str(e)
            }
            return False
    
    def test_subscription_system(self):
        """Тестирование системы подписок"""
        try:
            with app.app_context():
                # 1. Проверка активации подписки
                user_id = self.test_users[0].id
                
                # Сначала проверим текущий статус подписки
                initial_status = self.subscription_service.get_subscription_status(user_id)
                
                # Активируем подписку
                activation_result = self.subscription_service.activate_subscription(
                    user_id, days=30, transaction_id=None, is_test=True
                )
                
                # Проверяем статус после активации
                updated_status = self.subscription_service.get_subscription_status(user_id)
                subscription_activated = updated_status.get('active', False)
                
                # 2. Проверка проверки активности подписки
                is_active = self.subscription_service.is_subscription_active(user_id)
                
                # 3. Проверка обновления информации о подписке
                update_result = self.subscription_service.update_subscription_info(
                    user_id, active=True, expiry_date=datetime.datetime.now() + datetime.timedelta(days=30)
                )
                
                # 4. Проверка деактивации подписки
                deactivation_result = self.subscription_service.deactivate_subscription(
                    user_id, is_test=True
                )
                
                # Проверяем статус после деактивации
                final_status = self.subscription_service.get_subscription_status(user_id)
                subscription_deactivated = not final_status.get('active', True)
                
                # 5. Проверка бесплатного запроса
                free_request_status = self.subscription_service.use_free_request(user_id)
                
                # Повторная попытка использования бесплатного запроса
                second_free_request_status = self.subscription_service.use_free_request(user_id)
                
                # 6. Проверка сброса статуса бесплатного запроса
                reset_result = self.subscription_service.reset_free_request(user_id)
                
                # Проверка после сброса
                after_reset_status = self.subscription_service.use_free_request(user_id)
            
            self.results["subscription_system"] = {
                "success": all([activation_result, subscription_activated, 
                               is_active, update_result, deactivation_result, 
                               subscription_deactivated]),
                "details": {
                    "subscription_status": {
                        "initial": initial_status,
                        "after_activation": updated_status,
                        "after_deactivation": final_status
                    },
                    "activation": {
                        "result": activation_result,
                        "activated": subscription_activated
                    },
                    "is_active_check": is_active,
                    "update_result": update_result,
                    "deactivation": {
                        "result": deactivation_result,
                        "deactivated": subscription_deactivated
                    },
                    "free_request": {
                        "first_attempt": free_request_status,
                        "second_attempt": second_free_request_status,
                        "reset_result": reset_result,
                        "after_reset": after_reset_status
                    }
                }
            }
            
            return self.results["subscription_system"]["success"]
            
        except Exception as e:
            logger.error(f"Ошибка при тестировании системы подписок: {e}")
            self.results["subscription_system"] = {
                "success": False,
                "error": str(e)
            }
            return False
    
    def test_notification_system(self):
        """Тестирование системы уведомлений"""
        try:
            # 1. Проверка отправки уведомлений разных типов без реальной отправки
            # в Telegram, используя тестовый режим
            
            user_id = self.test_users[0].id
            
            # Уведомление об успешном платеже
            payment_success_notification = self.notification_service.send_notification(
                user_id, "payment_successful", {"amount": 199}, is_test=True
            )
            
            # Уведомление об ошибке платежа
            payment_error_notification = self.notification_service.send_notification(
                user_id, "payment_failed", {"error": "test_error"}, is_test=True
            )
            
            # Уведомление о реферальном вознаграждении
            referral_reward_notification = self.notification_service.send_notification(
                user_id, "referral_reward", {"amount": 9.95}, is_test=True
            )
            
            # Уведомление о начале обработки выплаты
            payout_notification = self.notification_service.send_notification(
                user_id, "payout_processing", {"amount": 9.95}, is_test=True
            )
            
            # Системное уведомление
            system_notification = self.notification_service.send_notification(
                user_id, "system", {"message": "test_message"}, is_test=True
            )
            
            # 2. Проверка форматирования сообщений
            test_message = "Test *bold* _italic_ [link](https://example.com)"
            formatted_message = self.notification_service.format_message(
                test_message, parse_mode="Markdown"
            )
            message_formatting_works = formatted_message is not None
            
            # 3. Проверка буферизации уведомлений
            buffered_notification = self.notification_service.buffer_notification(
                user_id, "test_notification", {"data": "test"}
            )
            
            # Проверка получения буферизованных уведомлений
            buffered_notifications = self.notification_service.get_buffered_notifications(
                user_id
            )
            buffering_works = len(buffered_notifications) > 0
            
            # 4. Проверка отправки буферизованных уведомлений
            send_buffered_result = self.notification_service.send_buffered_notifications(
                user_id, is_test=True
            )
            
            # 5. Проверка форматирования шаблонов уведомлений
            template_result = self.notification_service.format_template(
                "payment_successful", {"amount": 199}
            )
            template_formatting_works = template_result is not None
            
            self.results["notification_system"] = {
                "success": all([payment_success_notification, payment_error_notification,
                              referral_reward_notification, payout_notification,
                              system_notification, message_formatting_works,
                              buffered_notification, buffering_works,
                              send_buffered_result, template_formatting_works]),
                "details": {
                    "notifications": {
                        "payment_success": payment_success_notification,
                        "payment_error": payment_error_notification,
                        "referral_reward": referral_reward_notification,
                        "payout": payout_notification,
                        "system": system_notification
                    },
                    "message_formatting": {
                        "works": message_formatting_works,
                        "input": test_message,
                        "formatted": formatted_message
                    },
                    "buffering": {
                        "buffered": buffered_notification,
                        "retrieved": buffering_works,
                        "notifications_count": len(buffered_notifications) if buffering_works else 0,
                        "send_result": send_buffered_result
                    },
                    "template_formatting": {
                        "works": template_formatting_works,
                        "formatted": template_result
                    }
                }
            }
            
            return self.results["notification_system"]["success"]
            
        except Exception as e:
            logger.error(f"Ошибка при тестировании системы уведомлений: {e}")
            self.results["notification_system"] = {
                "success": False,
                "error": str(e)
            }
            return False
    
    def test_admin_system(self):
        """Тестирование административной системы"""
        try:
            with app.app_context():
                # 1. Проверка ролей администраторов
                is_superadmin = self.admin_role_manager.has_role(
                    self.admin_user_id, "super_admin"
                )
                
                # 2. Проверка прав доступа
                has_payout_permission = self.admin_role_manager.has_permission(
                    self.admin_user_id, "manage_payouts"
                )
                
                has_user_permission = self.admin_role_manager.has_permission(
                    self.admin_user_id, "manage_users"
                )
                
                # 3. Проверка создания действия администратора
                admin_action = AdminActionLog(
                    admin_id=self.admin_user_id,
                    action="test_admin_system",
                    details=json.dumps({"test": "admin_system"}),
                    created_at=datetime.datetime.now()
                )
                db.session.add(admin_action)
                db.session.commit()
                
                action_created = AdminActionLog.query.get(admin_action.id) is not None
                
                # 4. Проверка получения действий администратора
                admin_actions = AdminActionLog.query.filter_by(
                    admin_id=self.admin_user_id
                ).order_by(
                    desc(AdminActionLog.created_at)
                ).limit(10).all()
                
                actions_found = len(admin_actions) > 0
                
                # 5. Проверка административных функций для выплат
                latest_payout = WeeklyPayout.query.order_by(
                    desc(WeeklyPayout.created_at)
                ).first()
                
                if latest_payout:
                    # Проверка получения статуса выплаты
                    payout_status = WeeklyPayout.query.get(latest_payout.id).status
                    payout_status_retrieved = payout_status is not None
                    
                    # Обновление статуса выплаты (для теста)
                    latest_payout.status = "processing"
                    db.session.commit()
                    
                    updated_status = WeeklyPayout.query.get(latest_payout.id).status
                    payout_status_updated = updated_status == "processing"
                else:
                    payout_status_retrieved = False
                    payout_status_updated = False
                
                # 6. Проверка функций управления пользователями
                user_id = self.test_users[0].id
                
                # Блокировка пользователя
                user = User.query.get(user_id)
                user.is_blocked = True
                db.session.commit()
                
                block_status = User.query.get(user_id).is_blocked
                user_blocked = block_status == True
                
                # Разблокировка пользователя
                user = User.query.get(user_id)
                user.is_blocked = False
                db.session.commit()
                
                unblock_status = User.query.get(user_id).is_blocked
                user_unblocked = unblock_status == False
            
            self.results["admin_system"] = {
                "success": all([is_superadmin, has_payout_permission, has_user_permission,
                              action_created, actions_found, payout_status_retrieved,
                              payout_status_updated, user_blocked, user_unblocked]),
                "details": {
                    "admin_roles": {
                        "is_superadmin": is_superadmin,
                        "has_payout_permission": has_payout_permission,
                        "has_user_permission": has_user_permission
                    },
                    "admin_actions": {
                        "action_created": action_created,
                        "actions_found": actions_found,
                        "actions_count": len(admin_actions) if actions_found else 0
                    },
                    "payout_management": {
                        "status_retrieved": payout_status_retrieved,
                        "status_updated": payout_status_updated
                    },
                    "user_management": {
                        "user_blocked": user_blocked,
                        "user_unblocked": user_unblocked
                    }
                }
            }
            
            return self.results["admin_system"]["success"]
            
        except Exception as e:
            logger.error(f"Ошибка при тестировании административной системы: {e}")
            self.results["admin_system"] = {
                "success": False,
                "error": str(e)
            }
            return False
    
    def run_all_tests(self):
        """Запуск всех тестов"""
        logger.info("Запуск всестороннего тестирования системы...")
        
        # Подготавливаем тестовых пользователей
        logger.info("1. Настройка тестовых пользователей...")
        self.setup_test_users()
        
        # Тестируем запросы к пользователям
        logger.info("2. Тестирование запросов к пользователям...")
        self.test_user_queries()
        
        # Тестируем реферальную систему
        logger.info("3. Тестирование реферальной системы...")
        self.test_referral_system()
        
        # Тестируем платежную систему
        logger.info("4. Тестирование платежной системы...")
        self.test_payment_system()
        
        # Тестируем систему безопасности
        logger.info("5. Тестирование системы безопасности...")
        self.test_security_system()
        
        # Тестируем систему отчетов
        logger.info("6. Тестирование системы отчетов...")
        self.test_reporting_system()
        
        # Тестируем систему подписок
        logger.info("7. Тестирование системы подписок...")
        self.test_subscription_system()
        
        # Тестируем систему уведомлений
        logger.info("8. Тестирование системы уведомлений...")
        self.test_notification_system()
        
        # Тестируем административную систему
        logger.info("9. Тестирование административной системы...")
        self.test_admin_system()
        
        # Подсчитываем общие результаты
        successful_tests = sum(1 for result in self.results.values() if result.get('success', False))
        total_tests = len(self.results)
        success_rate = successful_tests / total_tests if total_tests > 0 else 0
        
        logger.info(f"Всестороннее тестирование завершено. Успешно: {successful_tests}/{total_tests} ({success_rate:.0%})")
        
        # Выводим общий результат
        return {
            "overall_success": success_rate == 1.0,
            "success_rate": success_rate,
            "successful_tests": successful_tests,
            "total_tests": total_tests,
            "results": self.results
        }
    
    def save_results_to_file(self, filename=None):
        """Сохранение результатов тестирования в файл"""
        if filename is None:
            timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            filename = f"system_test_results_{timestamp}.json"
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Результаты тестирования сохранены в файл: {filename}")
        return filename
    
    def analyze_results_and_suggest_fixes(self):
        """Анализ результатов и предложение исправлений"""
        suggestions = {}
        
        for system_name, result in self.results.items():
            if not result.get('success', False):
                suggestions[system_name] = {
                    "issues": [],
                    "suggestions": []
                }
                
                # Если есть конкретная ошибка, добавляем ее
                if 'error' in result:
                    suggestions[system_name]["issues"].append(result['error'])
                
                # Анализируем детали результата, если они есть
                if 'details' in result:
                    for detail_name, detail_result in result['details'].items():
                        if isinstance(detail_result, dict) and 'success' in detail_result and not detail_result['success']:
                            suggestions[system_name]["issues"].append(f"Проблема в {detail_name}: {detail_result.get('error', 'неизвестная ошибка')}")
                        elif isinstance(detail_result, bool) and not detail_result:
                            suggestions[system_name]["issues"].append(f"Проблема в {detail_name}")
                
                # Добавляем общие предложения по исправлению
                if system_name == "user_access":
                    suggestions[system_name]["suggestions"].append("Проверьте права доступа к базе данных")
                    suggestions[system_name]["suggestions"].append("Убедитесь, что таблица пользователей существует и имеет правильную структуру")
                elif system_name == "referral_system":
                    suggestions[system_name]["suggestions"].append("Проверьте миграцию реферальной системы")
                    suggestions[system_name]["suggestions"].append("Убедитесь, что OptimizedReferralManager корректно инициализирован")
                elif system_name == "payment_system":
                    suggestions[system_name]["suggestions"].append("Проверьте настройки Robokassa и ключи доступа")
                    suggestions[system_name]["suggestions"].append("Убедитесь, что таблица транзакций имеет правильную структуру")
                elif system_name == "security_system":
                    suggestions[system_name]["suggestions"].append("Проверьте настройки безопасности и права администраторов")
                    suggestions[system_name]["suggestions"].append("Убедитесь, что AntifraudService корректно инициализирован")
                elif system_name == "reporting_system":
                    suggestions[system_name]["suggestions"].append("Проверьте настройки генерации отчетов")
                    suggestions[system_name]["suggestions"].append("Убедитесь, что ReportingService имеет доступ к необходимым данным")
                elif system_name == "subscription_system":
                    suggestions[system_name]["suggestions"].append("Проверьте логику работы с подписками")
                    suggestions[system_name]["suggestions"].append("Убедитесь, что таблица пользователей содержит необходимые поля для подписок")
                elif system_name == "notification_system":
                    suggestions[system_name]["suggestions"].append("Проверьте настройки Telegram API и токена бота")
                    suggestions[system_name]["suggestions"].append("Убедитесь, что шаблоны уведомлений корректно настроены")
                elif system_name == "admin_system":
                    suggestions[system_name]["suggestions"].append("Проверьте настройки административных ролей и прав")
                    suggestions[system_name]["suggestions"].append("Убедитесь, что таблица административных действий доступна")
        
        return suggestions

if __name__ == "__main__":
    try:
        # Создаем и запускаем тестер
        tester = SystemTester()
        results = tester.run_all_tests()
        
        # Сохраняем результаты в файл
        results_file = tester.save_results_to_file()
        
        # Анализируем результаты и предлагаем исправления
        suggestions = tester.analyze_results_and_suggest_fixes()
        
        # Если есть проблемы, выводим предложения по исправлению
        if suggestions:
            logger.info("\nПредложения по исправлению выявленных проблем:")
            for system_name, system_suggestions in suggestions.items():
                logger.info(f"\n{system_name.upper()}:")
                
                if system_suggestions["issues"]:
                    logger.info("  Выявленные проблемы:")
                    for issue in system_suggestions["issues"]:
                        logger.info(f"    - {issue}")
                
                if system_suggestions["suggestions"]:
                    logger.info("  Предложения по исправлению:")
                    for suggestion in system_suggestions["suggestions"]:
                        logger.info(f"    - {suggestion}")
        
        # Выводим итоговый результат
        if results["overall_success"]:
            logger.info("\n✅ Все системы работают корректно!")
        else:
            logger.info(f"\n⚠️ Выявлены проблемы в работе некоторых систем. "
                      f"Успешно пройдено {results['successful_tests']} из {results['total_tests']} "
                      f"тестов ({results['success_rate']:.0%}).")
            logger.info(f"Детальные результаты сохранены в файле: {results_file}")
        
        sys.exit(0 if results["overall_success"] else 1)
        
    except Exception as e:
        logger.error(f"Ошибка при запуске тестирования: {e}")
        sys.exit(1)