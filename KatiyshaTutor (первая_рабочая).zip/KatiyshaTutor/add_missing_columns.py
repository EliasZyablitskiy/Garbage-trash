#!/usr/bin/env python3
"""
Скрипт для добавления недостающих колонок в таблицы базы данных
"""
import sys
import logging
from sqlalchemy import text
from db_config import db, get_flask_app

app = get_flask_app()

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def add_subscription_end_to_users():
    """
    Добавляет поле subscription_end в таблицу users и копирует значения из subscription_expiry
    """
    try:
        with app.app_context():
            # Проверяем существование колонки
            column_exists = db.session.execute(text("""
                SELECT EXISTS (
                    SELECT 1 
                    FROM information_schema.columns 
                    WHERE table_name = 'users' 
                    AND column_name = 'subscription_end'
                );
            """)).scalar()
            
            if column_exists:
                logger.info("Колонка subscription_end уже существует в таблице users")
                return True
            
            # Добавляем колонку
            db.session.execute(text("""
                ALTER TABLE users
                ADD COLUMN subscription_end TIMESTAMP;
            """))
            
            # Копируем значения из subscription_expiry
            db.session.execute(text("""
                UPDATE users
                SET subscription_end = subscription_expiry;
            """))
            
            db.session.commit()
            logger.info("Колонка subscription_end успешно добавлена в таблицу users")
            return True
    
    except Exception as e:
        logger.error(f"Ошибка при добавлении колонки subscription_end: {str(e)}")
        return False

def add_admin_id_to_weekly_payouts():
    """
    Добавляет поле admin_id в таблицу weekly_payouts
    """
    try:
        with app.app_context():
            # Проверяем существование колонки
            column_exists = db.session.execute(text("""
                SELECT EXISTS (
                    SELECT 1 
                    FROM information_schema.columns 
                    WHERE table_name = 'weekly_payouts' 
                    AND column_name = 'admin_id'
                );
            """)).scalar()
            
            if column_exists:
                logger.info("Колонка admin_id уже существует в таблице weekly_payouts")
                return True
            
            # Добавляем колонку
            db.session.execute(text("""
                ALTER TABLE weekly_payouts
                ADD COLUMN admin_id BIGINT;
            """))
            
            # Устанавливаем внешний ключ
            db.session.execute(text("""
                ALTER TABLE weekly_payouts
                ADD CONSTRAINT fk_weekly_payouts_admin
                FOREIGN KEY (admin_id) REFERENCES users(id);
            """))
            
            db.session.commit()
            logger.info("Колонка admin_id успешно добавлена в таблицу weekly_payouts")
            return True
    
    except Exception as e:
        logger.error(f"Ошибка при добавлении колонки admin_id: {str(e)}")
        return False

def add_amount_to_weekly_payouts():
    """
    Добавляет поле amount в таблицу weekly_payouts и копирует значения из total_amount
    """
    try:
        with app.app_context():
            # Проверяем существование колонки
            column_exists = db.session.execute(text("""
                SELECT EXISTS (
                    SELECT 1 
                    FROM information_schema.columns 
                    WHERE table_name = 'weekly_payouts' 
                    AND column_name = 'amount'
                );
            """)).scalar()
            
            if column_exists:
                logger.info("Колонка amount уже существует в таблице weekly_payouts")
                return True
            
            # Добавляем колонку
            db.session.execute(text("""
                ALTER TABLE weekly_payouts
                ADD COLUMN amount FLOAT;
            """))
            
            # Копируем значения из total_amount
            db.session.execute(text("""
                UPDATE weekly_payouts
                SET amount = total_amount;
            """))
            
            # Устанавливаем NOT NULL
            db.session.execute(text("""
                ALTER TABLE weekly_payouts
                ALTER COLUMN amount SET NOT NULL;
            """))
            
            db.session.commit()
            logger.info("Колонка amount успешно добавлена в таблицу weekly_payouts")
            return True
    
    except Exception as e:
        logger.error(f"Ошибка при добавлении колонки amount: {str(e)}")
        return False

def main():
    """
    Основная функция
    """
    logger.info("Запуск миграции для добавления недостающих колонок...")
    
    # Добавляем колонку subscription_end в users
    subscription_end_added = add_subscription_end_to_users()
    
    # Добавляем колонку admin_id в weekly_payouts
    admin_id_added = add_admin_id_to_weekly_payouts()
    
    # Добавляем колонку amount в weekly_payouts
    amount_added = add_amount_to_weekly_payouts()
    
    # Подводим итоги
    if subscription_end_added and admin_id_added and amount_added:
        logger.info("✅ Миграция успешно завершена")
        return 0
    else:
        logger.error("❌ Миграция завершилась с ошибками")
        return 1

if __name__ == "__main__":
    sys.exit(main())