#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для добавления полей в таблицу transactions, необходимых для процессора платежей
"""

import os
import logging
import sys

# Настраиваем логирование
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Импортируем SQLAlchemy и модели
from sqlalchemy import create_engine, Column, String, DateTime, Integer, Text
from sqlalchemy.sql import text
from sqlalchemy.exc import SQLAlchemyError

def add_transaction_fields():
    """
    Добавляет необходимые поля в таблицу transactions
    """
    # Получаем строку подключения к базе данных
    database_url = os.environ.get('DATABASE_URL')
    if not database_url:
        logger.error("DATABASE_URL не указан в переменных окружения")
        sys.exit(1)
    
    logger.info("Подключение к базе данных...")
    engine = create_engine(database_url)
    connection = engine.connect()
    
    try:
        logger.info("Проверка существующих полей...")
        
        # Список полей для добавления и их SQL-определения
        fields_to_add = [
            ("external_id", "VARCHAR(255) UNIQUE"),
            ("idempotency_key", "VARCHAR(255) UNIQUE"),
            ("payment_method", "VARCHAR(50)"),
            ("payment_expires_at", "TIMESTAMP"),
            ("retry_count", "INTEGER DEFAULT 0"),
            ("last_error", "TEXT")
        ]
        
        # Проверяем и добавляем поля, если они отсутствуют
        for field_name, field_def in fields_to_add:
            # Проверяем, существует ли поле
            result = connection.execute(text(
                f"SELECT column_name FROM information_schema.columns "
                f"WHERE table_name = 'transactions' AND column_name = '{field_name}'"
            )).fetchone()
            
            if not result:
                logger.info(f"Добавляем поле {field_name} в таблицу transactions...")
                connection.execute(text(
                    f"ALTER TABLE transactions ADD COLUMN {field_name} {field_def}"
                ))
                
                # Создаем индекс для полей, если нужно
                if field_name in ["external_id", "idempotency_key"]:
                    logger.info(f"Создаем индекс для {field_name}...")
                    connection.execute(text(
                        f"CREATE INDEX idx_transactions_{field_name} ON transactions ({field_name})"
                    ))
                
                logger.info(f"Поле {field_name} успешно добавлено")
            else:
                logger.info(f"Поле {field_name} уже существует")
        
        # Проверяем, есть ли данные в таблице
        count = connection.execute(text("SELECT COUNT(*) FROM transactions")).scalar()
        logger.info(f"Текущее количество записей в таблице transactions: {count}")
        
        # Коммитим транзакцию
        connection.execute(text("COMMIT"))
        logger.info("Миграция успешно завершена")
        
    except SQLAlchemyError as e:
        logger.error(f"Ошибка при выполнении миграции: {e}")
        connection.execute(text("ROLLBACK"))
        sys.exit(1)
    finally:
        connection.close()
        engine.dispose()

def main():
    """
    Основная функция
    """
    try:
        logger.info("Запуск миграции для добавления полей в таблицу transactions...")
        add_transaction_fields()
        logger.info("Миграция успешно завершена")
    except Exception as e:
        logger.error(f"Ошибка при выполнении миграции: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()