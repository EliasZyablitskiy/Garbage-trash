#!/usr/bin/env python
# coding: utf-8

"""
Модуль для ограничения частоты запросов к боту (защита от флуда)
"""

import time
import logging
import functools
from typing import Dict, Tuple, Callable, Any, Optional
from telegram import Update
from telegram.ext import ContextTypes

logger = logging.getLogger(__name__)

# Словарь для хранения данных о последних запросах пользователей
# Формат: {user_id: {command_name: (timestamp, count)}}
request_history: Dict[int, Dict[str, Tuple[float, int]]] = {}

# Настройки по умолчанию
DEFAULT_RATE_LIMIT = 3  # Количество разрешенных запросов в период времени
DEFAULT_TIME_WINDOW = 60  # Период времени в секундах
DEFAULT_COOLDOWN = 30  # Время блокировки в секундах после превышения лимита

def rate_limit(
    limit: int = DEFAULT_RATE_LIMIT,
    window: int = DEFAULT_TIME_WINDOW,
    cooldown: int = DEFAULT_COOLDOWN,
    admin_bypass: bool = True,
    custom_message: Optional[str] = None
):
    """
    Декоратор для ограничения частоты вызова команд.
    
    Args:
        limit: Максимальное количество вызовов за временной период
        window: Временной период в секундах
        cooldown: Время блокировки в секундах после превышения лимита
        admin_bypass: Флаг, позволяющий администраторам обходить ограничение
        custom_message: Кастомное сообщение при блокировке. Если None, используется стандартное
        
    Returns:
        Декоратор функции
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
            # Получаем ID пользователя
            user_id = update.effective_user.id
            
            # Получаем имя команды
            command_name = func.__name__
            
            # Проверяем, является ли пользователь администратором
            is_admin = False
            if admin_bypass and hasattr(context.bot_data, 'admins'):
                is_admin = user_id in context.bot_data.get('admins', [])
                
            # Администраторы обходят ограничение
            if admin_bypass and is_admin:
                return await func(update, context, *args, **kwargs)
            
            current_time = time.time()
            
            # Инициализируем историю запросов пользователя, если ее еще нет
            if user_id not in request_history:
                request_history[user_id] = {}
                
            # Инициализируем историю запросов для данной команды
            if command_name not in request_history[user_id]:
                request_history[user_id][command_name] = (current_time, 1)
                return await func(update, context, *args, **kwargs)
                
            last_time, count = request_history[user_id][command_name]
            
            # Проверяем, прошло ли достаточно времени с последнего запроса
            if current_time - last_time > window:
                # Сбрасываем счетчик, если прошло достаточно времени
                request_history[user_id][command_name] = (current_time, 1)
                return await func(update, context, *args, **kwargs)
            
            # Проверяем, в режиме кулдауна ли пользователь
            if count > limit:
                # Проверяем, прошло ли время кулдауна
                if current_time - last_time > cooldown:
                    # Сбрасываем счетчик после кулдауна
                    request_history[user_id][command_name] = (current_time, 1)
                    return await func(update, context, *args, **kwargs)
                else:
                    # Пользователь еще в режиме кулдауна
                    remaining = int(cooldown - (current_time - last_time))
                    message = custom_message or f"⚠️ Слишком много запросов! Попробуйте снова через {remaining} сек."
                    await update.message.reply_text(message)
                    logger.warning(f"Rate limit exceeded: user {user_id} for command {command_name}")
                    return None
            
            # Увеличиваем счетчик запросов
            request_history[user_id][command_name] = (last_time, count + 1)
            
            # Проверяем, не превышен ли лимит после увеличения счетчика
            if count + 1 > limit:
                message = custom_message or f"⚠️ Слишком много запросов! Подождите {cooldown} сек."
                await update.message.reply_text(message)
                logger.warning(f"Rate limit exceeded: user {user_id} for command {command_name}")
                return None
                
            # Выполняем исходную функцию
            return await func(update, context, *args, **kwargs)
            
        return wrapper
    return decorator

def cleanup_history():
    """
    Очищает историю запросов от устаревших записей.
    Рекомендуется запускать периодически через планировщик задач.
    """
    current_time = time.time()
    expired_time = current_time - max(DEFAULT_TIME_WINDOW, DEFAULT_COOLDOWN) * 10  # 10x больше максимального окна для надежности
    
    users_to_remove = []
    
    for user_id, commands in request_history.items():
        commands_to_remove = []
        
        for cmd, (timestamp, _) in commands.items():
            if timestamp < expired_time:
                commands_to_remove.append(cmd)
                
        for cmd in commands_to_remove:
            del commands[cmd]
            
        if not commands:
            users_to_remove.append(user_id)
            
    for user_id in users_to_remove:
        del request_history[user_id]
        
    logger.info(f"Rate limiter: cleaned up history, remaining users: {len(request_history)}")