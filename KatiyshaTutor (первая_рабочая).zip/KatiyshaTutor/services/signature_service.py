"""
Сервис для генерации и проверки подписей API запросов
"""
import hmac
import hashlib
import json
import logging
import time
from typing import Dict, Any, Optional, Union

import config

logger = logging.getLogger(__name__)

def generate_signature(data: Dict[str, Any], secret_key: Optional[str] = None) -> str:
    """
    Генерирует HMAC-SHA256 подпись для данных API запроса
    
    Args:
        data: Данные для подписи
        secret_key: Секретный ключ для подписи (если не указан, берется из config)
        
    Returns:
        str: Сгенерированная подпись
    """
    if secret_key is None:
        secret_key = config.SIGNATURE_SECRET_KEY
    
    # Отсортированные по ключу данные для стабильной генерации подписи
    sorted_data = {k: data[k] for k in sorted(data.keys()) if k != 'signature'}
    
    # Преобразуем данные в JSON-строку
    data_string = json.dumps(sorted_data, sort_keys=True, separators=(',', ':'))
    
    # Генерируем HMAC-SHA256 подпись
    signature = hmac.new(
        secret_key.encode('utf-8'),
        data_string.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    return signature

def verify_signature(data: Dict[str, Any], signature: str, secret_key: Optional[str] = None) -> bool:
    """
    Проверяет подпись для данных API запроса
    
    Args:
        data: Данные, для которых нужно проверить подпись
        signature: Подпись для проверки
        secret_key: Секретный ключ для подписи (если не указан, берется из config)
        
    Returns:
        bool: True, если подпись верна; False в противном случае
    """
    # Генерируем ожидаемую подпись
    expected_signature = generate_signature(data, secret_key)
    
    # Проверяем, совпадает ли переданная подпись с ожидаемой
    return hmac.compare_digest(signature, expected_signature)

def add_signature_to_data(data: Dict[str, Any], secret_key: Optional[str] = None) -> Dict[str, Any]:
    """
    Добавляет подпись к данным API запроса
    
    Args:
        data: Данные для подписи
        secret_key: Секретный ключ для подписи (если не указан, берется из config)
        
    Returns:
        Dict: Данные с добавленной подписью
    """
    # Копируем данные, чтобы не изменять оригинал
    signed_data = data.copy()
    
    # Добавляем подпись к данным
    signed_data['signature'] = generate_signature(data, secret_key)
    
    return signed_data

def add_timestamp_to_data(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Добавляет метку времени к данным API запроса
    
    Args:
        data: Данные для добавления метки времени
        
    Returns:
        Dict: Данные с добавленной меткой времени
    """
    # Копируем данные, чтобы не изменять оригинал
    timestamped_data = data.copy()
    
    # Добавляем метку времени к данным
    timestamped_data['timestamp'] = int(time.time())
    
    return timestamped_data

def is_request_expired(data: Dict[str, Any], max_age_seconds: int = 300) -> bool:
    """
    Проверяет, истек ли срок действия запроса
    
    Args:
        data: Данные запроса
        max_age_seconds: Максимальный возраст запроса в секундах (по умолчанию 5 минут)
        
    Returns:
        bool: True, если срок действия запроса истек; False в противном случае
    """
    if 'timestamp' not in data:
        logger.warning("Запрос не содержит метки времени")
        return True
    
    # Получаем метку времени из данных
    request_timestamp = data['timestamp']
    
    # Получаем текущее время
    current_timestamp = int(time.time())
    
    # Проверяем, не истек ли срок действия запроса
    return current_timestamp - request_timestamp > max_age_seconds

def generate_payout_signature(payout_data: Dict[str, Any]) -> str:
    """
    Генерирует подпись для запроса выплаты Robokassa
    
    Args:
        payout_data: Данные запроса выплаты
        
    Returns:
        str: Сгенерированная подпись
    """
    return generate_signature(payout_data, config.ROBOKASSA_SECRET_KEY)