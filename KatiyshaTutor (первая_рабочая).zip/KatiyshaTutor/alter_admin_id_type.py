#!/usr/bin/env python3
# alter_admin_id_type.py

import os
import psycopg2
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def alter_admin_id_type():
    """
    Изменяет тип поля admin_id в таблице admin_action_logs с INTEGER на BIGINT
    напрямую с помощью SQL запроса
    """
    try:
        # Получаем строку подключения к базе данных из переменной окружения
        database_url = os.environ.get('DATABASE_URL')
        if not database_url:
            logger.error("Переменная окружения DATABASE_URL не найдена")
            return False

        # Устанавливаем соединение с базой данных
        logger.info("Подключение к базе данных...")
        conn = psycopg2.connect(database_url)
        conn.autocommit = True
        cursor = conn.cursor()

        # SQL запрос для изменения типа поля
        logger.info("Выполнение ALTER TABLE запроса...")
        sql_query = """
        ALTER TABLE admin_action_logs 
        ALTER COLUMN admin_id TYPE BIGINT;
        """
        cursor.execute(sql_query)
        
        # Проверяем, что изменение было применено успешно
        cursor.execute("SELECT data_type FROM information_schema.columns WHERE table_name = 'admin_action_logs' AND column_name = 'admin_id'")
        data_type = cursor.fetchone()[0]
        logger.info(f"Новый тип данных для admin_id: {data_type}")
        
        # Закрываем соединение
        cursor.close()
        conn.close()
        
        if data_type.lower() == 'bigint':
            logger.info("Миграция успешно выполнена: admin_id теперь имеет тип BIGINT")
            return True
        else:
            logger.error(f"Миграция не удалась: admin_id имеет тип {data_type}, а не BIGINT")
            return False
            
    except Exception as e:
        logger.error(f"Ошибка при изменении типа поля: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    alter_admin_id_type()