import sys
import os
import pytest
from unittest.mock import MagicMock, AsyncMock, patch
import json
from datetime import datetime, timedelta

# Добавляем корневую директорию проекта в sys.path для корректного импорта
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Фикстуры для мокирования телеграм-бота

@pytest.fixture
def mock_update():
    """Фикстура для мокирования объекта update в тестах обработчиков"""
    update = MagicMock()
    update.effective_user = MagicMock()
    update.effective_user.id = 123456789
    update.effective_user.username = "test_user"
    update.effective_user.first_name = "Test"
    update.message = MagicMock()
    update.message.reply_text = AsyncMock()
    update.message.reply_html = AsyncMock()
    update.message.reply_document = AsyncMock()
    update.message.text = "test message"
    update.callback_query = MagicMock()
    update.callback_query.data = "test_data"
    update.callback_query.answer = AsyncMock()
    update.callback_query.message = update.message
    return update

@pytest.fixture
def mock_context():
    """Фикстура для мокирования объекта context в тестах обработчиков"""
    context = MagicMock()
    context.bot = MagicMock()
    context.bot.send_message = AsyncMock()
    context.bot.send_document = AsyncMock()
    context.args = []
    context.job_queue = MagicMock()
    context.job_queue.run_once = MagicMock()
    context.job_queue.run_repeating = MagicMock()
    return context

@pytest.fixture
def mock_db():
    """Фикстура для мокирования функций работы с базой данных"""
    # Создаем тестовые данные пользователей
    test_users = [
        {
            "user_id": 123456789,
            "username": "test_user",
            "first_name": "Test",
            "subscription": {"active": True, "expires": (datetime.now() + timedelta(days=30)).isoformat()},
            "referrer_id": None,
            "referrals": []
        },
        {
            "user_id": 987654321,
            "username": "another_user",
            "first_name": "Another",
            "subscription": {"active": False},
            "referrer_id": 123456789,
            "referrals": []
        }
    ]
    
    # Создаем тестовые транзакции
    test_transactions = [
        {
            "transaction_id": "test-tx-1",
            "user_id": 123456789,
            "amount": 100.0,
            "type": "subscription",
            "status": "completed",
            "created_at": datetime.now().isoformat()
        },
        {
            "transaction_id": "test-tx-2",
            "user_id": 123456789,
            "amount": 5.0,
            "type": "referral_reward",
            "status": "pending_payout",
            "created_at": (datetime.now() - timedelta(days=7)).isoformat()
        }
    ]
    
    # Тестовая конфигурация
    test_config = {
        "admins": [123456789],
        "subscription_price": 1000,
        "subscription_duration_days": 30,
        "referral_rates": {
            "level_1": 0.05,
            "level_2": 0.02,
            "level_3": 0.02,
            "level_4": 0.02
        },
        "robokassa": {
            "merchant_login": "test_merchant",
            "password1": "test_password1",
            "password2": "test_password2",
            "test_mode": True
        }
    }
    
    # Патчим функции работы с базой данных
    with patch('database.get_user', side_effect=lambda user_id: next((user for user in test_users if user["user_id"] == user_id), None)), \
         patch('database.update_user', return_value=True), \
         patch('database.add_transaction', lambda tx: test_transactions.append(tx) or tx), \
         patch('database.get_transactions', return_value=test_transactions), \
         patch('database.get_config', return_value=test_config), \
         patch('database.update_transaction', lambda tx: True), \
         patch('database.get_users', return_value=test_users), \
         patch('database.is_admin', lambda user_id: user_id in test_config["admins"]):
        
        yield {
            "users": test_users,
            "transactions": test_transactions,
            "config": test_config
        }

@pytest.fixture
def robokassa_settings():
    """Фикстура с настройками Robokassa для тестов"""
    return {
        "merchant_login": "test_merchant",
        "password1": "test_password1",
        "password2": "test_password2",
        "test_mode": True
    }

@pytest.fixture
def sample_user_data():
    """
    Фикстура, возвращающая образец данных пользователя
    """
    return {
        "user_id": 123456789,
        "username": "test_user",
        "first_name": "Test",
        "last_name": "User",
        "is_admin": False,
        "referrer_id": None,
        "referrals": [],
        "subscription": {
            "active": False,
            "expires": None,
            "type": None
        },
        "created_at": "2023-01-01T00:00:00",
        "last_activity": "2023-01-01T00:00:00"
    }

@pytest.fixture
def sample_transaction_data():
    """
    Фикстура, возвращающая образец данных транзакции
    """
    return {
        "transaction_id": "12345",
        "user_id": 123456789,
        "amount": 100.0,
        "type": "subscription_payment",
        "status": "pending",
        "created_at": "2023-01-01T00:00:00",
        "updated_at": "2023-01-01T00:00:00",
        "payment_method": "robokassa",
        "description": "Subscription payment",
        "metadata": {}
    } 