#!/usr/bin/env python3
"""
Скрипт для автоматического удаления тестовых пользователей из базы данных
"""

import os
import sys
import json
from datetime import datetime
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from flask import Flask

# Импортируем модели
from db_models import User, MathProblem, Transaction, WeeklyPayout, AccumulatedReward
from db_models import FraudDetectionLog, ReferralNetwork
from db_config import db, get_flask_app

# ID пользователей, которые следует сохранить
KEEP_USER_IDS = [5913639088, 6198324744]

def check_users_status():
    """
    Проверяет статус пользователей, которых нужно сохранить
    """
    print("=== Проверка статуса пользователей для сохранения ===")
    for user_id in KEEP_USER_IDS:
        user = User.query.get(user_id)
        if user:
            print(f"Пользователь ID: {user.id}")
            print(f"  Имя пользователя: {user.username or 'Не указано'}")
            print(f"  Дата создания: {user.created_at}")
            print(f"  Подписка активна: {user.has_active_subscription()}")
            print(f"  Подписка до: {user.subscription_end}")
            print()
        else:
            print(f"Пользователь с ID {user_id} не найден в базе данных!")
            print()

def count_users():
    """
    Подсчитывает общее количество пользователей
    """
    print("=== Подсчет пользователей ===")
    total_users = User.query.count()
    to_keep = User.query.filter(User.id.in_(KEEP_USER_IDS)).count()
    to_delete = total_users - to_keep
    
    print(f"Всего пользователей: {total_users}")
    print(f"Пользователей для сохранения: {to_keep}")
    print(f"Пользователей для удаления: {to_delete}")
    print()
    
    return total_users, to_keep, to_delete

def list_dependent_data():
    """
    Показывает, сколько связанных данных будет удалено
    """
    print("=== Подсчет связанных данных ===")
    
    # Формируем список ID пользователей для удаления
    all_users = User.query.all()
    delete_user_ids = [user.id for user in all_users if user.id not in KEEP_USER_IDS]
    
    # Проверяем связи в каждой таблице
    try:
        transactions_count = Transaction.query.filter(Transaction.user_id.in_(delete_user_ids)).count()
    except Exception as e:
        print(f"У Transaction нет колонки user_id: {e}")
        transactions_count = 0
        
    try:
        math_problems_count = MathProblem.query.filter(MathProblem.user_id.in_(delete_user_ids)).count()
    except Exception as e:
        print(f"У MathProblem нет колонки user_id: {e}")
        math_problems_count = 0
        
    try:
        accumulated_rewards_count = AccumulatedReward.query.filter(AccumulatedReward.user_id.in_(delete_user_ids)).count()
    except Exception as e:
        print(f"У AccumulatedReward нет колонки user_id: {e}")
        accumulated_rewards_count = 0
        
    try:
        weekly_payouts_count = WeeklyPayout.query.filter(WeeklyPayout.admin_id.in_(delete_user_ids)).count()
    except Exception as e:
        print(f"У WeeklyPayout нет колонки user_id")
        weekly_payouts_count = 0
    
    try:
        referral_networks_count = ReferralNetwork.query.filter(
            (ReferralNetwork.user_id.in_(delete_user_ids))
        ).count()
    except Exception as e:
        print(f"У ReferralNetwork нет колонки user_id: {e}")
        referral_networks_count = 0
        
    try:
        fraud_logs_count = FraudDetectionLog.query.filter(FraudDetectionLog.user_id.in_(delete_user_ids)).count()
    except Exception as e:
        print(f"У FraudDetectionLog нет колонки user_id: {e}")
        fraud_logs_count = 0
        
    # Выводим результаты
    print("Связанные данные для удаления:")
    print(f"- Транзакции: {transactions_count}")
    print(f"- Математические задачи: {math_problems_count}")
    print(f"- Накопленные вознаграждения: {accumulated_rewards_count}")
    print(f"- Еженедельные выплаты: {weekly_payouts_count}")
    print(f"- Сети рефералов: {referral_networks_count}")
    print(f"- Журналы обнаружения мошенничества: {fraud_logs_count}")
    print()

def delete_dependent_data():
    """
    Удаляет зависимые данные пользователей
    """
    print("=== Удаление зависимых данных ===")
    
    # Формируем список ID пользователей для удаления
    all_users = User.query.all()
    delete_user_ids = [user.id for user in all_users if user.id not in KEEP_USER_IDS]
    
    if not delete_user_ids:
        print("Нет пользователей для удаления!")
        return
    
    try:
        deleted = Transaction.query.filter(Transaction.user_id.in_(delete_user_ids)).delete(synchronize_session=False)
        print(f"Удалено транзакций: {deleted}")
    except Exception as e:
        print(f"Ошибка при удалении Transaction: {e}")
    
    try:
        deleted = MathProblem.query.filter(MathProblem.user_id.in_(delete_user_ids)).delete(synchronize_session=False)
        print(f"Удалено математических задач: {deleted}")
    except Exception as e:
        print(f"Ошибка при удалении MathProblem: {e}")
    
    try:
        deleted = AccumulatedReward.query.filter(AccumulatedReward.user_id.in_(delete_user_ids)).delete(synchronize_session=False)
        print(f"Удалено накопленных вознаграждений: {deleted}")
    except Exception as e:
        print(f"Ошибка при удалении AccumulatedReward: {e}")
    
    try:
        deleted = ReferralNetwork.query.filter(ReferralNetwork.user_id.in_(delete_user_ids)).delete(synchronize_session=False)
        print(f"Удалено сетей рефералов: {deleted}")
    except Exception as e:
        print(f"Ошибка при удалении ReferralNetwork: {e}")
    
    try:
        deleted = FraudDetectionLog.query.filter(FraudDetectionLog.user_id.in_(delete_user_ids)).delete(synchronize_session=False)
        print(f"Удалено журналов обнаружения мошенничества: {deleted}")
    except Exception as e:
        print(f"Ошибка при удалении FraudDetectionLog: {e}")
    
    # Сохраняем изменения
    db.session.commit()
    print("Зависимые данные успешно удалены!")
    print()

def delete_test_users():
    """
    Удаляет тестовых пользователей
    """
    print("=== Удаление тестовых пользователей ===")
    
    # Формируем список ID пользователей для удаления
    all_users = User.query.all()
    delete_user_ids = [user.id for user in all_users if user.id not in KEEP_USER_IDS]
    
    if not delete_user_ids:
        print("Нет пользователей для удаления!")
        return 0
    
    # Удаляем пользователей
    deleted = User.query.filter(User.id.in_(delete_user_ids)).delete(synchronize_session=False)
    
    # Сохраняем изменения
    db.session.commit()
    
    print(f"Удалено пользователей: {deleted}")
    print("Тестовые пользователи успешно удалены!")
    print()
    
    return deleted

def clean_json_storage():
    """
    Очищает JSON-хранилище пользователей, оставляя только пользователей из KEEP_USER_IDS
    """
    print("=== Очистка JSON-хранилища ===")
    file_path = "users_db.json"
    
    if not os.path.exists(file_path):
        print(f"Файл {file_path} не существует!")
        return
    
    # Создаем резервную копию
    backup_dir = "json_backup"
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = os.path.join(backup_dir, f"{os.path.basename(file_path)}_backup_{timestamp}")
    
    try:
        import shutil
        shutil.copy2(file_path, backup_file)
        print(f"Создана резервная копия: {backup_file}")
    except Exception as e:
        print(f"Ошибка при создании резервной копии: {e}")
        return
    
    try:
        # Загружаем текущие данные
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Проверка формата данных
        if not isinstance(data, dict):
            print(f"Неожиданный формат данных в файле {file_path}!")
            return
        
        # Проверяем наличие ключа "users"
        if "users" in data:
            # Подсчет пользователей до очистки
            initial_count = len(data["users"])
            
            # Оставляем только нужных пользователей
            cleaned_users = {str(user_id): data["users"].get(str(user_id), {}) 
                             for user_id in KEEP_USER_IDS 
                             if str(user_id) in data["users"]}
            
            # Обновляем только раздел users, сохраняя остальные данные
            cleaned_data = data.copy()
            cleaned_data["users"] = cleaned_users
        else:
            # Простой словарь пользователей
            initial_count = len(data)
            cleaned_data = {str(user_id): data.get(str(user_id), {}) 
                           for user_id in KEEP_USER_IDS 
                           if str(user_id) in data}
        
        # Подсчет пользователей после очистки
        if "users" in cleaned_data:
            final_count = len(cleaned_data["users"])
        else:
            final_count = len(cleaned_data)
        removed_count = initial_count - final_count
        
        # Сохраняем очищенные данные
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(cleaned_data, f, ensure_ascii=False, indent=2)
        
        print(f"JSON-хранилище очищено:")
        print(f"- Было пользователей: {initial_count}")
        print(f"- Осталось пользователей: {final_count}")
        print(f"- Удалено пользователей: {removed_count}")
        
    except Exception as e:
        print(f"Ошибка при очистке JSON-хранилища: {e}")
    
    print()

def main():
    """
    Основная функция скрипта
    """
    print("=== Автоматическая очистка тестовых пользователей ===")
    
    app = get_flask_app()
    
    with app.app_context():
        # Проверяем статус пользователей, которых нужно сохранить
        check_users_status()
        
        # Подсчитываем пользователей
        total_users, to_keep, to_delete = count_users()
        
        if to_delete == 0:
            print("Нет пользователей для удаления!")
            return
        
        # Показываем информацию о связанных данных
        list_dependent_data()
        
        # Удаляем зависимые данные
        delete_dependent_data()
        
        # Удаляем тестовых пользователей
        deleted_users = delete_test_users()
    
    # Очищаем JSON-хранилище (не требует контекста приложения)
    clean_json_storage()
    
    print(f"Всего удалено пользователей: {deleted_users}")
    print("Очистка завершена!")

if __name__ == "__main__":
    main()