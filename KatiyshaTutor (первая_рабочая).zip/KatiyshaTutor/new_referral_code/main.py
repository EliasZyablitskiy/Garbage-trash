#!/usr/bin/env python
# coding: utf-8

"""
Main entry point for the Katiysha Telegram Bot
"""

import os
import sys
import logging
import asyncio
import threading
from concurrent.futures import ThreadPoolExecutor
import logging.handlers

from bot import create_bot
from webhook_handler import run_webhook_server

# Создаем директорию для логов, если она еще не существует
log_dir = 'logs'
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

# Настраиваем ротацию файлов лога
log_file = os.path.join(log_dir, 'bot.log')
file_handler = logging.handlers.RotatingFileHandler(
    log_file, maxBytes=5*1024*1024, backupCount=5, encoding='utf-8'
)

# Форматирование лога
log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
formatter = logging.Formatter(log_format)
file_handler.setFormatter(formatter)

# Настраиваем консольный вывод
console_handler = logging.StreamHandler()
console_handler.setFormatter(formatter)

# Устанавливаем общие настройки логирования
logging.basicConfig(
    format=log_format,
    level=logging.DEBUG,
    handlers=[file_handler, console_handler]
)

# Уменьшаем уровень некоторых слишком подробных библиотек
logging.getLogger('telegram').setLevel(logging.INFO)
logging.getLogger('httpx').setLevel(logging.INFO)
logging.getLogger('apscheduler').setLevel(logging.INFO)

logger = logging.getLogger(__name__)

def main():
    """Start the bot and webhook server."""
    try:
        # Запускаем webhook сервер в отдельном потоке
        webhook_thread = threading.Thread(target=run_webhook_server, args=(5000,), daemon=True)
        webhook_thread.start()
        logger.info("Webhook server started")
        
        # Запускаем бота в основном потоке
        loop = asyncio.get_event_loop()
        bot_app = loop.run_until_complete(create_bot())
        
        if bot_app:
            logger.info("Bot started")
            bot_app.run_polling()
        else:
            logger.error("Failed to create bot application")
            sys.exit(1)
            
    except KeyboardInterrupt:
        logger.info("Stopping the bot...")
    except Exception as e:
        logger.error(f"Error in main: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()