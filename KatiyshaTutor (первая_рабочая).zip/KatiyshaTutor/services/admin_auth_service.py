#!/usr/bin/env python
# coding: utf-8

"""
Сервис для управления аутентификацией и авторизацией администраторов
Включает в себя:
- Аутентификацию с защитой от brute-force
- Проверку ролей и прав доступа
- Двухфакторную аутентификацию (2FA)
- Временное делегирование прав
"""

import os
import hmac
import hashlib
import logging
import pyotp
import qrcode
from io import BytesIO
from datetime import datetime, timedelta
from functools import wraps
from flask import request, session, redirect, url_for, flash, g, abort
from werkzeug.security import generate_password_hash, check_password_hash
from db_models import db, AdminUser, AdminActionLog, User

# Настройка логирования
logger = logging.getLogger(__name__)

# Определяем карту ролей и прав доступа
ROLE_PERMISSIONS = {
    'super_admin': {
        'can_view_admin_dashboard': True,
        'can_view_users': True,
        'can_edit_users': True,
        'can_view_transactions': True,
        'can_process_payouts': True,
        'can_approve_payouts': True,
        'can_view_reports': True,
        'can_access_system_settings': True,
        'can_manage_admins': True,
        'can_manage_roles': True,
        'can_delegate_rights': True,
        'can_view_logs': True,
    },
    'finance_admin': {
        'can_view_admin_dashboard': True,
        'can_view_users': True,
        'can_edit_users': False,
        'can_view_transactions': True,
        'can_process_payouts': True,
        'can_approve_payouts': True,
        'can_view_reports': True,
        'can_access_system_settings': False,
        'can_manage_admins': False,
        'can_manage_roles': False,
        'can_delegate_rights': False,
        'can_view_logs': True,
    },
    'monitoring_admin': {
        'can_view_admin_dashboard': True,
        'can_view_users': True,
        'can_edit_users': False,
        'can_view_transactions': True,
        'can_process_payouts': False,
        'can_approve_payouts': False,
        'can_view_reports': True,
        'can_access_system_settings': False,
        'can_manage_admins': False,
        'can_manage_roles': False,
        'can_delegate_rights': False,
        'can_view_logs': True,
    },
    'support_admin': {
        'can_view_admin_dashboard': True,
        'can_view_users': True,
        'can_edit_users': False,
        'can_view_transactions': False,
        'can_process_payouts': False,
        'can_approve_payouts': False,
        'can_view_reports': False,
        'can_access_system_settings': False,
        'can_manage_admins': False,
        'can_manage_roles': False,
        'can_delegate_rights': False,
        'can_view_logs': False,
    }
}

class AdminAuthService:
    """Сервис аутентификации и авторизации администраторов"""
    
    @staticmethod
    def authenticate(telegram_id, password):
        """
        Аутентифицировать администратора по Telegram ID и паролю
        
        Args:
            telegram_id (str): Telegram ID администратора
            password (str): Пароль администратора
            
        Returns:
            tuple: (admin_user, error_message)
        """
        # Ищем пользователя по Telegram ID
        try:
            telegram_id_int = int(telegram_id)
            admin_user = AdminUser.query.filter_by(telegram_id=telegram_id_int).first()
        except ValueError:
            return None, "Неверный формат Telegram ID"
        
        if not admin_user:
            return None, "Неверное имя пользователя или пароль"
        
        # Проверяем, не заблокирован ли аккаунт
        if admin_user.is_account_locked():
            lock_until = admin_user.lock_until.strftime('%H:%M:%S') if admin_user.lock_until else "неизвестно"
            return None, f"Аккаунт заблокирован до {lock_until} из-за слишком большого количества неудачных попыток входа"
        
        # Проверяем активен ли аккаунт
        if not admin_user.is_active:
            return None, "Аккаунт отключен. Обратитесь к администратору"
        
        # Проверяем пароль
        if not admin_user.check_password(password):
            # Увеличиваем счетчик неудачных попыток
            admin_user.increment_login_attempts()
            db.session.commit()
            
            # Если аккаунт заблокирован после этой попытки, сообщаем об этом
            if admin_user.is_account_locked():
                lock_until = admin_user.lock_until.strftime('%H:%M:%S')
                return None, f"Слишком много неудачных попыток. Аккаунт заблокирован до {lock_until}"
            
            return None, "Неверный пароль"
        
        # Сбрасываем счетчик неудачных попыток
        admin_user.reset_login_attempts()
        db.session.commit()
        
        # Если включена 2FA, пароля недостаточно для входа
        if admin_user.two_factor_enabled:
            # Генерируем временный токен для следующего шага аутентификации
            token = admin_user.generate_temporary_access_token()
            db.session.commit()
            return admin_user, "2FA_REQUIRED"
        
        # Создаем запись в логах о входе в систему
        AdminAuthService.log_admin_action(
            admin_id=admin_user.telegram_id,
            admin_user_id=admin_user.id,
            action_type="login",
            details="Успешный вход в административную панель",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
        
        return admin_user, None
    
    @staticmethod
    def verify_2fa(admin_user_id, otp_code):
        """
        Проверить код 2FA
        
        Args:
            admin_user_id (int): ID администратора
            otp_code (str): Одноразовый пароль
            
        Returns:
            tuple: (admin_user, error_message)
        """
        admin_user = AdminUser.query.get(admin_user_id)
        
        if not admin_user:
            return None, "Администратор не найден"
        
        if not admin_user.two_factor_secret:
            return None, "Двухфакторная аутентификация не настроена"
        
        # Проверяем код
        totp = pyotp.TOTP(admin_user.two_factor_secret)
        if not totp.verify(otp_code):
            return None, "Неверный код 2FA"
        
        # Создаем запись в логах о входе в систему
        AdminAuthService.log_admin_action(
            admin_id=admin_user.telegram_id,
            admin_user_id=admin_user.id,
            action_type="login_2fa",
            details="Успешная двухфакторная аутентификация",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
        
        return admin_user, None
    
    @staticmethod
    def setup_2fa(admin_user_id):
        """
        Настроить двухфакторную аутентификацию для администратора
        
        Args:
            admin_user_id (int): ID администратора
            
        Returns:
            tuple: (qr_code_image, secret_key, error_message)
        """
        admin_user = AdminUser.query.get(admin_user_id)
        
        if not admin_user:
            return None, None, "Администратор не найден"
        
        # Генерируем секрет для 2FA
        secret = pyotp.random_base32()
        admin_user.two_factor_secret = secret
        admin_user.two_factor_enabled = False  # Пока пользователь не подтвердит код, 2FA не будет включена
        db.session.commit()
        
        # Генерируем URI для QR-кода
        service_name = "КатюшаБот-Админ"
        totp = pyotp.TOTP(secret)
        uri = totp.provisioning_uri(name=str(admin_user.telegram_id), issuer_name=service_name)
        
        # Генерируем QR-код
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(uri)
        qr.make(fit=True)
        
        img = qr.make_image(fill='black', back_color='white')
        
        # Сохраняем QR-код в буфер
        buffer = BytesIO()
        img.save(buffer)
        buffer.seek(0)
        
        # Создаем запись в логах о настройке 2FA
        AdminAuthService.log_admin_action(
            admin_id=admin_user.telegram_id,
            admin_user_id=admin_user.id,
            action_type="setup_2fa",
            details="Начата настройка двухфакторной аутентификации",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
        
        return buffer, secret, None
    
    @staticmethod
    def confirm_2fa(admin_user_id, otp_code):
        """
        Подтвердить настройку 2FA путем проверки кода
        
        Args:
            admin_user_id (int): ID администратора
            otp_code (str): Одноразовый пароль
            
        Returns:
            tuple: (success, error_message)
        """
        admin_user = AdminUser.query.get(admin_user_id)
        
        if not admin_user:
            return False, "Администратор не найден"
        
        if not admin_user.two_factor_secret:
            return False, "Двухфакторная аутентификация не настроена"
        
        # Проверяем код
        totp = pyotp.TOTP(admin_user.two_factor_secret)
        if not totp.verify(otp_code):
            return False, "Неверный код 2FA"
        
        # Активируем 2FA
        admin_user.two_factor_enabled = True
        db.session.commit()
        
        # Создаем запись в логах о подтверждении 2FA
        AdminAuthService.log_admin_action(
            admin_id=admin_user.telegram_id,
            admin_user_id=admin_user.id,
            action_type="confirm_2fa",
            details="Двухфакторная аутентификация успешно настроена",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
        
        return True, None
    
    @staticmethod
    def disable_2fa(admin_user_id, password):
        """
        Отключить 2FA для администратора
        
        Args:
            admin_user_id (int): ID администратора
            password (str): Пароль для подтверждения
            
        Returns:
            tuple: (success, error_message)
        """
        admin_user = AdminUser.query.get(admin_user_id)
        
        if not admin_user:
            return False, "Администратор не найден"
        
        if not admin_user.two_factor_enabled:
            return False, "Двухфакторная аутентификация не включена"
        
        # Проверяем пароль
        if not admin_user.check_password(password):
            return False, "Неверный пароль"
        
        # Отключаем 2FA
        admin_user.two_factor_enabled = False
        admin_user.two_factor_secret = None
        db.session.commit()
        
        # Создаем запись в логах об отключении 2FA
        AdminAuthService.log_admin_action(
            admin_id=admin_user.telegram_id,
            admin_user_id=admin_user.id,
            action_type="disable_2fa",
            details="Двухфакторная аутентификация отключена",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
        
        return True, None
    
    @staticmethod
    def change_password(admin_user_id, current_password, new_password):
        """
        Изменить пароль администратора
        
        Args:
            admin_user_id (int): ID администратора
            current_password (str): Текущий пароль
            new_password (str): Новый пароль
            
        Returns:
            tuple: (success, error_message)
        """
        admin_user = AdminUser.query.get(admin_user_id)
        
        if not admin_user:
            return False, "Администратор не найден"
        
        # Проверяем текущий пароль
        if not admin_user.check_password(current_password):
            return False, "Неверный текущий пароль"
        
        # Проверяем сложность нового пароля
        if len(new_password) < 10:
            return False, "Пароль должен содержать не менее 10 символов"
        
        if not any(c.isupper() for c in new_password):
            return False, "Пароль должен содержать хотя бы одну заглавную букву"
        
        if not any(c.islower() for c in new_password):
            return False, "Пароль должен содержать хотя бы одну строчную букву"
        
        if not any(c.isdigit() for c in new_password):
            return False, "Пароль должен содержать хотя бы одну цифру"
        
        if not any(c in "!@#$%^&*()_+-=[]{}|;':\",./<>?" for c in new_password):
            return False, "Пароль должен содержать хотя бы один специальный символ"
        
        # Устанавливаем новый пароль
        admin_user.set_password(new_password)
        db.session.commit()
        
        # Создаем запись в логах о смене пароля
        AdminAuthService.log_admin_action(
            admin_id=admin_user.telegram_id,
            admin_user_id=admin_user.id,
            action_type="change_password",
            details="Пароль успешно изменен",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
        
        return True, None
    
    @staticmethod
    def has_permission(admin_user_id, permission):
        """
        Проверить наличие права у администратора
        
        Args:
            admin_user_id (int): ID администратора
            permission (str): Право доступа
            
        Returns:
            bool: True, если администратор имеет право, иначе False
        """
        admin_user = AdminUser.query.get(admin_user_id)
        
        if not admin_user:
            return False
        
        if not admin_user.is_active:
            return False
        
        if admin_user.role not in ROLE_PERMISSIONS:
            return False
        
        # Получаем права роли
        role_permissions = ROLE_PERMISSIONS[admin_user.role]
        
        # Проверяем наличие права
        return role_permissions.get(permission, False)
    
    @staticmethod
    def get_admin_permissions(admin_user_id):
        """
        Получить список всех прав доступа администратора
        
        Args:
            admin_user_id (int): ID администратора
            
        Returns:
            dict: Словарь прав доступа {permission: bool}
        """
        admin_user = AdminUser.query.get(admin_user_id)
        
        if not admin_user:
            return {}
        
        if not admin_user.is_active:
            return {}
        
        if admin_user.role not in ROLE_PERMISSIONS:
            return {}
        
        # Возвращаем права роли
        return ROLE_PERMISSIONS[admin_user.role]
    
    @staticmethod
    def get_all_admin_users():
        """
        Получить список всех администраторов
        
        Returns:
            list: Список объектов AdminUser
        """
        return AdminUser.query.all()
    
    @staticmethod
    def get_admin_user_by_id(admin_user_id):
        """
        Получить администратора по ID
        
        Args:
            admin_user_id (int): ID администратора
            
        Returns:
            AdminUser: Объект администратора
        """
        return AdminUser.query.get(admin_user_id)
    
    @staticmethod
    def get_admin_user_by_telegram_id(telegram_id):
        """
        Получить администратора по Telegram ID
        
        Args:
            telegram_id (int): Telegram ID администратора
            
        Returns:
            AdminUser: Объект администратора
        """
        return AdminUser.query.filter_by(telegram_id=telegram_id).first()
    
    @staticmethod
    def create_admin_user(telegram_id, password, role='support_admin'):
        """
        Создать нового администратора
        
        Args:
            telegram_id (int): Telegram ID пользователя
            password (str): Пароль администратора
            role (str): Роль администратора
            
        Returns:
            tuple: (admin_user, error_message)
        """
        # Проверяем существует ли пользователь с указанным Telegram ID
        user = User.query.get(telegram_id)
        if not user:
            return None, f"Пользователь с Telegram ID {telegram_id} не найден"
        
        # Проверяем не является ли пользователь уже администратором
        existing_admin = AdminUser.query.filter_by(telegram_id=telegram_id).first()
        if existing_admin:
            return None, f"Пользователь с Telegram ID {telegram_id} уже является администратором"
        
        # Проверяем корректность роли
        if role not in ROLE_PERMISSIONS:
            return None, f"Некорректная роль: {role}"
        
        # Проверяем сложность пароля
        if len(password) < 10:
            return None, "Пароль должен содержать не менее 10 символов"
        
        if not any(c.isupper() for c in password):
            return None, "Пароль должен содержать хотя бы одну заглавную букву"
        
        if not any(c.islower() for c in password):
            return None, "Пароль должен содержать хотя бы одну строчную букву"
        
        if not any(c.isdigit() for c in password):
            return None, "Пароль должен содержать хотя бы одну цифру"
        
        if not any(c in "!@#$%^&*()_+-=[]{}|;':\",./<>?" for c in password):
            return None, "Пароль должен содержать хотя бы один специальный символ"
        
        # Создаем нового администратора
        admin_user = AdminUser(
            telegram_id=telegram_id,
            role=role,
            is_active=True,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        admin_user.set_password(password)
        
        db.session.add(admin_user)
        db.session.commit()
        
        # Создаем запись в логах о создании администратора
        current_admin_id = session.get('admin_user_id') if 'admin_user_id' in session else None
        if current_admin_id:
            current_admin = AdminUser.query.get(current_admin_id)
            AdminAuthService.log_admin_action(
                admin_id=current_admin.telegram_id,
                admin_user_id=current_admin.id,
                action_type="create_admin",
                details=f"Создан новый администратор с Telegram ID {telegram_id} и ролью {role}",
                ip_address=request.remote_addr,
                user_agent=request.user_agent.string
            )
        
        return admin_user, None
    
    @staticmethod
    def update_admin_user(admin_user_id, role=None, is_active=None):
        """
        Обновить данные администратора
        
        Args:
            admin_user_id (int): ID администратора
            role (str, optional): Новая роль администратора
            is_active (bool, optional): Новый статус активности
            
        Returns:
            tuple: (admin_user, error_message)
        """
        admin_user = AdminUser.query.get(admin_user_id)
        
        if not admin_user:
            return None, "Администратор не найден"
        
        # Текущий администратор не может изменить свою собственную роль или отключить себя
        current_admin_id = session.get('admin_user_id')
        if current_admin_id and int(current_admin_id) == admin_user_id:
            return None, "Вы не можете изменить свою собственную роль или отключить себя"
        
        # Обновляем роль, если она указана
        if role is not None:
            if role not in ROLE_PERMISSIONS:
                return None, f"Некорректная роль: {role}"
            admin_user.role = role
        
        # Обновляем статус активности, если он указан
        if is_active is not None:
            admin_user.is_active = is_active
        
        # Обновляем время изменения
        admin_user.updated_at = datetime.now()
        
        db.session.commit()
        
        # Создаем запись в логах об обновлении администратора
        current_admin_id = session.get('admin_user_id')
        if current_admin_id:
            current_admin = AdminUser.query.get(current_admin_id)
            details = f"Обновлен администратор с ID {admin_user_id}. "
            if role is not None:
                details += f"Новая роль: {role}. "
            if is_active is not None:
                details += f"Новый статус: {'активен' if is_active else 'неактивен'}."
                
            AdminAuthService.log_admin_action(
                admin_id=current_admin.telegram_id,
                admin_user_id=current_admin.id,
                action_type="update_admin",
                details=details,
                ip_address=request.remote_addr,
                user_agent=request.user_agent.string
            )
        
        return admin_user, None
    
    @staticmethod
    def delegate_temporary_access(from_admin_user_id, to_telegram_id, permissions, duration_hours=1):
        """
        Делегировать временный доступ другому пользователю
        
        Args:
            from_admin_user_id (int): ID администратора, делегирующего права
            to_telegram_id (int): Telegram ID пользователя, которому делегируются права
            permissions (list): Список делегируемых прав
            duration_hours (int): Продолжительность делегирования в часах
            
        Returns:
            tuple: (success, error_message)
        """
        from_admin = AdminUser.query.get(from_admin_user_id)
        
        if not from_admin:
            return False, "Администратор не найден"
        
        # Проверяем есть ли у администратора право делегировать права
        if not AdminAuthService.has_permission(from_admin_user_id, "can_delegate_rights"):
            return False, "У вас нет прав для делегирования доступа"
        
        # Проверяем существует ли пользователь с указанным Telegram ID
        user = User.query.get(to_telegram_id)
        if not user:
            return False, f"Пользователь с Telegram ID {to_telegram_id} не найден"
        
        # Проверяем имеет ли администратор все права, которые он хочет делегировать
        admin_permissions = AdminAuthService.get_admin_permissions(from_admin_user_id)
        for permission in permissions:
            if permission not in admin_permissions or not admin_permissions[permission]:
                return False, f"Вы не можете делегировать право '{permission}', так как сами его не имеете"
        
        # Проверяем не является ли пользователь уже администратором
        to_admin = AdminUser.query.filter_by(telegram_id=to_telegram_id).first()
        if to_admin:
            # Если пользователь уже администратор, можно только расширить его права
            # Но это требует отдельной логики, которую мы не реализуем в рамках этой функции
            return False, f"Пользователь с Telegram ID {to_telegram_id} уже является администратором"
        
        # Создаем временного администратора с указанными правами
        # Генерируем случайный пароль, который пользователь должен будет сменить при первом входе
        temp_password = os.urandom(8).hex()
        
        # Создаем временную роль, которая истечет через указанное время
        temp_role = "temp_delegate"
        
        # Создаем нового администратора
        admin_user = AdminUser(
            telegram_id=to_telegram_id,
            role=temp_role,
            is_active=True,
            created_at=datetime.now(),
            updated_at=datetime.now(),
            # Устанавливаем время истечения делегирования
            temporary_access_expires=datetime.now() + timedelta(hours=duration_hours)
        )
        admin_user.set_password(temp_password)
        
        db.session.add(admin_user)
        db.session.commit()
        
        # Создаем запись в логах о делегировании прав
        AdminAuthService.log_admin_action(
            admin_id=from_admin.telegram_id,
            admin_user_id=from_admin.id,
            action_type="delegate_access",
            details=f"Делегированы права {', '.join(permissions)} пользователю с Telegram ID {to_telegram_id} на {duration_hours} ч.",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
        
        # Отправляем пользователю уведомление о делегировании прав
        # Реализация отправки уведомления не входит в рамки этой функции
        
        return True, None
    
    @staticmethod
    def get_admin_action_logs(start_date=None, end_date=None, admin_id=None, action_type=None, limit=100, offset=0):
        """
        Получить логи действий администраторов с фильтрацией
        
        Args:
            start_date (datetime, optional): Начальная дата
            end_date (datetime, optional): Конечная дата
            admin_id (int, optional): ID администратора
            action_type (str, optional): Тип действия
            limit (int): Лимит записей
            offset (int): Смещение
            
        Returns:
            list: Список объектов AdminActionLog
        """
        query = AdminActionLog.query
        
        if start_date:
            query = query.filter(AdminActionLog.timestamp >= start_date)
        
        if end_date:
            query = query.filter(AdminActionLog.timestamp <= end_date)
        
        if admin_id:
            query = query.filter(AdminActionLog.admin_id == admin_id)
        
        if action_type:
            query = query.filter(AdminActionLog.action_type == action_type)
        
        # Сортировка по времени (сначала новые)
        query = query.order_by(AdminActionLog.timestamp.desc())
        
        # Применяем пагинацию
        logs = query.limit(limit).offset(offset).all()
        
        return logs
    
    @staticmethod
    def log_admin_action(admin_id, action_type, details=None, ip_address=None, user_agent=None, admin_user_id=None):
        """
        Записать действие администратора в лог
        
        Args:
            admin_id (int): ID администратора (может быть как telegram_id, так и id из admin_users)
            action_type (str): Тип действия
            details (str, optional): Детали действия
            ip_address (str, optional): IP-адрес
            user_agent (str, optional): User-Agent
            admin_user_id (int, optional): ID администратора в таблице AdminUser
            
        Returns:
            AdminActionLog: Объект лога действия
        """
        # Если передан admin_user_id, используем его для поиска telegram_id
        if admin_user_id:
            admin_user = AdminUser.query.get(admin_user_id)
            if admin_user:
                telegram_id = admin_user.telegram_id
            else:
                logger.error(f"Не удалось создать запись в логе: администратор с ID {admin_user_id} не найден в таблице admin_users")
                return None
        else:
            # Проверяем, не является ли admin_id ID из таблицы admin_users
            admin_user = AdminUser.query.get(admin_id)
            if admin_user:
                telegram_id = admin_user.telegram_id
            else:
                # Считаем, что admin_id - это telegram_id
                telegram_id = admin_id
                user = User.query.get(telegram_id)
                if not user:
                    logger.error(f"Не удалось создать запись в логе: пользователь с ID {telegram_id} не найден в таблице users")
                    # Не бросаем исключение, чтобы не нарушать работу системы
                    return None
            
        log_entry = AdminActionLog(
            admin_id=telegram_id,  # admin_id в базе данных - это telegram_id администратора, который должен существовать в таблице users
            admin_user_id=admin_user_id if admin_user_id else (admin_user.id if admin_user else None),
            action_type=action_type,
            details=details,
            ip_address=ip_address,
            user_agent=user_agent,
            timestamp=datetime.now(),
            is_verified=False
        )
        
        db.session.add(log_entry)
        
        # Устанавливаем хеш для проверки целостности логов
        log_entry.set_verification_hash()
        
        db.session.commit()
        
        return log_entry
    
    @staticmethod
    def verify_admin_log_integrity(log_id=None):
        """
        Проверить целостность логов административных действий
        
        Args:
            log_id (int, optional): ID лога для проверки. Если не указан, проверяются все логи
            
        Returns:
            dict: Результаты проверки {log_id: bool}
        """
        if log_id:
            logs = [AdminActionLog.query.get(log_id)]
        else:
            logs = AdminActionLog.query.all()
        
        results = {}
        for log in logs:
            if not log.verification_hash:
                results[log.id] = False
                continue
            
            results[log.id] = log.verify_integrity()
        
        return results

# Декоратор для проверки аутентификации в административной панели
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_user_id' not in session:
            return redirect(url_for('admin_login', next=request.url))
        
        admin_user = AdminUser.query.get(session['admin_user_id'])
        if not admin_user or not admin_user.is_active:
            session.pop('admin_user_id', None)
            return redirect(url_for('admin_login'))
        
        # Устанавливаем admin_user в глобальном контексте запроса
        g.admin_user = admin_user
        
        return f(*args, **kwargs)
    return decorated_function

# Декоратор для проверки наличия определенного права у администратора
def permission_required(permission):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'admin_user_id' not in session:
                return redirect(url_for('admin_login', next=request.url))
            
            admin_user_id = session['admin_user_id']
            if not AdminAuthService.has_permission(admin_user_id, permission):
                abort(403)  # Доступ запрещен
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator