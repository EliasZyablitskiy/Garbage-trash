#!/usr/bin/env python
# coding: utf-8

"""
Keyboard layouts for the Katiysha bot
"""

from telegram import ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton

def get_main_keyboard():
    """Return the main menu keyboard."""
    keyboard = ReplyKeyboardMarkup(
        [
            ["Решить задачу", "Купить подписку (199₽/месяц)"],
            ["Пригласить друга (реферальная система)"]
        ],
        resize_keyboard=True
    )
    return keyboard

def get_problem_keyboard():
    """Return keyboard for confirming problem solving."""
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("Решить", callback_data="confirm_solve"),
            InlineKeyboardButton("Отмена", callback_data="cancel_solve")
        ]
    ])
    return keyboard