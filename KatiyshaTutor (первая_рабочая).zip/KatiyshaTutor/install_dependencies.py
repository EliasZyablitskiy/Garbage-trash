#!/usr/bin/env python
# coding: utf-8

"""
Script for installing project dependencies
"""

import os
import sys
import subprocess
import logging

# Настраиваем логирование
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Список необходимых пакетов Python
REQUIRED_PACKAGES = [
    # Telegram Bot
    "python-telegram-bot>=14.0.0",
    
    # API-клиенты
    "aiohttp>=3.8.0",
    "openai>=1.0.0",
    
    # Обработка изображений и OCR
    "pillow>=9.0.0",
    "pytesseract>=0.3.0",
    "qrcode>=7.0.0",
    
    # Обработка аудио
    "pydub>=0.25.0",
    "speechrecognition>=3.8.0",
    
    # База данных PostgreSQL
    "flask>=2.2.0",
    "flask-sqlalchemy>=3.0.0",
    "flask-migrate>=3.0.0",
    "sqlalchemy>=2.0.0",
    "alembic>=1.0.0",
    "psycopg2-binary>=2.0.0",
    
    # Валидация
    "email-validator>=1.0.0",
    
    # Веб-сервер
    "gunicorn>=21.0.0",
    
    # Утилиты
    "python-dotenv>=0.0.0",
]

def install_packages():
    """
    Install required packages using pip
    """
    try:
        logger.info("Installing required packages...")
        
        # Upgrade pip
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"], check=True)
        
        # Install required packages
        for package in REQUIRED_PACKAGES:
            logger.info(f"Installing {package}...")
            subprocess.run([sys.executable, "-m", "pip", "install", package], check=True)
        
        logger.info("All required packages installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Error installing packages: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return False

def check_postgres():
    """
    Check PostgreSQL connection
    """
    try:
        import psycopg2
        
        # Получаем переменные окружения для подключения к PostgreSQL
        pg_host = os.environ.get("PGHOST")
        pg_port = os.environ.get("PGPORT")
        pg_user = os.environ.get("PGUSER")
        pg_password = os.environ.get("PGPASSWORD")
        pg_database = os.environ.get("PGDATABASE")
        
        if not all([pg_host, pg_port, pg_user, pg_password, pg_database]):
            logger.warning("PostgreSQL connection parameters not set")
            return False
        
        # Проверяем подключение к PostgreSQL
        conn = psycopg2.connect(
            host=pg_host,
            port=pg_port,
            user=pg_user,
            password=pg_password,
            database=pg_database
        )
        
        logger.info("PostgreSQL connection successful")
        
        # Закрываем соединение
        conn.close()
        
        return True
    except ImportError:
        logger.error("psycopg2 not installed")
        return False
    except Exception as e:
        logger.error(f"Error connecting to PostgreSQL: {e}")
        return False

def main():
    """
    Main function
    """
    # Устанавливаем пакеты
    if not install_packages():
        logger.error("Failed to install required packages")
        sys.exit(1)
    
    # Проверяем подключение к PostgreSQL
    if not check_postgres():
        logger.warning("PostgreSQL connection failed, but continuing anyway")
    
    logger.info("All dependencies installed and checked")

if __name__ == "__main__":
    main()