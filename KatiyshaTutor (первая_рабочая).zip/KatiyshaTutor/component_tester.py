#!/usr/bin/env python3
"""
Модульное тестирование отдельных компонентов системы
"""
import os
import sys
import json
import logging
import datetime
import traceback
from sqlalchemy import func, text
from db_config import db, get_flask_app
from db_models import User, Transaction, WeeklyPayout, MathProblem
from new_referral_code.optimized_referral_manager import OptimizedReferralManager
from new_referral_code.referral_adapter import get_or_create_referral_code, add_referral, \
    process_payment_rewards, get_pending_rewards, create_weekly_payout

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ComponentTester:
    """Тестирует отдельные компоненты системы"""
    
    def __init__(self):
        self.app = get_flask_app()
        self.referral_manager = OptimizedReferralManager()
        self.results = {}
    
    def test_database_connection(self):
        """Проверяет соединение с базой данных"""
        logger.info("Тестирование соединения с базой данных...")
        try:
            with self.app.app_context():
                # Проверяем соединение с базой данных выполнением простого запроса
                result = db.session.execute(text("SELECT 1")).scalar()
                
                if result == 1:
                    logger.info("✅ Соединение с базой данных работает корректно")
                    self.results["database_connection"] = {
                        "success": True,
                        "message": "Соединение с базой данных установлено успешно"
                    }
                    return True
                else:
                    logger.error("❌ Ошибка при проверке соединения с базой данных")
                    self.results["database_connection"] = {
                        "success": False,
                        "message": "Неожиданный результат при проверке соединения с базой данных"
                    }
                    return False
                
        except Exception as e:
            logger.error(f"❌ Ошибка при тестировании соединения с базой данных: {e}")
            self.results["database_connection"] = {
                "success": False,
                "message": f"Ошибка: {str(e)}"
            }
            return False
    
    def test_user_model(self):
        """Проверяет возможность работы с моделью пользователя"""
        logger.info("Тестирование модели User...")
        try:
            with self.app.app_context():
                # Проверяем, существуют ли пользователи в базе данных
                user_count = User.query.count()
                logger.info(f"Количество пользователей в базе данных: {user_count}")
                
                if user_count > 0:
                    # Получаем произвольного пользователя
                    user = User.query.first()
                    logger.info(f"Найден пользователь: ID={user.id}, Username={user.username}")
                    
                    self.results["user_model"] = {
                        "success": True,
                        "message": f"Найдено {user_count} пользователей в базе данных",
                        "sample_user": {
                            "id": user.id,
                            "username": user.username,
                            "subscription_active": user.subscription_end > datetime.datetime.now() if user.subscription_end else False
                        }
                    }
                    return True
                else:
                    logger.warning("В базе данных нет пользователей")
                    self.results["user_model"] = {
                        "success": True,
                        "message": "База данных не содержит пользователей",
                        "sample_user": None
                    }
                    return True
                
        except Exception as e:
            logger.error(f"❌ Ошибка при тестировании модели User: {e}")
            self.results["user_model"] = {
                "success": False,
                "message": f"Ошибка: {str(e)}"
            }
            return False
    
    def test_transaction_model(self):
        """Проверяет возможность работы с моделью транзакций"""
        logger.info("Тестирование модели Transaction...")
        try:
            with self.app.app_context():
                # Проверяем, существуют ли транзакции в базе данных
                transaction_count = Transaction.query.count()
                logger.info(f"Количество транзакций в базе данных: {transaction_count}")
                
                # Получаем статистику по типам транзакций
                types = db.session.query(
                    Transaction.type, 
                    func.count(Transaction.id)
                ).group_by(Transaction.type).all()
                
                type_stats = {t_type: count for t_type, count in types}
                logger.info(f"Статистика по типам транзакций: {type_stats}")
                
                self.results["transaction_model"] = {
                    "success": True,
                    "message": f"Найдено {transaction_count} транзакций в базе данных",
                    "transaction_types": type_stats
                }
                return True
                
        except Exception as e:
            logger.error(f"❌ Ошибка при тестировании модели Transaction: {e}")
            self.results["transaction_model"] = {
                "success": False,
                "message": f"Ошибка: {str(e)}"
            }
            return False
    
    def test_referral_code_generation(self):
        """Проверяет генерацию реферальных кодов"""
        logger.info("Тестирование генерации реферальных кодов...")
        try:
            with self.app.app_context():
                # Находим пользователя для тестирования
                test_user = User.query.first()
                
                if not test_user:
                    logger.warning("Не найдены пользователи для тестирования реферальных кодов")
                    self.results["referral_code_generation"] = {
                        "success": False,
                        "message": "Не найдены пользователи для тестирования"
                    }
                    return False
                
                # Генерируем или получаем реферальный код
                code = get_or_create_referral_code(test_user.id)
                
                if code:
                    logger.info(f"Реферальный код для пользователя {test_user.id}: {code}")
                    
                    # Проверяем повторное получение кода (должен быть тот же)
                    second_code = get_or_create_referral_code(test_user.id)
                    
                    if code == second_code:
                        logger.info("✅ Повторное получение кода вернуло тот же код")
                        consistency = True
                    else:
                        logger.error("❌ Повторное получение кода вернуло другой код")
                        consistency = False
                    
                    self.results["referral_code_generation"] = {
                        "success": True,
                        "message": f"Сгенерирован реферальный код: {code}",
                        "user_id": test_user.id,
                        "code": code,
                        "consistent_retrieval": consistency
                    }
                    return True
                else:
                    logger.error("❌ Не удалось сгенерировать реферальный код")
                    self.results["referral_code_generation"] = {
                        "success": False,
                        "message": "Не удалось сгенерировать реферальный код"
                    }
                    return False
                
        except Exception as e:
            logger.error(f"❌ Ошибка при тестировании генерации реферальных кодов: {e}")
            self.results["referral_code_generation"] = {
                "success": False,
                "message": f"Ошибка: {str(e)}"
            }
            return False
    
    def test_referral_stats(self):
        """Проверяет получение реферальной статистики"""
        logger.info("Тестирование получения реферальной статистики...")
        try:
            with self.app.app_context():
                # Находим пользователя для тестирования
                test_user = User.query.first()
                
                if not test_user:
                    logger.warning("Не найдены пользователи для тестирования реферальной статистики")
                    self.results["referral_stats"] = {
                        "success": False,
                        "message": "Не найдены пользователи для тестирования"
                    }
                    return False
                
                # Получаем статистику
                stats = self.referral_manager.get_referral_stats(test_user.id)
                
                if stats is not None:
                    logger.info(f"Реферальная статистика для пользователя {test_user.id}: {stats}")
                    
                    self.results["referral_stats"] = {
                        "success": True,
                        "message": "Получена реферальная статистика",
                        "user_id": test_user.id,
                        "stats": stats
                    }
                    return True
                else:
                    logger.error("❌ Не удалось получить реферальную статистику")
                    self.results["referral_stats"] = {
                        "success": False,
                        "message": "Не удалось получить реферальную статистику"
                    }
                    return False
                
        except Exception as e:
            logger.error(f"❌ Ошибка при тестировании получения реферальной статистики: {e}")
            self.results["referral_stats"] = {
                "success": False,
                "message": f"Ошибка: {str(e)}"
            }
            return False
    
    def test_pending_rewards(self):
        """Проверяет получение ожидающих выплат"""
        logger.info("Тестирование получения ожидающих выплат...")
        try:
            with self.app.app_context():
                # Получаем ожидающие выплаты
                pending_rewards, total_count = get_pending_rewards(page=1, page_size=50)
                
                logger.info(f"Получено {len(pending_rewards)} ожидающих выплат из {total_count} всего")
                
                # Проверяем пагинацию, если есть больше 50 ожидающих выплат
                pagination_works = False
                if total_count > 50:
                    page2_rewards, _ = get_pending_rewards(page=2, page_size=50)
                    pagination_works = len(page2_rewards) > 0
                    logger.info(f"Пагинация работает: {pagination_works}")
                
                self.results["pending_rewards"] = {
                    "success": True,
                    "message": f"Получено {len(pending_rewards)} ожидающих выплат из {total_count} всего",
                    "count": len(pending_rewards),
                    "total_count": total_count,
                    "pagination": pagination_works if total_count > 50 else None
                }
                return True
                
        except Exception as e:
            logger.error(f"❌ Ошибка при тестировании получения ожидающих выплат: {e}")
            self.results["pending_rewards"] = {
                "success": False,
                "message": f"Ошибка: {str(e)}"
            }
            return False
    
    def test_weekly_payout(self):
        """Проверяет получение информации о еженедельных выплатах"""
        logger.info("Тестирование получения информации о еженедельных выплатах...")
        try:
            with self.app.app_context():
                # Проверяем, существуют ли еженедельные выплаты в базе данных
                payout_count = WeeklyPayout.query.count()
                logger.info(f"Количество еженедельных выплат в базе данных: {payout_count}")
                
                if payout_count > 0:
                    # Получаем последнюю выплату
                    latest_payout = WeeklyPayout.query.order_by(WeeklyPayout.created_at.desc()).first()
                    
                    if latest_payout:
                        logger.info(f"Последняя выплата: ID={latest_payout.id}, статус={latest_payout.status}, сумма={latest_payout.amount}")
                        
                        # Получаем количество наград, связанных с этой выплатой
                        reward_count = db.session.execute(
                            text("SELECT COUNT(*) FROM referral_rewards WHERE payout_id = :payout_id"),
                            {"payout_id": latest_payout.id}
                        ).scalar()
                        
                        logger.info(f"Количество наград, связанных с выплатой {latest_payout.id}: {reward_count}")
                        
                        self.results["weekly_payout"] = {
                            "success": True,
                            "message": f"Найдено {payout_count} еженедельных выплат в базе данных",
                            "latest_payout": {
                                "id": latest_payout.id,
                                "status": latest_payout.status,
                                "amount": latest_payout.amount,
                                "rewards_count": reward_count
                            }
                        }
                        return True
                    else:
                        logger.warning("Не удалось получить последнюю выплату")
                        self.results["weekly_payout"] = {
                            "success": False,
                            "message": "Не удалось получить последнюю выплату"
                        }
                        return False
                else:
                    logger.info("В базе данных нет еженедельных выплат")
                    
                    # Создаем тестовую выплату для администратора
                    admin_id = 5913639088
                    test_description = f"Тестовая выплата {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                    
                    payout_id = create_weekly_payout(admin_id, test_description)
                    if payout_id:
                        logger.info(f"✅ Создана тестовая выплата с ID: {payout_id}")
                        
                        # Получаем созданную выплату
                        new_payout = WeeklyPayout.query.get(payout_id)
                        
                        self.results["weekly_payout"] = {
                            "success": True,
                            "message": "Создана тестовая еженедельная выплата",
                            "latest_payout": {
                                "id": new_payout.id,
                                "status": new_payout.status,
                                "amount": new_payout.amount,
                                "rewards_count": 0  # новая выплата без наград
                            }
                        }
                        return True
                    else:
                        logger.error("❌ Не удалось создать тестовую выплату")
                        self.results["weekly_payout"] = {
                            "success": False,
                            "message": "Не удалось создать тестовую выплату"
                        }
                        return False
                
        except Exception as e:
            logger.error(f"❌ Ошибка при тестировании еженедельных выплат: {e}")
            self.results["weekly_payout"] = {
                "success": False,
                "message": f"Ошибка: {str(e)}"
            }
            return False
    
    def test_db_integrity(self):
        """Проверяет целостность данных между таблицами"""
        logger.info("Тестирование целостности данных между таблицами...")
        try:
            with self.app.app_context():
                integrity_issues = []
                
                # Проверяем транзакции на корректность user_id
                orphaned_transactions = db.session.execute(
                    text("""
                    SELECT COUNT(*) FROM transactions t
                    LEFT JOIN users u ON t.user_id = u.id
                    WHERE u.id IS NULL
                    """)
                ).scalar()
                
                if orphaned_transactions > 0:
                    logger.warning(f"⚠️ Найдено {orphaned_transactions} транзакций без соответствующих пользователей")
                    integrity_issues.append(f"Транзакции без пользователей: {orphaned_transactions}")
                
                # Проверяем реферальные отношения на корректность user_id и referrer_id
                orphaned_relations = db.session.execute(
                    text("""
                    SELECT COUNT(*) FROM referral_relations rr
                    LEFT JOIN users u1 ON rr.user_id = u1.id
                    LEFT JOIN users u2 ON rr.referrer_id = u2.id
                    WHERE u1.id IS NULL OR u2.id IS NULL
                    """)
                ).scalar()
                
                if orphaned_relations > 0:
                    logger.warning(f"⚠️ Найдено {orphaned_relations} реферальных отношений с невалидными ID пользователей")
                    integrity_issues.append(f"Невалидные реферальные отношения: {orphaned_relations}")
                
                # Проверяем реферальные коды на корректность user_id
                orphaned_codes = db.session.execute(
                    text("""
                    SELECT COUNT(*) FROM referral_codes rc
                    LEFT JOIN users u ON rc.user_id = u.id
                    WHERE u.id IS NULL
                    """)
                ).scalar()
                
                if orphaned_codes > 0:
                    logger.warning(f"⚠️ Найдено {orphaned_codes} реферальных кодов без соответствующих пользователей")
                    integrity_issues.append(f"Реферальные коды без пользователей: {orphaned_codes}")
                
                # Проверяем реферальные вознаграждения на корректность referral_relation_id
                orphaned_rewards = db.session.execute(
                    text("""
                    SELECT COUNT(*) FROM referral_rewards rr
                    LEFT JOIN referral_relations rl ON rr.referral_relation_id = rl.id
                    WHERE rl.id IS NULL
                    """)
                ).scalar()
                
                if orphaned_rewards > 0:
                    logger.warning(f"⚠️ Найдено {orphaned_rewards} реферальных вознаграждений без соответствующих отношений")
                    integrity_issues.append(f"Вознаграждения без отношений: {orphaned_rewards}")
                
                # Проверяем еженедельные выплаты на корректность admin_id
                invalid_payouts = db.session.execute(
                    text("""
                    SELECT COUNT(*) FROM weekly_payouts wp
                    LEFT JOIN users u ON wp.admin_id = u.id
                    WHERE u.id IS NULL
                    """)
                ).scalar()
                
                if invalid_payouts > 0:
                    logger.warning(f"⚠️ Найдено {invalid_payouts} еженедельных выплат с невалидным admin_id")
                    integrity_issues.append(f"Выплаты с невалидным admin_id: {invalid_payouts}")
                
                if integrity_issues:
                    logger.warning("⚠️ Найдены проблемы с целостностью данных")
                    self.results["db_integrity"] = {
                        "success": False,
                        "message": "Найдены проблемы с целостностью данных",
                        "issues": integrity_issues
                    }
                    return False
                else:
                    logger.info("✅ Целостность данных в порядке")
                    self.results["db_integrity"] = {
                        "success": True,
                        "message": "Целостность данных в порядке"
                    }
                    return True
                
        except Exception as e:
            logger.error(f"❌ Ошибка при тестировании целостности данных: {e}")
            self.results["db_integrity"] = {
                "success": False,
                "message": f"Ошибка: {str(e)}"
            }
            return False
    
    def run_all_tests(self):
        """Запускает все тесты и возвращает результаты"""
        tests = [
            self.test_database_connection,
            self.test_user_model,
            self.test_transaction_model,
            self.test_referral_code_generation,
            self.test_referral_stats,
            self.test_pending_rewards,
            self.test_weekly_payout,
            self.test_db_integrity
        ]
        
        results = {}
        all_success = True
        
        for test in tests:
            test_name = test.__name__
            logger.info(f"\n🔍 Запуск теста: {test_name}")
            
            try:
                success = test()
                results[test_name] = {
                    "success": success,
                    "details": self.results.get(test_name.replace("test_", ""), {})
                }
                
                if not success:
                    all_success = False
                    
            except Exception as e:
                logger.error(f"❌ Ошибка при выполнении теста {test_name}: {e}")
                traceback.print_exc()
                results[test_name] = {
                    "success": False,
                    "error": str(e)
                }
                all_success = False
        
        return {
            "overall_success": all_success,
            "results": results
        }
    
    def save_results(self, filename=None):
        """Сохраняет результаты тестирования в файл"""
        if filename is None:
            timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            filename = f"component_test_results_{timestamp}.json"
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Результаты тестирования сохранены в файл: {filename}")
        return filename

if __name__ == "__main__":
    try:
        logger.info("Запуск модульного тестирования компонентов...")
        
        tester = ComponentTester()
        results = tester.run_all_tests()
        
        # Сохраняем результаты в файл
        timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        filename = f"component_test_results_{timestamp}.json"
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Результаты сохранены в файл: {filename}")
        
        # Выводим общий результат
        success_count = sum(1 for test_name, test_result in results["results"].items() if test_result["success"])
        total_count = len(results["results"])
        
        print("\n" + "="*50)
        print(f"РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ: {success_count}/{total_count} успешно")
        print("="*50)
        
        for test_name, test_result in results["results"].items():
            status = "✅" if test_result["success"] else "❌"
            display_name = test_name.replace("test_", "").replace("_", " ").title()
            print(f"{status} {display_name}")
            
            if not test_result["success"] and "error" in test_result:
                print(f"   Ошибка: {test_result['error']}")
        
        print("="*50)
        if results["overall_success"]:
            print("✅ ВСЕ ТЕСТЫ ПРОЙДЕНЫ УСПЕШНО!")
        else:
            print("⚠️ НЕКОТОРЫЕ ТЕСТЫ НЕ ПРОЙДЕНЫ")
        print("="*50)
        
        sys.exit(0 if results["overall_success"] else 1)
        
    except Exception as e:
        logger.error(f"Ошибка при запуске тестирования: {e}")
        traceback.print_exc()
        sys.exit(1)