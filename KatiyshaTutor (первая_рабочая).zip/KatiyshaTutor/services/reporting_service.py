#!/usr/bin/env python
# coding: utf-8

"""
Сервис для создания и экспорта отчетов в различных форматах
"""

import os
import json
import csv
import logging
import datetime
import tempfile
from io import StringIO, BytesIO
from typing import Dict, List, Any, Optional, Tuple, Union, Iterable
from enum import Enum

import xlsxwriter
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
from pptx import Presentation
from pptx.util import Inches, Pt

from services.payout_monitoring_service import ReportFormat

logger = logging.getLogger(__name__)

class ReportingService:
    """Сервис для создания и экспорта отчетов в различных форматах"""
    
    @staticmethod
    def export_report(data: Dict[str, Any], report_format: ReportFormat, title: str = "") -> Tuple[bytes, str]:
        """
        Экспорт данных в указанном формате
        
        Args:
            data: Данные для экспорта
            report_format: Формат экспорта
            title: Заголовок отчета
            
        Returns:
            tuple: (bytes данных отчета, mime-тип)
        """
        if report_format == ReportFormat.JSON:
            return ReportingService._export_as_json(data), "application/json"
        elif report_format == ReportFormat.CSV:
            return ReportingService._export_as_csv(data), "text/csv"
        elif report_format == ReportFormat.TEXT:
            return ReportingService._export_as_text(data, title), "text/plain"
        elif report_format == ReportFormat.HTML:
            return ReportingService._export_as_html(data, title), "text/html"
        elif report_format == ReportFormat.PDF:
            return ReportingService._export_as_pdf(data, title), "application/pdf"
        elif report_format == ReportFormat.EXCEL:
            return ReportingService._export_as_excel(data, title), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        else:
            raise ValueError(f"Unsupported report format: {report_format}")
    
    @staticmethod
    def _export_as_json(data: Dict[str, Any]) -> bytes:
        """
        Экспорт данных в формате JSON
        
        Args:
            data: Данные для экспорта
            
        Returns:
            bytes: Данные в формате JSON
        """
        return json.dumps(data, ensure_ascii=False, indent=2).encode('utf-8')
    
    @staticmethod
    def _export_as_csv(data: Dict[str, Any]) -> bytes:
        """
        Экспорт данных в формате CSV
        
        Args:
            data: Данные для экспорта
            
        Returns:
            bytes: Данные в формате CSV
        """
        output = StringIO()
        
        # Определяем заголовки и строки на основе структуры данных
        if isinstance(data, dict) and 'items' in data and isinstance(data['items'], list) and data['items']:
            # Если это словарь с элементами в ключе 'items'
            items = data['items']
            if items and isinstance(items[0], dict):
                headers = list(items[0].keys())
                
                writer = csv.DictWriter(output, fieldnames=headers)
                writer.writeheader()
                writer.writerows(items)
        else:
            # Плоский экспорт для простого словаря
            writer = csv.writer(output)
            for key, value in data.items():
                if isinstance(value, (list, dict)):
                    value = json.dumps(value, ensure_ascii=False)
                writer.writerow([key, value])
        
        return output.getvalue().encode('utf-8')
    
    @staticmethod
    def _export_as_text(data: Dict[str, Any], title: str = "") -> bytes:
        """
        Экспорт данных в текстовом формате
        
        Args:
            data: Данные для экспорта
            title: Заголовок отчета
            
        Returns:
            bytes: Данные в текстовом формате
        """
        output = []
        
        if title:
            output.append(title)
            output.append("=" * len(title))
            output.append("")
        
        def _format_value(value):
            if isinstance(value, (dict, list)):
                return json.dumps(value, ensure_ascii=False, indent=2)
            return str(value)
        
        def _add_dict_to_output(d, indent=0):
            for key, value in d.items():
                if isinstance(value, dict):
                    output.append(" " * indent + f"{key}:")
                    _add_dict_to_output(value, indent + 2)
                elif isinstance(value, list) and value and isinstance(value[0], dict):
                    output.append(" " * indent + f"{key}:")
                    for i, item in enumerate(value):
                        output.append(" " * (indent + 2) + f"[{i}]:")
                        _add_dict_to_output(item, indent + 4)
                else:
                    output.append(" " * indent + f"{key}: {_format_value(value)}")
        
        _add_dict_to_output(data)
        
        return "\n".join(output).encode('utf-8')
    
    @staticmethod
    def _export_as_html(data: Dict[str, Any], title: str = "") -> bytes:
        """
        Экспорт данных в формате HTML
        
        Args:
            data: Данные для экспорта
            title: Заголовок отчета
            
        Returns:
            bytes: Данные в формате HTML
        """
        html = ["<!DOCTYPE html>", "<html>", "<head>", 
                "<meta charset='utf-8'>",
                f"<title>{title}</title>", 
                "<style>",
                "body { font-family: Arial, sans-serif; margin: 20px; }",
                "h1 { color: #333; }",
                "table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }",
                "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }",
                "th { background-color: #f2f2f2; }",
                "tr:nth-child(even) { background-color: #f9f9f9; }",
                ".key { font-weight: bold; width: 30%; }",
                "</style>",
                "</head>", 
                "<body>"]
        
        if title:
            html.append(f"<h1>{title}</h1>")
        
        def _format_value(value):
            if isinstance(value, (dict, list)):
                return f"<pre>{json.dumps(value, ensure_ascii=False, indent=2)}</pre>"
            return str(value)
        
        def _add_dict_to_html(d, level=1):
            html.append("<table>")
            
            for key, value in d.items():
                html.append("<tr>")
                html.append(f"<td class='key'>{key}</td>")
                
                if isinstance(value, dict):
                    html.append("<td>")
                    _add_dict_to_html(value, level + 1)
                    html.append("</td>")
                elif isinstance(value, list) and value and isinstance(value[0], dict):
                    html.append("<td>")
                    for item in value:
                        _add_dict_to_html(item, level + 1)
                    html.append("</td>")
                else:
                    html.append(f"<td>{_format_value(value)}</td>")
                
                html.append("</tr>")
            
            html.append("</table>")
        
        _add_dict_to_html(data)
        
        html.extend(["</body>", "</html>"])
        
        return "\n".join(html).encode('utf-8')
    
    @staticmethod
    def _export_as_pdf(data: Dict[str, Any], title: str = "") -> bytes:
        """
        Экспорт данных в формате PDF
        
        Args:
            data: Данные для экспорта
            title: Заголовок отчета
            
        Returns:
            bytes: Данные в формате PDF
        """
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        elements = []
        
        styles = getSampleStyleSheet()
        
        if title:
            elements.append(Paragraph(title, styles['Heading1']))
        
        # Преобразуем данные в таблицу
        table_data = []
        
        def _format_value(value):
            if isinstance(value, (dict, list)):
                return json.dumps(value, ensure_ascii=False, indent=2)
            return str(value)
        
        def _add_dict_to_table(d, indent=0):
            for key, value in d.items():
                if isinstance(value, dict):
                    table_data.append([" " * indent + key, ""])
                    _add_dict_to_table(value, indent + 2)
                elif isinstance(value, list) and value and isinstance(value[0], dict):
                    table_data.append([" " * indent + key, ""])
                    for i, item in enumerate(value):
                        table_data.append([" " * (indent + 2) + f"[{i}]", ""])
                        _add_dict_to_table(item, indent + 4)
                else:
                    table_data.append([" " * indent + key, _format_value(value)])
        
        _add_dict_to_table(data)
        
        if table_data:
            table = Table(table_data)
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
                ('TEXTCOLOR', (0, 0), (0, -1), colors.black),
                ('ALIGN', (0, 0), (0, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                ('BACKGROUND', (1, 0), (-1, -1), colors.white),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ]))
            elements.append(table)
        
        # Сохраняем PDF
        doc.build(elements)
        buffer.seek(0)
        
        return buffer.getvalue()
    
    @staticmethod
    def _export_as_excel(data: Dict[str, Any], title: str = "") -> bytes:
        """
        Экспорт данных в формате Excel
        
        Args:
            data: Данные для экспорта
            title: Заголовок отчета
            
        Returns:
            bytes: Данные в формате Excel
        """
        buffer = BytesIO()
        workbook = xlsxwriter.Workbook(buffer)
        
        # Определяем имя листа на основе заголовка или используем стандартное название
        sheet_name = title[:31] if title else "Report"  # Excel ограничивает длину имени листа до 31 символа
        worksheet = workbook.add_worksheet(sheet_name)
        
        # Добавляем заголовок, если он указан
        if title:
            title_format = workbook.add_format({'bold': True, 'font_size': 14})
            worksheet.write(0, 0, title, title_format)
            current_row = 2  # Пропускаем строку после заголовка
        else:
            current_row = 0
        
        # Форматы для ячеек
        header_format = workbook.add_format({'bold': True, 'bg_color': '#D3D3D3', 'border': 1})
        cell_format = workbook.add_format({'border': 1})
        
        # Определяем, как экспортировать данные на основе их структуры
        if 'items' in data and isinstance(data['items'], list) and data['items'] and isinstance(data['items'][0], dict):
            # Список объектов - экспортируем как таблицу с заголовками
            items = data['items']
            headers = list(items[0].keys())
            
            # Записываем заголовки
            for col, header in enumerate(headers):
                worksheet.write(current_row, col, header, header_format)
            current_row += 1
            
            # Записываем данные
            for item in items:
                for col, header in enumerate(headers):
                    value = item.get(header, "")
                    if isinstance(value, (dict, list)):
                        value = json.dumps(value, ensure_ascii=False)
                    worksheet.write(current_row, col, value, cell_format)
                current_row += 1
        else:
            # Обычный словарь - экспортируем как пары ключ-значение
            worksheet.write(current_row, 0, "Key", header_format)
            worksheet.write(current_row, 1, "Value", header_format)
            current_row += 1
            
            def _format_value(value):
                if isinstance(value, (dict, list)):
                    return json.dumps(value, ensure_ascii=False, indent=2)
                return str(value)
            
            def _add_dict_to_sheet(d, indent=0):
                nonlocal current_row
                for key, value in d.items():
                    indented_key = " " * indent + str(key)
                    if isinstance(value, dict):
                        worksheet.write(current_row, 0, indented_key, cell_format)
                        worksheet.write(current_row, 1, "", cell_format)
                        current_row += 1
                        _add_dict_to_sheet(value, indent + 2)
                    elif isinstance(value, list) and value and isinstance(value[0], dict):
                        worksheet.write(current_row, 0, indented_key, cell_format)
                        worksheet.write(current_row, 1, "", cell_format)
                        current_row += 1
                        for i, item in enumerate(value):
                            list_key = " " * (indent + 2) + f"[{i}]"
                            worksheet.write(current_row, 0, list_key, cell_format)
                            worksheet.write(current_row, 1, "", cell_format)
                            current_row += 1
                            _add_dict_to_sheet(item, indent + 4)
                    else:
                        worksheet.write(current_row, 0, indented_key, cell_format)
                        worksheet.write(current_row, 1, _format_value(value), cell_format)
                        current_row += 1
            
            _add_dict_to_sheet(data)
        
        # Автоматически регулируем ширину столбцов
        worksheet.autofit()
        
        workbook.close()
        buffer.seek(0)
        
        return buffer.getvalue()
    
    @staticmethod
    def get_filename(report_type: str, report_format: ReportFormat) -> str:
        """
        Генерация имени файла для отчета
        
        Args:
            report_type: Тип отчета
            report_format: Формат отчета
            
        Returns:
            str: Имя файла
        """
        date_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        format_extensions = {
            ReportFormat.JSON: "json",
            ReportFormat.CSV: "csv",
            ReportFormat.TEXT: "txt",
            ReportFormat.HTML: "html",
            ReportFormat.PDF: "pdf",
            ReportFormat.EXCEL: "xlsx"
        }
        extension = format_extensions.get(report_format, "dat")
        
        return f"{report_type}_{date_str}.{extension}"

# Вспомогательные функции для admin_web_interface.py

def generate_report_pdf(data: Dict[str, Any], title: str = "") -> BytesIO:
    """
    Создание отчета в формате PDF
    
    Args:
        data: Данные для отчета
        title: Заголовок отчета
        
    Returns:
        BytesIO: Буфер с PDF-данными
    """
    pdf_data = ReportingService._export_as_pdf(data, title)
    pdf_buffer = BytesIO(pdf_data)
    return pdf_buffer

def generate_report_excel(data: Dict[str, Any], title: str = "") -> BytesIO:
    """
    Создание отчета в формате Excel
    
    Args:
        data: Данные для отчета
        title: Заголовок отчета
        
    Returns:
        BytesIO: Буфер с Excel-данными
    """
    excel_data = ReportingService._export_as_excel(data, title)
    excel_buffer = BytesIO(excel_data)
    return excel_buffer

def generate_report_json(data: Dict[str, Any]) -> StringIO:
    """
    Создание отчета в формате JSON
    
    Args:
        data: Данные для отчета
        
    Returns:
        StringIO: Буфер с JSON-данными
    """
    json_data = ReportingService._export_as_json(data)
    json_buffer = StringIO(json_data.decode('utf-8'))
    return json_buffer