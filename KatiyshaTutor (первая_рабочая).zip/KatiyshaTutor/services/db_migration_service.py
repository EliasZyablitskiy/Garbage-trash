#!/usr/bin/env python
# coding: utf-8

"""
Сервис для миграции данных из JSON-файлов в PostgreSQL базу данных
"""

import os
import json
import logging
import datetime
from typing import Dict, List, Any, Optional, Tuple

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func, or_, and_

from db_models import (
    User, Transaction, WeeklyPayout, BatchPayout,
    PayoutOperationLog, PayoutTransaction, 
    AdminActionLog, BackupLog, db
)

logger = logging.getLogger(__name__)

class DBMigrationService:
    """
    Сервис для миграции данных из JSON в PostgreSQL
    """
    
    @staticmethod
    async def migrate_users(session: AsyncSession, json_file: str = 'users_db.json') -> Tuple[int, int, List[str]]:
        """
        Миграция пользователей из JSON-файла в PostgreSQL
        
        Args:
            session: Активная сессия базы данных
            json_file: Путь к JSON-файлу с пользователями
        
        Returns:
            tuple: (кол-во обработанных записей, кол-во добавленных записей, список ошибок)
        """
        if not os.path.exists(json_file):
            logger.error(f"JSON file not found: {json_file}")
            return 0, 0, [f"Файл не найден: {json_file}"]
        
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                users_data = json.load(f)
            
            processed = 0
            added = 0
            errors = []
            
            for user_id, user_data in users_data.items():
                try:
                    # Проверяем, существует ли пользователь
                    result = await session.execute(
                        select(User).where(User.id == int(user_id))
                    )
                    existing_user = result.scalars().first()
                    
                    if not existing_user:
                        # Создаем нового пользователя
                        user = User(
                            id=int(user_id),
                            username=user_data.get('username', ''),
                            referrer_id=user_data.get('referrer_id'),
                            joined_at=datetime.datetime.fromisoformat(user_data.get('joined_at', datetime.datetime.now().isoformat())),
                            is_subscriber=user_data.get('is_subscriber', False),
                            subscription_expires=datetime.datetime.fromisoformat(user_data.get('subscription_expires', datetime.datetime.now().isoformat())) if user_data.get('subscription_expires') else None,
                            last_activity=datetime.datetime.fromisoformat(user_data.get('last_activity', datetime.datetime.now().isoformat())) if user_data.get('last_activity') else None,
                            language_code=user_data.get('language_code', 'ru'),
                            free_requests_used=user_data.get('free_requests_used', 0),
                            is_banned=user_data.get('is_banned', False),
                            ban_reason=user_data.get('ban_reason', None),
                            first_name=user_data.get('first_name', ''),
                            last_name=user_data.get('last_name', '')
                        )
                        session.add(user)
                        added += 1
                    else:
                        # Обновляем данные существующего пользователя
                        if user_data.get('username'):
                            existing_user.username = user_data.get('username')
                        if user_data.get('referrer_id') and not existing_user.referrer_id:
                            existing_user.referrer_id = user_data.get('referrer_id')
                        if user_data.get('is_subscriber') is not None:
                            existing_user.is_subscriber = user_data.get('is_subscriber')
                        if user_data.get('subscription_expires'):
                            existing_user.subscription_expires = datetime.datetime.fromisoformat(user_data.get('subscription_expires'))
                        if user_data.get('language_code'):
                            existing_user.language_code = user_data.get('language_code')
                        if user_data.get('free_requests_used') is not None:
                            existing_user.free_requests_used = user_data.get('free_requests_used')
                        if user_data.get('is_banned') is not None:
                            existing_user.is_banned = user_data.get('is_banned')
                        if user_data.get('ban_reason'):
                            existing_user.ban_reason = user_data.get('ban_reason')
                        if user_data.get('first_name'):
                            existing_user.first_name = user_data.get('first_name')
                        if user_data.get('last_name'):
                            existing_user.last_name = user_data.get('last_name')
                    
                    processed += 1
                    
                    # Коммитим каждые 100 записей для снижения нагрузки
                    if processed % 100 == 0:
                        await session.commit()
                        logger.info(f"Migrated {processed} users")
                        
                except Exception as e:
                    error_msg = f"Error migrating user {user_id}: {str(e)}"
                    logger.error(error_msg)
                    errors.append(error_msg)
            
            # Финальный коммит
            await session.commit()
            
            return processed, added, errors
            
        except Exception as e:
            logger.error(f"Error during user migration: {str(e)}")
            return 0, 0, [f"Ошибка миграции пользователей: {str(e)}"]
    
    @staticmethod
    async def migrate_transactions(session: AsyncSession, json_file: str = 'transactions_db.json') -> Tuple[int, int, List[str]]:
        """
        Миграция транзакций из JSON-файла в PostgreSQL
        
        Args:
            session: Активная сессия базы данных
            json_file: Путь к JSON-файлу с транзакциями
        
        Returns:
            tuple: (кол-во обработанных записей, кол-во добавленных записей, список ошибок)
        """
        if not os.path.exists(json_file):
            logger.error(f"JSON file not found: {json_file}")
            return 0, 0, [f"Файл не найден: {json_file}"]
        
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                transactions_data = json.load(f)
            
            processed = 0
            added = 0
            errors = []
            
            for tx_id, tx_data in transactions_data.items():
                try:
                    # Проверяем, существует ли транзакция
                    result = await session.execute(
                        select(Transaction).where(Transaction.transaction_id == tx_id)
                    )
                    existing_tx = result.scalars().first()
                    
                    if not existing_tx:
                        # Создаем новую транзакцию
                        tx = Transaction(
                            transaction_id=tx_id,
                            user_id=tx_data.get('user_id'),
                            transaction_type=tx_data.get('type', 'unknown'),
                            amount=float(tx_data.get('amount', 0.0)),
                            status=tx_data.get('status', 'pending'),
                            description=tx_data.get('description', ''),
                            created_at=datetime.datetime.fromisoformat(tx_data.get('created_at', datetime.datetime.now().isoformat())),
                            updated_at=datetime.datetime.fromisoformat(tx_data.get('updated_at', datetime.datetime.now().isoformat())) if tx_data.get('updated_at') else None,
                            payment_method=tx_data.get('payment_method', None),
                            payment_id=tx_data.get('payment_id', None),
                            payout_id=tx_data.get('payout_id', None),
                            error_message=tx_data.get('error_message', None),
                            retry_count=tx_data.get('retry_count', 0)
                        )
                        session.add(tx)
                        added += 1
                    else:
                        # Обновляем данные существующей транзакции если статус не completed или failed
                        if existing_tx.status not in ('completed', 'failed'):
                            if tx_data.get('status'):
                                existing_tx.status = tx_data.get('status')
                            if tx_data.get('updated_at'):
                                existing_tx.updated_at = datetime.datetime.fromisoformat(tx_data.get('updated_at'))
                            if tx_data.get('payout_id'):
                                existing_tx.payout_id = tx_data.get('payout_id')
                            if tx_data.get('payment_id'):
                                existing_tx.payment_id = tx_data.get('payment_id')
                            if tx_data.get('error_message'):
                                existing_tx.error_message = tx_data.get('error_message')
                            if tx_data.get('retry_count') is not None:
                                existing_tx.retry_count = tx_data.get('retry_count')
                    
                    processed += 1
                    
                    # Коммитим каждые 100 записей для снижения нагрузки
                    if processed % 100 == 0:
                        await session.commit()
                        logger.info(f"Migrated {processed} transactions")
                        
                except Exception as e:
                    error_msg = f"Error migrating transaction {tx_id}: {str(e)}"
                    logger.error(error_msg)
                    errors.append(error_msg)
            
            # Финальный коммит
            await session.commit()
            
            return processed, added, errors
            
        except Exception as e:
            logger.error(f"Error during transaction migration: {str(e)}")
            return 0, 0, [f"Ошибка миграции транзакций: {str(e)}"]
    
    @staticmethod
    async def migrate_weekly_payouts(session: AsyncSession, json_file: str = 'payouts_db.json') -> Tuple[int, int, List[str]]:
        """
        Миграция еженедельных выплат из JSON-файла в PostgreSQL
        
        Args:
            session: Активная сессия базы данных
            json_file: Путь к JSON-файлу с выплатами
        
        Returns:
            tuple: (кол-во обработанных записей, кол-во добавленных записей, список ошибок)
        """
        if not os.path.exists(json_file):
            logger.error(f"JSON file not found: {json_file}")
            return 0, 0, [f"Файл не найден: {json_file}"]
        
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                payouts_data = json.load(f)
            
            processed = 0
            added = 0
            errors = []
            
            for payout_id, payout_data in payouts_data.items():
                try:
                    # Проверяем, существует ли выплата
                    result = await session.execute(
                        select(WeeklyPayout).where(WeeklyPayout.id == int(payout_id))
                    )
                    existing_payout = result.scalars().first()
                    
                    if not existing_payout:
                        # Создаем новую выплату
                        payout = WeeklyPayout(
                            id=int(payout_id),
                            status=payout_data.get('status', 'pending'),
                            total_amount=float(payout_data.get('total_amount', 0.0)),
                            total_users=payout_data.get('total_users', 0),
                            created_at=datetime.datetime.fromisoformat(payout_data.get('created_at', datetime.datetime.now().isoformat())),
                            processed_at=datetime.datetime.fromisoformat(payout_data.get('processed_at', datetime.datetime.now().isoformat())) if payout_data.get('processed_at') else None,
                            admin_id=payout_data.get('admin_id', None),
                            description=payout_data.get('description', ''),
                            payment_details=payout_data.get('payment_details', {})
                        )
                        session.add(payout)
                        added += 1
                    else:
                        # Обновляем данные существующей выплаты
                        if payout_data.get('status'):
                            existing_payout.status = payout_data.get('status')
                        if payout_data.get('processed_at'):
                            existing_payout.processed_at = datetime.datetime.fromisoformat(payout_data.get('processed_at'))
                        if payout_data.get('admin_id'):
                            existing_payout.admin_id = payout_data.get('admin_id')
                        if payout_data.get('payment_details'):
                            existing_payout.payment_details = payout_data.get('payment_details')
                    
                    processed += 1
                    
                    # Коммитим каждые 10 записей для снижения нагрузки (выплат обычно немного)
                    if processed % 10 == 0:
                        await session.commit()
                        logger.info(f"Migrated {processed} weekly payouts")
                        
                except Exception as e:
                    error_msg = f"Error migrating weekly payout {payout_id}: {str(e)}"
                    logger.error(error_msg)
                    errors.append(error_msg)
            
            # Финальный коммит
            await session.commit()
            
            return processed, added, errors
            
        except Exception as e:
            logger.error(f"Error during weekly payout migration: {str(e)}")
            return 0, 0, [f"Ошибка миграции еженедельных выплат: {str(e)}"]
    
    @staticmethod
    async def migrate_all(session: AsyncSession) -> Dict[str, Any]:
        """
        Выполняет миграцию всех данных из JSON-файлов в PostgreSQL
        
        Args:
            session: Активная сессия базы данных
        
        Returns:
            dict: Результаты миграции
        """
        results = {
            "users": {"processed": 0, "added": 0, "errors": []},
            "transactions": {"processed": 0, "added": 0, "errors": []},
            "weekly_payouts": {"processed": 0, "added": 0, "errors": []},
            "total_processed": 0,
            "total_added": 0,
            "total_errors": 0,
            "status": "success"
        }
        
        try:
            # Миграция пользователей
            logger.info("Starting user migration...")
            users_processed, users_added, users_errors = await DBMigrationService.migrate_users(session)
            results["users"]["processed"] = users_processed
            results["users"]["added"] = users_added
            results["users"]["errors"] = users_errors
            results["total_processed"] += users_processed
            results["total_added"] += users_added
            results["total_errors"] += len(users_errors)
            
            # Миграция транзакций
            logger.info("Starting transaction migration...")
            txs_processed, txs_added, txs_errors = await DBMigrationService.migrate_transactions(session)
            results["transactions"]["processed"] = txs_processed
            results["transactions"]["added"] = txs_added
            results["transactions"]["errors"] = txs_errors
            results["total_processed"] += txs_processed
            results["total_added"] += txs_added
            results["total_errors"] += len(txs_errors)
            
            # Миграция еженедельных выплат
            logger.info("Starting weekly payout migration...")
            payouts_processed, payouts_added, payouts_errors = await DBMigrationService.migrate_weekly_payouts(session)
            results["weekly_payouts"]["processed"] = payouts_processed
            results["weekly_payouts"]["added"] = payouts_added
            results["weekly_payouts"]["errors"] = payouts_errors
            results["total_processed"] += payouts_processed
            results["total_added"] += payouts_added
            results["total_errors"] += len(payouts_errors)
            
            logger.info(f"Migration completed. Processed: {results['total_processed']}, Added: {results['total_added']}, Errors: {results['total_errors']}")
            
            if results["total_errors"] > 0:
                results["status"] = "completed_with_errors"
                
            return results
            
        except Exception as e:
            logger.error(f"Error during full migration: {str(e)}")
            results["status"] = "failed"
            results["error"] = str(e)
            return results

# Функция для запуска миграции
async def run_migration() -> Dict[str, Any]:
    """
    Запускает полную миграцию данных из JSON в PostgreSQL
    
    Returns:
        dict: Результаты миграции
    """
    async with db.start_session() as session:
        results = await DBMigrationService.migrate_all(session)
        
        # Логируем результаты миграции
        log_entry = AdminActionLog(
            admin_id=0,  # Системный процесс
            action_type="json_to_db_migration",
            details=json.dumps(results)
        )
        session.add(log_entry)
        await session.commit()
        
        return results