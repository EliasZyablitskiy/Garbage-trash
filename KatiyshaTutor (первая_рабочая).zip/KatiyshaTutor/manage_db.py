#!/usr/bin/env python
# coding: utf-8

"""
Утилита для управления базой данных и применения оптимизаций
"""

import os
import logging
import argparse
from datetime import datetime
from typing import List, Tuple, Dict, Any

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Получаем строку подключения к базе данных
DATABASE_URL = os.environ.get("DATABASE_URL")
if DATABASE_URL and DATABASE_URL.startswith('postgres://'):
    DATABASE_URL = DATABASE_URL.replace('postgres://', 'postgresql://', 1)


def execute_sql_file(file_path: str) -> Tuple[bool, List[str]]:
    """
    Выполняет SQL-запросы из файла напрямую через psycopg2
    
    Args:
        file_path: Путь к файлу с SQL-запросами
        
    Returns:
        Tuple[bool, List[str]]: Результат выполнения (успех/ошибка) и список сообщений
    """
    import psycopg2
    
    results = []
    success = True
    
    try:
        with open(file_path, 'r') as f:
            sql_content = f.read()
        
        # Разделяем файл на отдельные SQL-запросы
        statements = [s.strip() for s in sql_content.split(';') if s.strip()]
        
        # Подключаемся напрямую через psycopg2
        conn = psycopg2.connect(DATABASE_URL)
        conn.autocommit = False  # Включаем автоматическую фиксацию транзакций
        
        try:
            with conn.cursor() as cursor:
                for i, statement in enumerate(statements):
                    try:
                        start_time = datetime.now()
                        cursor.execute(statement)
                        end_time = datetime.now()
                        execution_time = (end_time - start_time).total_seconds()
                        
                        results.append(f"Успешно выполнен запрос #{i+1} ({execution_time:.2f}с): {statement[:50]}...")
                        logger.info(f"Успешно выполнен запрос #{i+1} ({execution_time:.2f}с)")
                    except Exception as e:
                        error_msg = f"Ошибка при выполнении запроса #{i+1}: {str(e)}"
                        results.append(error_msg)
                        logger.error(error_msg)
                        success = False
                        
                if success:
                    conn.commit()
                    logger.info("Транзакция успешно зафиксирована")
                else:
                    conn.rollback()
                    logger.warning("Транзакция отменена из-за ошибок")
        finally:
            conn.close()
            
    except Exception as e:
        error_msg = f"Ошибка при чтении файла или подключении к базе данных: {str(e)}"
        results.append(error_msg)
        logger.error(error_msg)
        success = False
        
    return success, results


def get_index_size_stats() -> List[Dict[str, Any]]:
    """
    Получить статистику по размеру индексов
    
    Returns:
        List[Dict[str, Any]]: Список словарей с информацией о размерах индексов
    """
    import psycopg2
    import psycopg2.extras
    
    query = """
    SELECT
        schemaname AS schema,
        tablename AS table_name,
        indexname AS index_name,
        pg_size_pretty(pg_relation_size(quote_ident(schemaname) || '.' || quote_ident(indexname)::text)) AS index_size,
        pg_relation_size(quote_ident(schemaname) || '.' || quote_ident(indexname)::text) AS index_size_bytes
    FROM pg_indexes
    WHERE schemaname = 'public'
    ORDER BY pg_relation_size(quote_ident(schemaname) || '.' || quote_ident(indexname)::text) DESC;
    """
    
    conn = psycopg2.connect(DATABASE_URL)
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
            cursor.execute(query)
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
    finally:
        conn.close()


def get_table_stats() -> List[Dict[str, Any]]:
    """
    Получить статистику по таблицам
    
    Returns:
        List[Dict[str, Any]]: Список словарей с информацией о таблицах
    """
    import psycopg2
    import psycopg2.extras
    
    query = """
    SELECT
        relname AS table_name,
        n_live_tup AS row_count,
        pg_size_pretty(pg_total_relation_size(quote_ident(relname))) AS total_size,
        pg_size_pretty(pg_relation_size(quote_ident(relname))) AS table_size,
        pg_size_pretty(pg_total_relation_size(quote_ident(relname)) - pg_relation_size(quote_ident(relname))) AS index_size,
        pg_total_relation_size(quote_ident(relname)) AS total_size_bytes
    FROM pg_stat_user_tables
    ORDER BY pg_total_relation_size(quote_ident(relname)) DESC;
    """
    
    conn = psycopg2.connect(DATABASE_URL)
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
            cursor.execute(query)
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
    finally:
        conn.close()


def show_stats() -> None:
    """Отображает статистику базы данных"""
    
    logger.info("Получение статистики таблиц...")
    table_stats = get_table_stats()
    
    logger.info("Получение статистики индексов...")
    index_stats = get_index_size_stats()
    
    print("\n=== Статистика таблиц ===")
    print("{:<20} {:<10} {:<15} {:<15} {:<15}".format(
        "Таблица", "Строки", "Общий размер", "Размер таблицы", "Размер индексов"
    ))
    print("-" * 75)
    
    for stat in table_stats:
        print("{:<20} {:<10} {:<15} {:<15} {:<15}".format(
            stat['table_name'][:20],
            stat['row_count'],
            stat['total_size'],
            stat['table_size'],
            stat['index_size']
        ))
    
    print("\n=== Статистика индексов ===")
    print("{:<20} {:<35} {:<15}".format(
        "Таблица", "Индекс", "Размер"
    ))
    print("-" * 70)
    
    for stat in index_stats:
        print("{:<20} {:<35} {:<15}".format(
            stat['table_name'][:20],
            stat['index_name'][:35],
            stat['index_size']
        ))


def main() -> None:
    """
    Основная функция запуска
    """
    parser = argparse.ArgumentParser(description='Утилита для управления базой данных')
    subparsers = parser.add_subparsers(dest='command', help='Команда для выполнения')
    
    # Команда для оптимизации
    optimize_parser = subparsers.add_parser('optimize', help='Применить оптимизации из SQL-файла')
    optimize_parser.add_argument('--file', default='sql_optimizations.sql', help='Путь к файлу с SQL-запросами')
    
    # Команда для отображения статистики
    subparsers.add_parser('stats', help='Показать статистику базы данных')
    
    args = parser.parse_args()
    
    if args.command == 'optimize':
        logger.info(f"Применение оптимизаций из файла: {args.file}")
        success, results = execute_sql_file(args.file)
        
        if success:
            logger.info("Все оптимизации успешно применены")
        else:
            logger.warning("При применении оптимизаций возникли ошибки")
            
        for result in results:
            logger.info(result)
            
    elif args.command == 'stats':
        show_stats()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()