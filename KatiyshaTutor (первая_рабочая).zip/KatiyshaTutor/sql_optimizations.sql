-- Оптимизации индексов для масштабирования до 100,000+ пользователей

-- Индексы для таблицы users
CREATE INDEX IF NOT EXISTS idx_users_referrer_id ON users(referrer_id);
CREATE INDEX IF NOT EXISTS idx_users_subscription_expiry ON users(subscription_expiry);
CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at);

-- Индексы для таблицы transactions
CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(type);
CREATE INDEX IF NOT EXISTS idx_transactions_status ON transactions(status);
CREATE INDEX IF NOT EXISTS idx_transactions_created_at ON transactions(created_at);
CREATE INDEX IF NOT EXISTS idx_transactions_user_id_type ON transactions(user_id, type);
CREATE INDEX IF NOT EXISTS idx_transactions_user_id_status ON transactions(user_id, status);
CREATE INDEX IF NOT EXISTS idx_transactions_related_user_id ON transactions(related_user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_payout_id ON transactions(payout_id);

-- Индексы для таблицы weekly_payouts
CREATE INDEX IF NOT EXISTS idx_weekly_payouts_status ON weekly_payouts(status);
CREATE INDEX IF NOT EXISTS idx_weekly_payouts_created_at ON weekly_payouts(created_at);

-- Индексы для таблицы batch_payouts
CREATE INDEX IF NOT EXISTS idx_batch_payouts_status ON batch_payouts(status);
CREATE INDEX IF NOT EXISTS idx_batch_payouts_weekly_payout_id ON batch_payouts(weekly_payout_id);

-- Индексы для таблицы admin_action_logs
CREATE INDEX IF NOT EXISTS idx_admin_action_logs_admin_id ON admin_action_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_admin_action_logs_action_type ON admin_action_logs(action_type);
CREATE INDEX IF NOT EXISTS idx_admin_action_logs_timestamp ON admin_action_logs(timestamp);

-- Индексы для таблицы math_problems
CREATE INDEX IF NOT EXISTS idx_math_problems_user_id ON math_problems(user_id);
CREATE INDEX IF NOT EXISTS idx_math_problems_created_at ON math_problems(created_at);

-- Индексы для антифрод-системы
CREATE INDEX IF NOT EXISTS idx_fraud_detection_logs_user_id ON fraud_detection_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_fraud_detection_logs_rule_type ON fraud_detection_logs(rule_type);
CREATE INDEX IF NOT EXISTS idx_fraud_detection_logs_risk_level ON fraud_detection_logs(risk_level);
CREATE INDEX IF NOT EXISTS idx_fraud_detection_logs_created_at ON fraud_detection_logs(created_at);

-- Индексы для таблицы referral_networks
CREATE INDEX IF NOT EXISTS idx_referral_networks_user_id ON referral_networks(user_id);
CREATE INDEX IF NOT EXISTS idx_referral_networks_risk_level ON referral_networks(risk_level);
CREATE INDEX IF NOT EXISTS idx_referral_networks_analyzed_at ON referral_networks(analyzed_at);

-- Индексы для таблицы payout_operation_logs
CREATE INDEX IF NOT EXISTS idx_payout_operation_logs_payout_id ON payout_operation_logs(payout_id);
CREATE INDEX IF NOT EXISTS idx_payout_operation_logs_batch_id ON payout_operation_logs(batch_id);
CREATE INDEX IF NOT EXISTS idx_payout_operation_logs_created_at ON payout_operation_logs(created_at);