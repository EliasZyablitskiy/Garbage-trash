#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для создания таблицы accumulated_rewards
"""

import os
import sys
import logging

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def run_migration():
    """Выполнение миграции"""
    try:
        # Получаем Flask приложение и создаем контекст
        from db_config import get_flask_app
        
        app = get_flask_app()
        with app.app_context():
            from db_models import db, AccumulatedReward
            
            # Создаем инспектор для проверки структуры базы данных
            inspector = db.inspect(db.engine)
            
            # Проверка наличия таблицы
            if 'accumulated_rewards' not in inspector.get_table_names():
                logger.info("Создаем таблицу accumulated_rewards")
                db.create_all()
                logger.info("Таблица accumulated_rewards успешно создана")
            else:
                logger.info("Таблица accumulated_rewards уже существует")
                
            logger.info("Миграция успешно завершена")
            return True
            
    except Exception as e:
        logger.error(f"Ошибка при выполнении миграции: {e}")
        return False

if __name__ == "__main__":
    if run_migration():
        logger.info("Миграция успешно выполнена")
    else:
        logger.error("Ошибка при выполнении миграции")
        sys.exit(1)