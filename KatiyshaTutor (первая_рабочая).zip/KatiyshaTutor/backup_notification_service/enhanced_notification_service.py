#!/usr/bin/env python
# coding: utf-8

"""
Расширенный сервис для отправки уведомлений пользователям
"""

import os
import logging
import datetime
from typing import Dict, List, Any, Optional, Tuple, Union, Set

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func, or_, and_, desc, asc, text
from telegram import Bot

import config
from db_models import User, Transaction, WeeklyPayout

# Импортируем NotificationType из основного сервиса
from services.notification_service import NotificationType, get_notification_manager, NotificationManager

logger = logging.getLogger(__name__)

class EnhancedNotificationService:
    """Расширенный сервис для отправки уведомлений пользователям"""
    
    def __init__(self, bot: Bot):
        """
        Инициализация сервиса
        
        Args:
            bot: Экземпляр бота Telegram
        """
        self.bot = bot
        # Получаем базовый менеджер уведомлений для совместимости
        self.notification_manager = get_notification_manager()
    
    async def send_notification(self, 
                              user_id: int, 
                              notification_type: str, 
                              context: Dict[str, Any] = None) -> bool:
        """
        Отправка уведомления пользователю
        
        Args:
            user_id: ID пользователя в Telegram
            notification_type: Тип уведомления
            context: Дополнительные данные для уведомления
            
        Returns:
            bool: True в случае успеха, False в случае ошибки
        """
        try:
            if not context:
                context = {}
            
            message = self._format_notification(notification_type, context)
            
            if not message:
                logger.warning(f"Unknown notification type: {notification_type}")
                return False
            
            # Добавляем задержку, чтобы не превысить лимиты Telegram API
            await self.bot.send_message(
                chat_id=user_id,
                text=message,
                parse_mode="Markdown"
            )
            
            logger.info(f"Notification sent to user {user_id}, type: {notification_type}")
            return True
        except Exception as e:
            logger.error(f"Error sending notification to user {user_id}: {e}")
            return False
    
    def _format_notification(self, notification_type: str, context: Dict[str, Any]) -> str:
        """
        Форматирование текста уведомления на основе типа и контекста
        
        Args:
            notification_type: Тип уведомления
            context: Дополнительные данные для уведомления
            
        Returns:
            str: Текст уведомления или пустая строка, если тип неизвестен
        """
        if notification_type == NotificationType.PAYMENT_PENDING:
            return (
                "💳 *Ожидается оплата подписки*\n\n"
                "Мы создали запрос на оплату подписки. "
                "Вы можете завершить процесс оплаты в любое удобное время.\n\n"
                f"Сумма: *{context.get('amount', 199)}₽*\n"
                f"Срок действия: *{context.get('duration', 30)} дней*\n\n"
                "Для завершения оплаты используйте команду /activate_subscription"
            )
        
        elif notification_type == NotificationType.PAYMENT_SUCCESSFUL:
            return (
                "✅ *Оплата прошла успешно!*\n\n"
                "Спасибо за оплату подписки на бота Катюша!\n\n"
                f"Ваша подписка активна до: *{context.get('expiry_date', 'N/A')}*\n\n"
                "Теперь у вас есть неограниченный доступ к решению "
                "математических задач. Просто отправьте боту вашу задачу "
                "текстом, фотографией или голосовым сообщением."
            )
        
        elif notification_type == NotificationType.PAYMENT_FAILED:
            return (
                "❌ *Ошибка оплаты*\n\n"
                "К сожалению, произошла ошибка при обработке вашего платежа.\n\n"
                f"Причина: *{context.get('reason', 'Неизвестная ошибка')}*\n\n"
                "Пожалуйста, попробуйте оплатить подписку еще раз, используя "
                "команду /subscribe, или свяжитесь с нами для получения помощи."
            )
        
        elif notification_type == NotificationType.SUBSCRIPTION_EXPIRING:
            return (
                "⏳ *Срок действия подписки истекает*\n\n"
                f"Ваша подписка истекает *{context.get('expiry_date', 'скоро')}*.\n\n"
                "Чтобы продолжить пользоваться ботом Катюша без ограничений, "
                "пожалуйста, продлите подписку, используя команду /subscribe."
            )
        
        elif notification_type == NotificationType.SUBSCRIPTION_EXPIRED:
            return (
                "⌛ *Подписка истекла*\n\n"
                "Срок действия вашей подписки истек.\n\n"
                "Чтобы продолжить пользоваться ботом Катюша, пожалуйста, "
                "приобретите новую подписку, используя команду /subscribe."
            )
        
        elif notification_type == NotificationType.REFERRAL_REWARD:
            return (
                "💰 *Получено реферальное вознаграждение!*\n\n"
                f"Вы получили *{context.get('amount', 0)}₽* реферального вознаграждения!\n\n"
                f"Уровень реферала: *{context.get('level', 1)}*\n"
                f"Процент вознаграждения: *{context.get('percent', '5%')}*\n\n"
                "Спасибо за участие в реферальной программе Катюши! "
                "Продолжайте приглашать друзей, чтобы зарабатывать больше.\n\n"
                "Используйте команду /rewards, чтобы узнать о всех ваших вознаграждениях."
            )
        
        elif notification_type == NotificationType.PAYOUT_AVAILABLE:
            return (
                "💸 *Доступна выплата реферального вознаграждения*\n\n"
                f"У вас есть *{context.get('amount', 0)}₽* доступных для выплаты.\n\n"
                "Минимальная сумма для выплаты составляет 1000₽.\n\n"
                "Чтобы запросить выплату, используйте команду /rewards и "
                "выберите опцию 'Запросить выплату'."
            )
        
        elif notification_type == NotificationType.PAYOUT_PROCESSING:
            return (
                "⏳ *Ваша выплата в обработке*\n\n"
                f"Сумма: *{context.get('amount', 0)}₽*\n"
                f"ID выплаты: `{context.get('payout_id', 'N/A')}`\n\n"
                "Мы обрабатываем вашу выплату. Это может занять до 3 рабочих дней.\n"
                "Мы уведомим вас, когда выплата будет завершена."
            )
        
        elif notification_type == NotificationType.PAYOUT_COMPLETED:
            return (
                "✅ *Выплата успешно завершена*\n\n"
                f"Сумма: *{context.get('amount', 0)}₽*\n"
                f"ID выплаты: `{context.get('payout_id', 'N/A')}`\n"
                f"Дата: *{context.get('date', 'Сегодня')}*\n\n"
                "Благодарим вас за участие в реферальной программе Катюши!"
            )
        
        elif notification_type == NotificationType.PAYOUT_FAILED:
            return (
                "❌ *Ошибка при обработке выплаты*\n\n"
                f"Сумма: *{context.get('amount', 0)}₽*\n"
                f"ID выплаты: `{context.get('payout_id', 'N/A')}`\n"
                f"Причина: *{context.get('reason', 'Неизвестная ошибка')}*\n\n"
                "Пожалуйста, проверьте ваши платежные реквизиты и попробуйте запросить "
                "выплату снова. Если проблема сохраняется, пожалуйста, свяжитесь с нами."
            )
        
        elif notification_type == NotificationType.SYSTEM:
            return context.get('message', 'Системное уведомление')
        
        # Если тип не определен, пробуем использовать базовый менеджер уведомлений
        return ""
    
    async def notify_users_about_available_payouts(self, session: AsyncSession) -> int:
        """
        Уведомление пользователей о доступных выплатах
        
        Args:
            session: Активная сессия базы данных
            
        Returns:
            int: Количество отправленных уведомлений
        """
        # Получаем пользователей с балансом выше минимального порога выплаты
        stmt = select(User).where(
            User.referral_balance >= config.MIN_PAYOUT_AMOUNT
        )
        users_result = await session.execute(stmt)
        users = users_result.scalars().all()
        
        # Проверяем, когда последний раз отправлялись уведомления
        current_time = datetime.datetime.now()
        notification_count = 0
        
        for user in users:
            # Проверяем, было ли уведомление в течение последних 7 дней
            should_notify = True
            
            if user.last_payout_notification:
                days_since_notification = (current_time - user.last_payout_notification).days
                if days_since_notification < 7:
                    should_notify = False
            
            if should_notify:
                # Отправляем уведомление
                notification_sent = await self.send_notification(
                    user_id=user.id,
                    notification_type=NotificationType.PAYOUT_AVAILABLE,
                    context={
                        'amount': user.referral_balance
                    }
                )
                
                if notification_sent:
                    # Обновляем время последнего уведомления
                    user.last_payout_notification = current_time
                    notification_count += 1
        
        # Сохраняем изменения в базе данных
        await session.commit()
        
        logger.info(f"Sent {notification_count} payout availability notifications")
        return notification_count
    
    async def notify_users_about_expiring_subscriptions(self, session: AsyncSession, days_threshold: int = 3) -> int:
        """
        Уведомление пользователей об истекающих подписках
        
        Args:
            session: Активная сессия базы данных
            days_threshold: За сколько дней до истечения отправлять уведомление
            
        Returns:
            int: Количество отправленных уведомлений
        """
        # Текущая дата
        current_date = datetime.datetime.now().date()
        
        # Дата истечения для проверки
        expiry_date = current_date + datetime.timedelta(days=days_threshold)
        
        # Получаем пользователей с истекающими подписками
        stmt = select(User).where(
            and_(
                # Подписка активна
                User.is_subscribed == True,
                # Подписка истекает через days_threshold дней
                func.date(User.subscription_expiry) == expiry_date,
                # Не было отправлено уведомление (или отправлено более 24 часов назад)
                or_(
                    User.last_subscription_notification.is_(None),
                    User.last_subscription_notification < datetime.datetime.now() - datetime.timedelta(hours=24)
                )
            )
        )
        users_result = await session.execute(stmt)
        users = users_result.scalars().all()
        
        notification_count = 0
        
        for user in users:
            # Форматируем дату истечения для уведомления
            expiry_date_str = user.subscription_expiry.strftime("%d.%m.%Y")
            
            # Отправляем уведомление
            notification_sent = await self.send_notification(
                user_id=user.id,
                notification_type=NotificationType.SUBSCRIPTION_EXPIRING,
                context={
                    'expiry_date': expiry_date_str
                }
            )
            
            if notification_sent:
                # Обновляем время последнего уведомления
                user.last_subscription_notification = datetime.datetime.now()
                notification_count += 1
        
        # Сохраняем изменения в базе данных
        await session.commit()
        
        logger.info(f"Sent {notification_count} subscription expiry notifications")
        return notification_count

# Глобальный экземпляр сервиса для удобства использования
_enhanced_notification_service = None

def get_enhanced_notification_service(bot: Bot = None) -> EnhancedNotificationService:
    """
    Получение экземпляра расширенного сервиса уведомлений
    
    Args:
        bot: Экземпляр бота Telegram
        
    Returns:
        EnhancedNotificationService: Экземпляр сервиса
    """
    global _enhanced_notification_service
    if _enhanced_notification_service is None and bot is not None:
        _enhanced_notification_service = EnhancedNotificationService(bot)
    return _enhanced_notification_service