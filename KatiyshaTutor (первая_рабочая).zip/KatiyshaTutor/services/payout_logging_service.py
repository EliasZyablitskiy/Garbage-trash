#!/usr/bin/env python
# coding: utf-8

"""
Сервис для логирования операций с выплатами
"""

import time
import logging
import functools
import traceback
from typing import Dict, Any, Optional, Callable, TypeVar, cast

from db_config import db
from db_models import PayoutOperationLog

# Настройка логирования
logger = logging.getLogger(__name__)

# Типы для аннотаций
T = TypeVar('T')
AsyncFunc = Callable[..., T]


async def log_payout_operation(
    operation_type: str,
    payout_id: Optional[int] = None,
    batch_id: Optional[int] = None,
    transaction_id: Optional[int] = None,
    request_data: Optional[Dict[str, Any]] = None,
    response_data: Optional[Dict[str, Any]] = None,
    status: str = "success",
    error_message: Optional[str] = None,
    retry_count: int = 0,
    execution_time_ms: Optional[int] = None,
    ip_address: Optional[str] = None
) -> int:
    """
    Логирование операции с выплатами в базу данных
    
    Args:
        operation_type: Тип операции
        payout_id: ID выплаты (опционально)
        batch_id: ID пакетной выплаты (опционально)
        transaction_id: ID транзакции (опционально)
        request_data: Данные запроса (опционально)
        response_data: Данные ответа (опционально)
        status: Статус операции (success, failed, retry)
        error_message: Сообщение об ошибке (опционально)
        retry_count: Счетчик повторных попыток
        execution_time_ms: Время выполнения в мс (опционально)
        ip_address: IP-адрес запроса (опционально)
        
    Returns:
        int: ID записи лога
    """
    try:
        # Импортируем Flask app для контекста
        import app as app_module
        
        # Используем контекст приложения для работы с базой данных
        async with app_module.app.app_context():
            log_entry = PayoutOperationLog(
                operation_type=operation_type,
                payout_id=payout_id,
                batch_id=batch_id,
                transaction_id=transaction_id,
                request_data=request_data,
                response_data=response_data,
                status=status,
                error_message=error_message,
                retry_count=retry_count,
                execution_time_ms=execution_time_ms,
                ip_address=ip_address
            )
            
            db.session.add(log_entry)
            await db.session.commit()
            
            logger.info(f"Payout operation logged: {operation_type}, status={status}, id={log_entry.id}")
            return log_entry.id
    except Exception as e:
        logger.error(f"Failed to log payout operation: {e}")
        try:
            await db.session.rollback()
        except Exception:
            pass
        # В случае ошибки логирования не прерываем работу, возвращаем 0
        return 0


def log_payout_operation_decorator(operation_type: str):
    """
    Декоратор для автоматического логирования операций с выплатами
    
    Args:
        operation_type: Тип операции
        
    Returns:
        Decorator: Декоратор для функции
    """
    def decorator(func: AsyncFunc[T]) -> AsyncFunc[T]:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs) -> T:
            # Извлекаем параметры для логирования
            payout_id = kwargs.get('payout_id')
            if payout_id is None and len(args) > 0:
                # Проверяем, есть ли payout_id в аргументах позиционно
                if operation_type in ["update_payout_status", "process_payout", "process_payout_by_tiers"]:
                    payout_id = args[0]
                    
            batch_id = kwargs.get('batch_id')
            transaction_id = kwargs.get('transaction_id')
            request_data = {
                'args': [arg for arg in args if isinstance(arg, (int, float, str, bool, dict, list))],
                'kwargs': {k: v for k, v in kwargs.items() if isinstance(v, (int, float, str, bool, dict, list))}
            }
            
            # Безопасно удаляем конфиденциальные данные
            if 'token' in request_data['kwargs']:
                request_data['kwargs']['token'] = '***'
            if 'api_key' in request_data['kwargs']:
                request_data['kwargs']['api_key'] = '***'
                
            start_time = time.time()
            status = "success"
            error_message = None
            response_data = None
            retry_count = kwargs.get('retry_count', 0)
            
            try:
                # Выполняем оригинальную функцию
                result = await func(*args, **kwargs)
                
                # Сохраняем результат для логирования
                if isinstance(result, dict):
                    response_data = result
                elif hasattr(result, 'to_dict'):
                    response_data = result.to_dict()
                else:
                    response_data = {'result': str(result)}
                    
                return result
            except Exception as e:
                status = "failed"
                error_message = f"{str(e)}\n{traceback.format_exc()}"
                logger.error(f"Error in {func.__name__}: {e}")
                raise
            finally:
                # Вычисляем время выполнения
                execution_time_ms = int((time.time() - start_time) * 1000)
                
                # Логируем операцию
                await log_payout_operation(
                    operation_type=operation_type,
                    payout_id=payout_id,
                    batch_id=batch_id,
                    transaction_id=transaction_id,
                    request_data=request_data,
                    response_data=response_data,
                    status=status,
                    error_message=error_message,
                    retry_count=retry_count,
                    execution_time_ms=execution_time_ms
                )
        
        return cast(AsyncFunc[T], wrapper)
    
    return decorator


async def get_operation_logs(
    operation_type: Optional[str] = None,
    payout_id: Optional[int] = None,
    batch_id: Optional[int] = None,
    transaction_id: Optional[int] = None,
    status: Optional[str] = None,
    limit: int = 100,
    offset: int = 0
) -> Dict[str, Any]:
    """
    Получение логов операций с фильтрацией
    
    Args:
        operation_type: Тип операции (опционально)
        payout_id: ID выплаты (опционально)
        batch_id: ID пакетной выплаты (опционально)
        transaction_id: ID транзакции (опционально)
        status: Статус операции (опционально)
        limit: Максимальное количество записей
        offset: Смещение для пагинации
        
    Returns:
        Dict: Список логов и общее количество
    """
    try:
        # Строим базовый запрос
        query = db.select(PayoutOperationLog)
        count_query = db.select(db.func.count(PayoutOperationLog.id))
        
        # Применяем фильтры
        if operation_type:
            query = query.filter(PayoutOperationLog.operation_type == operation_type)
            count_query = count_query.filter(PayoutOperationLog.operation_type == operation_type)
            
        if payout_id is not None:
            query = query.filter(PayoutOperationLog.payout_id == payout_id)
            count_query = count_query.filter(PayoutOperationLog.payout_id == payout_id)
            
        if batch_id is not None:
            query = query.filter(PayoutOperationLog.batch_id == batch_id)
            count_query = count_query.filter(PayoutOperationLog.batch_id == batch_id)
            
        if transaction_id is not None:
            query = query.filter(PayoutOperationLog.transaction_id == transaction_id)
            count_query = count_query.filter(PayoutOperationLog.transaction_id == transaction_id)
            
        if status:
            query = query.filter(PayoutOperationLog.status == status)
            count_query = count_query.filter(PayoutOperationLog.status == status)
        
        # Добавляем сортировку и пагинацию
        query = query.order_by(PayoutOperationLog.created_at.desc())
        query = query.limit(limit).offset(offset)
        
        # Выполняем запросы
        logs_result = await db.session.execute(query)
        count_result = await db.session.execute(count_query)
        
        logs = logs_result.scalars().all()
        total_count = count_result.scalar() or 0
        
        # Форматируем результат
        result = {
            "logs": [log.to_dict() for log in logs],
            "total": total_count,
            "limit": limit,
            "offset": offset
        }
        
        return result
    except Exception as e:
        logger.error(f"Error getting operation logs: {e}")
        return {
            "logs": [],
            "total": 0,
            "limit": limit,
            "offset": offset,
            "error": str(e)
        }