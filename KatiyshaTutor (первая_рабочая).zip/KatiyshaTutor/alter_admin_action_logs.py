#!/usr/bin/env python
# coding: utf-8

"""
Script to alter admin_action_logs table to add columns for enhanced logging
"""

import os
import sys
from sqlalchemy import create_engine, text

def alter_admin_action_logs_table():
    """Add columns to admin_action_logs table for enhanced security"""
    try:
        # Получаем URL базы данных из переменной окружения
        DATABASE_URL = os.environ.get('DATABASE_URL')
        if not DATABASE_URL:
            print("Error: DATABASE_URL environment variable is not set.")
            sys.exit(1)

        # Создаем соединение с базой данных
        engine = create_engine(DATABASE_URL)
        
        # Проверяем существует ли таблица admin_action_logs
        with engine.connect() as connection:
            result = connection.execute(text("SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'admin_action_logs')"))
            table_exists = result.scalar()
            
            if not table_exists:
                print("Error: admin_action_logs table does not exist.")
                return
            
            # Проверяем существует ли колонка admin_user_id
            result = connection.execute(text(
                "SELECT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'admin_action_logs' AND column_name = 'admin_user_id')"
            ))
            admin_user_id_exists = result.scalar()
            
            # Проверяем существует ли колонка is_verified
            result = connection.execute(text(
                "SELECT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'admin_action_logs' AND column_name = 'is_verified')"
            ))
            is_verified_exists = result.scalar()
            
            # Проверяем существует ли колонка verification_hash
            result = connection.execute(text(
                "SELECT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'admin_action_logs' AND column_name = 'verification_hash')"
            ))
            verification_hash_exists = result.scalar()
            
            # Добавляем колонки, если их нет
            if not admin_user_id_exists:
                connection.execute(text("ALTER TABLE admin_action_logs ADD COLUMN admin_user_id INTEGER"))
                print("Added column admin_user_id to admin_action_logs")
                
                # Добавляем foreign key constraint
                connection.execute(text("""
                    ALTER TABLE admin_action_logs
                    ADD CONSTRAINT admin_action_logs_admin_user_id_fkey 
                    FOREIGN KEY (admin_user_id) REFERENCES admin_users(id)
                """))
                print("Added foreign key constraint for admin_user_id")
            
            if not is_verified_exists:
                connection.execute(text("ALTER TABLE admin_action_logs ADD COLUMN is_verified BOOLEAN DEFAULT FALSE"))
                print("Added column is_verified to admin_action_logs")
            
            if not verification_hash_exists:
                connection.execute(text("ALTER TABLE admin_action_logs ADD COLUMN verification_hash VARCHAR(64)"))
                print("Added column verification_hash to admin_action_logs")
            
            if admin_user_id_exists and is_verified_exists and verification_hash_exists:
                print("All required columns already exist in admin_action_logs table.")
    
    except Exception as e:
        print(f"Error altering admin_action_logs table: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    alter_admin_action_logs_table()