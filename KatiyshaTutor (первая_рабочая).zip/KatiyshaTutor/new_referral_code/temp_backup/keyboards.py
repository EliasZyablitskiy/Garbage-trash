#!/usr/bin/env python
# coding: utf-8

"""
Keyboard layouts for the Katiysha bot
"""

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton

def get_main_keyboard():
    """Return the main menu keyboard."""
    keyboard = [
        [KeyboardButton("🧮 Решить задачу")],
        [KeyboardButton("💳 Купить подписку (199₽/месяц)")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_problem_keyboard():
    """Return keyboard for confirming problem solving."""
    keyboard = [
        [
            InlineKeyboardButton("✅ Да, решить", callback_data="confirm_solve"),
            InlineKeyboardButton("❌ Нет, отмена", callback_data="cancel_solve")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)
