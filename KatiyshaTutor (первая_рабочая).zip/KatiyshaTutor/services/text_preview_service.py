#!/usr/bin/env python
# coding: utf-8

"""
Сервис предварительного просмотра и редактирования распознанного текста
Позволяет пользователям просматривать и корректировать текст перед обработкой
"""

import logging
import asyncio
from typing import Dict, Optional, Callable, Any, Awaitable, Tuple
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes, CallbackContext

# Настройка логирования
logger = logging.getLogger(__name__)

# Словарь для хранения состояний ожидания редактирования
_edit_states: Dict[int, Dict[str, Any]] = {}

# Префиксы для callback данных
EDIT_PREFIX = "edit_text_"
CONFIRM_PREFIX = "confirm_text_"
CANCEL_PREFIX = "cancel_text_"

async def send_text_preview(
    update: Update,
    context: CallbackContext,
    text: str,
    operation_type: str,
    on_confirm: Callable[[Update, CallbackContext, str], Awaitable[Any]],
    on_cancel: Optional[Callable[[Update, CallbackContext], Awaitable[Any]]] = None,
    timeout: int = 300  # 5 минут на редактирование
) -> Tuple[int, str]:
    """
    Отправляет сообщение с предварительным просмотром распознанного текста и
    предлагает пользователю отредактировать его перед обработкой
    
    Args:
        update: Telegram Update
        context: Telegram CallbackContext
        text: Распознанный текст
        operation_type: Тип операции (например, "ocr", "speech")
        on_confirm: Функция, которая будет вызвана при подтверждении (с обновленным текстом)
        on_cancel: Функция, которая будет вызвана при отмене
        timeout: Время ожидания в секундах
        
    Returns:
        Tuple[int, str]: Кортеж (ID сообщения, ID операции)
    """
    try:
        chat_id = update.effective_chat.id
        user_id = update.effective_user.id
        
        # Генерируем уникальный ID для этой операции
        operation_id = f"{operation_type}_{user_id}_{chat_id}_{id(text)}"
        
        # Готовим клавиатуру
        keyboard = [
            [
                InlineKeyboardButton("✏️ Редактировать", callback_data=f"{EDIT_PREFIX}{operation_id}"),
                InlineKeyboardButton("✅ Подтвердить", callback_data=f"{CONFIRM_PREFIX}{operation_id}")
            ],
            [
                InlineKeyboardButton("❌ Отменить", callback_data=f"{CANCEL_PREFIX}{operation_id}")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Определяем заголовок в зависимости от типа операции
        title = "📝 Распознанный текст"
        if operation_type == "ocr":
            title = "🔍 Текст с изображения"
        elif operation_type == "speech":
            title = "🎤 Распознанная речь"
        
        # Отправляем сообщение с предпросмотром
        message_text = f"{title}:\n\n```\n{text[:3800]}```\n\nВы можете отредактировать текст перед обработкой."
        if len(text) > 3800:
            message_text += "\n(Текст был сокращен из-за ограничений Telegram. При редактировании будет доступен полный текст.)"
            
        message = await context.bot.send_message(
            chat_id=chat_id,
            text=message_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
        # Сохраняем состояние
        _edit_states[user_id] = {
            'operation_id': operation_id,
            'message_id': message.message_id,
            'chat_id': chat_id,
            'text': text,
            'operation_type': operation_type,
            'on_confirm': on_confirm,
            'on_cancel': on_cancel,
            'timeout': timeout,
            'expire_at': asyncio.get_event_loop().time() + timeout
        }
        
        # Запускаем таймер для автоматической отмены
        asyncio.create_task(_handle_timeout(user_id, operation_id, context))
        
        logger.debug(f"Sent text preview for operation {operation_id}")
        return message.message_id, operation_id
    except Exception as e:
        logger.error(f"Error sending text preview: {e}")
        # Вызываем on_confirm с исходным текстом, чтобы продолжить работу
        await on_confirm(update, context, text)
        return 0, ""

async def handle_edit_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для кнопки 'Редактировать'
    
    Args:
        update: Telegram Update
        context: Telegram ContextTypes.DEFAULT_TYPE
    """
    try:
        callback_query = update.callback_query
        await callback_query.answer()
        
        user_id = update.effective_user.id
        operation_id = callback_query.data[len(EDIT_PREFIX):]
        
        # Проверяем, что пользователь имеет активное состояние
        if user_id not in _edit_states or _edit_states[user_id]['operation_id'] != operation_id:
            await callback_query.message.reply_text("⚠️ Время редактирования истекло или операция отменена.")
            return
            
        state = _edit_states[user_id]
        
        # Отправляем инструкции по редактированию
        instructions_message = await context.bot.send_message(
            chat_id=state['chat_id'],
            text="📝 *Отправьте исправленный текст в новом сообщении.*\n\nИли нажмите 'Отмена' для отмены редактирования.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("❌ Отмена", callback_data=f"{CANCEL_PREFIX}{operation_id}")]
            ]),
            parse_mode='Markdown'
        )
        
        # Обновляем состояние, чтобы включить ожидание ввода текста
        state['awaiting_edit'] = True
        state['instructions_message_id'] = instructions_message.message_id
        
        logger.debug(f"Edit mode activated for operation {operation_id}")
    except Exception as e:
        logger.error(f"Error handling edit callback: {e}")
        await update.callback_query.message.reply_text("⚠️ Произошла ошибка. Пожалуйста, повторите попытку.")

async def handle_confirm_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для кнопки 'Подтвердить'
    
    Args:
        update: Telegram Update
        context: Telegram ContextTypes.DEFAULT_TYPE
    """
    try:
        callback_query = update.callback_query
        await callback_query.answer()
        
        user_id = update.effective_user.id
        operation_id = callback_query.data[len(CONFIRM_PREFIX):]
        
        # Проверяем, что пользователь имеет активное состояние
        if user_id not in _edit_states or _edit_states[user_id]['operation_id'] != operation_id:
            await callback_query.message.reply_text("⚠️ Время редактирования истекло или операция отменена.")
            return
            
        state = _edit_states[user_id]
        
        # Вызываем функцию обратного вызова с текущим текстом
        if state['on_confirm']:
            on_confirm_func = state['on_confirm']
            text = state['text']
            
            # Удаляем состояние перед вызовом колбэка
            del _edit_states[user_id]
            
            # Обновляем сообщение, убирая кнопки
            await _update_preview_message_without_keyboard(
                context.bot,
                state['chat_id'],
                state['message_id'],
                text,
                state['operation_type'],
                "✅ Подтверждено"
            )
            
            # Вызываем колбэк
            await on_confirm_func(update, context, text)
        
        logger.debug(f"Text confirmed for operation {operation_id}")
    except Exception as e:
        logger.error(f"Error handling confirm callback: {e}")
        await update.callback_query.message.reply_text("⚠️ Произошла ошибка. Пожалуйста, повторите попытку.")

async def handle_cancel_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для кнопки 'Отменить'
    
    Args:
        update: Telegram Update
        context: Telegram ContextTypes.DEFAULT_TYPE
    """
    try:
        callback_query = update.callback_query
        await callback_query.answer()
        
        user_id = update.effective_user.id
        operation_id = callback_query.data[len(CANCEL_PREFIX):]
        
        # Проверяем, что пользователь имеет активное состояние
        if user_id not in _edit_states or _edit_states[user_id]['operation_id'] != operation_id:
            await callback_query.message.reply_text("⚠️ Время редактирования истекло или операция уже отменена.")
            return
            
        state = _edit_states[user_id]
        
        # Обновляем сообщение, убирая кнопки
        await _update_preview_message_without_keyboard(
            context.bot,
            state['chat_id'],
            state['message_id'],
            state['text'],
            state['operation_type'],
            "❌ Отменено"
        )
        
        # Если были инструкции по редактированию, удаляем их
        if 'instructions_message_id' in state:
            try:
                await context.bot.delete_message(
                    chat_id=state['chat_id'],
                    message_id=state['instructions_message_id']
                )
            except Exception:
                pass
        
        # Вызываем функцию отмены, если она есть
        if state['on_cancel']:
            on_cancel_func = state['on_cancel']
            
            # Удаляем состояние перед вызовом колбэка
            del _edit_states[user_id]
            
            # Вызываем колбэк
            await on_cancel_func(update, context)
        else:
            # Просто удаляем состояние
            del _edit_states[user_id]
            
            # Отправляем сообщение об отмене
            await callback_query.message.reply_text("❌ Операция отменена.")
        
        logger.debug(f"Operation {operation_id} cancelled")
    except Exception as e:
        logger.error(f"Error handling cancel callback: {e}")
        await update.callback_query.message.reply_text("⚠️ Произошла ошибка. Пожалуйста, повторите попытку.")

async def handle_edited_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """
    Обрабатывает отредактированный пользователем текст
    
    Args:
        update: Telegram Update
        context: Telegram ContextTypes.DEFAULT_TYPE
        
    Returns:
        bool: True если сообщение обработано как отредактированный текст, False в противном случае
    """
    try:
        user_id = update.effective_user.id
        
        # Проверяем, ожидается ли ввод текста от пользователя
        if user_id not in _edit_states or not _edit_states[user_id].get('awaiting_edit', False):
            return False
            
        state = _edit_states[user_id]
        
        # Получаем отредактированный текст
        new_text = update.message.text
        if not new_text:
            await update.message.reply_text("⚠️ Текст не может быть пустым. Пожалуйста, отправьте корректный текст.")
            return True
        
        # Обновляем текст в состоянии
        state['text'] = new_text
        state['awaiting_edit'] = False
        
        # Обновляем предпросмотр с новым текстом
        operation_type = state['operation_type']
        
        # Определяем заголовок в зависимости от типа операции
        title = "📝 Отредактированный текст"
        if operation_type == "ocr":
            title = "🔍 Отредактированный текст с изображения"
        elif operation_type == "speech":
            title = "🎤 Отредактированная речь"
        
        message_text = f"{title}:\n\n```\n{new_text[:3800]}```\n\nВы можете подтвердить текст или отредактировать его снова."
        if len(new_text) > 3800:
            message_text += "\n(Текст был сокращен из-за ограничений Telegram. При редактировании будет доступен полный текст.)"
        
        # Обновляем сообщение с предпросмотром
        await context.bot.edit_message_text(
            chat_id=state['chat_id'],
            message_id=state['message_id'],
            text=message_text,
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("✏️ Редактировать снова", callback_data=f"{EDIT_PREFIX}{state['operation_id']}"),
                    InlineKeyboardButton("✅ Подтвердить", callback_data=f"{CONFIRM_PREFIX}{state['operation_id']}")
                ],
                [
                    InlineKeyboardButton("❌ Отменить", callback_data=f"{CANCEL_PREFIX}{state['operation_id']}")
                ]
            ]),
            parse_mode='Markdown'
        )
        
        # Если были инструкции по редактированию, удаляем их
        if 'instructions_message_id' in state:
            try:
                await context.bot.delete_message(
                    chat_id=state['chat_id'],
                    message_id=state['instructions_message_id']
                )
                del state['instructions_message_id']
            except Exception:
                pass
        
        logger.debug(f"Text edited for operation {state['operation_id']}")
        return True
    except Exception as e:
        logger.error(f"Error handling edited text: {e}")
        return False

async def _handle_timeout(user_id: int, operation_id: str, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обрабатывает истечение времени ожидания редактирования
    
    Args:
        user_id: ID пользователя
        operation_id: ID операции
        context: Telegram ContextTypes.DEFAULT_TYPE
    """
    try:
        # Ждем указанное время
        await asyncio.sleep(1)  # Небольшая задержка для избежания гонки условий
        
        while user_id in _edit_states and _edit_states[user_id]['operation_id'] == operation_id:
            state = _edit_states[user_id]
            
            # Проверяем, не истекло ли время
            current_time = asyncio.get_event_loop().time()
            if current_time >= state['expire_at']:
                # Время истекло, отменяем операцию
                logger.debug(f"Timeout for operation {operation_id}")
                
                # Обновляем сообщение, убирая кнопки
                await _update_preview_message_without_keyboard(
                    context.bot,
                    state['chat_id'],
                    state['message_id'],
                    state['text'],
                    state['operation_type'],
                    "⏰ Время истекло"
                )
                
                # Отправляем уведомление
                await context.bot.send_message(
                    chat_id=state['chat_id'],
                    text="⏰ Время редактирования истекло. Операция будет продолжена с исходным текстом."
                )
                
                # Вызываем колбэк подтверждения с исходным текстом
                if state['on_confirm']:
                    await state['on_confirm'](None, context, state['text'])
                
                # Удаляем состояние
                del _edit_states[user_id]
                break
                
            # Ждем перед следующей проверкой
            await asyncio.sleep(5)
    except Exception as e:
        logger.error(f"Error in timeout handler: {e}")

async def _update_preview_message_without_keyboard(bot, chat_id: int, message_id: int, text: str, operation_type: str, status: str) -> None:
    """
    Обновляет сообщение предпросмотра, убирая клавиатуру и добавляя статус
    
    Args:
        bot: Telegram Bot
        chat_id: ID чата
        message_id: ID сообщения
        text: Текст
        operation_type: Тип операции
        status: Статус операции
    """
    try:
        # Определяем заголовок в зависимости от типа операции
        title = "📝 Распознанный текст"
        if operation_type == "ocr":
            title = "🔍 Текст с изображения"
        elif operation_type == "speech":
            title = "🎤 Распознанная речь"
        
        message_text = f"{title} ({status}):\n\n```\n{text[:3800]}```"
        if len(text) > 3800:
            message_text += "\n(Текст был сокращен из-за ограничений Telegram.)"
        
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=message_text,
            parse_mode='Markdown',
            reply_markup=None
        )
    except Exception as e:
        logger.warning(f"Error updating preview message: {e}")

# Список обработчиков для регистрации в приложении
def get_text_preview_handlers() -> Dict[str, callable]:
    """
    Возвращает словарь обработчиков для регистрации
    
    Returns:
        Dict[str, callable]: Словарь {callback_data_prefix: handler_function}
    """
    return {
        EDIT_PREFIX: handle_edit_callback,
        CONFIRM_PREFIX: handle_confirm_callback,
        CANCEL_PREFIX: handle_cancel_callback
    }