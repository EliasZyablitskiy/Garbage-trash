#!/usr/bin/env python
# coding: utf-8

"""
Configuration settings for the Katiysha bot
"""

import os
import logging
from enum import Enum

logger = logging.getLogger(__name__)

# Уровни безопасности для системы анти-фрода
class SecurityLevel(Enum):
    DEFAULT = "default"       # Стандартный уровень безопасности
    ENHANCED = "enhanced"     # Повышенный уровень безопасности
    EXTREME = "extreme"       # Экстремальный уровень безопасности

# Роли администраторов
class AdminRole(Enum):
    SUPER_ADMIN = "super_admin"          # Полный доступ ко всем функциям
    FINANCE_ADMIN = "finance_admin"      # Доступ к финансовым функциям
    MONITORING_ADMIN = "monitoring_admin"  # Доступ к мониторингу и отчетам
    SUPPORT_ADMIN = "support_admin"      # Доступ к функциям поддержки пользователей

# Bot Configuration
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "")
BOT_USERNAME = "Katiysha_bot"  # Имя бота без символа @

# ProxyAPI Configuration
PROXYAPI_KEY = os.getenv("PROXYAPI_KEY", "")
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")

# Free Online OCR API
OCR_API_KEY = os.getenv("OCR_API_KEY", "")
OCR_API_URL = "https://api.free-online-ocr.com/v1/parse-image"

# Payment Configuration
PAYMENT_PROVIDER_TOKEN = os.getenv("PAYMENT_PROVIDER_TOKEN", "")
SUBSCRIPTION_PRICE = 19900  # 199 RUB в копейках
SUBSCRIPTION_DURATION_DAYS = 30
SUBSCRIPTION_TITLE = "Ежемесячная подписка Катюша"
SUBSCRIPTION_DESCRIPTION = "Неограниченный доступ к решению математических задач с ботом Катюша"

# Robokassa Configuration
ROBOKASSA_SECRET_KEY = os.getenv("ROBOKASSA_SECRET_KEY", "")  # Секретный ключ для проверки уведомлений от Robokassa
WEBHOOK_HOST = os.getenv("WEBHOOK_HOST", "")  # Домен сервера, на котором размещен бот (для вебхуков)

# Настройка окружения платежей: development, staging, production
PAYMENT_ENVIRONMENT = os.getenv("PAYMENT_ENVIRONMENT", "development")

# Referral Payment System
ROBOKASSA_MERCHANT_LOGIN = "katiysha"  # Логин мерчанта в Robokassa
ROBOKASSA_SECRET_KEY_1 = ROBOKASSA_SECRET_KEY  # Пароль #1 для генерации подписи
ROBOKASSA_PAYMENT_URL = "https://auth.robokassa.ru/Merchant/Index.aspx"
ROBOKASSA_PAYOUT_URL = "https://auth.robokassa.ru/Merchant/Payout"  # URL для выплат через Robokassa

# Автоматическая настройка режима тестирования на основе окружения
if PAYMENT_ENVIRONMENT == "production":
    ROBOKASSA_TEST_MODE = False
    USE_REAL_ROBOKASSA_API = True
    DEBUG = False
elif PAYMENT_ENVIRONMENT == "staging":
    ROBOKASSA_TEST_MODE = True
    USE_REAL_ROBOKASSA_API = True
    DEBUG = True
else:  # development
    ROBOKASSA_TEST_MODE = True
    USE_REAL_ROBOKASSA_API = False
    DEBUG = os.getenv("DEBUG", "true").lower() == "true"  # Режим отладки по умолчанию включен в development

# Параметры выплат по реферальной программе
MIN_PAYOUT_AMOUNT = 1000.0  # Минимальная сумма для выплаты (рублей)
PAYOUT_PROCESSING_BATCH_SIZE = 50  # Максимальное количество одновременных обработок выплат
PAYOUT_PROCESSING_DELAY = 1.0  # Задержка между обработкой выплат (секунды)
PAYOUT_DAY_OF_WEEK = 6  # День недели для еженедельных выплат (0=понедельник, 6=воскресенье)
ENABLE_AUTO_PAYOUTS = False  # Включение автоматических еженедельных выплат (True - включено, False - только вручную)

# Referral Reward Rates
REFERRAL_RATES = {
    "level1": 0.05,  # 5% для первого уровня
    "level2": 0.02,  # 2% для второго уровня
    "level3": 0.02,  # 2% для третьего уровня
    "level4": 0.02,  # 2% для четвертого уровня
}

# Admin IDs - список ID администраторов для доступа к админке
ADMIN_USER_ID = 5913639088  # Основной ID администратора
ADMIN_IDS = [ADMIN_USER_ID]  # Список всех администраторов для совместимости
ADDITIONAL_ADMIN_IDS = []  # Дополнительные администраторы

# Роли администраторов (импортируется из services.admin_roles)
# Ключ - ID администратора, значение - роль администратора
# Если для администратора не указана роль, по умолчанию используется SUPPORT_ADMIN
try:
    from services.admin_roles import AdminRole
    ADMIN_ROLES = {
        ADMIN_USER_ID: AdminRole.SUPER_ADMIN,  # Основной администратор - полный доступ
        # Дополнительные администраторы с разными ролями будут добавлены здесь
    }
    
    # Соответствие ID администраторов и строковых имен ролей для веб-интерфейса и др.
    ADMIN_ROLES_MAP = {
        ADMIN_USER_ID: "super_admin",  # Основной администратор
        # Дополнительные администраторы будут добавлены здесь
    }
except ImportError:
    # Для совместимости, если модуль ролей еще не создан
    ADMIN_ROLES = {}
    ADMIN_ROLES_MAP = {}

# Настройки мониторинга
MONITORING_CHANNEL_ID = None  # ID канала для отправки уведомлений мониторинга
ENABLE_DETAILED_LOGGING = True  # Включить подробное логирование операций
LOG_SENSITIVE_DATA = False  # Логировать чувствительные данные (только для отладки)

# Расписание автоматических отчетов (для использования с APScheduler)
REPORT_SCHEDULE = {
    "daily": {"hour": 9, "minute": 0},  # Ежедневный отчет в 9:00
    "weekly": {"day_of_week": 1, "hour": 10, "minute": 0},  # Еженедельный отчет по понедельникам
    "monthly": {"day": 1, "hour": 8, "minute": 0}  # Ежемесячный отчет первого числа
}
ENABLE_AUTO_REPORTS = os.getenv("ENABLE_AUTO_REPORTS", "false").lower() == "true"  # Включение автоматических отчетов

# Настройки безопасности
SIGNATURE_SECRET_KEY = ROBOKASSA_SECRET_KEY  # Секретный ключ для подписи запросов
DUPLICATE_PROTECTION_MINUTES = 30  # Защита от дублирующих транзакций (минуты)
MAX_MESSAGES_PER_MINUTE = 30  # Ограничение на отправку сообщений (защита от спама)

def get_base_url():
    """
    Получить базовый URL для веб-сервера
    
    Returns:
        str: Базовый URL (по умолчанию для Replit или кастомный из переменных окружения)
    """
    # Попробуем получить URL Replit, если бот запущен на Replit
    replit_url = os.getenv("REPLIT_DOMAINS", "")
    if replit_url:
        domains = replit_url.split(',')
        if domains:
            # В случае запуска на Replit возвращаем первый доступный домен
            return f"https://{domains[0]}"
    
    # Если указан кастомный домен, используем его
    if WEBHOOK_HOST:
        # Проверяем, начинается ли домен с http:// или https://
        if WEBHOOK_HOST.startswith(('http://', 'https://')):
            return WEBHOOK_HOST
        else:
            return f"https://{WEBHOOK_HOST}"
    
    # Если ничего не указано, используем локальный адрес (только для разработки)
    logger.warning("No base URL found in environment variables, using localhost")
    return "http://localhost:5000"

# Commands
COMMANDS = {
    "start": "Запустить бота",
    "help": "Показать справочную информацию",
    "solve": "Решить математическую задачу",
    "subscribe": "Купить подписку",
    "invite": "Пригласить друзей и заработать",
    "rewards": "Посмотреть мои вознаграждения",
    "activate_subscription": "Активировать подписку после оплаты",
    "admin": "Панель администратора (только для админов)"
}

# Messages
WELCOME_MESSAGE = (
    "👋 Привет! Я Катюша, твой помощник в решении задач.\n\n"
    "Я могу решать любые задачи по математике, геометрии, и даже русскому языку! Ты можешь отправить мне задание:\n"
    "• Текстовым сообщением\n"
    "• Фотографией из учебника (я распознаю текст)\n"
    "• Голосовым сообщением (я переведу его в текст)\n\n"
    "🎁 У тебя есть одно бесплатное решение, после чего понадобится подписка.\n\n"
    "💰 Стоимость подписки всего 199₽ в месяц\n"
    "Оферта https://disk.yandex.ru/i/KTubnOE5AqQnFg\n\n"
    "👥 А ГЛАВНОЕ - ПРИГЛАШАЙ ДРУЗЕЙ И ЗАРАБАТЫВАЙ НА ИХ ПОДПИСКАХ!!!"
)

HELP_MESSAGE = (
    "🔍 Как пользоваться ботом Катюша:\n\n"
    "1️⃣ Отправь мне задачу текстом, голосовым сообщением или фотографией\n"
    "2️⃣ Нажми 'Решить задачу', чтобы получить решение\n"
    "3️⃣ Твой первый запрос бесплатный, потом подписка за 199₽/месяц\n"
    "4️⃣ Нажми 'Пригласить друга' и получи % от оплаты приглашенных пользователей\n\n"
    "Команды:\n"
    "/start - Запустить бота\n"
    "/help - Показать эту справку\n"
    "/solve - Решить задачу\n"
    "/subscribe - Купить подписку\n"
    "/invite - Пригласить друзей\n"
    "/rewards - Посмотреть мои вознаграждения\n"
    "/activate_subscription - Активировать подписку после оплаты"
)

SUBSCRIPTION_NEEDED_MESSAGE = (
    "⚠️ Ты уже использовал свое бесплатное решение!\n\n"
    "Чтобы продолжить пользоваться Катюшей, приобрети подписку за *199₽/месяц*.\n\n"
    "Нажми кнопку «Купить подписку» чтобы перейти к оплате.\n\n"
    "💡 *Совет:* Пригласи друзей и заработай на их подписках!"
)

SOLUTION_PROMPT = (
    "Пожалуйста, реши следующую математическую задачу пошагово, покажи весь ход решения и объясни "
    "подход. Используй только обычный текст и простые математические символы (+ - * / = < >), "
    "не используй LaTeX и сложные математические обозначения. Выражения должны быть понятны и читаемы "
    "в обычном текстовом формате. Убедись, что дал ясный окончательный ответ:\n\n{problem}"
)

PROCESSING_MESSAGE = "⏳ Обрабатываю ваш запрос... Это может занять некоторое время."
VOICE_PROCESSING_MESSAGE = "🎤 Распознаю голосовое сообщение... Это может занять некоторое время."
SEND_PROBLEM_MESSAGE = "📝 Пожалуйста, отправьте мне вашу математическую задачу текстом, голосовым сообщением или фотографией."
SUBSCRIPTION_SUCCESS_MESSAGE = "✅ Ваша подписка активирована! Теперь у вас есть неограниченный доступ к боту Катюша на один месяц."
ERROR_MESSAGE = "❌ Извините, что-то пошло не так. Пожалуйста, попробуйте позже."
OCR_ERROR_MESSAGE = "❌ Я не смог прочитать текст с вашего изображения. Пожалуйста, отправьте более четкое изображение или напишите задачу текстом."
VOICE_ERROR_MESSAGE = "❌ Я не смог распознать текст из вашего голосового сообщения. Пожалуйста, попробуйте говорить более четко или отправьте задачу текстом."

# Referral system
REFERRAL_MESSAGE = (
    "👥 *Реферальная система Катюши*\n\n"
    "Приглашай друзей и получай:\n"
    "• 5% от их оплаты\n"
    "• 2% от 2-3 уровня рефералов твоей ветки\n"
    "• 2% от 4 уровня рефералов твоей ветки\n\n"
    "Вот твоя персональная реферальная ссылка:\n"
    "{referral_link}\n\n"
    "Отправь эту ссылку друзьям и начни зарабатывать!"
)

REWARDS_MESSAGE = (
    "💰 *Ваши реферальные вознаграждения*\n\n"
    "Всего заработано: *{total_earned}₽*\n"
    "Выплачено: *{total_paid}₽*\n"
    "Ожидает выплаты: *{total_pending}₽*\n"
    "В обработке: *{total_processing}₽*\n\n"
    "👥 *Ваши рефералы:*\n"
    "• Уровень 1: {level1_count} ({level1_reward}₽)\n"
    "• Уровень 2: {level2_count} ({level2_reward}₽)\n"
    "• Уровень 3: {level3_count} ({level3_reward}₽)\n"
    "• Уровень 4: {level4_count} ({level4_reward}₽)\n\n"
    "Используйте команду /invite, чтобы пригласить больше друзей и заработать больше!"
)