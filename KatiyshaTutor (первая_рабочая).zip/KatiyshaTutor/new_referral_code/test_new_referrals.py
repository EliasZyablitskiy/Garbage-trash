#!/usr/bin/env python
# coding: utf-8

"""
Тестовый скрипт для проверки новой реферальной системы
"""

import os
import sys
import json
import logging

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Добавляем корневой каталог в путь
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

def test_referral_generation():
    """
    Тестирует генерацию реферального кода
    """
    from models import User
    
    # Создаем тестового пользователя
    test_user = User(user_id=999999, username="test_user")
    
    # Генерируем реферальный код
    referral_code = test_user.generate_referral_code()
    referral_link = test_user.get_referral_link()
    
    logger.info(f"Сгенерирован реферальный код: {referral_code}")
    logger.info(f"Сгенерирована реферальная ссылка: {referral_link}")
    
    assert referral_code is not None and len(referral_code) > 0, "Реферальный код не сгенерирован"
    assert "ref_" in referral_link, "Реферальная ссылка не содержит кода"
    
    return referral_code, referral_link

def test_referral_tracking():
    """
    Тестирует отслеживание рефералов
    """
    from database import load_database, save_database, save_user
    
    # Загружаем текущую базу данных
    db = load_database()
    
    # Создаем тестовых пользователей
    referrer_id = 1000001
    referred_id = 1000002
    
    # Добавляем реферера
    referrer_data = {
        "id": referrer_id,
        "username": "referrer_user",
        "first_name": "Referrer",
        "last_name": "User",
        "free_request_used": False,
        "subscription_expiry": None,
        "referral_code": "test_ref_1",
        "referrer_id": None,
        "referrals": {
            "level1": [],
            "level2": [],
            "level3": [],
            "level4": []
        }
    }
    
    # Добавляем реферала
    referred_data = {
        "id": referred_id,
        "username": "referred_user",
        "first_name": "Referred",
        "last_name": "User",
        "free_request_used": False,
        "subscription_expiry": None,
        "referral_code": None,
        "referrer_id": referrer_id,
        "referrals": {
            "level1": [],
            "level2": [],
            "level3": [],
            "level4": []
        }
    }
    
    # Сохраняем пользователей
    save_user(referrer_data)
    save_user(referred_data)
    
    # Проверяем, что реферал добавлен к рефереру
    db = load_database()
    updated_referrer = db['users'].get(str(referrer_id))
    
    assert updated_referrer is not None, "Реферер не найден в базе данных"
    assert "referrals" in updated_referrer, "У реферера нет поля referrals"
    
    # Проверяем реферальную связь
    from handlers import process_referral
    # Здесь должен быть код для тестирования process_referral
    
    # Выводим результат
    logger.info(f"Реферер: {json.dumps(updated_referrer, indent=2)}")
    logger.info(f"Реферал: {json.dumps(db['users'].get(str(referred_id)), indent=2)}")
    
    return updated_referrer, db['users'].get(str(referred_id))

def test_reward_calculation():
    """
    Тестирует расчет вознаграждений
    """
    # Здесь должна быть функция из новой реферальной системы для расчета вознаграждений
    # Например:
    # from referrals.reward_calculator import calculate_referral_reward
    
    # Тестовые данные
    subscription_amount = 199.0  # Стоимость подписки
    
    # Ожидаемые результаты
    expected_level1_reward = 199 * 0.05  # 5% для первого уровня
    expected_level2_reward = 199 * 0.02  # 2% для второго уровня
    expected_level3_reward = 199 * 0.02  # 2% для третьего уровня
    expected_level4_reward = 199 * 0.02  # 2% для четвертого уровня
    
    logger.info(f"Ожидаемые вознаграждения:")
    logger.info(f"Уровень 1: {expected_level1_reward} руб.")
    logger.info(f"Уровень 2: {expected_level2_reward} руб.")
    logger.info(f"Уровень 3: {expected_level3_reward} руб.")
    logger.info(f"Уровень 4: {expected_level4_reward} руб.")
    
    # В новой системе может быть другая логика расчета, которую нужно протестировать
    
    return {
        "level1": expected_level1_reward,
        "level2": expected_level2_reward,
        "level3": expected_level3_reward,
        "level4": expected_level4_reward
    }

def run_all_tests():
    """
    Запускает все тесты
    """
    logger.info("=== Тестирование генерации реферальных кодов ===")
    referral_code, referral_link = test_referral_generation()
    
    logger.info("\n=== Тестирование отслеживания рефералов ===")
    referrer, referred = test_referral_tracking()
    
    logger.info("\n=== Тестирование расчета вознаграждений ===")
    rewards = test_reward_calculation()
    
    logger.info("\n=== Все тесты завершены ===")
    return {
        "referral_code": referral_code,
        "referral_link": referral_link,
        "referrer": referrer,
        "referred": referred,
        "rewards": rewards
    }

if __name__ == "__main__":
    run_all_tests()