#!/bin/bash
# Скрипт для остановки планировщика резервного копирования

if [ -f backup_service.pid ]; then
    PID=$(cat backup_service.pid)
    if ps -p $PID > /dev/null; then
        echo "Остановка сервиса резервного копирования (PID: $PID)..."
        kill $PID
        echo "Сервис остановлен."
    else
        echo "Процесс с PID $PID не найден. Возможно, сервис уже остановлен."
    fi
    rm -f backup_service.pid
else
    echo "Файл backup_service.pid не найден. Сервис не запущен."
fi