import unittest
import sys
import os
import json
from unittest.mock import patch, MagicMock, call
from datetime import datetime, timedelta

# Add the project root directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from models import ReferralSystem
from services.payment_service import process_payment_notification, process_pending_payouts
import database
import config


class TestReferralIntegration(unittest.TestCase):
    """Integration tests for referral system components working together"""
    
    def setUp(self):
        """Set up test fixtures before each test"""
        # Mock database functions to prevent file operations
        self.db_patcher = patch('database.save_data')
        self.mock_save_data = self.db_patcher.start()
        
        # Initialize test data
        self.test_users = {
            "123": {
                "id": 123,
                "username": "user1",
                "first_name": "User One",
                "referral_code": "REF123",
                "referrer_id": None,
                "referrals": [],
                "referral_levels": {"1": [], "2": [], "3": [], "4": []},
                "total_earned": 0,
                "subscription_end_date": None,
                "wallet": "wallet123"
            },
            "456": {
                "id": 456,
                "username": "user2",
                "first_name": "User Two",
                "referral_code": "REF456",
                "referrer_id": 123,
                "referrals": [],
                "referral_levels": {"1": [], "2": [], "3": [], "4": []},
                "total_earned": 0,
                "subscription_end_date": None,
                "wallet": "wallet456"
            },
            "789": {
                "id": 789,
                "username": "user3",
                "first_name": "User Three",
                "referral_code": "REF789",
                "referrer_id": 456,
                "referrals": [],
                "referral_levels": {"1": [], "2": [], "3": [], "4": []},
                "total_earned": 0,
                "subscription_end_date": None,
                "wallet": "wallet789"
            }
        }
        
        # Update user referrals and referral levels
        self.test_users["123"]["referrals"] = [456]
        self.test_users["123"]["referral_levels"]["1"] = [456]
        self.test_users["123"]["referral_levels"]["2"] = [789]
        
        self.test_users["456"]["referrals"] = [789]
        self.test_users["456"]["referral_levels"]["1"] = [789]
        
        # Create test transactions
        self.test_transactions = {
            "tx123": {
                "id": "tx123",
                "user_id": 789,
                "amount": 100.0,
                "type": "subscription",
                "status": "pending",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "description": "Monthly subscription"
            }
        }
        
        # Configure mocks for database access
        self.get_user_data_patcher = patch('database.get_user_data')
        self.mock_get_user_data = self.get_user_data_patcher.start()
        self.mock_get_user_data.side_effect = lambda user_id: self.test_users.get(str(user_id))
        
        self.get_all_users_patcher = patch('database.get_all_users')
        self.mock_get_all_users = self.get_all_users_patcher.start()
        self.mock_get_all_users.return_value = self.test_users
        
        self.update_user_data_patcher = patch('database.update_user_data')
        self.mock_update_user_data = self.update_user_data_patcher.start()
        self.mock_update_user_data.side_effect = self.mock_update_user
        
        self.get_transaction_data_patcher = patch('database.get_transaction_data')
        self.mock_get_transaction_data = self.get_transaction_data_patcher.start()
        self.mock_get_transaction_data.side_effect = lambda tx_id: self.test_transactions.get(tx_id)
        
        self.update_transaction_patcher = patch('database.update_transaction')
        self.mock_update_transaction = self.update_transaction_patcher.start()
        self.mock_update_transaction.side_effect = self.mock_update_transaction_data
        
        self.create_transaction_patcher = patch('database.create_transaction')
        self.mock_create_transaction = self.create_transaction_patcher.start()
        self.mock_create_transaction.side_effect = self.mock_create_transaction_data
        
        self.get_transactions_by_user_patcher = patch('database.get_transactions_by_user')
        self.mock_get_transactions_by_user = self.get_transactions_by_user_patcher.start()
        self.mock_get_transactions_by_user.side_effect = self.mock_get_transactions_by_user_data
        
        # Mock configuration
        self.config_patcher = patch.multiple(
            'config',
            ROBOKASSA_MERCHANT_LOGIN="test_merchant",
            ROBOKASSA_PASSWORD1="test_password1",
            ROBOKASSA_PASSWORD2="test_password2",
            ROBOKASSA_TEST_MODE=True,
            REFERRAL_LEVEL1_RATE=0.05,
            REFERRAL_LEVEL2_RATE=0.02,
            REFERRAL_LEVEL3_RATE=0.02,
            REFERRAL_LEVEL4_RATE=0.02
        )
        self.config_patcher.start()
        
        # Initialize the referral system
        self.referral_system = ReferralSystem()
    
    def tearDown(self):
        """Tear down test fixtures after each test"""
        self.db_patcher.stop()
        self.get_user_data_patcher.stop()
        self.get_all_users_patcher.stop()
        self.update_user_data_patcher.stop()
        self.get_transaction_data_patcher.stop()
        self.update_transaction_patcher.stop()
        self.create_transaction_patcher.stop()
        self.get_transactions_by_user_patcher.stop()
        self.config_patcher.stop()
    
    def mock_update_user(self, user_id, updated_data):
        """Mock implementation of update_user_data"""
        user_id_str = str(user_id)
        if user_id_str in self.test_users:
            self.test_users[user_id_str].update(updated_data)
            return True
        return False
    
    def mock_update_transaction_data(self, tx_id, updated_data):
        """Mock implementation of update_transaction"""
        if tx_id in self.test_transactions:
            self.test_transactions[tx_id].update(updated_data)
            self.test_transactions[tx_id]["updated_at"] = datetime.now().isoformat()
            return True
        return False
    
    def mock_create_transaction_data(self, user_id, amount, description, transaction_type):
        """Mock implementation of create_transaction"""
        tx_id = f"tx{len(self.test_transactions) + 1}"
        self.test_transactions[tx_id] = {
            "id": tx_id,
            "user_id": user_id,
            "amount": amount,
            "type": transaction_type,
            "status": "pending",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "description": description
        }
        return tx_id
    
    def mock_get_transactions_by_user_data(self, user_id):
        """Mock implementation of get_transactions_by_user"""
        return {tx_id: tx for tx_id, tx in self.test_transactions.items() 
                if tx["user_id"] == user_id}
    
    @patch('services.payment_service.verify_signature')
    @patch('services.payment_service.notify_user')
    def test_full_referral_flow(self, mock_notify_user, mock_verify_signature):
        """Test the entire flow from payment to referral rewards"""
        # Mock signature verification
        mock_verify_signature.return_value = True
        
        # Process a payment notification for user3's subscription
        payment_data = {
            "OutSum": "100.0",
            "InvId": "tx123",
            "SignatureValue": "test_signature",
            "UserID": "789"
        }
        
        # Process the payment notification
        result = process_payment_notification(payment_data)
        self.assertTrue(result)
        
        # Verify the transaction status was updated
        self.assertEqual(self.test_transactions["tx123"]["status"], "completed")
        
        # Verify that referral transactions were created by checking if 
        # create_transaction was called with the right parameters
        # User2 (level 1 referrer) should get 5% of 100 = 5.0
        level1_call = any(
            call[0] == 456 and call[1] == 5.0 and call[3] == "referral_reward"
            for call in self.mock_create_transaction.call_args_list
        )
        self.assertTrue(level1_call, "Level 1 referrer should receive 5% commission")
        
        # User1 (level 2 referrer) should get 2% of 100 = 2.0
        level2_call = any(
            call[0] == 123 and call[1] == 2.0 and call[3] == "referral_reward"
            for call in self.mock_create_transaction.call_args_list
        )
        self.assertTrue(level2_call, "Level 2 referrer should receive 2% commission")
    
    @patch('services.payment_service.generate_payout_url')
    @patch('services.payment_service.notify_user')
    @patch('database.get_transactions_by_status')
    def test_process_payouts(self, mock_get_transactions, mock_notify_user, mock_generate_url):
        """Test processing of pending payouts"""
        # Create pending payout transactions
        payout_tx1 = {
            "id": "payout1",
            "user_id": 123,
            "amount": 5.0,
            "type": "referral_reward",
            "status": "pending_payout",
            "created_at": (datetime.now() - timedelta(days=7)).isoformat(),
            "updated_at": (datetime.now() - timedelta(days=7)).isoformat(),
            "description": "Referral reward for user subscription"
        }
        
        payout_tx2 = {
            "id": "payout2",
            "user_id": 456,
            "amount": 2.0,
            "type": "referral_reward",
            "status": "pending_payout",
            "created_at": (datetime.now() - timedelta(days=5)).isoformat(),
            "updated_at": (datetime.now() - timedelta(days=5)).isoformat(),
            "description": "Referral reward for user subscription"
        }
        
        # Add transactions to the mock database
        self.test_transactions["payout1"] = payout_tx1
        self.test_transactions["payout2"] = payout_tx2
        
        # Mock the get_transactions_by_status function
        mock_get_transactions.return_value = [payout_tx1, payout_tx2]
        
        # Mock generate_payout_url
        mock_generate_url.side_effect = lambda user_id, amount, tx_id: f"https://test.robokassa.ru/payout/{tx_id}"
        
        # Process the pending payouts
        result = process_pending_payouts()
        
        # Verify the result
        self.assertEqual(len(result), 2)
        
        # Verify that generate_payout_url was called for both transactions
        self.assertEqual(mock_generate_url.call_count, 2)
        
        # Verify that users were notified
        self.assertEqual(mock_notify_user.call_count, 2)
        
        # Verify transaction statuses were updated
        self.assertEqual(self.test_transactions["payout1"]["status"], "processing_payout")
        self.assertEqual(self.test_transactions["payout2"]["status"], "processing_payout")
    
    def test_referral_code_generation(self):
        """Test that referral codes are generated correctly"""
        # Get a user without a referral code
        user = self.test_users["123"].copy()
        user["referral_code"] = None
        
        # Mock get_user_data to return this user
        self.mock_get_user_data.return_value = user
        
        # Generate a referral code
        result = self.referral_system.generate_referral_code(123)
        
        # Verify the result
        self.assertIsNotNone(result)
        self.assertTrue(len(result) > 5, "Referral code should be at least 6 characters")
        
        # Verify that update_user_data was called
        self.mock_update_user_data.assert_called_with(123, {"referral_code": result})
    
    def test_add_referral_relationship(self):
        """Test adding a referral relationship between users"""
        # Create a new user without a referrer
        new_user = {
            "id": 999,
            "username": "newuser",
            "first_name": "New User",
            "referral_code": None,
            "referrer_id": None,
            "referrals": [],
            "referral_levels": {"1": [], "2": [], "3": [], "4": []},
            "total_earned": 0,
            "subscription_end_date": None
        }
        self.test_users["999"] = new_user
        
        # Set up mock to return the existing users
        self.mock_get_user_data.side_effect = lambda user_id: self.test_users.get(str(user_id))
        
        # Set up mock to find user by referral code
        with patch.object(self.referral_system, 'get_user_by_referral_code') as mock_get_by_code:
            mock_get_by_code.return_value = self.test_users["123"]
            
            # Add the referral relationship
            result = self.referral_system.add_referral(999, "REF123")
            
            # Verify the result
            self.assertTrue(result)
            
            # Verify the new user's referrer was set
            self.assertEqual(self.test_users["999"]["referrer_id"], 123)
            
            # Verify the referrer's referrals list was updated
            self.assertIn(999, self.test_users["123"]["referrals"])
            
            # Verify the referrer's level 1 referrals list was updated
            self.assertIn(999, self.test_users["123"]["referral_levels"]["1"])
            
            # Test adding a deeper level referral
            new_user2 = {
                "id": 1000,
                "username": "newuser2",
                "first_name": "New User Two",
                "referral_code": None,
                "referrer_id": None,
                "referrals": [],
                "referral_levels": {"1": [], "2": [], "3": [], "4": []},
                "total_earned": 0,
                "subscription_end_date": None
            }
            self.test_users["1000"] = new_user2
            
            # Set up mock to find user by referral code
            mock_get_by_code.return_value = self.test_users["999"]
            
            # Add the referral relationship
            result = self.referral_system.add_referral(1000, "REF999")
            
            # Verify the referrer chain was correctly updated
            self.assertEqual(self.test_users["1000"]["referrer_id"], 999)
            self.assertIn(1000, self.test_users["999"]["referrals"])
            self.assertIn(1000, self.test_users["999"]["referral_levels"]["1"])
            
            # Verify that User 1 (123) has User 3 (1000) as a level 2 referral
            self.assertIn(1000, self.test_users["123"]["referral_levels"]["2"])
    
    def test_deep_level_referrals(self):
        """Test referral relationships across multiple levels (up to 4)"""
        # Add users for levels 3 and 4
        level3_user = {
            "id": 1001,
            "username": "level3user",
            "first_name": "Level Three",
            "referral_code": "REF1001",
            "referrer_id": None,
            "referrals": [],
            "referral_levels": {"1": [], "2": [], "3": [], "4": []},
            "total_earned": 0,
            "subscription_end_date": None,
            "wallet": "wallet1001"
        }
        
        level4_user = {
            "id": 1002,
            "username": "level4user",
            "first_name": "Level Four",
            "referral_code": "REF1002",
            "referrer_id": None,
            "referrals": [],
            "referral_levels": {"1": [], "2": [], "3": [], "4": []},
            "total_earned": 0,
            "subscription_end_date": None,
            "wallet": "wallet1002"
        }
        
        self.test_users["1001"] = level3_user
        self.test_users["1002"] = level4_user
        
        # Set up the referral chain: 123 -> 456 -> 789 -> 1001 -> 1002
        with patch.object(self.referral_system, 'get_user_by_referral_code') as mock_get_by_code:
            # Level 3 user refers to user 789
            mock_get_by_code.return_value = self.test_users["789"]
            self.referral_system.add_referral(1001, "REF789")
            
            # Level 4 user refers to level 3 user
            mock_get_by_code.return_value = self.test_users["1001"]
            self.referral_system.add_referral(1002, "REF1001")
        
        # Verify the referral levels are correctly set up
        self.assertEqual(self.test_users["1001"]["referrer_id"], 789)
        self.assertEqual(self.test_users["1002"]["referrer_id"], 1001)
        
        # Verify level 3 referrals
        self.assertIn(1001, self.test_users["789"]["referrals"])
        self.assertIn(1001, self.test_users["789"]["referral_levels"]["1"])
        self.assertIn(1001, self.test_users["456"]["referral_levels"]["2"])
        self.assertIn(1001, self.test_users["123"]["referral_levels"]["3"])
        
        # Verify level 4 referrals
        self.assertIn(1002, self.test_users["1001"]["referrals"])
        self.assertIn(1002, self.test_users["1001"]["referral_levels"]["1"])
        self.assertIn(1002, self.test_users["789"]["referral_levels"]["2"])
        self.assertIn(1002, self.test_users["456"]["referral_levels"]["3"])
        self.assertIn(1002, self.test_users["123"]["referral_levels"]["4"])
        
        # Test payment and commission across all 4 levels
        with patch('services.payment_service.verify_signature') as mock_verify:
            mock_verify.return_value = True
            
            # Create a subscription payment for the level 4 user
            payment_tx = {
                "id": "tx_level4",
                "user_id": 1002,
                "amount": 100.0,
                "type": "subscription",
                "status": "pending",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "description": "Monthly subscription"
            }
            self.test_transactions["tx_level4"] = payment_tx
            
            # Process payment notification
            payment_data = {
                "OutSum": "100.0",
                "InvId": "tx_level4",
                "SignatureValue": "test_signature",
                "UserID": "1002"
            }
            
            # Process the payment
            process_payment_notification(payment_data)
            
            # Verify commissions for all levels
            calls = self.mock_create_transaction.call_args_list
            
            # User at level 1 (direct referrer) should get 5%
            level1_commission = any(
                call[0] == 1001 and call[1] == 5.0 and call[3] == "referral_reward"
                for call in calls
            )
            self.assertTrue(level1_commission, "Level 1 referrer should receive 5% commission")
            
            # User at level 2 should get 2%
            level2_commission = any(
                call[0] == 789 and call[1] == 2.0 and call[3] == "referral_reward"
                for call in calls
            )
            self.assertTrue(level2_commission, "Level 2 referrer should receive 2% commission")
            
            # User at level 3 should get 2%
            level3_commission = any(
                call[0] == 456 and call[1] == 2.0 and call[3] == "referral_reward"
                for call in calls
            )
            self.assertTrue(level3_commission, "Level 3 referrer should receive 2% commission")
            
            # User at level 4 should get 2%
            level4_commission = any(
                call[0] == 123 and call[1] == 2.0 and call[3] == "referral_reward"
                for call in calls
            )
            self.assertTrue(level4_commission, "Level 4 referrer should receive 2% commission")
    
    def test_invalid_referral_code(self):
        """Test adding a referral with an invalid code"""
        # Create a new user
        new_user = {
            "id": 2000,
            "username": "invalid_test",
            "first_name": "Invalid Test",
            "referral_code": None,
            "referrer_id": None,
            "referrals": [],
            "referral_levels": {"1": [], "2": [], "3": [], "4": []},
            "total_earned": 0,
            "subscription_end_date": None
        }
        self.test_users["2000"] = new_user
        
        # Set up mock to return None for invalid code
        with patch.object(self.referral_system, 'get_user_by_referral_code') as mock_get_by_code:
            mock_get_by_code.return_value = None
            
            # Try to add referral with invalid code
            result = self.referral_system.add_referral(2000, "INVALID_CODE")
            
            # Verify the result is False
            self.assertFalse(result)
            
            # Verify user data wasn't changed
            self.assertIsNone(self.test_users["2000"]["referrer_id"])
            self.assertEqual(len(self.test_users["2000"]["referrals"]), 0)
    
    def test_prevent_self_referral(self):
        """Test that a user cannot refer themselves"""
        # Set up user with an existing referral code
        user = self.test_users["123"]
        
        # Set up mock for get_user_by_referral_code to return the same user
        with patch.object(self.referral_system, 'get_user_by_referral_code') as mock_get_by_code:
            mock_get_by_code.return_value = user
            
            # Try to add self-referral
            result = self.referral_system.add_referral(123, "REF123")
            
            # Verify the result is False
            self.assertFalse(result)
            
            # Verify that referral data wasn't changed
            self.assertIsNone(user["referrer_id"])
            self.assertNotIn(123, user["referrals"])
    
    @patch('database.get_transactions_by_status')
    def test_aggregate_pending_rewards(self, mock_get_transactions):
        """Test aggregating pending rewards into a payout transaction"""
        # Create test reward transactions
        rewards = [
            {
                "id": "reward1",
                "user_id": 123,
                "amount": 3.0,
                "type": "referral_reward",
                "status": "completed",
                "created_at": (datetime.now() - timedelta(days=10)).isoformat(),
                "updated_at": (datetime.now() - timedelta(days=10)).isoformat(),
                "description": "Referral reward from user 456"
            },
            {
                "id": "reward2",
                "user_id": 123,
                "amount": 2.0,
                "type": "referral_reward",
                "status": "completed",
                "created_at": (datetime.now() - timedelta(days=8)).isoformat(),
                "updated_at": (datetime.now() - timedelta(days=8)).isoformat(),
                "description": "Referral reward from user 789"
            }
        ]
        
        # Add transactions to our test database
        self.test_transactions["reward1"] = rewards[0]
        self.test_transactions["reward2"] = rewards[1]
        
        # Mock get_transactions_by_status to return our test rewards
        mock_get_transactions.return_value = rewards
        
        # Mock the function that processes rewards into payouts
        with patch('services.payment_service.aggregate_user_rewards') as mock_aggregate:
            mock_aggregate.return_value = {123: 5.0}
            
            # Call the function that processes rewards
            from services.payment_service import process_referral_rewards
            result = process_referral_rewards()
            
            # Verify result
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0]["user_id"], 123)
            self.assertEqual(result[0]["amount"], 5.0)
            self.assertEqual(result[0]["type"], "payout")
            self.assertEqual(result[0]["status"], "pending_payout")

if __name__ == "__main__":
    unittest.main()