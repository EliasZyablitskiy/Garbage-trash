#!/usr/bin/env python
# coding: utf-8

"""
Keyboard layouts for the Katiysha bot
Адаптировано для кросс-платформенной совместимости
"""

import logging
from telegram import ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton
from typing import Dict, Any, Optional, List

from services.platform_detection_service import (
    PLATFORM_UNKNOWN, get_user_platform, get_platform_from_update
)
from services.keyboard_service import (
    get_adaptive_main_keyboard, get_adaptive_problem_keyboard, 
    get_adaptive_payment_keyboard, create_adaptive_reply_keyboard,
    create_adaptive_inline_keyboard
)

logger = logging.getLogger(__name__)

def get_main_keyboard(user_data=None, platform_type=PLATFORM_UNKNOWN, platform_version=None):
    """
    Return the main menu keyboard adapted to user subscription status and platform.
    
    Args:
        user_data (dict, optional): User data containing subscription information.
            If None, default keyboard is returned.
        platform_type (str, optional): The platform type (ios, android, desktop, web, unknown)
        platform_version (str, optional): Platform version string
    
    Returns:
        ReplyKeyboardMarkup: Keyboard layout adapted to user status and platform
    """
    # Если не указан тип платформы, но есть ID пользователя, пытаемся получить из базы
    if platform_type == PLATFORM_UNKNOWN and user_data and 'id' in user_data:
        platform_info = get_user_platform(user_data['id'])
        if platform_info:
            platform_type = platform_info.get('platform', PLATFORM_UNKNOWN)
            platform_version = platform_info.get('version')
            logger.debug(f"Retrieved platform from database: {platform_type} {platform_version}")
    
    # Вызываем адаптивную функцию создания клавиатуры
    return get_adaptive_main_keyboard(user_data, platform_type, platform_version)

def get_problem_keyboard(platform_type=PLATFORM_UNKNOWN, platform_version=None):
    """
    Return keyboard for confirming problem solving adapted to platform.
    
    Args:
        platform_type (str, optional): The platform type (ios, android, desktop, web, unknown)
        platform_version (str, optional): Platform version string
        
    Returns:
        InlineKeyboardMarkup: Platform-adapted keyboard
    """
    return get_adaptive_problem_keyboard(platform_type, platform_version)

def get_payment_keyboard(payment_url, platform_type=PLATFORM_UNKNOWN, platform_version=None):
    """
    Return keyboard for payment adapted to platform.
    
    Args:
        payment_url (str): URL for payment
        platform_type (str, optional): The platform type (ios, android, desktop, web, unknown)
        platform_version (str, optional): Platform version string
        
    Returns:
        InlineKeyboardMarkup: Platform-adapted payment keyboard
    """
    return get_adaptive_payment_keyboard(payment_url, platform_type, platform_version)

# Добавляем функции-обертки для обратной совместимости со старым кодом
def create_platform_aware_reply_keyboard(buttons, update=None, user_id=None):
    """
    Create a platform-aware reply keyboard.
    
    Args:
        buttons (List[List[str]]): Button layout
        update (Update, optional): Telegram update object to detect platform
        user_id (int, optional): User ID to retrieve platform from database
        
    Returns:
        ReplyKeyboardMarkup: Platform-adapted keyboard
    """
    platform_type = PLATFORM_UNKNOWN
    platform_version = None
    
    # Определяем тип платформы
    if update:
        platform_info = get_platform_from_update(update)
        platform_type = platform_info.get('platform', PLATFORM_UNKNOWN)
        platform_version = platform_info.get('version')
    elif user_id:
        platform_info = get_user_platform(user_id)
        if platform_info:
            platform_type = platform_info.get('platform', PLATFORM_UNKNOWN)
            platform_version = platform_info.get('version')
    
    return create_adaptive_reply_keyboard(buttons, platform_type, platform_version)

def create_platform_aware_inline_keyboard(buttons, update=None, user_id=None):
    """
    Create a platform-aware inline keyboard.
    
    Args:
        buttons (List[List[Dict]]): Button layout with dict items
        update (Update, optional): Telegram update object to detect platform
        user_id (int, optional): User ID to retrieve platform from database
        
    Returns:
        InlineKeyboardMarkup: Platform-adapted keyboard
    """
    platform_type = PLATFORM_UNKNOWN
    platform_version = None
    
    # Определяем тип платформы
    if update:
        platform_info = get_platform_from_update(update)
        platform_type = platform_info.get('platform', PLATFORM_UNKNOWN)
        platform_version = platform_info.get('version')
    elif user_id:
        platform_info = get_user_platform(user_id)
        if platform_info:
            platform_type = platform_info.get('platform', PLATFORM_UNKNOWN)
            platform_version = platform_info.get('version')
    
    return create_adaptive_inline_keyboard(buttons, platform_type, platform_version)