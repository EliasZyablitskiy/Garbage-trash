#!/usr/bin/env python3
"""
Скрипт для восстановления базы данных PostgreSQL из резервной копии
"""
import os
import sys
import json
import logging
import datetime
import subprocess
import requests
from typing import Optional, Dict, Any, List

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('restore.log')
    ]
)
logger = logging.getLogger(__name__)

# Папка для временных файлов
TEMP_DIR = "temp_backup"
os.makedirs(TEMP_DIR, exist_ok=True)

# Настройки базы данных из переменных окружения
PGHOST = os.environ.get("PGHOST")
PGPORT = os.environ.get("PGPORT")
PGUSER = os.environ.get("PGUSER")
PGPASSWORD = os.environ.get("PGPASSWORD")
PGDATABASE = os.environ.get("PGDATABASE")

def get_token_from_file(filename="yandex_token.json") -> Optional[str]:
    """
    Получает токен из файла
    
    Returns:
        str: Токен доступа или None в случае ошибки
    """
    try:
        with open(filename, "r") as f:
            token_data = json.load(f)
        return token_data.get("access_token")
    except Exception as e:
        logger.error(f"Ошибка при чтении токена из файла: {e}")
        return None

def list_backups_on_disk(folder: str = "backup") -> List[Dict[str, Any]]:
    """
    Получает список бэкапов на Яндекс.Диске
    
    Args:
        folder: Папка с бэкапами на Яндекс.Диске
    
    Returns:
        List[Dict]: Список информации о бэкапах
    """
    try:
        # Получаем токен
        token = get_token_from_file()
        if not token:
            logger.error("Токен Яндекс.Диска не найден")
            return []
        
        # Формируем запрос к API
        url = "https://cloud-api.yandex.net/v1/disk/resources"
        headers = {
            "Authorization": f"OAuth {token}"
        }
        params = {
            "path": folder,
            "limit": 100
        }
        
        # Отправляем запрос
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        
        # Получаем данные
        data = response.json()
        
        # Проверяем наличие файлов
        if "_embedded" not in data or "items" not in data["_embedded"]:
            logger.warning(f"Папка '{folder}' не содержит файлов")
            return []
        
        # Фильтруем только файлы бэкапов
        backups = []
        for item in data["_embedded"]["items"]:
            if item["type"] == "file" and item["name"].startswith("backup_") and item["name"].endswith(".sql"):
                backup_info = {
                    "name": item["name"],
                    "path": item["path"],
                    "size": item["size"],
                    "created": item["created"],
                    "modified": item["modified"]
                }
                backups.append(backup_info)
        
        # Сортируем по дате создания (новые в начале)
        backups.sort(key=lambda x: x["created"], reverse=True)
        
        logger.info(f"Найдено бэкапов: {len(backups)}")
        return backups
    except Exception as e:
        logger.error(f"Ошибка при получении списка бэкапов: {e}")
        return []

def download_backup(remote_path: str) -> Optional[str]:
    """
    Скачивает бэкап с Яндекс.Диска
    
    Args:
        remote_path: Путь к файлу на Яндекс.Диске
    
    Returns:
        str: Путь к локальному файлу или None в случае ошибки
    """
    try:
        # Получаем токен
        token = get_token_from_file()
        if not token:
            logger.error("Токен Яндекс.Диска не найден")
            return None
        
        # Формируем путь для сохранения файла
        filename = os.path.basename(remote_path)
        local_path = os.path.join(TEMP_DIR, filename)
        
        # Получаем ссылку для скачивания
        url = "https://cloud-api.yandex.net/v1/disk/resources/download"
        headers = {
            "Authorization": f"OAuth {token}"
        }
        params = {
            "path": remote_path
        }
        
        # Отправляем запрос
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        
        # Получаем ссылку для скачивания
        download_url = response.json().get("href")
        if not download_url:
            logger.error("Не удалось получить ссылку для скачивания")
            return None
        
        # Скачиваем файл
        download_response = requests.get(download_url, stream=True)
        download_response.raise_for_status()
        
        # Сохраняем файл
        with open(local_path, "wb") as f:
            for chunk in download_response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        logger.info(f"Файл успешно скачан: {local_path}")
        return local_path
    except Exception as e:
        logger.error(f"Ошибка при скачивании бэкапа: {e}")
        return None

def restore_database(backup_file: str) -> bool:
    """
    Восстанавливает базу данных из бэкапа
    
    Args:
        backup_file: Путь к файлу бэкапа
    
    Returns:
        bool: True в случае успеха, False в случае ошибки
    """
    try:
        # Устанавливаем переменные окружения для psql
        env = os.environ.copy()
        env["PGPASSWORD"] = PGPASSWORD
        
        # Формируем команду для psql (работает как с текстовыми дампами, так и с бинарными)
        command = [
            "psql",
            "-h", PGHOST,
            "-p", PGPORT,
            "-U", PGUSER,
            "-d", PGDATABASE,
            "-f", backup_file,  # Указываем файл со скриптом SQL
            "--echo-errors",    # Выводить ошибки
            "--single-transaction"  # Выполнить как одну транзакцию
        ]
        
        # Запускаем команду pg_restore
        logger.info(f"Запуск команды: {' '.join(command)}")
        process = subprocess.Popen(
            command,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        stdout, stderr = process.communicate()
        
        # Проверяем результат выполнения
        if process.returncode != 0:
            logger.error(f"Ошибка при восстановлении базы данных: {stderr.decode()}")
            return False
        
        logger.info("База данных успешно восстановлена")
        logger.debug(f"Вывод psql: {stdout.decode()}")
        
        return True
    except Exception as e:
        logger.error(f"Ошибка при восстановлении базы данных: {e}")
        return False

def show_available_backups() -> List[Dict[str, Any]]:
    """
    Выводит список доступных бэкапов
    
    Returns:
        List[Dict]: Список информации о бэкапах
    """
    logger.info("Получение списка доступных бэкапов...")
    
    # Получаем список бэкапов
    backups = list_backups_on_disk()
    
    if not backups:
        logger.warning("Бэкапы не найдены")
        return []
    
    # Выводим информацию о бэкапах
    logger.info(f"Найдено бэкапов: {len(backups)}")
    
    for i, backup in enumerate(backups):
        # Преобразуем дату в читаемый формат
        created_date = datetime.datetime.fromisoformat(backup["created"].replace("Z", "+00:00"))
        
        # Преобразуем размер в читаемый формат
        size_kb = backup["size"] / 1024
        size_mb = size_kb / 1024
        size_str = f"{size_mb:.2f} МБ" if size_mb >= 1 else f"{size_kb:.2f} КБ"
        
        logger.info(f"{i+1}. {backup['name']} - {created_date.strftime('%d.%m.%Y %H:%M:%S')} ({size_str})")
    
    return backups

def main() -> None:
    """
    Основная функция
    """
    logger.info("Запуск процесса восстановления базы данных")
    
    try:
        # Показываем доступные бэкапы
        backups = show_available_backups()
        
        if not backups:
            logger.error("Нет доступных бэкапов для восстановления")
            return
        
        # Если скрипт запущен с аргументом (индексом или именем бэкапа)
        if len(sys.argv) > 1:
            backup_arg = sys.argv[1]
            
            # Проверяем, является ли аргумент индексом или именем файла
            try:
                # Если это индекс
                backup_index = int(backup_arg) - 1
                if 0 <= backup_index < len(backups):
                    backup_to_restore = backups[backup_index]
                else:
                    logger.error(f"Некорректный индекс бэкапа: {backup_arg}")
                    return
            except ValueError:
                # Если это имя файла
                found = False
                for backup in backups:
                    if backup["name"] == backup_arg:
                        backup_to_restore = backup
                        found = True
                        break
                
                if not found:
                    logger.error(f"Бэкап с именем '{backup_arg}' не найден")
                    return
        else:
            # Если аргумент не указан, используем последний бэкап
            backup_to_restore = backups[0]
            logger.info(f"Аргумент не указан, будет использован последний бэкап: {backup_to_restore['name']}")
        
        # Скачиваем бэкап
        logger.info(f"Скачивание бэкапа: {backup_to_restore['name']}")
        local_path = download_backup(backup_to_restore["path"])
        
        if not local_path:
            logger.error("Не удалось скачать бэкап")
            return
        
        # Спрашиваем подтверждение, только если скрипт запущен интерактивно
        if sys.stdin.isatty():
            confirm = input(f"Вы уверены, что хотите восстановить базу данных из бэкапа '{backup_to_restore['name']}'? "
                           f"Все текущие данные будут удалены! (y/n): ")
            if confirm.lower() != "y":
                logger.info("Восстановление отменено")
                return
        
        # Восстанавливаем базу данных
        success = restore_database(local_path)
        
        if success:
            logger.info("Процесс восстановления базы данных успешно завершен")
        else:
            logger.error("Не удалось восстановить базу данных")
    except Exception as e:
        logger.error(f"Ошибка при восстановлении базы данных: {e}")

if __name__ == "__main__":
    main()