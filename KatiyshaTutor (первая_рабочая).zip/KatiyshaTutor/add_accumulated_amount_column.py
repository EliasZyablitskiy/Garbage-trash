#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для добавления колонки accumulated_amount в таблицу users
"""

import os
import sys
import logging
from sqlalchemy import text

from db_config import get_flask_app

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def run_migration():
    """Выполнение миграции"""
    try:
        # Получаем Flask приложение и создаем контекст
        app = get_flask_app()
        with app.app_context():
            from db_models import db
            
            # Создаем инспектор для проверки структуры базы данных
            inspector = db.inspect(db.engine)
            
            # Проверка наличия колонки в таблице users
            users_columns = [c['name'] for c in inspector.get_columns('users')]
            
            # Если колонки нет, то добавляем ее
            if 'accumulated_amount' not in users_columns:
                logger.info("Добавляем колонку accumulated_amount в таблицу users")
                with db.engine.connect() as connection:
                    connection.execute(text('ALTER TABLE users ADD COLUMN accumulated_amount FLOAT DEFAULT 0.0'))
                    connection.commit()
                logger.info("Колонка accumulated_amount успешно добавлена")
            else:
                logger.info("Колонка accumulated_amount уже существует в таблице users")
                
            logger.info("Миграция успешно завершена")
            return True
            
    except Exception as e:
        logger.error(f"Ошибка при выполнении миграции: {e}")
        return False

if __name__ == "__main__":
    if run_migration():
        logger.info("Миграция успешно выполнена")
    else:
        logger.error("Ошибка при выполнении миграции")
        sys.exit(1)