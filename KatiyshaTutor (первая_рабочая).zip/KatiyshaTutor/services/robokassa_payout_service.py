#!/usr/bin/env python
# coding: utf-8

"""
Сервис для работы с API Robokassa для выплат реферальных вознаграждений
"""

import os
import logging
import hashlib
import json
import datetime
import time
import uuid
import aiohttp
from typing import Dict, Any, List, Optional, Tuple, Union

import config
from services.payment_error_handler import analyze_robokassa_error, should_retry_error
from services.signature_service import generate_payout_signature, add_timestamp_to_data

logger = logging.getLogger(__name__)

# Константы API Robokassa
API_BASE_URL = "https://api.robokassa.ru/api"
API_VERSION = "v1"

class RobokassaPayoutService:
    """
    Класс для работы с API Robokassa для выплат
    
    Документация API: https://docs.robokassa.ru/payouts/
    """
    
    def __init__(self, merchant_login: str = None, merchant_password: str = None):
        """
        Инициализация сервиса
        
        Args:
            merchant_login: Логин мерчанта Robokassa
            merchant_password: Пароль мерчанта Robokassa
        """
        self.merchant_login = merchant_login or config.ROBOKASSA_MERCHANT_LOGIN
        self.merchant_password = merchant_password or config.ROBOKASSA_SECRET_KEY
        
        logger.info(f"Initializing Robokassa Payout Service for merchant {self.merchant_login}")
    
    def _generate_signature(self, params: Dict[str, Any]) -> str:
        """
        Генерация подписи для запроса к API Robokassa
        
        Args:
            params: Параметры запроса
            
        Returns:
            str: Подпись запроса
        """
        # Сортируем параметры по алфавиту
        sorted_params = sorted(params.items(), key=lambda x: x[0])
        
        # Формируем строку для подписи
        signature_string = ":".join([f"{k}={v}" for k, v in sorted_params])
        signature_string += f":{self.merchant_password}"
        
        # Генерируем подпись MD5
        return hashlib.md5(signature_string.encode('utf-8')).hexdigest()
    
    async def create_payout(self, 
                          transaction_id: Optional[str] = None,
                          user_id: Optional[int] = None, 
                          amount: Optional[float] = None, 
                          description: str = "", 
                          payout_method: str = "card",
                          retry_count: int = 0,
                          request_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Создание выплаты через API Robokassa с поддержкой повторных попыток и улучшенной обработкой ошибок
        
        Args:
            transaction_id: Уникальный идентификатор транзакции
            user_id: ID пользователя в Telegram
            amount: Сумма выплаты
            description: Описание выплаты
            payout_method: Метод выплаты (card, qiwi, webmoney, etc.)
            retry_count: Счетчик повторных попыток (для внутреннего использования)
            request_id: Уникальный идентификатор запроса (для отслеживания)
            
        Returns:
            Dict: Результат создания выплаты
        """
        start_time = time.time()
        
        # Генерируем request_id, если не указан
        if not request_id:
            request_id = str(uuid.uuid4())
            
        # Генерируем transaction_id, если не указан
        if not transaction_id:
            transaction_id = f"tx_{int(time.time())}_{user_id}_{request_id[:8]}"
            
        # Валидация входных данных
        if not user_id:
            error_msg = "Не указан ID пользователя (user_id)"
            logger.error(f"Validation error: {error_msg}")
            return {
                "success": False,
                "error_code": "VALIDATION_ERROR",
                "error": error_msg,
                "request_id": request_id,
                "retry_count": retry_count
            }
            
        if not amount or amount <= 0:
            error_msg = f"Некорректная сумма выплаты: {amount}"
            logger.error(f"Validation error: {error_msg}")
            return {
                "success": False,
                "error_code": "INVALID_AMOUNT",
                "error": error_msg,
                "request_id": request_id,
                "retry_count": retry_count
            }
        
        # Параметры запроса
        params = {
            "MerchantLogin": self.merchant_login,
            "TransactionId": transaction_id,
            "Amount": str(amount),
            "Description": description or f"Выплата пользователю {user_id}",
            "PayoutMethod": payout_method,
            "PayoutDestination": str(user_id),  # В данном случае используем ID пользователя как идентификатор карты
            "Currency": "RUB",
            "IsTest": "1" if config.DEBUG else "0",
            "RequestId": request_id,
        }
        
        # Добавляем метку времени для защиты от повторных запросов
        params = add_timestamp_to_data(params)
        
        # Генерируем подпись нового формата
        signature = generate_payout_signature(params)
        params["Signature"] = signature
        
        logger.info(f"Creating payout: TransactionId={transaction_id}, Amount={amount}, User={user_id}, RequestId={request_id}, Attempt={retry_count+1}")
        
        # При использовании реального API, здесь будет асинхронный запрос
        # Для демонстрации используем имитацию ответа
        if not config.USE_REAL_ROBOKASSA_API:
            # Имитация успешного ответа API
            result = {
                "success": True,
                "payout_id": f"payout_{transaction_id}",
                "status": "pending",
                "created_at": datetime.datetime.now().isoformat(),
                "amount": amount,
                "user_id": user_id,
                "transaction_id": transaction_id,
                "request_id": request_id,
                "execution_time_ms": int((time.time() - start_time) * 1000)
            }
            
            logger.info(f"Payout created (demo mode): {result}")
            return result
        
        # Для реального API
        try:
            # Установка таймаута на запрос
            timeout = aiohttp.ClientTimeout(total=30)  # 30 секунд на запрос
            
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(f"{API_BASE_URL}/{API_VERSION}/payout/create", 
                                       json=params,
                                       headers={
                                           "Content-Type": "application/json",
                                           "X-Request-ID": request_id,
                                           "X-Retry-Count": str(retry_count)
                                       }) as response:
                    # Получаем ответ как JSON, если возможно
                    try:
                        response_data = await response.json()
                    except:
                        response_data = {"error": await response.text()}
                    
                    execution_time_ms = int((time.time() - start_time) * 1000)
                    
                    if response.status == 200 and response_data.get("success") is True:
                        # Успешный ответ
                        result = {
                            "success": True,
                            "payout_id": response_data.get("payout_id", f"payout_{transaction_id}"),
                            "status": response_data.get("status", "pending"),
                            "created_at": response_data.get("created_at", datetime.datetime.now().isoformat()),
                            "amount": amount,
                            "user_id": user_id,
                            "transaction_id": transaction_id,
                            "request_id": request_id,
                            "execution_time_ms": execution_time_ms,
                            "api_response": response_data
                        }
                        
                        logger.info(f"Payout created: {result}")
                        return result
                    else:
                        # Ошибка API
                        error_code = response_data.get("error_code", f"API_ERROR_{response.status}")
                        error_message = response_data.get("error", f"API Error: {response.status}")
                        
                        # Анализируем ошибку
                        error_info = analyze_robokassa_error(error_code, error_message)
                        
                        result = {
                            "success": False,
                            "error_code": error_code,
                            "error": error_message,
                            "details": response_data,
                            "can_retry": error_info.get("can_retry", False),
                            "action": error_info.get("action", "manual_review"),
                            "user_message": error_info.get("user_message", "Произошла ошибка при обработке выплаты. Пожалуйста, повторите запрос позже."),
                            "admin_message": error_info.get("admin_message", f"Ошибка API Robokassa: {error_code} - {error_message}"),
                            "request_id": request_id,
                            "retry_count": retry_count,
                            "execution_time_ms": execution_time_ms
                        }
                        
                        logger.error(f"Error creating payout: {error_code} - {error_message}")
                        
                        # Если ошибку можно повторить и счетчик повторов не превышен
                        if error_info.get("can_retry", False) and retry_count < 3:
                            # Экспоненциальная задержка перед повторным запросом
                            retry_delay = 2 ** retry_count  # 1, 2, 4 секунды
                            logger.info(f"Retrying payout after {retry_delay} seconds (attempt {retry_count+1}/3)")
                            
                            await asyncio.sleep(retry_delay)
                            return await self.create_payout(
                                transaction_id=transaction_id,
                                user_id=user_id,
                                amount=amount,
                                description=description,
                                payout_method=payout_method,
                                retry_count=retry_count + 1,
                                request_id=request_id
                            )
                        
                        return result
                        
        except asyncio.TimeoutError:
            # Ошибка таймаута
            execution_time_ms = int((time.time() - start_time) * 1000)
            
            result = {
                "success": False,
                "error_code": "TIMEOUT",
                "error": "Превышено время ожидания ответа от API Robokassa",
                "can_retry": True,
                "action": "retry",
                "user_message": "Превышено время ожидания ответа от платежной системы. Повторите запрос позже.",
                "admin_message": f"Таймаут запроса API Robokassa (>{timeout.total} сек) для транзакции {transaction_id}",
                "request_id": request_id,
                "retry_count": retry_count,
                "execution_time_ms": execution_time_ms
            }
            
            logger.error(f"Timeout in create_payout: {result['error']}")
            
            # Если счетчик повторов не превышен
            if retry_count < 3:
                # Экспоненциальная задержка перед повторным запросом
                retry_delay = 2 ** retry_count  # 1, 2, 4 секунды
                logger.info(f"Retrying payout after {retry_delay} seconds (attempt {retry_count+1}/3)")
                
                await asyncio.sleep(retry_delay)
                return await self.create_payout(
                    transaction_id=transaction_id,
                    user_id=user_id,
                    amount=amount,
                    description=description,
                    payout_method=payout_method,
                    retry_count=retry_count + 1,
                    request_id=request_id
                )
            
            return result
            
        except Exception as e:
            # Другие исключения
            execution_time_ms = int((time.time() - start_time) * 1000)
            
            result = {
                "success": False,
                "error_code": "TECHNICAL_ERROR",
                "error": f"Ошибка при обработке запроса: {str(e)}",
                "exception": str(e),
                "traceback": traceback.format_exc(),
                "can_retry": retry_count < 3,  # Можно повторить, если счетчик не превышен
                "action": "retry" if retry_count < 3 else "manual_review",
                "user_message": "Техническая ошибка при обработке выплаты. Наша команда уже работает над её устранением.",
                "admin_message": f"Исключение при создании выплаты {transaction_id}: {str(e)}",
                "request_id": request_id,
                "retry_count": retry_count,
                "execution_time_ms": execution_time_ms
            }
            
            logger.error(f"Exception in create_payout: {e}", exc_info=True)
            
            # Если счетчик повторов не превышен
            if retry_count < 3:
                # Экспоненциальная задержка перед повторным запросом
                retry_delay = 2 ** retry_count  # 1, 2, 4 секунды
                logger.info(f"Retrying payout after {retry_delay} seconds (attempt {retry_count+1}/3)")
                
                await asyncio.sleep(retry_delay)
                return await self.create_payout(
                    transaction_id=transaction_id,
                    user_id=user_id,
                    amount=amount,
                    description=description,
                    payout_method=payout_method,
                    retry_count=retry_count + 1,
                    request_id=request_id
                )
            
            return result
    
    async def get_payout_status(self, transaction_id: str) -> Dict[str, Any]:
        """
        Получение статуса выплаты
        
        Args:
            transaction_id: Уникальный идентификатор транзакции
            
        Returns:
            Dict: Информация о статусе выплаты
        """
        # Параметры запроса
        params = {
            "MerchantLogin": self.merchant_login,
            "TransactionId": transaction_id
        }
        
        # Генерируем подпись
        signature = self._generate_signature(params)
        params["Signature"] = signature
        
        logger.info(f"Getting payout status: TransactionId={transaction_id}")
        
        # При использовании реального API, здесь будет асинхронный запрос
        # Для демонстрации используем имитацию ответа
        if not config.USE_REAL_ROBOKASSA_API:
            # Имитация ответа API
            result = {
                "success": True,
                "payout_id": f"payout_{transaction_id}",
                "status": "completed",
                "updated_at": datetime.datetime.now().isoformat(),
                "transaction_id": transaction_id
            }
            logger.info(f"Payout status (demo mode): {result}")
            return result
        
        # Для реального API
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{API_BASE_URL}/{API_VERSION}/payout/status", 
                                      params=params) as response:
                    if response.status == 200:
                        result = await response.json()
                        logger.info(f"Payout status: {result}")
                        return result
                    else:
                        error_text = await response.text()
                        logger.error(f"Error getting payout status: {response.status}, {error_text}")
                        return {
                            "success": False,
                            "error": f"API Error: {response.status}",
                            "details": error_text
                        }
        except Exception as e:
            logger.error(f"Exception in get_payout_status: {e}")
            return {
                "success": False,
                "error": f"Exception: {str(e)}"
            }
    
    async def process_batch_payouts(self, payouts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Обработка группы выплат
        
        Args:
            payouts: Список выплат для обработки
            
        Returns:
            Dict: Результат обработки выплат
        """
        logger.info(f"Processing batch of {len(payouts)} payouts")
        
        results = {
            "total": len(payouts),
            "successful": 0,
            "failed": 0,
            "details": []
        }
        
        for payout in payouts:
            try:
                result = await self.create_payout(
                    transaction_id=payout.get("transaction_id"),
                    user_id=payout.get("user_id"),
                    amount=payout.get("amount"),
                    description=payout.get("description", "Реферальное вознаграждение")
                )
                
                if result.get("success"):
                    results["successful"] += 1
                else:
                    results["failed"] += 1
                
                results["details"].append({
                    "transaction_id": payout.get("transaction_id"),
                    "user_id": payout.get("user_id"),
                    "amount": payout.get("amount"),
                    "result": result
                })
            except Exception as e:
                logger.error(f"Error processing payout {payout.get('transaction_id')}: {e}")
                results["failed"] += 1
                results["details"].append({
                    "transaction_id": payout.get("transaction_id"),
                    "user_id": payout.get("user_id"),
                    "amount": payout.get("amount"),
                    "result": {
                        "success": False,
                        "error": str(e)
                    }
                })
        
        logger.info(f"Batch processing completed: {results['successful']} successful, {results['failed']} failed")
        return results
    
    async def process_payout_group(self, payout_id: str, 
                                  tier_name: str, 
                                  transactions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Обработка группы выплат определенного уровня (tier)
        
        Args:
            payout_id: ID еженедельной выплаты
            tier_name: Название группы выплат (1000-3000₽, etc.)
            transactions: Список транзакций для обработки
            
        Returns:
            Dict: Результат обработки группы выплат
        """
        logger.info(f"Processing payout group {tier_name} with {len(transactions)} transactions for payout #{payout_id}")
        
        payouts = []
        for tx in transactions:
            payouts.append({
                "transaction_id": f"{payout_id}_{tx.get('id')}",
                "user_id": tx.get("user_id"),
                "amount": tx.get("amount"),
                "description": f"Реферальное вознаграждение (группа {tier_name})"
            })
        
        return await self.process_batch_payouts(payouts)

# Создаем глобальный экземпляр сервиса
robokassa_payout_service = RobokassaPayoutService()