#!/usr/bin/env python
# coding: utf-8

"""
Улучшенный веб-интерфейс администратора для бота Катюша
Реализует рекомендации аудита по улучшению безопасности и производительности
"""

import os
import json
import logging
import zipfile
from datetime import datetime, timedelta
from functools import wraps
from urllib.parse import urlparse
from io import BytesIO

from flask import Blueprint, render_template, request, redirect, url_for, session, flash, abort, jsonify, g, current_app, send_file
from flask_wtf.csrf import CSRFProtect, generate_csrf
from sqlalchemy import func, desc, asc, or_, and_
import asyncio

import config
from db_models import db, User, Transaction, WeeklyPayout, AdminActionLog, SubscriptionAuditLog, AdminUser
from services.notification_service import log_admin_action
from services.admin_auth_service import AdminAuthService, admin_required, permission_required
from services.payout_monitoring_service import PayoutMonitoringService, ReportFormat
from services.subscription_service import synchronize_all_subscriptions, process_expiring_subscriptions
from services.reporting_service import generate_report_pdf, generate_report_excel, generate_report_json
from services.report_service import get_report_progress, start_report_generation

logger = logging.getLogger(__name__)

# Создаем Blueprint для маршрутов улучшенного веб-интерфейса администратора
enhanced_admin = Blueprint('enhanced_admin', __name__, url_prefix='/admin/v2')

# Инициализируем защиту от CSRF
csrf = CSRFProtect()

# Контекстный процессор для добавления общих переменных в шаблоны
@enhanced_admin.context_processor
def inject_template_vars():
    """
    Добавляет переменные в контекст шаблона
    """
    context = {
        'now': datetime.now(),
        'app_version': '2.0.0',  # Версия приложения
        'is_admin_authenticated': 'admin_user_id' in session
    }
    
    # Если администратор аутентифицирован, добавляем его данные
    if 'admin_user_id' in session:
        admin_user = AdminUser.query.get(session['admin_user_id'])
        if admin_user:
            context['admin_user'] = admin_user
            context['admin_telegram_id'] = admin_user.telegram_id
            context['admin_role'] = admin_user.role
            context['admin_permissions'] = AdminAuthService.get_admin_permissions(admin_user.id)
    
    return context

# Обработчик ошибок для Blueprint
@enhanced_admin.errorhandler(404)
def page_not_found(e):
    return render_template('enhanced_admin/error.html', error_code=404, error_message="Страница не найдена"), 404

@enhanced_admin.errorhandler(403)
def forbidden(e):
    return render_template('enhanced_admin/error.html', error_code=403, error_message="Доступ запрещен"), 403

@enhanced_admin.errorhandler(500)
def internal_server_error(e):
    logger.error(f"Внутренняя ошибка сервера: {e}")
    return render_template('enhanced_admin/error.html', error_code=500, error_message="Внутренняя ошибка сервера"), 500

# Маршруты авторизации

@enhanced_admin.route('/login', methods=['GET', 'POST'])
def login():
    """
    Страница входа в административную панель
    """
    # Импортируем форму
    from forms import LoginForm
    
    # Создаем экземпляр формы
    form = LoginForm()
    
    # Если администратор уже авторизован, перенаправляем на главную страницу
    if 'admin_user_id' in session:
        return redirect(url_for('enhanced_admin.dashboard'))
    
    # Если форма отправлена и валидна
    if form.validate_on_submit():
        telegram_id = form.telegram_id.data
        password = form.password.data
        remember = form.remember.data
        
        # Аутентифицируем администратора
        admin_user, error = AdminAuthService.authenticate(telegram_id, password)
        
        if error:
            # Если требуется 2FA, сохраняем временный ID админа и перенаправляем на форму 2FA
            if error == "2FA_REQUIRED" and admin_user:
                session['temp_admin_id'] = admin_user.id
                return redirect(url_for('enhanced_admin.verify_2fa'))
            
            # Иначе показываем ошибку
            flash(error, 'danger')
            return render_template('enhanced_admin/login.html', form=form)
        
        # Если администратор успешно аутентифицирован, сохраняем его ID в сессии
        session['admin_user_id'] = admin_user.id
        session['admin_role'] = admin_user.role
        session.permanent = remember  # Используем значение из чекбокса "Запомнить меня"
        
        # Журналируем успешный вход (журналирование уже происходит в AdminAuthService.authenticate)
        
        # Перенаправляем на URL из параметра next или на главную страницу
        next_page = request.args.get('next')
        if not next_page or urlparse(next_page).netloc != '':
            next_page = url_for('enhanced_admin.dashboard')
        
        return redirect(next_page)
    
    # Рендерим страницу входа с формой
    return render_template('enhanced_admin/login.html', form=form)

@enhanced_admin.route('/verify-2fa', methods=['GET', 'POST'])
def verify_2fa():
    """
    Обработка формы двухфакторной аутентификации
    """
    # Импортируем форму
    from forms import Verify2FAForm
    
    # Создаем экземпляр формы
    form = Verify2FAForm()
    
    # Если пользователь уже авторизован, перенаправляем его на дашборд
    if 'admin_user_id' in session and not 'temp_admin_id' in session:
        return redirect(url_for('enhanced_admin.dashboard'))
    
    # Получаем ID администратора из временной сессии
    admin_user_id = session.get('temp_admin_id')
    
    # Если нет ID в сессии, значит пользователь попал сюда напрямую
    if not admin_user_id:
        flash('Сессия истекла. Попробуйте войти заново', 'danger')
        return redirect(url_for('enhanced_admin.login'))
    
    # Устанавливаем admin_id в форму
    form.admin_id.data = str(admin_user_id)
    
    # Если форма отправлена и валидна
    if form.validate_on_submit():
        otp_code = form.code.data
        
        # Проверяем код 2FA
        admin_user, error = AdminAuthService.verify_2fa(admin_user_id, otp_code)
        
        if error:
            flash(error, 'danger')
            return render_template('enhanced_admin/verify_2fa.html', form=form)
        
        # Удаляем временную сессию
        session.pop('temp_admin_id', None)
        
        # Если код верный, сохраняем ID администратора в сессии
        session['admin_user_id'] = admin_user.id
        session['admin_role'] = admin_user.role
        session.permanent = True
        
        # Перенаправляем на URL из параметра next или на главную страницу
        next_page = request.args.get('next')
        if not next_page or urlparse(next_page).netloc != '':
            next_page = url_for('enhanced_admin.dashboard')
        
        return redirect(next_page)
    
    # Если GET-запрос, показываем форму 2FA
    return render_template('enhanced_admin/verify_2fa.html', form=form)

@enhanced_admin.route('/logout')
def logout():
    """
    Выход из административной панели
    """
    # Если администратор авторизован, журналируем выход
    if 'admin_user_id' in session:
        admin_user_id = session['admin_user_id']
        admin_user = AdminUser.query.get(admin_user_id)
        
        if admin_user:
            # Используем ID администратора из модели AdminUser вместо telegram_id
            AdminAuthService.log_admin_action(
                admin_id=admin_user_id,  # Используем ID из таблицы admin_users
                admin_user_id=admin_user.id,
                action_type="logout",
                details="Выход из административной панели",
                ip_address=request.remote_addr,
                user_agent=request.user_agent.string
            )
    
    # Удаляем все ключи сессии, связанные с администратором
    session.pop('admin_user_id', None)
    
    flash('Вы успешно вышли из системы', 'success')
    return redirect(url_for('enhanced_admin.login'))

# Маршруты административной панели

@enhanced_admin.route('/')
@admin_required
def dashboard():
    """
    Главная страница административной панели
    """
    # Получаем статистику для дашборда
    
    # Количество активных пользователей (с подпиской)
    active_users_count = db.session.query(func.count(User.id)).filter(
        User.subscription_expiry > datetime.now()
    ).scalar()
    
    # Общее количество пользователей
    total_users_count = db.session.query(func.count(User.id)).scalar()
    
    # Количество платежей за последние 30 дней
    last_30_days = datetime.now() - timedelta(days=30)
    payments_count = db.session.query(func.count(Transaction.id)).filter(
        Transaction.type == 'subscription',
        Transaction.created_at > last_30_days
    ).scalar()
    
    # Сумма платежей за последние 30 дней
    payments_amount = db.session.query(func.sum(Transaction.amount)).filter(
        Transaction.type == 'subscription',
        Transaction.created_at > last_30_days
    ).scalar() or 0
    
    # Неподтвержденные выплаты
    pending_payouts_count = db.session.query(func.count(WeeklyPayout.id)).filter(
        WeeklyPayout.status == 'pending'
    ).scalar()
    
    # Платежи по дням за последнюю неделю
    last_7_days = datetime.now() - timedelta(days=7)
    daily_payments = db.session.query(
        func.date(Transaction.created_at).label('date'),
        func.count(Transaction.id).label('count'),
        func.sum(Transaction.amount).label('amount')
    ).filter(
        Transaction.type == 'subscription',
        Transaction.created_at > last_7_days
    ).group_by(func.date(Transaction.created_at)).all()
    
    # Преобразуем результаты в формат для графика
    daily_payments_data = {
        'labels': [],
        'counts': [],
        'amounts': []
    }
    
    for day in range(7):
        date = (datetime.now() - timedelta(days=6-day)).date()
        day_data = next((d for d in daily_payments if d.date.strftime('%Y-%m-%d') == date.strftime('%Y-%m-%d')), None)
        
        daily_payments_data['labels'].append(date.strftime('%d.%m'))
        daily_payments_data['counts'].append(day_data.count if day_data else 0)
        daily_payments_data['amounts'].append(float(day_data.amount) if day_data and day_data.amount else 0)
    
    # Получаем последние действия администраторов (для журнала активности)
    admin_logs = AdminActionLog.query.order_by(AdminActionLog.timestamp.desc()).limit(10).all()
    
    # Собираем все данные для отображения на дашборде
    dashboard_data = {
        'active_users_count': active_users_count,
        'total_users_count': total_users_count,
        'payments_count': payments_count,
        'payments_amount': payments_amount,
        'pending_payouts_count': pending_payouts_count,
        'daily_payments_data': daily_payments_data,
        'admin_logs': admin_logs
    }
    
    return render_template('enhanced_admin/dashboard.html', **dashboard_data)

@enhanced_admin.route('/users')
@admin_required
@permission_required('can_view_users')
def users_list():
    """
    Список пользователей с пагинацией и фильтрацией
    """
    # Получаем параметры запроса для пагинации и фильтрации
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    
    # Ограничиваем максимальное количество записей на странице
    if per_page > 100:
        per_page = 100
    
    # Параметры фильтрации
    search_query = request.args.get('q', '')
    filter_subscription = request.args.get('subscription', '')
    
    # Базовый запрос
    query = User.query
    
    # Применяем фильтры
    if search_query:
        query = query.filter(or_(
            User.id.cast(db.String).like(f'%{search_query}%'),
            User.username.like(f'%{search_query}%'),
            User.first_name.like(f'%{search_query}%'),
            User.last_name.like(f'%{search_query}%')
        ))
    
    if filter_subscription == 'active':
        query = query.filter(User.subscription_expiry > datetime.now())
    elif filter_subscription == 'expired':
        query = query.filter(User.subscription_expiry <= datetime.now())
    elif filter_subscription == 'never':
        query = query.filter(User.subscription_expiry == None)
    
    # Применяем пагинацию с таймаутом
    try:
        users_pagination = query.paginate(page=page, per_page=per_page)
    except Exception as e:
        logger.error(f"Error during users pagination: {e}")
        flash('Ошибка при загрузке списка пользователей. Пожалуйста, уточните критерии поиска.', 'danger')
        users_pagination = User.query.limit(per_page).paginate(page=1, per_page=per_page)
    
    return render_template(
        'enhanced_admin/users.html',
        users=users_pagination.items,
        pagination=users_pagination,
        search_query=search_query,
        filter_subscription=filter_subscription
    )

@enhanced_admin.route('/users/<int:user_id>')
@admin_required
@permission_required('can_view_users')
def user_details(user_id):
    """
    Детальная информация о пользователе
    """
    user = User.query.get_or_404(user_id)
    
    # Получаем транзакции пользователя
    transactions = Transaction.query.filter(or_(
        Transaction.user_id == user_id,
        Transaction.related_user_id == user_id
    )).order_by(Transaction.created_at.desc()).limit(100).all()
    
    # Получаем данные о рефералах пользователя
    referrals_data = {
        'level1_count': len(user.referrals_dict.get('level1', [])),
        'level2_count': len(user.referrals_dict.get('level2', [])),
        'level3_count': len(user.referrals_dict.get('level3', [])),
        'level4_count': len(user.referrals_dict.get('level4', [])),
    }
    
    # Получаем прямых рефералов (уровень 1)
    direct_referrals = []
    for ref_id in user.referrals_dict.get('level1', []):
        ref_user = User.query.get(ref_id)
        if ref_user:
            direct_referrals.append(ref_user)
    
    return render_template(
        'enhanced_admin/user_details.html',
        user=user,
        transactions=transactions,
        referrals_data=referrals_data,
        direct_referrals=direct_referrals
    )

@enhanced_admin.route('/user/<int:user_id>/edit', methods=['GET', 'POST'])
@admin_required
@permission_required('can_edit_users')
def edit_user(user_id):
    """
    Редактирование информации о пользователе
    """
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        # Проверяем, что администратор имеет необходимые права
        if not AdminAuthService.has_permission(session['admin_user_id'], 'can_edit_users'):
            flash('У вас нет прав для редактирования пользователей', 'danger')
            return redirect(url_for('enhanced_admin.user_details', user_id=user_id))
        
        # Получаем данные из формы
        subscription_days = request.form.get('subscription_days', type=int)
        free_request_used = request.form.get('free_request_used') == 'on'
        
        # Применяем изменения
        if subscription_days is not None:
            if subscription_days > 0:
                # Продлеваем подписку от текущей даты или от даты окончания, если она еще активна
                if user.subscription_expiry and user.subscription_expiry > datetime.now():
                    user.subscription_expiry = user.subscription_expiry + timedelta(days=subscription_days)
                else:
                    user.subscription_expiry = datetime.now() + timedelta(days=subscription_days)
                
                # Обновляем subscription_end для обратной совместимости
                user.subscription_end = user.subscription_expiry
                
                flash(f'Подписка пользователя продлена на {subscription_days} дней', 'success')
            elif subscription_days < 0:
                # Если подписка активна, уменьшаем срок
                if user.subscription_expiry and user.subscription_expiry > datetime.now():
                    user.subscription_expiry = user.subscription_expiry + timedelta(days=subscription_days)
                    
                    # Если после уменьшения подписка становится просроченной, устанавливаем текущую дату
                    if user.subscription_expiry < datetime.now():
                        user.subscription_expiry = datetime.now()
                    
                    # Обновляем subscription_end для обратной совместимости
                    user.subscription_end = user.subscription_expiry
                    
                    flash(f'Срок подписки пользователя уменьшен на {abs(subscription_days)} дней', 'warning')
        
        # Обновляем флаг использования бесплатного запроса
        user.free_request_used = free_request_used
        
        # Сохраняем изменения
        db.session.commit()
        
        # Логируем действие администратора
        admin_user = AdminUser.query.get(session['admin_user_id'])
        AdminAuthService.log_admin_action(
            admin_id=admin_user.telegram_id,
            admin_user_id=admin_user.id,
            action_type="edit_user",
            details=f"Отредактирован пользователь {user_id}: подписка {'продлена' if subscription_days > 0 else 'уменьшена'} на {abs(subscription_days)} дней, free_request_used={free_request_used}",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
        
        return redirect(url_for('enhanced_admin.user_details', user_id=user_id))
    
    return render_template('enhanced_admin/edit_user.html', user=user)

@enhanced_admin.route('/user/<int:user_id>/block', methods=['GET', 'POST'])
@admin_required
@permission_required('can_edit_users')
def block_user(user_id):
    """
    Блокировка пользователя
    """
    user = User.query.get_or_404(user_id)
    
    # Устанавливаем флаг блокировки (добавим логику в зависимости от структуры данных)
    if hasattr(user, 'is_blocked'):
        user.is_blocked = True
    elif hasattr(user, 'is_active'):
        user.is_active = False
    else:
        # Если нет подходящего атрибута, создаем временное поле
        setattr(user, 'is_blocked', True)
        
    db.session.commit()
    
    # Логируем действие администратора
    admin_user = AdminUser.query.get(session['admin_user_id'])
    AdminAuthService.log_admin_action(
        admin_id=admin_user.telegram_id,
        admin_user_id=admin_user.id,
        action_type="block_user",
        details=f"Блокировка пользователя {user.id} ({user.username})",
        ip_address=request.remote_addr,
        user_agent=request.user_agent.string
    )
    
    flash(f'Пользователь {user.username} заблокирован', 'success')
    return redirect(url_for('enhanced_admin.users_list'))

@enhanced_admin.route('/user/<int:user_id>/unblock', methods=['GET', 'POST'])
@admin_required
@permission_required('can_edit_users')
def unblock_user(user_id):
    """
    Разблокировка пользователя
    """
    user = User.query.get_or_404(user_id)
    
    # Снимаем флаг блокировки
    if hasattr(user, 'is_blocked'):
        user.is_blocked = False
    elif hasattr(user, 'is_active'):
        user.is_active = True
    else:
        # Если нет подходящего атрибута, создаем временное поле
        setattr(user, 'is_blocked', False)
        
    db.session.commit()
    
    # Логируем действие администратора
    admin_user = AdminUser.query.get(session['admin_user_id'])
    AdminAuthService.log_admin_action(
        admin_id=admin_user.telegram_id,
        admin_user_id=admin_user.id,
        action_type="unblock_user",
        details=f"Разблокировка пользователя {user.id} ({user.username})",
        ip_address=request.remote_addr,
        user_agent=request.user_agent.string
    )
    
    flash(f'Пользователь {user.username} разблокирован', 'success')
    return redirect(url_for('enhanced_admin.users_list'))

@enhanced_admin.route('/transactions')
@admin_required
@permission_required('can_view_transactions')
def transactions_list():
    """
    Список транзакций с пагинацией и фильтрацией
    """
    # Получаем параметры запроса для пагинации и фильтрации
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    
    # Ограничиваем максимальное количество записей на странице
    if per_page > 100:
        per_page = 100
    
    # Параметры фильтрации
    search_query = request.args.get('q', '')
    filter_type = request.args.get('type', '')
    filter_status = request.args.get('status', '')
    filter_date_from = request.args.get('date_from', '')
    filter_date_to = request.args.get('date_to', '')
    
    # Базовый запрос
    query = Transaction.query
    
    # Применяем фильтры
    if search_query:
        query = query.filter(or_(
            Transaction.id.cast(db.String).like(f'%{search_query}%'),
            Transaction.user_id.cast(db.String).like(f'%{search_query}%'),
            Transaction.related_user_id.cast(db.String).like(f'%{search_query}%'),
            Transaction.details.like(f'%{search_query}%')
        ))
    
    if filter_type:
        query = query.filter(Transaction.type == filter_type)
    
    if filter_status:
        query = query.filter(Transaction.status == filter_status)
    
    if filter_date_from:
        try:
            date_from = datetime.strptime(filter_date_from, '%Y-%m-%d')
            query = query.filter(Transaction.created_at >= date_from)
        except ValueError:
            flash(f'Некорректный формат даты: {filter_date_from}', 'warning')
    
    if filter_date_to:
        try:
            date_to = datetime.strptime(filter_date_to, '%Y-%m-%d')
            # Добавляем 1 день, чтобы включить весь указанный день
            date_to = date_to + timedelta(days=1)
            query = query.filter(Transaction.created_at <= date_to)
        except ValueError:
            flash(f'Некорректный формат даты: {filter_date_to}', 'warning')
    
    # Сортировка по дате (сначала новые)
    query = query.order_by(Transaction.created_at.desc())
    
    # Применяем пагинацию с таймаутом
    try:
        transactions_pagination = query.paginate(page=page, per_page=per_page)
    except Exception as e:
        logger.error(f"Error during transactions pagination: {e}")
        flash('Ошибка при загрузке списка транзакций. Пожалуйста, уточните критерии поиска.', 'danger')
        transactions_pagination = Transaction.query.limit(per_page).paginate(page=1, per_page=per_page)
    
    return render_template(
        'enhanced_admin/transactions.html',
        transactions=transactions_pagination.items,
        pagination=transactions_pagination,
        search_query=search_query,
        filter_type=filter_type,
        filter_status=filter_status,
        filter_date_from=filter_date_from,
        filter_date_to=filter_date_to,
        transaction_types=['subscription', 'referral_reward', 'payout'],
        transaction_statuses=['pending', 'completed', 'failed', 'cancelled']
    )

@enhanced_admin.route('/payouts')
@admin_required
@permission_required('can_view_transactions')
def payouts_list():
    """
    Список выплат с пагинацией и фильтрацией
    """
    # Получаем параметры запроса для пагинации и фильтрации
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 25, type=int)
    
    # Ограничиваем максимальное количество записей на странице
    if per_page > 50:
        per_page = 50
    
    # Параметры фильтрации
    filter_status = request.args.get('status', '')
    
    # Базовый запрос
    query = WeeklyPayout.query
    
    # Применяем фильтры
    if filter_status:
        query = query.filter(WeeklyPayout.status == filter_status)
    
    # Сортировка по дате (сначала новые)
    query = query.order_by(WeeklyPayout.created_at.desc())
    
    # Применяем пагинацию с таймаутом
    try:
        payouts_pagination = query.paginate(page=page, per_page=per_page)
    except Exception as e:
        logger.error(f"Error during payouts pagination: {e}")
        flash('Ошибка при загрузке списка выплат. Пожалуйста, уточните критерии поиска.', 'danger')
        payouts_pagination = WeeklyPayout.query.limit(per_page).paginate(page=1, per_page=per_page)
    
    return render_template(
        'enhanced_admin/payouts.html',
        payouts=payouts_pagination.items,
        pagination=payouts_pagination,
        filter_status=filter_status,
        payout_statuses=['pending', 'approved', 'processed', 'failed', 'cancelled']
    )

@enhanced_admin.route('/payouts/<int:payout_id>')
@admin_required
@permission_required('can_view_transactions')
def payout_details(payout_id):
    """
    Детальная информация о выплате
    """
    payout = WeeklyPayout.query.get_or_404(payout_id)
    
    # Получаем связанные транзакции
    transactions = []
    if payout.transactions:
        transactions = payout.transactions
    else:
        # Для обратной совместимости, если связь не установлена
        # Ищем транзакции по weekly_payout_id
        transactions = Transaction.query.filter_by(weekly_payout_id=payout_id).all()
    
    return render_template(
        'enhanced_admin/payout_details.html',
        payout=payout,
        transactions=transactions
    )

@enhanced_admin.route('/payouts/<int:payout_id>/approve', methods=['POST'])
@admin_required
@permission_required('can_approve_payouts')
def approve_payout(payout_id):
    """
    Подтверждение выплаты
    """
    payout = WeeklyPayout.query.get_or_404(payout_id)
    
    # Проверяем, что выплата в статусе "pending"
    if payout.status != 'pending':
        flash(f'Невозможно подтвердить выплату в статусе "{payout.status}"', 'danger')
        return redirect(url_for('enhanced_admin.payout_details', payout_id=payout_id))
    
    # Подтверждаем выплату
    payout.status = 'approved'
    payout.approved_at = datetime.now()
    
    # Если установлен admin_id для обратной совместимости, используем его
    if not payout.admin_id:
        admin_user = AdminUser.query.get(session['admin_user_id'])
        payout.admin_id = admin_user.telegram_id
    
    db.session.commit()
    
    # Логируем действие администратора
    admin_user = AdminUser.query.get(session['admin_user_id'])
    AdminAuthService.log_admin_action(
        admin_id=admin_user.telegram_id,
        admin_user_id=admin_user.id,
        action_type="approve_payout",
        details=f"Подтверждена выплата #{payout_id} на сумму {payout.amount} руб. для пользователя {payout.user_id}",
        ip_address=request.remote_addr,
        user_agent=request.user_agent.string
    )
    
    flash(f'Выплата #{payout_id} успешно подтверждена', 'success')
    return redirect(url_for('enhanced_admin.payout_details', payout_id=payout_id))

@enhanced_admin.route('/payouts/<int:payout_id>/process', methods=['POST'])
@admin_required
@permission_required('can_process_payouts')
def process_payout(payout_id):
    """
    Обработка выплаты (отметка как выполненная)
    """
    payout = WeeklyPayout.query.get_or_404(payout_id)
    
    # Проверяем, что выплата в статусе "approved"
    if payout.status != 'approved':
        flash(f'Невозможно обработать выплату в статусе "{payout.status}"', 'danger')
        return redirect(url_for('enhanced_admin.payout_details', payout_id=payout_id))
    
    # Обрабатываем выплату
    payout.status = 'processed'
    payout.processed_at = datetime.now()
    
    # Если установлен admin_id для обратной совместимости, используем его
    if not payout.admin_id:
        admin_user = AdminUser.query.get(session['admin_user_id'])
        payout.admin_id = admin_user.telegram_id
    
    db.session.commit()
    
    # Логируем действие администратора
    admin_user = AdminUser.query.get(session['admin_user_id'])
    AdminAuthService.log_admin_action(
        admin_id=admin_user.telegram_id,
        admin_user_id=admin_user.id,
        action_type="process_payout",
        details=f"Обработана выплата #{payout_id} на сумму {payout.amount} руб. для пользователя {payout.user_id}",
        ip_address=request.remote_addr,
        user_agent=request.user_agent.string
    )
    
    flash(f'Выплата #{payout_id} успешно обработана', 'success')
    return redirect(url_for('enhanced_admin.payout_details', payout_id=payout_id))

@enhanced_admin.route('/payouts/<int:payout_id>/cancel', methods=['POST'])
@admin_required
@permission_required('can_approve_payouts')
def cancel_payout(payout_id):
    """
    Отмена выплаты
    """
    payout = WeeklyPayout.query.get_or_404(payout_id)
    
    # Проверяем, что выплата не в финальном статусе
    if payout.status in ['processed', 'cancelled']:
        flash(f'Невозможно отменить выплату в статусе "{payout.status}"', 'danger')
        return redirect(url_for('enhanced_admin.payout_details', payout_id=payout_id))
    
    # Отменяем выплату
    payout.status = 'cancelled'
    payout.updated_at = datetime.now()
    
    db.session.commit()
    
    # Логируем действие администратора
    admin_user = AdminUser.query.get(session['admin_user_id'])
    AdminAuthService.log_admin_action(
        admin_id=admin_user.telegram_id,
        admin_user_id=admin_user.id,
        action_type="cancel_payout",
        details=f"Отменена выплата #{payout_id} на сумму {payout.amount} руб. для пользователя {payout.user_id}",
        ip_address=request.remote_addr,
        user_agent=request.user_agent.string
    )
    
    flash(f'Выплата #{payout_id} отменена', 'warning')
    return redirect(url_for('enhanced_admin.payout_details', payout_id=payout_id))

@enhanced_admin.route('/activity-log')
@admin_required
@permission_required('can_view_logs')
def activity_log():
    """
    Журнал активности администраторов
    """
    # Получаем параметры запроса для пагинации и фильтрации
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    
    # Ограничиваем максимальное количество записей на странице
    if per_page > 100:
        per_page = 100
    
    # Параметры фильтрации
    admin_id = request.args.get('admin_id', '')
    action_type = request.args.get('action_type', '')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    # Базовый запрос
    query = AdminActionLog.query
    
    # Применяем фильтры
    if admin_id:
        try:
            admin_id_int = int(admin_id)
            query = query.filter(AdminActionLog.admin_id == admin_id_int)
        except ValueError:
            flash(f'Некорректный ID администратора: {admin_id}', 'warning')
    
    if action_type:
        query = query.filter(AdminActionLog.action_type == action_type)
    
    if date_from:
        try:
            date_from_dt = datetime.strptime(date_from, '%Y-%m-%d')
            query = query.filter(AdminActionLog.timestamp >= date_from_dt)
        except ValueError:
            flash(f'Некорректный формат даты: {date_from}', 'warning')
    
    if date_to:
        try:
            date_to_dt = datetime.strptime(date_to, '%Y-%m-%d')
            # Добавляем 1 день, чтобы включить весь указанный день
            date_to_dt = date_to_dt + timedelta(days=1)
            query = query.filter(AdminActionLog.timestamp <= date_to_dt)
        except ValueError:
            flash(f'Некорректный формат даты: {date_to}', 'warning')
    
    # Сортировка по дате (сначала новые)
    query = query.order_by(AdminActionLog.timestamp.desc())
    
    # Применяем пагинацию с таймаутом
    try:
        logs_pagination = query.paginate(page=page, per_page=per_page)
    except Exception as e:
        logger.error(f"Error during activity logs pagination: {e}")
        flash('Ошибка при загрузке журнала активности. Пожалуйста, уточните критерии поиска.', 'danger')
        logs_pagination = AdminActionLog.query.limit(per_page).paginate(page=1, per_page=per_page)
    
    # Получаем уникальные типы действий для фильтра
    action_types = db.session.query(AdminActionLog.action_type).distinct().all()
    action_types = [a[0] for a in action_types]
    
    # Получаем уникальные ID администраторов для фильтра
    admin_ids = db.session.query(AdminActionLog.admin_id).distinct().all()
    admin_ids = [a[0] for a in admin_ids]
    
    # Создаем словарь администраторов для отображения имен
    admins = {}
    for aid in admin_ids:
        user = User.query.get(aid)
        if user:
            admins[aid] = user.username or f"User #{aid}"
        else:
            admins[aid] = f"Unknown Admin #{aid}"
    
    return render_template(
        'enhanced_admin/activity_log.html',
        logs=logs_pagination,
        admin_id=admin_id,
        action_type=action_type,
        date_from=date_from,
        date_to=date_to,
        action_types=action_types,
        admin_ids=admin_ids,
        admins=admins
    )

@enhanced_admin.route('/reports')
@admin_required
@permission_required('can_view_reports')
def reports():
    """
    Страница с отчетами
    """
    return render_template('enhanced_admin/reports.html')

@enhanced_admin.route('/reports/download/<string:report_id>', methods=['GET'])
@admin_required
@permission_required('can_view_reports')
def download_report(report_id):
    """
    Скачивание готового отчета
    
    Args:
        report_id: ID отчета для скачивания
        
    Returns:
        Файл отчета или ошибку, если отчет не готов
    """
    try:
        # Получаем информацию о прогрессе отчета
        progress_data = get_report_progress(report_id)
        
        # Если отчет не найден
        if not progress_data:
            flash('Отчет не найден', 'danger')
            return redirect(url_for('enhanced_admin.reports'))
            
        # Если отчет не завершен
        if progress_data.get('progress', 0) < 100:
            flash('Отчет еще не готов для скачивания', 'warning')
            return redirect(url_for('enhanced_admin.reports'))
            
        # Определяем формат отчета и настраиваем MIME-тип
        format_type = progress_data.get('format_type', 'pdf')
        mime_types = {
            'pdf': 'application/pdf',
            'excel': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'csv': 'text/csv',
            'json': 'application/json'
        }
        mime_type = mime_types.get(format_type, 'application/octet-stream')
        
        # Логируем скачивание отчета
        admin_user = AdminUser.query.get(session['admin_user_id'])
        AdminAuthService.log_admin_action(
            admin_id=admin_user.telegram_id,
            admin_user_id=admin_user.id,
            action_type="download_report",
            details=f"Скачивание отчета {report_id}",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
        
        # В реальном приложении здесь будет загрузка файла из хранилища
        # (базы данных, файловой системы, облачного хранилища и т.д.)
        # Для демонстрации создаем простой файл в памяти
        
        # Имитируем содержимое отчета в соответствии с форматом
        if format_type == 'pdf':
            # Создаем простой PDF в памяти
            from reportlab.pdfgen import canvas
            from io import BytesIO
            
            buffer = BytesIO()
            p = canvas.Canvas(buffer)
            p.drawString(100, 800, f"Демонстрационный отчет {report_id}")
            p.drawString(100, 780, f"Сгенерирован: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            p.drawString(100, 760, "Это тестовый отчет для демонстрации функциональности.")
            p.save()
            buffer.seek(0)
            
            report_filename = f"report_{report_id}.pdf"
            return send_file(
                buffer, 
                download_name=report_filename,
                as_attachment=True,
                mimetype=mime_type
            )
            
        elif format_type == 'excel':
            # Имитируем Excel-файл
            import xlsxwriter
            from io import BytesIO
            
            buffer = BytesIO()
            workbook = xlsxwriter.Workbook(buffer)
            worksheet = workbook.add_worksheet()
            
            worksheet.write(0, 0, "ID отчета")
            worksheet.write(0, 1, report_id)
            worksheet.write(1, 0, "Дата генерации")
            worksheet.write(1, 1, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            worksheet.write(2, 0, "Описание")
            worksheet.write(2, 1, "Это тестовый отчет для демонстрации функциональности.")
            
            workbook.close()
            buffer.seek(0)
            
            report_filename = f"report_{report_id}.xlsx"
            return send_file(
                buffer, 
                download_name=report_filename,
                as_attachment=True,
                mimetype=mime_type
            )
            
        elif format_type == 'json':
            # Имитируем JSON-файл
            import json
            from io import BytesIO
            
            data = {
                "report_id": report_id,
                "generated_at": datetime.now().isoformat(),
                "description": "Это тестовый отчет для демонстрации функциональности.",
                "data": {
                    "items": [
                        {"id": 1, "name": "Тестовый элемент 1", "value": 100},
                        {"id": 2, "name": "Тестовый элемент 2", "value": 200},
                        {"id": 3, "name": "Тестовый элемент 3", "value": 300},
                    ]
                }
            }
            
            buffer = BytesIO()
            buffer.write(json.dumps(data, indent=2, ensure_ascii=False).encode('utf-8'))
            buffer.seek(0)
            
            report_filename = f"report_{report_id}.json"
            return send_file(
                buffer, 
                download_name=report_filename,
                as_attachment=True,
                mimetype=mime_type
            )
            
        else:
            # Для неизвестных форматов возвращаем текстовый файл
            from io import BytesIO
            
            buffer = BytesIO()
            buffer.write(f"Демонстрационный отчет {report_id}\n".encode('utf-8'))
            buffer.write(f"Сгенерирован: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n".encode('utf-8'))
            buffer.write("Это тестовый отчет для демонстрации функциональности.\n".encode('utf-8'))
            buffer.seek(0)
            
            report_filename = f"report_{report_id}.txt"
            return send_file(
                buffer, 
                download_name=report_filename,
                as_attachment=True,
                mimetype='text/plain'
            )
            
    except Exception as e:
        logger.error(f"Error downloading report {report_id}: {e}")
        flash(f'Ошибка при скачивании отчета: {str(e)}', 'danger')
        return redirect(url_for('enhanced_admin.reports'))

@enhanced_admin.route('/api/report-progress/<string:report_id>', methods=['GET'])
@admin_required
def report_progress_api(report_id):
    """
    API для получения статуса формирования отчета
    
    Args:
        report_id: ID отчета для проверки прогресса
        
    Returns:
        JSON с информацией о прогрессе отчета
    """
    try:
        progress_data = get_report_progress(report_id)
        
        # Если отчет не найден
        if not progress_data:
            return jsonify({
                'success': False,
                'error': 'Отчет не найден',
                'progress': 0,
                'status': 'Ошибка: отчет не найден'
            }), 404
            
        return jsonify({
            'success': True,
            'progress': progress_data.get('progress', 0),
            'status': progress_data.get('status', 'Формирование отчета...'),
            'complete': progress_data.get('progress', 0) >= 100,
            'download_url': url_for('enhanced_admin.download_report', report_id=report_id) if progress_data.get('progress', 0) >= 100 else None,
            'report_id': report_id,
            'format_type': progress_data.get('format_type', 'pdf')
        })
        
    except Exception as e:
        logger.error(f"Error getting report progress for {report_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'progress': 0,
            'status': 'Ошибка при получении статуса отчета'
        }), 500

@enhanced_admin.route('/generate-report', methods=['POST'])
@admin_required
@permission_required('can_view_reports')
def generate_report():
    """
    Генерация отчета
    """
    report_type = request.form.get('report_type')
    format_type = request.form.get('format_type', 'pdf')
    date_from = request.form.get('date_from')
    date_to = request.form.get('date_to')
    
    if not report_type:
        flash('Необходимо указать тип отчета', 'danger')
        return redirect(url_for('enhanced_admin.reports'))
    
    # Преобразуем даты
    try:
        if date_from:
            date_from = datetime.strptime(date_from, '%Y-%m-%d')
        else:
            date_from = datetime.now() - timedelta(days=30)
        
        if date_to:
            date_to = datetime.strptime(date_to, '%Y-%m-%d')
            # Добавляем 1 день, чтобы включить весь указанный день
            date_to = date_to + timedelta(days=1)
        else:
            date_to = datetime.now()
    except ValueError:
        flash('Некорректный формат даты', 'danger')
        return redirect(url_for('enhanced_admin.reports'))
    
    # Подготавливаем параметры отчета
    report_params = {
        'date_from': date_from.strftime('%Y-%m-%d'),
        'date_to': date_to.strftime('%Y-%m-%d'),
        'period': request.form.get('period', 'custom')
    }
    
    # Получаем пользователя администратора
    admin_user = AdminUser.query.get(session['admin_user_id'])
    
    try:
        # Запускаем асинхронную генерацию отчета
        report_id = start_report_generation(
            report_type=report_type,
            format_type=format_type,
            params=report_params,
            admin_id=admin_user.telegram_id
        )
        
        # Логируем запуск генерации отчета
        AdminAuthService.log_admin_action(
            admin_id=admin_user.telegram_id,
            admin_user_id=admin_user.id,
            action_type="generate_report",
            details=f"Запущена генерация отчета типа '{report_type}' в формате '{format_type}' за период {date_from.strftime('%Y-%m-%d')} - {date_to.strftime('%Y-%m-%d')}. ID отчета: {report_id}",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
        
        # В реальности здесь можно добавить ссылку на страницу для отслеживания прогресса
        flash(f'Отчет типа "{report_type}" поставлен в очередь на генерацию. ID: {report_id}', 'success')
        
        # Возвращаем JSON с ID отчета для обработки асинхронной генерации
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({
                'success': True,
                'message': 'Отчет поставлен в очередь на генерацию',
                'report_id': report_id
            })
        
        return redirect(url_for('enhanced_admin.reports'))
        
    except Exception as e:
        logger.error(f"Error starting report generation: {e}")
        
        # Логируем ошибку
        AdminAuthService.log_admin_action(
            admin_id=admin_user.telegram_id,
            admin_user_id=admin_user.id,
            action_type="generate_report_error",
            details=f"Ошибка при запуске генерации отчета типа '{report_type}': {str(e)}",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
        
        flash(f'Ошибка при запуске генерации отчета: {str(e)}', 'danger')
        
        # Если AJAX-запрос, возвращаем JSON с ошибкой
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
            
        return redirect(url_for('enhanced_admin.reports'))

@enhanced_admin.route('/admin-settings')
@admin_required
@permission_required('can_manage_admins')
def admin_settings():
    """
    Настройки администраторов
    """
    # Получаем список всех администраторов
    admin_users = AdminUser.query.all()
    
    return render_template('enhanced_admin/admin_settings.html', admin_users=admin_users)

@enhanced_admin.route('/admin-settings/create', methods=['POST'])
@admin_required
@permission_required('can_manage_admins')
def create_admin():
    """
    Создание нового администратора
    """
    telegram_id = request.form.get('telegram_id')
    password = request.form.get('password')
    role = request.form.get('role')
    
    if not telegram_id or not password or not role:
        flash('Необходимо указать Telegram ID, пароль и роль', 'danger')
        return redirect(url_for('enhanced_admin.admin_settings'))
    
    try:
        telegram_id = int(telegram_id)
    except ValueError:
        flash('Telegram ID должен быть числовым значением', 'danger')
        return redirect(url_for('enhanced_admin.admin_settings'))
    
    # Создаем нового администратора
    admin_user, error = AdminAuthService.create_admin_user(telegram_id, password, role)
    
    if error:
        flash(error, 'danger')
    else:
        flash(f'Администратор с Telegram ID {telegram_id} успешно создан', 'success')
    
    return redirect(url_for('enhanced_admin.admin_settings'))

@enhanced_admin.route('/admin-settings/<int:admin_user_id>/edit', methods=['POST'])
@admin_required
@permission_required('can_manage_admins')
def edit_admin(admin_user_id):
    """
    Редактирование администратора
    """
    role = request.form.get('role')
    is_active = request.form.get('is_active') == 'on'
    
    # Обновляем данные администратора
    admin_user, error = AdminAuthService.update_admin_user(admin_user_id, role, is_active)
    
    if error:
        flash(error, 'danger')
    else:
        flash(f'Данные администратора #{admin_user_id} успешно обновлены', 'success')
    
    return redirect(url_for('enhanced_admin.admin_settings'))
    
@enhanced_admin.route('/admin-settings/<int:admin_user_id>/delete', methods=['POST'])
@admin_required
@permission_required('can_manage_admins')
def delete_admin(admin_user_id):
    """
    Удаление администратора
    """
    # Получаем текущего администратора
    current_admin_user_id = session.get('admin_user_id')
    
    # Нельзя удалить самого себя
    if int(admin_user_id) == int(current_admin_user_id):
        flash('Вы не можете удалить собственную учетную запись', 'danger')
        return redirect(url_for('enhanced_admin.admin_settings'))
    
    # Удаляем администратора
    admin_user = AdminUser.query.get(admin_user_id)
    if not admin_user:
        flash('Администратор не найден', 'danger')
        return redirect(url_for('enhanced_admin.admin_settings'))
    
    # Записываем имя администратора для вывода сообщения
    admin_name = f"{admin_user.telegram_id}"
    
    try:
        db.session.delete(admin_user)
        db.session.commit()
        flash(f'Администратор {admin_name} успешно удален', 'success')
        
        # Логируем действие
        AdminAuthService.log_admin_action(
            admin_id=session.get('admin_user_id'),
            action=f"Удален администратор {admin_name}",
            entity_type="admin_user",
            entity_id=admin_user_id
        )
    except Exception as e:
        db.session.rollback()
        logger.error(f"Ошибка при удалении администратора {admin_user_id}: {e}")
        flash(f'Ошибка при удалении администратора: {e}', 'danger')
    
    return redirect(url_for('enhanced_admin.admin_settings'))

@enhanced_admin.route('/profile')
@admin_required
def profile():
    """
    Профиль текущего администратора
    """
    admin_user = AdminUser.query.get(session['admin_user_id'])
    
    return render_template('enhanced_admin/profile.html', admin=admin_user)

@enhanced_admin.route('/profile/change-password', methods=['POST'])
@admin_required
def change_password():
    """
    Изменение пароля текущего администратора
    """
    current_password = request.form.get('current_password')
    new_password = request.form.get('new_password')
    confirm_password = request.form.get('confirm_password')
    
    if not current_password or not new_password or not confirm_password:
        flash('Необходимо заполнить все поля', 'danger')
        return redirect(url_for('enhanced_admin.profile'))
    
    if new_password != confirm_password:
        flash('Новый пароль и подтверждение не совпадают', 'danger')
        return redirect(url_for('enhanced_admin.profile'))
    
    # Изменяем пароль
    success, error = AdminAuthService.change_password(session['admin_user_id'], current_password, new_password)
    
    if not success:
        flash(error, 'danger')
    else:
        flash('Пароль успешно изменен', 'success')
    
    return redirect(url_for('enhanced_admin.profile'))

@enhanced_admin.route('/profile/setup-2fa', methods=['GET', 'POST'])
@admin_required
def setup_2fa():
    """
    Настройка двухфакторной аутентификации
    """
    admin_user_id = session['admin_user_id']
    
    if request.method == 'POST':
        otp_code = request.form.get('otp_code')
        
        if not otp_code:
            flash('Необходимо указать код подтверждения', 'danger')
            return redirect(url_for('enhanced_admin.setup_2fa'))
        
        # Подтверждаем настройку 2FA
        success, error = AdminAuthService.confirm_2fa(admin_user_id, otp_code)
        
        if not success:
            flash(error, 'danger')
            return redirect(url_for('enhanced_admin.setup_2fa'))
        
        flash('Двухфакторная аутентификация успешно настроена', 'success')
        return redirect(url_for('enhanced_admin.profile'))
    
    # Генерируем QR-код для настройки 2FA
    qr_code, secret, error = AdminAuthService.setup_2fa(admin_user_id)
    
    if error:
        flash(error, 'danger')
        return redirect(url_for('enhanced_admin.profile'))
    
    # Преобразуем QR-код в Data URL для отображения на странице
    import base64
    qr_base64 = base64.b64encode(qr_code.getvalue()).decode('utf-8')
    
    return render_template('enhanced_admin/setup_2fa.html', qr_code=qr_base64, secret=secret)

@enhanced_admin.route('/profile/disable-2fa', methods=['POST'])
@admin_required
def disable_2fa():
    """
    Отключение двухфакторной аутентификации
    """
    admin_user_id = session['admin_user_id']
    password = request.form.get('password')
    
    if not password:
        flash('Необходимо указать пароль', 'danger')
        return redirect(url_for('enhanced_admin.profile'))
    
    # Отключаем 2FA
    success, error = AdminAuthService.disable_2fa(admin_user_id, password)
    
    if not success:
        flash(error, 'danger')
    else:
        flash('Двухфакторная аутентификация отключена', 'success')
    
    return redirect(url_for('enhanced_admin.profile'))

@enhanced_admin.route('/system-info')
@admin_required
@permission_required('can_access_system_settings')
def system_info():
    """
    Информация о системе
    """
    # Получаем статистику системы
    stats = {
        'users_count': db.session.query(func.count(User.id)).scalar(),
        'active_subscriptions': db.session.query(func.count(User.id)).filter(User.subscription_expiry > datetime.now()).scalar(),
        'transactions_count': db.session.query(func.count(Transaction.id)).scalar(),
        'pending_payouts': db.session.query(func.count(WeeklyPayout.id)).filter(WeeklyPayout.status == 'pending').scalar()
    }
    
    # Получаем информацию о системе
    python_version = os.popen('python --version').read().strip()
    flask_version = os.popen('pip show flask | grep Version').read().strip()
    sqlalchemy_version = os.popen('pip show sqlalchemy | grep Version').read().strip()
    uptime = os.popen('uptime').read().strip()
    
    # Пытаемся получить версию python-telegram-bot
    telegram_bot_version = os.popen('pip show python-telegram-bot | grep Version').read().strip()
    
    # Получаем информацию об ОС
    os_info = os.popen('uname -a').read().strip()
    
    # Информация о CPU и памяти (примерно)
    try:
        cpu_usage = os.popen("top -bn1 | grep 'Cpu(s)' | awk '{print $2 + $4}'").read().strip()
        cpu_usage = float(cpu_usage) if cpu_usage else 0
    except:
        cpu_usage = 0
        
    try:
        memory_usage = os.popen("free | grep Mem | awk '{print $3/$2 * 100.0}'").read().strip()
        memory_usage = float(memory_usage) if memory_usage else 0
    except:
        memory_usage = 0
    
    # Информация о сервере
    server_address = request.host
    start_time = datetime.now() - timedelta(seconds=int(os.popen('cat /proc/uptime').read().split()[0].split('.')[0]))
    start_time = start_time.strftime('%Y-%m-%d %H:%M:%S')
    
    # Получаем статусы сервисов
    services = [
        {
            'name': 'Telegram Bot',
            'status': 'running',
            'uptime': uptime
        },
        {
            'name': 'Web Server',
            'status': 'running',
            'uptime': uptime
        },
        {
            'name': 'Database',
            'status': 'running',
            'uptime': uptime
        }
    ]
    
    # Получаем последние строки логов
    logs = []
    log_dir = os.path.join(os.getcwd(), 'logs')
    for log_file in os.listdir(log_dir):
        if log_file.endswith('.log'):
            file_path = os.path.join(log_dir, log_file)
            try:
                # Получаем последние 100 строк каждого лог-файла
                with open(file_path, 'r') as f:
                    lines = f.readlines()[-100:]
                    for line in lines:
                        logs.append(f"{log_file}: {line.strip()}")
            except Exception as e:
                logs.append(f"Ошибка чтения {log_file}: {str(e)}")
    
    # Сортируем логи по времени (наиболее новые сверху)
    logs.sort(reverse=True)
    
    # Ограничиваем количество строк в логах
    logs = logs[:100]
    
    # Получаем информацию о версии системы
    system_version = "1.2.0"  # Предположим, это текущая версия
    
    admin_id = session.get('admin_user_id')
    if admin_id:
        AdminAuthService.log_admin_action(
            admin_id=admin_id,
            admin_user_id=admin_id,
            action_type='view_system_info',
            details='Просмотр информации о системе',
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
    
    return render_template(
        'enhanced_admin/system_info.html', 
        stats=stats,
        python_version=python_version,
        flask_version=flask_version,
        sqlalchemy_version=sqlalchemy_version,
        uptime=uptime,
        telegram_bot_version=telegram_bot_version,
        os_info=os_info,
        cpu_usage=cpu_usage,
        memory_usage=memory_usage,
        server_address=server_address,
        start_time=start_time,
        services=services,
        logs=logs,
        system_version=system_version
    )

@enhanced_admin.route('/verify-logs')
@admin_required
@permission_required('can_view_logs')
def verify_logs():
    """
    Проверка целостности логов
    """
    # Получаем результаты проверки целостности логов
    integrity_results = AdminAuthService.verify_admin_log_integrity()
    
    # Получаем объекты логов для отображения полной информации
    log_ids = list(integrity_results.keys())
    logs = AdminActionLog.query.filter(AdminActionLog.id.in_(log_ids)).all() if log_ids else []
    
    # Подсчитываем статистику
    intact_count = sum(1 for is_intact in integrity_results.values() if is_intact)
    modified_count = len(integrity_results) - intact_count
    
    # Создаем объект для шаблона с полной информацией о логах и статусе проверки
    logs_with_status = []
    for log in logs:
        is_intact = integrity_results.get(log.id, False)
        logs_with_status.append({
            'log': log,
            'is_intact': is_intact,
            'status_class': 'success' if is_intact else 'danger',
            'status_text': 'Верифицирован' if is_intact else 'Модифицирован'
        })
    
    # Логируем действие
    admin_id = session.get('admin_user_id')
    if admin_id:
        AdminAuthService.log_admin_action(
            admin_id=admin_id,
            admin_user_id=admin_id,
            action_type="verify_logs",
            details=f"Проверка целостности логов: {intact_count} верифицировано, {modified_count} модифицировано",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
    
    return render_template(
        'enhanced_admin/verify_logs.html',
        logs=logs_with_status,
        intact_count=intact_count,
        modified_count=modified_count,
        total_count=len(integrity_results)
    )
    
@enhanced_admin.route('/download-logs')
@admin_required
@permission_required('can_view_logs')
def download_logs():
    """
    Скачивание файлов логов
    """
    # Создаем zip-архив в памяти
    memory_file = BytesIO()
    with zipfile.ZipFile(memory_file, 'w') as zf:
        log_dir = os.path.join(os.getcwd(), 'logs')
        
        # Добавляем все логи в архив
        for filename in os.listdir(log_dir):
            if filename.endswith('.log'):
                file_path = os.path.join(log_dir, filename)
                zf.write(file_path, arcname=filename)
    
    # Перемещаем указатель в начало файла
    memory_file.seek(0)
    
    # Логируем действие
    admin_id = session.get('admin_user_id')
    if admin_id:
        AdminAuthService.log_admin_action(
            admin_id=admin_id,
            admin_user_id=admin_id,
            action_type='download_logs',
            details="Скачивание файлов логов",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
    
    return send_file(
        memory_file,
        mimetype='application/zip',
        as_attachment=True,
        download_name='system_logs.zip'
    )

@enhanced_admin.route('/clear-logs', methods=['POST'])
@admin_required
@permission_required('can_manage_logs')
def clear_logs():
    """
    Очистка логов системы
    """
    # Проверяем подтверждение
    confirm = request.form.get('confirm')
    if not confirm or confirm.lower() != 'yes':
        flash('Операция отменена: требуется подтверждение', 'warning')
        return redirect(url_for('enhanced_admin.system_info'))
    
    # Архивируем текущие логи
    log_dir = os.path.join(os.getcwd(), 'logs')
    archive_dir = os.path.join(log_dir, 'archives')
    os.makedirs(archive_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
    archive_path = os.path.join(archive_dir, f'logs_backup_{timestamp}.zip')
    
    # Создаем архив
    with zipfile.ZipFile(archive_path, 'w') as zf:
        for filename in os.listdir(log_dir):
            if filename.endswith('.log'):
                file_path = os.path.join(log_dir, filename)
                zf.write(file_path, arcname=filename)
                
                # Очищаем содержимое файла
                with open(file_path, 'w') as f:
                    f.write(f"# Log file cleared by admin {session.get('admin_user_id')} at {datetime.now()}\n")
    
    # Логируем действие
    admin_id = session.get('admin_user_id')
    if admin_id:
        AdminAuthService.log_admin_action(
            admin_id=admin_id,
            admin_user_id=admin_id,
            action_type='clear_logs',
            details=f"Очистка логов системы. Архив сохранен как {archive_path}",
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string
        )
    
    flash('Логи успешно очищены и архивированы', 'success')
    return redirect(url_for('enhanced_admin.system_info'))