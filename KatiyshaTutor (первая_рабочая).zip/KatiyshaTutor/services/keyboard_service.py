#!/usr/bin/env python
# coding: utf-8

"""
Сервис для создания адаптивных клавиатур в зависимости от платформы пользователя
"""

import logging
from typing import List, Dict, Any, Optional, Union
from telegram import ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton

from services.platform_detection_service import (
    PLATFORM_IOS, PLATFORM_ANDROID, PLATFORM_DESKTOP, PLATFORM_WEB, PLATFORM_UNKNOWN
)
from services.platform_data_service import get_keyboard_settings, get_emoji

logger = logging.getLogger(__name__)

def create_adaptive_reply_keyboard(
    buttons: List[List[str]], 
    platform_type: str = PLATFORM_UNKNOWN,
    platform_version: Optional[str] = None,
    resize_keyboard: bool = True,
    one_time_keyboard: bool = False,
    selective: bool = False
) -> ReplyKeyboardMarkup:
    """
    Создает адаптивную клавиатуру с учетом платформы пользователя
    
    Args:
        buttons: Двумерный список кнопок ([["Кнопка 1", "Кнопка 2"], ["Кнопка 3"]])
        platform_type: Тип платформы пользователя
        platform_version: Версия платформы
        resize_keyboard: Флаг изменения размера клавиатуры
        one_time_keyboard: Флаг одноразовой клавиатуры
        selective: Флаг выборочного отображения клавиатуры
        
    Returns:
        ReplyKeyboardMarkup: Адаптированная клавиатура для указанной платформы
    """
    # Получаем настройки клавиатуры для платформы
    keyboard_settings = get_keyboard_settings(platform_type, platform_version)
    max_buttons_per_row = keyboard_settings.get("max_buttons_per_row", 3)
    
    # Адаптируем расположение кнопок
    adapted_buttons = []
    
    for row in buttons:
        # Если в ряду больше кнопок, чем максимально допустимо для платформы, разбиваем на несколько рядов
        if len(row) > max_buttons_per_row:
            # Разбиваем ряд на подряды нужной длины
            for i in range(0, len(row), max_buttons_per_row):
                adapted_buttons.append(row[i:i + max_buttons_per_row])
        else:
            adapted_buttons.append(row)
    
    # Логируем адаптацию, если она произошла
    if adapted_buttons != buttons:
        logger.debug(f"Keyboard adapted for {platform_type} v{platform_version}: Changed button layout")
    
    return ReplyKeyboardMarkup(
        keyboard=adapted_buttons,
        resize_keyboard=resize_keyboard,
        one_time_keyboard=one_time_keyboard,
        selective=selective
    )

def create_adaptive_inline_keyboard(
    buttons: List[List[Dict[str, str]]], 
    platform_type: str = PLATFORM_UNKNOWN,
    platform_version: Optional[str] = None
) -> InlineKeyboardMarkup:
    """
    Создает адаптивную inline-клавиатуру с учетом платформы пользователя
    
    Args:
        buttons: Список рядов с кнопками, где каждая кнопка - словарь с ключами 'text' и 'callback_data'
        platform_type: Тип платформы пользователя
        platform_version: Версия платформы пользователя
        
    Returns:
        InlineKeyboardMarkup: Адаптированная inline-клавиатура
    """
    # Получаем настройки клавиатуры для платформы
    keyboard_settings = get_keyboard_settings(platform_type, platform_version)
    max_buttons_per_row = keyboard_settings.get("max_buttons_per_row", 3)
    button_width = keyboard_settings.get("button_width", "normal")
    
    # Конвертируем словари кнопок в объекты InlineKeyboardButton
    keyboard_buttons = []
    
    for row in buttons:
        button_row = []
        
        # Если в ряду больше кнопок, чем максимально допустимо для платформы, разбиваем на несколько рядов
        if len(row) > max_buttons_per_row:
            button_batches = []
            
            # Разбиваем ряд на подряды нужной длины
            for i in range(0, len(row), max_buttons_per_row):
                batch = row[i:i + max_buttons_per_row]
                processed_batch = []
                
                for button_data in batch:
                    text = button_data.get('text', '')
                    callback_data = button_data.get('callback_data', '')
                    url = button_data.get('url')
                    
                    # Создаем кнопку в зависимости от наличия URL
                    if url:
                        processed_batch.append(InlineKeyboardButton(text=text, url=url))
                    else:
                        processed_batch.append(InlineKeyboardButton(text=text, callback_data=callback_data))
                
                button_batches.append(processed_batch)
            
            keyboard_buttons.extend(button_batches)
        else:
            # Обрабатываем ряд, если он не превышает максимальное количество кнопок
            for button_data in row:
                text = button_data.get('text', '')
                callback_data = button_data.get('callback_data', '')
                url = button_data.get('url')
                
                # Создаем кнопку в зависимости от наличия URL
                if url:
                    button_row.append(InlineKeyboardButton(text=text, url=url))
                else:
                    button_row.append(InlineKeyboardButton(text=text, callback_data=callback_data))
            
            keyboard_buttons.append(button_row)
    
    return InlineKeyboardMarkup(keyboard_buttons)

def get_adaptive_main_keyboard(
    user_data: Optional[Dict[str, Any]] = None,
    platform_type: str = PLATFORM_UNKNOWN,
    platform_version: Optional[str] = None
) -> ReplyKeyboardMarkup:
    """
    Возвращает основную клавиатуру, адаптированную под платформу и статус подписки пользователя.
    
    Args:
        user_data: Данные пользователя, содержащие информацию о подписке
        platform_type: Тип платформы пользователя
        platform_version: Версия платформы пользователя
        
    Returns:
        ReplyKeyboardMarkup: Адаптированная клавиатура
    """
    # Если данные пользователя не переданы - возвращаем стандартную клавиатуру
    if user_data is None:
        buttons = [
            ["Решить задачу", "Купить подписку (199₽/месяц)"],
            ["Пригласить друга (реферальная система)"]
        ]
        return create_adaptive_reply_keyboard(buttons, platform_type, platform_version)
    
    # Импортируем здесь, чтобы избежать циклического импорта
    from services.payment_service import is_subscription_active
    
    # Проверяем наличие активной подписки с учетом платформы
    has_subscription = is_subscription_active(user_data, platform_type)
    
    # Проверяем, использовал ли пользователь бесплатный запрос
    free_request_used = user_data.get('free_request_used', False)
    
    # Получаем адаптированные эмодзи для платформы
    success_emoji = get_emoji("success", platform_type)
    money_emoji = get_emoji("money", platform_type)
    person_emoji = get_emoji("person", platform_type)
    
    # Формируем тексты кнопок с эмодзи в зависимости от платформы
    solve_button = f"Решить задачу {success_emoji}" if has_subscription else "Решить задачу"
    subscription_button = f"Купить подписку {money_emoji} (199₽/месяц)"
    referral_button = f"Пригласить друга {person_emoji} (реф. система)"
    free_request_button = "Решить задачу (бесплатный запрос)"
    
    # Выбираем кнопки в зависимости от статуса подписки
    if has_subscription:
        # Если есть активная подписка, не показываем кнопку покупки подписки
        buttons = [
            [solve_button],
            [referral_button]
        ]
    elif not free_request_used:
        # Если нет подписки, но есть бесплатный запрос
        buttons = [
            [free_request_button],
            [subscription_button],
            [referral_button]
        ]
    else:
        # Если нет подписки и использован бесплатный запрос
        buttons = [
            [solve_button, subscription_button],
            [referral_button]
        ]
    
    # Создаем адаптивную клавиатуру
    return create_adaptive_reply_keyboard(buttons, platform_type, platform_version)

def get_adaptive_problem_keyboard(
    platform_type: str = PLATFORM_UNKNOWN,
    platform_version: Optional[str] = None
) -> InlineKeyboardMarkup:
    """
    Возвращает клавиатуру для подтверждения решения задачи, адаптированную под платформу.
    
    Args:
        platform_type: Тип платформы пользователя
        platform_version: Версия платформы пользователя
        
    Returns:
        InlineKeyboardMarkup: Адаптированная inline-клавиатура
    """
    # Получаем эмодзи для разных платформ
    success_emoji = get_emoji("success", platform_type)
    error_emoji = get_emoji("error", platform_type)
    
    # Создаем кнопки с учетом эмодзи
    buttons = [
        [
            {'text': f"Решить {success_emoji}", 'callback_data': "confirm_solve"},
            {'text': f"Отмена {error_emoji}", 'callback_data': "cancel_solve"}
        ]
    ]
    
    return create_adaptive_inline_keyboard(buttons, platform_type, platform_version)

def get_adaptive_payment_keyboard(
    payment_url: str,
    platform_type: str = PLATFORM_UNKNOWN,
    platform_version: Optional[str] = None
) -> InlineKeyboardMarkup:
    """
    Возвращает клавиатуру для оплаты подписки, адаптированную под платформу.
    
    Args:
        payment_url: URL для оплаты
        platform_type: Тип платформы пользователя
        platform_version: Версия платформы пользователя
        
    Returns:
        InlineKeyboardMarkup: Адаптированная inline-клавиатура
    """
    # Получаем эмодзи для разных платформ
    payment_emoji = get_emoji("payment", platform_type)
    
    # Создаем кнопки с учетом эмодзи и платформы
    button_text = f"Оплатить подписку {payment_emoji}"
    
    # Для iOS укорачиваем текст
    if platform_type == PLATFORM_IOS:
        button_text = f"Оплатить {payment_emoji}"
    
    buttons = [[{'text': button_text, 'url': payment_url}]]
    
    return create_adaptive_inline_keyboard(buttons, platform_type, platform_version)