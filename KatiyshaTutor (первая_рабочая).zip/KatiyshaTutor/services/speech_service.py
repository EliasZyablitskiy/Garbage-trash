#!/usr/bin/env python
# coding: utf-8

"""
Service for speech-to-text conversion
"""

import os
import tempfile
import logging
import speech_recognition as sr
from pydub import AudioSegment

# Настройка оптимизированного логирования
import os
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)

# Определяем уровень логирования в зависимости от среды
is_production = os.environ.get('ENVIRONMENT') == 'production'
log_level = logging.INFO if is_production else logging.DEBUG
logger.setLevel(log_level)

# Создаем обработчик для вывода в консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(log_level)

# Создаем обработчик для ротации файлов логов (10 МБ, макс. 5 файлов)
log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')
os.makedirs(log_dir, exist_ok=True)
file_handler = RotatingFileHandler(
    os.path.join(log_dir, 'speech_service.log'),
    maxBytes=10*1024*1024,  # 10 МБ
    backupCount=5
)
file_handler.setLevel(log_level)

# Определяем формат сообщений
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)

# Добавляем обработчики к логгеру
logger.addHandler(console_handler)
logger.addHandler(file_handler)

async def convert_voice_to_text(voice_file_path: str, language: str = None) -> str:
    """
    Convert a voice message to text
    
    Args:
        voice_file_path: Path to the voice file (.oga format from Telegram)
        language: Language code for recognition (если None, определяется автоматически)
        
    Returns:
        str: The extracted text from the voice message
    """
    # Определяем язык для распознавания, если он не указан
    if language is None:
        from services.language_detection import get_speech_language_code
        language = get_speech_language_code()
        logger.info(f"Automatically selected speech recognition language: {language}")
    
    logger.info(f"Converting voice to text: {voice_file_path} (language: {language})")
    
    try:
        # Преобразуем голосовое сообщение из формата OGG/OGA в WAV для распознавания
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_wav:
            wav_file_path = temp_wav.name
        
        try:
            # Загружаем аудио и конвертируем в WAV
            voice_message = AudioSegment.from_file(voice_file_path)
            
            # Проверяем длительность аудио и обрезаем, если оно слишком длинное
            MAX_DURATION_MS = 60 * 1000  # 60 секунд
            if len(voice_message) > MAX_DURATION_MS:
                logger.warning(f"Audio too long ({len(voice_message)/1000:.1f}s), truncating to {MAX_DURATION_MS/1000}s")
                voice_message = voice_message[:MAX_DURATION_MS]
            
            # Экспортируем в WAV
            voice_message.export(wav_file_path, format="wav")
            
            # Используем Google Speech Recognition для распознавания
            recognizer = sr.Recognizer()
            with sr.AudioFile(wav_file_path) as source:
                audio_data = recognizer.record(source)
                text = recognizer.recognize_google(audio_data, language=language)
                
                if not text:
                    logger.warning("Empty text recognized from voice")
                    return "Не удалось распознать текст из голосового сообщения."
                
                # Пробуем определить язык по полученному тексту для будущих запросов
                try:
                    from services.language_detection import detect_language
                    detected_lang, confidence = detect_language(text[:200])
                    logger.info(f"Detected language from speech result: {detected_lang} (confidence: {confidence:.2f})")
                except Exception as e:
                    logger.error(f"Error detecting language from speech result: {e}")
                
                return text
        finally:
            # Удаляем временный WAV файл
            if os.path.exists(wav_file_path):
                os.unlink(wav_file_path)
    
    except sr.UnknownValueError:
        logger.error("Google Speech Recognition could not understand audio")
        # Если не смогли распознать с указанным языком, попробуем еще раз с русским
        if language != "ru-RU":
            logger.info("Retrying with Russian language (ru-RU)")
            try:
                return await convert_voice_to_text(voice_file_path, "ru-RU")
            except Exception:
                pass
        return "Не удалось распознать текст из голосового сообщения."
    except sr.RequestError as e:
        logger.error(f"Google Speech Recognition service error: {e}")
        return "Произошла ошибка при обращении к сервису распознавания речи."
    except Exception as e:
        logger.error(f"Error converting voice to text: {e}")
        return "Произошла ошибка при обработке голосового сообщения."