#!/usr/bin/env python
# coding: utf-8

"""
Service for speech-to-text conversion
"""

import os
import tempfile
import logging
import speech_recognition as sr
from pydub import AudioSegment

logger = logging.getLogger(__name__)

async def convert_voice_to_text(voice_file_path: str, language: str = "ru-RU") -> str:
    """
    Convert a voice message to text
    
    Args:
        voice_file_path: Path to the voice file (.oga format from Telegram)
        language: Language code for recognition (default: ru-RU)
        
    Returns:
        str: The extracted text from the voice message
    """
    logger.info(f"Converting voice to text: {voice_file_path}")
    
    try:
        # Преобразуем голосовое сообщение из формата OGG/OGA в WAV для распознавания
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_wav:
            wav_file_path = temp_wav.name
        
        try:
            # Загружаем аудио и конвертируем в WAV
            voice_message = AudioSegment.from_file(voice_file_path)
            voice_message.export(wav_file_path, format="wav")
            
            # Используем Google Speech Recognition для распознавания
            recognizer = sr.Recognizer()
            with sr.AudioFile(wav_file_path) as source:
                audio_data = recognizer.record(source)
                text = recognizer.recognize_google(audio_data, language=language)
                
                if not text:
                    logger.warning("Empty text recognized from voice")
                    return "Не удалось распознать текст из голосового сообщения."
                
                return text
        finally:
            # Удаляем временный WAV файл
            if os.path.exists(wav_file_path):
                os.unlink(wav_file_path)
    
    except sr.UnknownValueError:
        logger.error("Google Speech Recognition could not understand audio")
        return "Не удалось распознать текст из голосового сообщения."
    except sr.RequestError as e:
        logger.error(f"Google Speech Recognition service error: {e}")
        return "Произошла ошибка при обращении к сервису распознавания речи."
    except Exception as e:
        logger.error(f"Error converting voice to text: {e}")
        return "Произошла ошибка при обработке голосового сообщения."