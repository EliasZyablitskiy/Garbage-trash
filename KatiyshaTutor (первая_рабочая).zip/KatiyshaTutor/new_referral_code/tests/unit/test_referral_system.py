import unittest
import pytest
import sys
import os
import json
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta

# Add the project root directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Import ReferralSystem
from models import ReferralSystem

class TestReferralSystem(unittest.TestCase):
    
    def setUp(self):
        """Set up test fixtures before each test"""
        # Create mock user data
        self.mock_user_data = {
            "12345": {
                "id": 12345,
                "username": "testuser",
                "first_name": "Test User",
                "subscription_end": None,
                "subscription_type": None,
                "referrals": [],
                "referred_by": None,
                "referral_levels": {},
                "total_earned": 0
            },
            "67890": {
                "id": 67890,
                "username": "referrer",
                "first_name": "Referrer User",
                "subscription_end": (datetime.now() + timedelta(days=30)).isoformat(),
                "subscription_type": "monthly",
                "referrals": ["12345"],
                "referred_by": None,
                "referral_levels": {"1": ["12345"]},
                "total_earned": 50
            },
            "54321": {
                "id": 54321,
                "username": "level2referrer",
                "first_name": "Level 2 Referrer",
                "subscription_end": (datetime.now() + timedelta(days=30)).isoformat(),
                "subscription_type": "monthly",
                "referrals": ["67890"],
                "referred_by": None,
                "referral_levels": {"1": ["67890"], "2": ["12345"]},
                "total_earned": 100
            }
        }
        
        # Initialize with dependency injection for easier testing
        self.referral_system = ReferralSystem()
    
    @patch('models.database.get_user_data')
    @patch('models.database.update_user_data')
    def test_generate_referral_code(self, mock_update_user, mock_get_user):
        """Test generating a referral code for a user"""
        # Mock get_user_data to return our test user
        mock_get_user.return_value = self.mock_user_data["12345"].copy()
        
        # Call the method
        ref_code = self.referral_system.generate_referral_code(12345)
        
        # Check that referral code was generated
        self.assertIsNotNone(ref_code)
        self.assertTrue(len(ref_code) > 0)
        
        # Verify the user data was updated with the referral code
        mock_update_user.assert_called_once()
        update_data = mock_update_user.call_args[0][1]
        self.assertIn("referral_code", update_data)
        self.assertEqual(update_data["referral_code"], ref_code)
    
    @patch('models.database.get_user_data')
    def test_get_user_by_referral_code_found(self, mock_get_user):
        """Test finding a user by their referral code when the user exists"""
        # Set up mock users with referral codes
        user1 = self.mock_user_data["12345"].copy()
        user1["referral_code"] = "ABC123"
        user2 = self.mock_user_data["67890"].copy()
        user2["referral_code"] = "DEF456"
        
        # Mock get_user_data to return a generator of mock users
        mock_get_user.side_effect = [
            # First call returns None (no user with this ID)
            None,
            # Then the function calls get_all_users_data which we mock to return our test users
            {"12345": user1, "67890": user2}
        ]
        
        # Call the method
        found_user = self.referral_system.get_user_by_referral_code("ABC123")
        
        # Check that the correct user was found
        self.assertEqual(found_user["id"], 12345)
        self.assertEqual(found_user["referral_code"], "ABC123")
    
    @patch('models.database.get_user_data')
    def test_get_user_by_referral_code_not_found(self, mock_get_user):
        """Test finding a user by their referral code when no user has that code"""
        # Mock get_user_data to return a generator of mock users without the sought code
        mock_get_user.side_effect = [
            # First call returns None (no user with this ID)
            None,
            # Then the function calls get_all_users_data which we mock to return our test users
            {"12345": self.mock_user_data["12345"], "67890": self.mock_user_data["67890"]}
        ]
        
        # Call the method
        found_user = self.referral_system.get_user_by_referral_code("NONEXISTENT")
        
        # Check that no user was found
        self.assertIsNone(found_user)
    
    @patch('models.database.get_user_data')
    @patch('models.database.update_user_data')
    def test_add_referral(self, mock_update_user, mock_get_user):
        """Test adding a new referral relationship"""
        # Mock user data for referrer and referrer's referrer
        referrer = self.mock_user_data["67890"].copy()
        referrer_referrer = self.mock_user_data["54321"].copy()
        new_user = self.mock_user_data["12345"].copy()
        
        # Mock get_user_data to return appropriate users based on ID
        def mock_get_user_side_effect(user_id):
            if user_id == 67890:
                return referrer
            elif user_id == 54321:
                return referrer_referrer
            elif user_id == 12345:
                return new_user
            return None
        
        mock_get_user.side_effect = mock_get_user_side_effect
        
        # Call the method
        result = self.referral_system.add_referral(12345, 67890)
        
        # Verify result
        self.assertTrue(result)
        
        # Check that both users were updated correctly
        # The new user should have referred_by set to the referrer
        # The referrer should have the new user added to referrals and referral_levels
        mock_update_user.assert_any_call(12345, {"referred_by": 67890})
        
        # Verify the updates to the referrer
        referrer_updates = None
        for call in mock_update_user.call_args_list:
            if call[0][0] == 67890:
                referrer_updates = call[0][1]
                break
        
        self.assertIsNotNone(referrer_updates)
        self.assertIn(12345, referrer_updates["referrals"])
        self.assertIn("1", referrer_updates["referral_levels"])
        self.assertIn(12345, referrer_updates["referral_levels"]["1"])
        
        # Verify the updates to the referrer's referrer (level 2)
        level2_updates = None
        for call in mock_update_user.call_args_list:
            if call[0][0] == 54321:
                level2_updates = call[0][1]
                break
        
        self.assertIsNotNone(level2_updates)
        self.assertIn("2", level2_updates["referral_levels"])
        self.assertIn(12345, level2_updates["referral_levels"]["2"])
    
    @patch('models.database.get_user_data')
    def test_add_referral_self_referral(self, mock_get_user):
        """Test adding a referral with the same user as referrer and referred"""
        # Mock get_user_data to return our test user
        mock_get_user.return_value = self.mock_user_data["12345"].copy()
        
        # Call the method (trying to refer oneself)
        result = self.referral_system.add_referral(12345, 12345)
        
        # Verify failure
        self.assertFalse(result)
    
    @patch('models.database.get_user_data')
    def test_add_referral_already_referred(self, mock_get_user):
        """Test adding a referral for a user who already has a referrer"""
        # Create a user who already has a referrer
        user_with_referrer = self.mock_user_data["12345"].copy()
        user_with_referrer["referred_by"] = 54321
        
        # Mock get_user_data to return our modified test user
        mock_get_user.return_value = user_with_referrer
        
        # Call the method (trying to add a new referrer)
        result = self.referral_system.add_referral(12345, 67890)
        
        # Verify failure
        self.assertFalse(result)
    
    @patch('models.database.get_user_data')
    @patch('models.database.update_user_data')
    @patch('models.database.record_referral_reward')
    def test_process_referral_rewards(self, mock_record_reward, mock_update_user, mock_get_user):
        """Test processing referral rewards when a user subscribes"""
        # Mock user data for multiple levels of referrers
        level1_referrer = self.mock_user_data["67890"].copy()
        level2_referrer = self.mock_user_data["54321"].copy()
        referred_user = self.mock_user_data["12345"].copy()
        referred_user["referred_by"] = 67890
        
        # Set up the referral chain: referred_user -> level1_referrer -> level2_referrer
        level1_referrer["referrals"] = [12345]
        level1_referrer["referred_by"] = 54321
        level1_referrer["referral_levels"] = {"1": [12345]}
        
        level2_referrer["referrals"] = [67890]
        level2_referrer["referral_levels"] = {"1": [67890], "2": [12345]}
        
        # Mock get_user_data to return appropriate users based on ID
        def mock_get_user_side_effect(user_id):
            if user_id == 67890:
                return level1_referrer
            elif user_id == 54321:
                return level2_referrer
            elif user_id == 12345:
                return referred_user
            return None
        
        mock_get_user.side_effect = mock_get_user_side_effect
        
        # Call the method
        result = self.referral_system.process_referral_rewards(12345, 100.00)
        
        # Verify result
        self.assertTrue(result)
        
        # Check that reward was recorded for the level 1 referrer (5%)
        mock_record_reward.assert_any_call(
            referrer_id=67890,
            referred_user_id=12345,
            subscription_amount=100.00,
            level=1
        )
        
        # Check that reward was recorded for the level 2 referrer (2%)
        mock_record_reward.assert_any_call(
            referrer_id=54321,
            referred_user_id=12345,
            subscription_amount=100.00,
            level=2
        )
    
    @patch('models.database.get_user_data')
    def test_process_referral_rewards_no_referrer(self, mock_get_user):
        """Test processing referral rewards when a user has no referrer"""
        # Mock user data with no referrer
        user_no_referrer = self.mock_user_data["12345"].copy()
        user_no_referrer["referred_by"] = None
        
        # Mock get_user_data to return our test user
        mock_get_user.return_value = user_no_referrer
        
        # Call the method
        result = self.referral_system.process_referral_rewards(12345, 100.00)
        
        # Verify result (should return True even though no rewards were processed)
        self.assertTrue(result)
    
    @patch('models.database.get_user_data')
    def test_get_referral_statistics(self, mock_get_user):
        """Test getting referral statistics for a user"""
        # Mock user with referrals
        user_with_referrals = self.mock_user_data["54321"].copy()
        user_with_referrals["referral_levels"] = {
            "1": [67890],
            "2": [12345]
        }
        user_with_referrals["total_earned"] = 150.0
        
        # Mock get_user_data to return our test user
        mock_get_user.return_value = user_with_referrals
        
        # Call the method
        stats = self.referral_system.get_referral_statistics(54321)
        
        # Verify statistics
        self.assertEqual(stats["total_referrals"], 2)  # 1 at level 1, 1 at level 2
        self.assertEqual(stats["level_1_referrals"], 1)
        self.assertEqual(stats["level_2_referrals"], 1)
        self.assertEqual(stats["total_earned"], 150.0)


if __name__ == "__main__":
    pytest.main() 