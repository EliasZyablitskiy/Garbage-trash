#!/usr/bin/env python
# coding: utf-8

"""
Обработчик вебхуков от платежных систем (Robokassa) и веб-страниц оплаты
Включает административный веб-интерфейс и централизованную систему проверки платежей
"""

import os
import logging
import asyncio
import datetime
import json
import hashlib
from io import BytesIO
from pathlib import Path
from functools import wraps
from flask import Flask, request, render_template, render_template_string, abort, send_from_directory, redirect, url_for, session, jsonify, flash
from telegram import Bot

import config
from db_config import get_flask_app
from services.db_service import get_user, update_user_subscription, add_transaction
from services.payment_verification_service_v2 import payment_verification_service_v2, PAYMENT_STATUS
from services.payment_processor_facade import payment_processor_facade
from services.payment_webhook_handler import register_payment_webhooks
from services.payment_pages import register_payment_pages
from services.instance_lock_service import instance_lock_service
from transactions import (
    get_weekly_payouts, 
    update_payout_status,
    get_user_transactions_by_status,
    create_weekly_payout,
    get_referral_statistics,
    get_transactions_by_status,
    get_users_with_pending_rewards
)
from oauth_routes import oauth_bp
# Старый административный интерфейс архивирован
from legacy_admin_archive.admin_web_interface import admin_web  # Импортируем Blueprint административного интерфейса (устаревший)
from enhanced_admin_interface import enhanced_admin, csrf  # Импортируем Blueprint улучшенного административного интерфейса и CSRF защиту

logger = logging.getLogger(__name__)

# Импортируем нужную функцию проверки администратора
from admin_handlers import is_admin

# Получаем Flask приложение с настроенной базой данных
app = get_flask_app()

# Настройка сессии для аутентификации
app.secret_key = os.environ.get("SESSION_SECRET", "katiysha_super_secure_key_2025")
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_USE_SIGNER'] = True

# Настройка префикса для сессий
app.config['SESSION_KEY_PREFIX'] = 'admin_session:'

# Перенаправляем запросы к старой админке на новую
@app.route('/admin')
def legacy_admin_redirect():
    """Перенаправление со старой админки на новую"""
    return redirect(url_for('enhanced_admin.dashboard'))

@app.route('/admin/login')
def legacy_admin_login_redirect():
    """Перенаправление со старой страницы входа на новую"""
    return redirect(url_for('enhanced_admin.login'))
    
@app.route('/admin/users')
def legacy_admin_users_redirect():
    """Перенаправление со старой страницы пользователей на новую"""
    return redirect(url_for('enhanced_admin.users_list'))
    
@app.route('/admin/transactions')
def legacy_admin_transactions_redirect():
    """Перенаправление со старой страницы транзакций на новую"""
    return redirect(url_for('enhanced_admin.transactions_list'))
    
@app.route('/admin/payouts')
def legacy_admin_payouts_redirect():
    """Перенаправление со старой страницы выплат на новую"""
    return redirect(url_for('enhanced_admin.payouts_list'))
    
@app.route('/admin/reports')
def legacy_admin_reports_redirect():
    """Перенаправление со старой страницы отчетов на новую"""
    return redirect(url_for('enhanced_admin.reports'))

# Старый Blueprint административного интерфейса архивирован
# app.register_blueprint(admin_web)

# Регистрируем Blueprint улучшенного административного интерфейса
app.register_blueprint(enhanced_admin)

# Регистрируем OAuth маршруты
app.register_blueprint(oauth_bp, url_prefix='/oauth')

# Инициализируем CSRF защиту
csrf.init_app(app)

# Создаем статический каталог, если его нет
STATIC_FOLDER = "static"
os.makedirs(STATIC_FOLDER, exist_ok=True)

# Создаем секретный ключ для административной панели
ADMIN_SECRET_KEY = config.ROBOKASSA_SECRET_KEY[:16] if config.ROBOKASSA_SECRET_KEY and len(config.ROBOKASSA_SECRET_KEY) >= 16 else "AdminSecretKey123"

# Определяем декоратор для проверки аутентификации администратора
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_authenticated' not in session or not session['admin_authenticated']:
            return redirect(url_for('admin_login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

# Добавляем обработчик статических файлов
@app.route('/static/<path:filename>')
def serve_static(filename):
    """
    Обработчик для статических файлов
    """
    return send_from_directory(STATIC_FOLDER, filename)

@app.route('/')
def index():
    """
    Главная страница бота с отображением счетчика пользователей
    """
    # Импортируем функцию для получения количества пользователей
    from services.db_service import get_total_users_count
    
    # Получаем общее количество пользователей
    total_users = get_total_users_count()
    
    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Бот Катюша</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }
            .container {
                background-color: #f5f5f5;
                border-radius: 10px;
                padding: 20px;
                margin-top: 20px;
            }
            .header-container {
                display: flex;
                align-items: center;
                justify-content: space-between;
                margin-bottom: 20px;
            }
            .user-counter {
                background-color: #4a76a8;
                color: white;
                padding: 8px 16px;
                border-radius: 20px;
                font-weight: bold;
                font-size: 18px;
                display: inline-flex;
                align-items: center;
            }
            .user-counter .icon {
                margin-right: 8px;
                font-size: 20px;
            }
            .nav {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                margin-top: 20px;
            }
            .button {
                display: inline-block;
                background-color: #4a76a8;
                color: white;
                padding: 10px 20px;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
            }
            .button:hover {
                background-color: #3d6293;
            }
        </style>
    </head>
    <body>
        <div class="header-container">
            <h1>Бот Катюша</h1>
            <div class="user-counter">
                <span class="icon">👥</span>
                {{ total_users }} пользователей
            </div>
        </div>
        <div class="container">
            <p>Добро пожаловать в панель управления бота Катюша!</p>
            <p>Здесь вы можете настроить различные функции бота и получить доступ к инструментам администрирования.</p>
            
            <div class="nav">
                <a href="/oauth/" class="button">Настройка Яндекс.Диска</a>
            </div>
        </div>
    </body>
    </html>
    """, total_users=total_users)

@app.route('/payment/<int:user_id>')
def payment_page(user_id):
    """
    Страница оплаты с iFrame Robokassa
    
    Args:
        user_id: Telegram ID пользователя
    """
    # Проверяем, существует ли пользователь
    user_data = get_user(user_id)
    if not user_data:
        return "Пользователь не найден", 404
    
    # Добавляем HTML-шаблон для страницы оплаты
    html_template = f"""
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Оплата подписки бота Катюша</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
            }}
            .payment-container {{
                margin-top: 30px;
            }}
            h1 {{
                color: #4a76a8;
            }}
            .robokassa-iframe {{
                width: 100%;
                height: 600px;
                border: none;
            }}
            .instructions {{
                background-color: #f1f1f1;
                padding: 15px;
                border-radius: 5px;
                margin-bottom: 20px;
                text-align: left;
            }}
        </style>
        <script src="https://auth.robokassa.ru/Merchant/bundle/robokassa_iframe.js"></script>
    </head>
    <body>
        <h1>Оплата подписки бота Катюша</h1>
        
        <div class="instructions">
            <p><strong>Инструкция:</strong></p>
            <ol>
                <li>Выберите удобный способ оплаты в форме ниже.</li>
                <li>Произведите оплату согласно инструкциям.</li>
                <li>После успешной оплаты ваша подписка будет активирована автоматически.</li>
                <li>В случае проблем, отправьте команду /activate_subscription боту.</li>
            </ol>
        </div>
        
        <div class="payment-container">
            <div id="robokassa-payment-form"></div>
        </div>
        
        <script type="text/javascript">
            document.addEventListener('DOMContentLoaded', function() {{
                // Инициализация формы оплаты Robokassa
                var robokassaParams = {{
                    MerchantLogin: "KatiyshaMathBot",
                    OutSum: 199.00,
                    InvId: Date.now(),
                    Description: "Подписка на бота Катюша на 1 месяц",
                    Email: "",
                    Culture: "ru",
                    Encoding: "utf-8",
                    IsTest: 1,
                    SignatureValue: "", // будет сгенерировано на стороне сервера
                    Shp_user: {user_id}
                }};
                
                const robokassaContainer = document.getElementById('robokassa-payment-form');
                if (robokassaContainer) {{
                    Robokassa.StartPayment({{
                        MerchantLogin: robokassaParams.MerchantLogin,
                        OutSum: robokassaParams.OutSum,
                        InvId: robokassaParams.InvId,
                        Description: robokassaParams.Description,
                        Email: robokassaParams.Email,
                        Culture: robokassaParams.Culture,
                        Encoding: robokassaParams.Encoding,
                        IsTest: robokassaParams.IsTest,
                        Shp_user: robokassaParams.Shp_user
                    }});
                }}
            }});
        </script>
    </body>
    </html>
    """
    return html_template

@app.route('/robokassa/webhook', methods=['GET', 'POST'])
def robokassa_webhook():
    """
    Обработчик уведомлений от Robokassa
    
    Документация по Result URL: https://docs.robokassa.ru/ru/knowledge-base/integration/notifications-paymentcompleted
    
    Улучшения:
    1. Идемпотентность - предотвращение повторной обработки того же платежа
    2. Атомарные транзакции - все изменения в БД либо выполняются целиком, либо отменяются
    3. Улучшенное логирование и отслеживание статуса платежа
    4. Параллельное использование нового сервиса проверки платежей для тестирования
    """
    # Получаем параметры запроса
    inv_id = request.args.get('InvId', '')
    outsum = request.args.get('OutSum', '')
    signature = request.args.get('SignatureValue', '')
    user_id = request.args.get('Shp_user', '')
    
    logger.info(f"Received Robokassa webhook: InvId={inv_id}, OutSum={outsum}, SignatureValue={signature[:10]}..., Shp_user={user_id}")
    
    # Собираем все параметры для проверки новым сервисом
    notification_data = dict(request.args)
    
    # НОВЫЙ ПУТЬ: Проверяем уведомление через новый сервис (только логирование, без действий)
    try:
        from services.payment_result import PaymentResult
        
        # Проверяем платеж через новый сервис v2
        payment_result = payment_verification_service_v2.verify_payment_unified(
            notification_data=notification_data,
            payment_system='robokassa'
        )
        
        # Логируем результат проверки новым сервисом для сравнения
        logger.info(f"[New Service] Payment verification result: success={payment_result.success}, " 
                   f"code={payment_result.result_code.name if payment_result.result_code else 'None'}, "
                   f"message={payment_result.message}")
        
        # Если настройка для использования нового сервиса включена, обрабатываем платеж через него
        if os.environ.get('USE_NEW_PAYMENT_SERVICE', '').lower() == 'true':
            # Обрабатываем платеж через новый сервис
            if payment_result.success:
                processed_result = payment_verification_service_v2.process_payment(payment_result)
                logger.info(f"[New Service] Payment processed: success={processed_result.success}, " 
                          f"message={processed_result.message}")
                return "OK", 200  # Возвращаем OK для Robokassa
            else:
                logger.warning(f"[New Service] Payment verification failed: {payment_result.message}")
                return "Failed", 400  # Возвращаем ошибку
    except Exception as e:
        logger.error(f"[New Service] Error in new payment verification service: {str(e)}")
        # Продолжаем со старым путем обработки в случае ошибки в новом
    
    # СТАРЫЙ ПУТЬ: Стандартная проверка подписи (сохраняем для совместимости)
    if not verify_robokassa_signature(inv_id, outsum, signature, user_id):
        logger.warning(f"Invalid Robokassa signature: {signature[:10]}...")
        return "Incorrect signature", 400
    
    # Если подпись действительна, активируем подписку пользователя (старый путь)
    if user_id and inv_id and os.environ.get('USE_NEW_PAYMENT_SERVICE', '').lower() != 'true':
        try:
            user_id_int = int(user_id)
            
            # Создаем уникальный идентификатор транзакции для обеспечения идемпотентности
            external_id = f"robokassa_{inv_id}"
            idempotency_key = f"robokassa_{inv_id}_{user_id}"
            
            # Начинаем работу с базой данных в одной транзакции
            from db_models import db, Transaction, User
            
            with app.app_context():
                try:
                    # Проверяем, не обрабатывался ли уже этот платеж
                    existing_transaction = Transaction.query.filter(
                        (Transaction.external_id == external_id) | 
                        (Transaction.idempotency_key == idempotency_key)
                    ).first()
                    
                    if existing_transaction:
                        logger.info(f"Duplicate payment notification detected: InvId={inv_id}, user={user_id}. " 
                                f"Transaction already exists with ID {existing_transaction.id}")
                        # Возвращаем успешный ответ для дупликатов, чтобы Robokassa не пытался переотправить уведомление
                        return "OK (duplicate)", 200
                    
                    # Получаем данные пользователя
                    user = User.query.get(user_id_int)
                    if not user:
                        logger.warning(f"User with ID {user_id_int} not found for subscription activation")
                        return "User not found", 404
                    
                    # Устанавливаем дату окончания подписки (один месяц от текущей даты)
                    now = datetime.datetime.now()
                    expires_in = datetime.timedelta(minutes=60)  # Таймаут платежа - 1 час
                    payment_expires_at = now + expires_in
                    
                    # Собираем детальную информацию о платеже для записи транзакции
                    payment_data = {
                        'invoice_id': inv_id,
                        'amount': outsum,
                        'payment_method': 'robokassa',
                        'payment_date': now.isoformat(),
                        'source': 'webhook',
                        'signature': signature[:10] + '...'  # Сохраняем только часть подписи для аудита
                    }
                    
                    # Создаем новую транзакцию в статусе "pending" для обработки процессором платежей
                    new_transaction = Transaction(
                        type="subscription_payment",
                        user_id=user_id_int,
                        amount=float(outsum),
                        description=f"Оплата подписки через Robokassa (InvId: {inv_id})",
                        status="pending",  # Начальный статус - в ожидании обработки
                        payment_data=payment_data,
                        external_id=external_id,
                        idempotency_key=idempotency_key,
                        payment_method="robokassa",
                        payment_expires_at=payment_expires_at,  # Устанавливаем срок истечения платежа
                        created_at=now,
                        updated_at=now
                    )
                    
                    # Добавляем транзакцию в сессию
                    db.session.add(new_transaction)
                    
                    # Фиксируем изменения в БД и получаем ID транзакции
                    db.session.flush()
                    transaction_id = new_transaction.id
                    db.session.commit()
                    
                    logger.info(f"Payment record created: InvId={inv_id}, user={user_id}, transaction_id={transaction_id}")
                    
                    # Используем процессор платежей для обработки транзакции (двухфазный коммит)
                    from services.payment_processor import process_single_payment
                    import asyncio
                    
                    # Функция для верификации платежа Robokassa
                    async def verify_robokassa_payment(transaction):
                        # Платеж уже проверен с помощью подписи выше, просто возвращаем успех
                        return True, "Robokassa signature verified"
                    
                    # Запускаем асинхронную обработку платежа
                    try:
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                        success, message, result = loop.run_until_complete(
                            process_single_payment(app, transaction_id, verify_robokassa_payment)
                        )
                        loop.close()
                        
                        if success:
                            logger.info(f"Payment successfully processed: {message}")
                            
                            # Получаем данные пользователя и новую дату окончания подписки
                            user = User.query.get(user_id_int)
                            if user and user.subscription_end:
                                expiry_date = user.subscription_end
                                
                                # Отправляем уведомление пользователю через бота
                                asyncio.run_coroutine_threadsafe(
                                    send_subscription_notification(user_id_int, expiry_date),
                                    asyncio.get_event_loop()
                                )
                            
                            return "OK", 200
                        else:
                            logger.error(f"Payment processing failed: {message}")
                            return f"Payment processing error: {message}", 500
                    except Exception as payment_error:
                        logger.error(f"Error during payment processing: {payment_error}")
                        return f"Error: {str(payment_error)}", 500
                    
                except Exception as db_error:
                    # В случае ошибки откатываем изменения
                    db.session.rollback()
                    logger.error(f"Database error processing payment: {db_error}")
                    return f"Error: {str(db_error)}", 500
            
            # После успешной записи в БД выполняем дополнительные действия вне транзакции
            try:
                # Обработка реферальных вознаграждений
                from new_referral_code.referral_handlers import process_subscription_rewards
                # Запускаем обработку вознаграждений синхронно, так как функция уже оптимизирована
                result = asyncio.run(process_subscription_rewards(user_id_int, float(outsum)))
                if result and result.get('success'):
                    logger.info(f"Processed referral rewards for user {user_id_int}: {result.get('rewards_count')} rewards, " 
                               f"total: {result.get('total_rewards')}")
                else:
                    logger.warning(f"No referral rewards processed for user {user_id_int}")
            except Exception as e:
                # Ошибка в обработке реферальных вознаграждений не должна влиять на статус платежа
                logger.error(f"Error processing referral rewards (non-critical): {e}")
            
            # Отправляем пользователю уведомление о активации подписки асинхронно
            # Это действие не критично для успешной обработки платежа
            try:
                asyncio.create_task(send_subscription_notification(user_id_int, transaction_id, payment_data))
            except Exception as e:
                logger.error(f"Error scheduling subscription notification (non-critical): {e}")
            
            return "OK", 200
            
        except Exception as e:
            logger.error(f"Error processing Robokassa webhook: {e}")
            return "Error", 500
    else:
        logger.warning("Invalid parameters: User ID or Invoice ID not provided in Robokassa webhook")
        return "Invalid parameters", 400

async def send_subscription_notification(user_id, transaction_id=None, payment_data=None):
    """
    Отправить уведомление пользователю о успешной активации подписки
    
    Args:
        user_id: Telegram ID пользователя
        transaction_id: ID транзакции оплаты (опционально)
        payment_data: Данные о платеже (опционально)
    """
    try:
        # Импортируем сервис для управления подписками
        from services.subscription_service import send_subscription_activation_notification
        
        # Получаем данные о подписке из базы данных
        user_data = get_user(user_id)
        
        # Определяем дату окончания подписки
        if user_data and 'subscription_expiry' in user_data and user_data['subscription_expiry']:
            try:
                expiry_date = datetime.datetime.fromisoformat(user_data['subscription_expiry'])
            except (ValueError, TypeError):
                # Если не удалось получить дату из базы, вычисляем её
                now = datetime.datetime.now()
                expiry_date = now + datetime.timedelta(days=config.SUBSCRIPTION_DURATION_DAYS)
        else:
            # Если нет данных о подписке, вычисляем дату стандартно
            now = datetime.datetime.now()
            expiry_date = now + datetime.timedelta(days=config.SUBSCRIPTION_DURATION_DAYS)
        
        # Отправляем уведомление через сервис подписок
        success = await send_subscription_activation_notification(
            user_id=user_id,
            expiry_date=expiry_date,
            transaction_id=transaction_id,
            payment_data=payment_data
        )
        
        if success:
            logger.info(f"Subscription notification sent to user {user_id}")
            
            # Напоминание за 3 дня до окончания подписки будет отправлено
            # автоматически через сервис напоминаний о подписке
            return True
        else:
            logger.warning(f"Failed to send subscription notification to user {user_id}")
            return False
        
    except Exception as e:
        logger.error(f"Error sending subscription notification: {e}")

@app.route('/activate/<int:user_id>', methods=['GET', 'POST'])
def activate_subscription_page(user_id):
    """
    Страница активации подписки с оплатой через СБП или по QR-коду с ограниченным сроком действия
    
    Args:
        user_id: Telegram ID пользователя
    """
    # Импортируем сервис для создания QR-кодов с ограниченным сроком действия
    from services.qr_service import generate_sbp_qr_code, check_payment_status, verify_and_process_payment, cleanup_expired_payments

    # Проверяем, существует ли пользователь
    user_data = get_user(user_id)
    if not user_data:
        return render_template('activate_subscription.html', error="Пользователь не найден")
    
    # Проверяем, нет ли уже активной подписки
    if user_data.get('subscription_expiry'):
        try:
            expiry_date = datetime.datetime.fromisoformat(user_data['subscription_expiry'])
            if expiry_date > datetime.datetime.now():
                # Подписка ещё активна
                return render_template('activate_subscription.html', 
                                      success="Подписка уже активна! Вы можете вернуться в бот и продолжить его использование.",
                                      user_id=user_id)
        except (ValueError, TypeError):
            # В случае ошибки парсинга даты, продолжаем как обычно
            logger.warning(f"Error parsing subscription_expiry for user {user_id}: {user_data.get('subscription_expiry')}")
            pass
    
    # Очищаем просроченные платежи при загрузке страницы
    cleanup_result = cleanup_expired_payments()
    if cleanup_result['success'] and cleanup_result['count'] > 0:
        logger.info(f"Cleaned up {cleanup_result['count']} expired payments")
    
    # Получаем параметры запроса для проверки статуса платежа
    payment_id = request.args.get('payment_id')
    
    # Обрабатываем проверку статуса существующего платежа
    if payment_id:
        payment_status = check_payment_status(payment_id)
        
        # Если платеж уже завершен успешно, активируем подписку
        if payment_status['success'] and payment_status['status'] == 'completed':
            try:
                # Пробуем получить объект пользователя из ORM
                from db_models import User
                with app.app_context():
                    user_orm = User.query.filter_by(telegram_id=user_id).first()
                    if user_orm and hasattr(user_orm, 'is_subscribed') and user_orm.is_subscribed():
                        return render_template('activate_subscription.html', 
                                               success="Подписка успешно активирована! Вы можете вернуться в бот и продолжить его использование.",
                                               user_id=user_id)
            except Exception as e:
                logger.error(f"Error checking user subscription status: {e}")
    
    # Обрабатываем POST-запрос для активации подписки с кодом или подтверждением платежа
    if request.method == 'POST':
        # Проверяем, есть ли подтверждение оплаты через QR
        payment_confirmation = request.form.get('payment_confirmation')
        payment_id_form = request.form.get('payment_id')
        activation_code = request.form.get('activation_code')
        
        # Если пользователь подтверждает оплату через QR
        if payment_confirmation and payment_id_form:
            # Проверяем статус платежа и обрабатываем его
            logger.info(f"Processing payment confirmation for user {user_id}, payment_id: {payment_id_form}")
            result = verify_and_process_payment(payment_id_form, user_id, float(config.SUBSCRIPTION_PRICE / 100.0))
            
            if result['success'] and result['status'] in ['completed', 'already_processed']:
                # Обработка реферальных вознаграждений
                try:
                    from new_referral_code.referral_handlers import process_subscription_rewards
                    # Запускаем обработку вознаграждений синхронно, так как функция уже оптимизирована
                    reward_result = asyncio.run(process_subscription_rewards(user_id, float(config.SUBSCRIPTION_PRICE / 100.0)))
                    if reward_result and reward_result.get('success'):
                        logger.info(f"Processed referral rewards for user {user_id}: {reward_result.get('rewards_count')} rewards, total: {reward_result.get('total_rewards')}")
                    else:
                        logger.warning(f"No referral rewards processed for user {user_id}")
                except Exception as e:
                    logger.error(f"Error processing referral rewards: {e}")
                
                # Отправляем пользователю уведомление о активации подписки
                asyncio.create_task(send_subscription_notification(user_id))
                
                return render_template('activate_subscription.html', 
                                      success="Подписка успешно активирована! Вы можете вернуться в бот и продолжить его использование.",
                                      user_id=user_id)
            else:
                # Если платеж не прошел
                error_message = result.get('message', "Платеж не найден или ещё не обработан.")
                logger.warning(f"Payment verification failed for user {user_id}, payment_id: {payment_id_form}: {error_message}")
                
                # Генерируем новый QR-код и возвращаем ошибку
                return render_template('activate_subscription.html', 
                                      error=error_message,
                                      user_id=user_id)
        
        # Обрабатываем активацию по коду активации
        elif activation_code:
            try:
                # Устанавливаем дату окончания подписки
                now = datetime.datetime.now()
                expiry_date = now + datetime.timedelta(days=config.SUBSCRIPTION_DURATION_DAYS)
                
                # Обновляем данные о подписке
                success = update_user_subscription(user_id, expiry_date.isoformat())
                
                if success:
                    logger.info(f"Subscription activated for user {user_id} with code until {expiry_date.isoformat()}")
                    
                    # Создаем транзакцию с уникальным идентификатором для обеспечения идемпотентности
                    idempotency_key = f"activation_code_{user_id}_{activation_code}_{int(now.timestamp())}"
                    
                    # Используем models.Transaction если доступно, иначе обычную функцию add_transaction
                    try:
                        from db_models import Transaction
                        with app.app_context():
                            # Проверяем, нет ли уже такой транзакции
                            existing_transaction = Transaction.query.filter_by(
                                idempotency_key=idempotency_key
                            ).first()
                            
                            if not existing_transaction:
                                # Создаем новую транзакцию
                                transaction = Transaction(
                                    type="subscription",
                                    user_id=user_id,
                                    amount=float(config.SUBSCRIPTION_PRICE / 100.0),
                                    description=f"Активация подписки с кодом: {activation_code}",
                                    status="completed",
                                    external_id=f"activation_code_{activation_code}",
                                    idempotency_key=idempotency_key,
                                    payment_method="activation_code",
                                    created_at=now,
                                    updated_at=now
                                )
                                
                                db.session.add(transaction)
                                db.session.commit()
                                logger.info(f"Created transaction for activation code: {activation_code}, user_id: {user_id}")
                    except Exception as e:
                        logger.error(f"Error creating Transaction ORM object: {e}")
                        # Используем обычную функцию add_transaction как резервный вариант
                        add_transaction(
                            transaction_type="subscription",
                            user_id=user_id,
                            amount=float(config.SUBSCRIPTION_PRICE / 100.0),
                            description=f"Активация подписки с кодом: {activation_code}",
                            status="completed"
                        )
                    
                    # Обработка реферальных вознаграждений
                    try:
                        from new_referral_code.referral_handlers import process_subscription_rewards
                        # Запускаем обработку вознаграждений синхронно, так как функция уже оптимизирована
                        result = asyncio.run(process_subscription_rewards(user_id, float(config.SUBSCRIPTION_PRICE / 100.0)))
                        if result and result.get('success'):
                            logger.info(f"Processed referral rewards for user {user_id}: {result.get('rewards_count')} rewards, total: {result.get('total_rewards')}")
                        else:
                            logger.warning(f"No referral rewards processed for user {user_id}")
                    except Exception as e:
                        logger.error(f"Error processing referral rewards: {e}")
                    
                    # Отправляем пользователю уведомление о активации подписки
                    asyncio.create_task(send_subscription_notification(user_id))
                    
                    return render_template('activate_subscription.html', 
                                          success="Подписка успешно активирована! Вы можете вернуться в бот и продолжить его использование.", 
                                          user_id=user_id)
                else:
                    return render_template('activate_subscription.html', 
                                          error="Не удалось активировать подписку. Пожалуйста, попробуйте еще раз или свяжитесь с поддержкой.", 
                                          user_id=user_id)
            except Exception as e:
                logger.error(f"Error activating subscription: {e}")
                return render_template('activate_subscription.html', 
                                      error=f"Произошла ошибка при активации подписки: {e}", 
                                      user_id=user_id)
        else:
            return render_template('activate_subscription.html', 
                                  error="Пожалуйста, введите код активации или оплатите подписку через СБП или QR-код.", 
                                  user_id=user_id)
    
    # Генерируем QR-код для оплаты с ограниченным сроком действия, если его еще нет или был запрос на новый
    qr_code_path = ""
    qr_payment_id = ""
    
    # Если у нас нет payment_id или его нужно обновить, генерируем новый QR-код
    if not payment_id:
        # Генерируем новый QR-код с ограниченным сроком действия (30 минут)
        logger.info(f"Generating new QR code for user {user_id}")
        result = generate_sbp_qr_code(user_id, float(config.SUBSCRIPTION_PRICE / 100.0))
        
        if result and result[0] and result[1]:
            # Получаем путь к QR-коду и ID платежа
            qr_code_path, qr_payment_id = result
            
            # Копируем файл QR-кода в статическую директорию для доступа через веб
            static_qr_path = os.path.join(STATIC_FOLDER, f"qrcode_{user_id}_{qr_payment_id}.png")
            try:
                import shutil
                shutil.copy2(qr_code_path, static_qr_path)
                logger.info(f"QR-code copied to static folder: {static_qr_path}")
                
                # Формируем относительный путь для отображения QR-кода в шаблоне
                qr_code_path = f"/static/qrcode_{user_id}_{qr_payment_id}.png"
            except Exception as e:
                logger.error(f"Error copying QR-code to static folder: {e}")
                qr_code_path = ""
        else:
            logger.error(f"Failed to generate QR-code for user {user_id}")
            qr_code_path = ""
    else:
        # Используем существующий payment_id
        qr_payment_id = payment_id
        static_qr_path = os.path.join(STATIC_FOLDER, f"qrcode_{user_id}_{qr_payment_id}.png")
        
        # Проверяем существование файла в статической директории
        if os.path.exists(static_qr_path):
            qr_code_path = f"/static/qrcode_{user_id}_{qr_payment_id}.png"
        else:
            # Если файл не найден, генерируем новый QR-код
            logger.info(f"QR code file not found, regenerating for user {user_id} with payment_id {payment_id}")
            result = generate_sbp_qr_code(user_id, float(config.SUBSCRIPTION_PRICE / 100.0), payment_id)
            if result and result[0]:
                qr_code_path, qr_payment_id = result
                
                # Копируем файл QR-кода в статическую директорию для доступа через веб
                try:
                    import shutil
                    shutil.copy2(qr_code_path, static_qr_path)
                    logger.info(f"QR-code copied to static folder: {static_qr_path}")
                    
                    # Формируем относительный путь для отображения QR-кода в шаблоне
                    qr_code_path = f"/static/qrcode_{user_id}_{qr_payment_id}.png"
                except Exception as e:
                    logger.error(f"Error copying QR-code to static folder: {e}")
                    qr_code_path = ""
    
    # Получаем информацию о платеже для отображения срока действия
    payment_expires_at = None
    if qr_payment_id:
        payment_status = check_payment_status(qr_payment_id)
        if payment_status['success'] and payment_status.get('expires_at'):
            try:
                payment_expires_at = datetime.datetime.fromisoformat(payment_status['expires_at']).strftime("%d.%m.%Y %H:%M")
            except (ValueError, TypeError) as e:
                logger.error(f"Error parsing payment expiry time: {e}")
                pass
    
    # Создаем уникальную ссылку на оплату через Robokassa для этого пользователя
    robokassa_payment_url = f"/pay/{user_id}"
    
    # Отображаем страницу активации подписки с QR-кодом и информацией о сроке действия
    template_data = {
        'user_id': user_id,
        'payment_id': qr_payment_id,
        'payment_expires_at': payment_expires_at
    }
    
    if qr_code_path:
        template_data['qr_code_path'] = qr_code_path
    
    if robokassa_payment_url:
        template_data['robokassa_payment_url'] = robokassa_payment_url
    
    return render_template('activate_subscription.html', **template_data)

# Административные маршруты
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """
    Страница входа в административную панель
    """
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Проверяем, является ли пользователь администратором по его Telegram ID
        # В реальной системе здесь должна быть более безопасная проверка
        if username == 'admin' and password == 'admin123':
            admin_id = 5913639088  # ID администратора из config.ADMIN_TELEGRAM_ID
            session['admin_authenticated'] = True
            session['admin_id'] = admin_id
            return redirect(url_for('admin_dashboard'))
        else:
            error = "Неверный ID администратора или ключ доступа"
    
    return render_template('admin_login.html', error=error)

@app.route('/admin/logout')
def admin_logout():
    """
    Выход из административной панели
    """
    session.pop('admin_authenticated', None)
    session.pop('admin_id', None)
    return redirect(url_for('admin_login'))

@app.route('/admin')
@login_required
def admin_dashboard():
    """
    Главная страница административной панели
    """
    # Получаем статистику реферальной программы
    stats = get_referral_statistics()
    
    return render_template_string("""
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Панель администратора | Бот Катюша</title>
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
        <style>
            body {
                padding-top: 20px;
                padding-bottom: 40px;
            }
            .admin-container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 20px;
            }
            .dashboard-stats {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin-bottom: 30px;
            }
            .stat-card {
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .stat-card h3 {
                margin-top: 0;
                color: #adb5bd;
                font-size: 1rem;
                text-transform: uppercase;
                letter-spacing: 1px;
            }
            .stat-card .stat-value {
                font-size: 2rem;
                font-weight: bold;
                margin: 10px 0;
            }
        </style>
    </head>
    <body data-bs-theme="dark">
        <div class="admin-container">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
                <div class="container-fluid">
                    <a class="navbar-brand" href="/admin">
                        <img src="/static/logo.png" alt="Катюша Бот" width="30" height="30" class="d-inline-block align-text-top">
                        Административная панель
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link active" href="/admin"><i class="bi bi-speedometer2"></i> Панель</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/admin/payouts"><i class="bi bi-cash-stack"></i> Выплаты</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/admin/users"><i class="bi bi-people"></i> Пользователи</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/admin/stats"><i class="bi bi-graph-up"></i> Статистика</a>
                            </li>
                        </ul>
                        <ul class="navbar-nav ms-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="/admin/logout"><i class="bi bi-box-arrow-right"></i> Выход</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            
            <h1 class="mb-4">Панель администратора</h1>
            
            <div class="dashboard-stats">
                <div class="stat-card bg-dark">
                    <h3>Всего пользователей</h3>
                    <div class="stat-value">{{ stats.total_users }}</div>
                    <div class="text-muted">Активных: {{ stats.active_users }}</div>
                </div>
                <div class="stat-card bg-dark">
                    <h3>Активных подписок</h3>
                    <div class="stat-value">{{ stats.active_subscriptions }}</div>
                    <div class="text-muted">Выручка: {{ stats.total_subscription_revenue }} ₽</div>
                </div>
                <div class="stat-card bg-dark">
                    <h3>Реферальная система</h3>
                    <div class="stat-value">{{ stats.total_referrals }}</div>
                    <div class="text-muted">Активных рефералов: {{ stats.active_referrals }}</div>
                </div>
                <div class="stat-card bg-dark">
                    <h3>Выплаты рефералам</h3>
                    <div class="stat-value">{{ stats.total_referral_payments }} ₽</div>
                    <div class="text-muted">Ожидает: {{ stats.pending_referral_payments }} ₽</div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Быстрые действия</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="/admin/payouts" class="btn btn-outline-primary">Управление выплатами</a>
                                <a href="/admin/backup" class="btn btn-outline-secondary">Создать резервную копию БД</a>
                                <a href="/oauth/" class="btn btn-outline-info">Настройка Яндекс.Диска</a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Последние активности</h5>
                        </div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                {% for activity in stats.recent_activities %}
                                <li class="list-group-item bg-dark">
                                    <div class="d-flex justify-content-between">
                                        <div>{{ activity.description }}</div>
                                        <small class="text-muted">{{ activity.time }}</small>
                                    </div>
                                </li>
                                {% endfor %}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    """, stats=stats)

@app.route('/admin/payouts')
@login_required
async def admin_payouts_page():
    """
    Страница управления выплатами
    """
    # Получаем параметры пагинации и фильтрации
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', 'all')
    per_page = 10
    
    # Получаем список еженедельных выплат
    payouts, total = await get_weekly_payouts(
        page=page, 
        per_page=per_page, 
        status=status if status != 'all' else None
    )
    
    # Получаем статистику по выплатам
    stats = {
        'total_payouts': total,
        'total_amount': sum(p.get('total_amount', 0) for p in payouts),
        'pending_payouts': len([p for p in payouts if p.get('status') == 'pending']),
        'pending_amount': sum(p.get('total_amount', 0) for p in payouts if p.get('status') == 'pending'),
        'processing_payouts': len([p for p in payouts if p.get('status') == 'processing']),
        'processing_amount': sum(p.get('total_amount', 0) for p in payouts if p.get('status') == 'processing'),
        'completed_payouts': len([p for p in payouts if p.get('status') == 'completed']),
        'completed_amount': sum(p.get('total_amount', 0) for p in payouts if p.get('status') == 'completed'),
    }
    
    # Получаем статистику по пользователям с ожидающими выплатами
    users_with_pending_rewards = await get_users_with_pending_rewards(min_amount=1000)
    pending_stats = {
        'total_users': len(users_with_pending_rewards),
        'total_amount': sum(u.get('amount', 0) for u in users_with_pending_rewards),
        'eligible_users': len([u for u in users_with_pending_rewards if u.get('amount', 0) >= 1000]),
        'eligible_amount': sum(u.get('amount', 0) for u in users_with_pending_rewards if u.get('amount', 0) >= 1000)
    }
    
    # Рассчитываем общее количество страниц
    total_pages = (total + per_page - 1) // per_page
    
    # Данные для вкладки с транзакциями
    transactions_page = request.args.get('transactions_page', 1, type=int)
    transaction_status = request.args.get('transaction_status', 'all')
    transactions_per_page = 20
    
    # Получаем список транзакций
    transactions, transactions_total = await get_transactions_by_status(
        page=transactions_page,
        per_page=transactions_per_page,
        status=transaction_status if transaction_status != 'all' else None,
        type_filter='referral_reward'
    )
    
    # Рассчитываем общее количество страниц для транзакций
    transactions_total_pages = (transactions_total + transactions_per_page - 1) // transactions_per_page
    
    return render_template(
        'admin_payouts.html',
        payouts=payouts,
        stats=stats,
        pending_stats=pending_stats,
        min_payout_amount=1000,
        current_page=page,
        total_pages=total_pages,
        status=status,
        transactions=transactions,
        transactions_current_page=transactions_page,
        transactions_total_pages=transactions_total_pages,
        transaction_status=transaction_status
    )

# Маршруты для API администратора

@app.route('/admin/payouts/create', methods=['POST'])
@login_required
def admin_create_payout():
    """
    Создание еженедельной выплаты
    """
    # Создаем еженедельную выплату
    payout = create_weekly_payout(min_amount=1000)
    
    if payout:
        return redirect(url_for('admin_payouts_page', success='Еженедельная выплата успешно создана'))
    else:
        return redirect(url_for('admin_payouts_page', error='Ошибка при создании выплаты'))

@app.route('/admin/payouts/process', methods=['POST'])
@login_required
def admin_process_payout():
    """
    Обработка еженедельной выплаты
    """
    payout_id = request.form.get('payout_id')
    processing_mode = request.form.get('mode', 'tier')
    
    if not payout_id:
        return redirect(url_for('admin_payouts_page', error='ID выплаты не указан'))
    
    # Обновляем статус выплаты
    success = update_payout_status(payout_id, 'processing')
    
    if success:
        # В реальной реализации здесь будет запуск процесса обработки выплат через API Robokassa
        return redirect(url_for('admin_payouts_page', success=f'Выплата #{payout_id} переведена в статус "обработка"'))
    else:
        return redirect(url_for('admin_payouts_page', error=f'Ошибка при обработке выплаты #{payout_id}'))

@app.route('/admin/payouts/complete', methods=['POST'])
@login_required
def admin_complete_payout():
    """
    Завершение еженедельной выплаты
    """
    payout_id = request.form.get('payout_id')
    
    if not payout_id:
        return redirect(url_for('admin_payouts_page', error='ID выплаты не указан'))
    
    # Обновляем статус выплаты
    success = update_payout_status(payout_id, 'completed')
    
    if success:
        return redirect(url_for('admin_payouts_page', success=f'Выплата #{payout_id} успешно завершена'))
    else:
        return redirect(url_for('admin_payouts_page', error=f'Ошибка при завершении выплаты #{payout_id}'))

@app.route('/admin/payouts/notify', methods=['POST'])
@login_required
def admin_notify_users():
    """
    Уведомление пользователей о доступных выплатах
    """
    message = request.form.get('message', '')
    
    # В реальной реализации здесь будет запуск уведомлений через Telegram API
    return redirect(url_for('admin_payouts_page', success='Уведомления отправлены пользователям'))

# Инициализация новой централизованной платежной системы
# Инициализируем сервис проверки платежей (старая версия)
payment_verification_service.init_app(app)

# Инициализируем улучшенный сервис проверки платежей (новая версия)
payment_verification_service_v2.init_app(app)

# Инициализируем фасад процессора платежей
payment_processor_facade.init_app(app)

# Инициализируем сервис блокировок для предотвращения параллельного запуска
instance_lock_service.init_app(app)

# Регистрируем обработчики веб-хуков для платежей
register_payment_webhooks(app)  # Для обратной совместимости

# Регистрируем страницы для платежей
register_payment_pages(app)  # Для обратной совместимости

# Подключаем новый унифицированный обработчик платежей
from services.unified_payment_routes import register_payment_routes
register_payment_routes(app)

# Логируем успешную инициализацию
logger.info("Payment system successfully initialized")

def run_webhook_server(port=5000):
    """
    Запускает сервер для обработки вебхуков
    
    Args:
        port: Порт для веб-сервера
    """
    logger.info(f"Starting webhook server on port {port}")
    app.run(host="0.0.0.0", port=port)