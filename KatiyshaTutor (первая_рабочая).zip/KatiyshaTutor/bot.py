#!/usr/bin/env python
# coding: utf-8

"""
Bot initialization and configuration
"""

import logging
import asyncio
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters
)

import config
from services.rate_limiter import cleanup_history
from handlers import (
    start_command,
    help_command,
    solve_command,
    subscribe_command,
    activate_subscription_command,
    handle_text,
    handle_photo,
    handle_voice,
    handle_callback,
    error_handler
)
# Импортируем обработчики реферальной системы напрямую из новой системы
from new_referral_code.referral_handlers import (
    invite_command, process_referral, get_referral_handlers, 
    get_referral_dynamic_handlers, rewards_command
)
from admin_handlers import admin_command, get_admin_handlers
# Импортируем обработчик тестирования платформы
from platform_test_handler import test_platform_command
# Импортируем обработчики обратной связи о совместимости платформ
from platform_feedback_handlers import get_feedback_handlers
# Старый модуль rewards для совместимости
# from reward_handlers import rewards_command, get_handlers as get_reward_handlers
from admin_new_handlers import (
    get_antifraud_admin_handlers,
    get_antifraud_admin_commands, 
    get_antifraud_dynamic_handlers, 
    process_export_user_command
)

logger = logging.getLogger(__name__)

async def create_bot():
    """Create and configure the bot with all necessary handlers and services"""
    # Получаем токен бота из конфига
    token = config.TELEGRAM_TOKEN
    if not token:
        logger.error("Bot token not found in environment variables")
        return None
    
    # Создаем приложение бота с улучшенными настройками сетевых таймаутов
    application = Application.builder()\
        .token(token)\
        .connect_timeout(30.0)\
        .read_timeout(30.0)\
        .pool_timeout(30.0)\
        .write_timeout(30.0)\
        .get_updates_connection_pool_size(8)\
        .get_updates_connect_timeout(30.0)\
        .get_updates_read_timeout(30.0)\
        .build()
    
    # Настраиваем планировщик задач для бота
    from apscheduler.schedulers.asyncio import AsyncIOScheduler
    scheduler = AsyncIOScheduler()
    
    # Добавляем задачу для очистки истории запросов (защита от флуда)
    scheduler.add_job(cleanup_history, 'interval', hours=1)  # Очистка каждый час
    scheduler.start()
    
    # Регистрируем обработчики команд
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("solve", solve_command))
    application.add_handler(CommandHandler("subscribe", subscribe_command))
    application.add_handler(CommandHandler("invite", invite_command))
    application.add_handler(CommandHandler("activate_subscription", activate_subscription_command))
    application.add_handler(CommandHandler("rewards", rewards_command))
    application.add_handler(CommandHandler("admin", admin_command))
    application.add_handler(CommandHandler("test_platform", test_platform_command))
    
    # Регистрируем обработчики обратной связи о платформах
    feedback_handlers = get_feedback_handlers()
    for handler in feedback_handlers:
        application.add_handler(handler)
    
    # Регистрируем обработчики сообщений
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    application.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    application.add_handler(MessageHandler(filters.VOICE, handle_voice))
    
    # Регистрируем обработчики административных команд
    # Получаем статические и динамические обработчики администратора
    admin_handlers, admin_dynamic_handlers = get_admin_handlers()
    
    # Регистрируем статические обработчики
    for callback_data, handler_func in admin_handlers.items():
        application.add_handler(CallbackQueryHandler(handler_func, pattern=f"^{callback_data}$"))
    
    # Регистрируем динамические обработчики (с маской)
    for prefix, handler_func in admin_dynamic_handlers.items():
        application.add_handler(CallbackQueryHandler(handler_func, pattern=f"^{prefix}"))
    
    # Регистрируем обработчики антифрод системы
    antifraud_handlers = get_antifraud_admin_handlers()
    for callback_data, handler_func in antifraud_handlers.items():
        application.add_handler(CallbackQueryHandler(handler_func, pattern=f"^{callback_data}$"))
    
    # Регистрируем динамические обработчики антифрод системы
    antifraud_dynamic_handlers = get_antifraud_dynamic_handlers()
    for prefix, handler_func in antifraud_dynamic_handlers.items():
        application.add_handler(CallbackQueryHandler(handler_func, pattern=f"^{prefix}"))
    
    # Регистрируем обработчики реферальной системы из новой имплементации
    referral_handlers = get_referral_handlers()
    for callback_data, handler_func in referral_handlers.items():
        application.add_handler(CallbackQueryHandler(handler_func, pattern=f"^{callback_data}$"))
    
    # Регистрируем динамические обработчики реферальной системы (с масками для поддержки колбэков с параметрами)
    referral_dynamic_handlers = get_referral_dynamic_handlers()
    for prefix, handler_func in referral_dynamic_handlers.items():
        application.add_handler(CallbackQueryHandler(handler_func, pattern=f"^{prefix}"))
    
    # Регистрируем обработчики предварительного просмотра текста
    try:
        from services.text_preview_service import get_text_preview_handlers
        text_preview_handlers = get_text_preview_handlers()
        for prefix, handler_func in text_preview_handlers.items():
            application.add_handler(CallbackQueryHandler(handler_func, pattern=f"^{prefix}"))
        logger.info("Text preview handlers registered")
    except Exception as e:
        logger.error(f"Failed to register text preview handlers: {e}")
    
    # Регистрируем обработчик колбэков для inline-клавиатур с проверкой подходящего обработчика
    # Должен быть последним, так как обрабатывает все оставшиеся callback запросы
    application.add_handler(CallbackQueryHandler(handle_callback))
    
    # Регистрируем вспомогательные команды администратора
    application.add_handler(CommandHandler("export_user", process_export_user_command))
    
    # Регистрируем обработчик ошибок
    application.add_error_handler(error_handler)
    
    # Настраиваем сервис уведомлений администраторов
    try:
        from services.admin_notification_service import setup_admin_notifications
        setup_admin_notifications(application.bot)
        logger.info("Admin notification service initialized")
    except Exception as e:
        logger.error(f"Failed to initialize admin notification service: {e}")
    
    # Устанавливаем команды для бота (отображаются в меню команд в Telegram)
    await application.bot.set_my_commands([
        (command, description) for command, description in config.COMMANDS.items()
    ])
    
    return application