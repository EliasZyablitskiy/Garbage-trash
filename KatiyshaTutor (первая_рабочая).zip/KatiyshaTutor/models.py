#!/usr/bin/env python
# coding: utf-8

"""
Data models for the Katiysha bot
"""

from datetime import datetime
from typing import Dict, Any, Optional

class User:
    """User model for storing user information and subscription status"""
    id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    free_request_used: bool = False
    subscription_expiry: Optional[datetime] = None
    referral_code: Optional[str] = None
    referrer_id: Optional[int] = None
    referrals: Optional[Dict[str, Any]] = None
    
    def __init__(self, user_id: int, username: Optional[str] = None, 
                 first_name: Optional[str] = None, last_name: Optional[str] = None):
        self.id = user_id
        self.username = username
        self.first_name = first_name
        self.last_name = last_name
        self.free_request_used = False
        self.subscription_expiry = None
        self.referral_code = None
        self.referrer_id = None
        self.referrals = {
            "level1": [],  # 5% (прямые рефералы)
            "level2": [],  # 2% (рефералы 2-го уровня)
            "level3": [],  # 2% (рефералы 3-го уровня)
            "level4": [],  # 2% (рефералы 4-го уровня)
        }
    
    def has_active_subscription(self) -> bool:
        """Check if user has an active subscription"""
        # Используем централизованный метод проверки подписки
        from services.subscription_service import is_subscription_active
        
        # Создаем словарь с данными для проверки
        user_data = {
            'id': self.id,
            'subscription_expiry': self.subscription_expiry.isoformat() if self.subscription_expiry else None
        }
        
        return is_subscription_active(user_data)
    
    def generate_referral_code(self) -> str:
        """Generate a unique referral code for the user"""
        if not self.referral_code:
            import uuid
            import base64
            # Создаем уникальный код на основе ID пользователя и случайного UUID
            code_base = f"{self.id}_{uuid.uuid4().hex[:8]}"
            # Кодируем в base64 и берем первые 10 символов
            self.referral_code = base64.b64encode(code_base.encode()).decode()[:10]
        return self.referral_code
    
    def get_referral_link(self) -> str:
        """Get full referral link for the user"""
        # We are importing here to avoid circular imports
        import config
        code = self.generate_referral_code()
        return f"https://t.me/{config.BOT_USERNAME}?start=ref_{code}"
    
    def can_solve_problem(self) -> bool:
        """Check if user can solve a problem (has free request or active subscription)"""
        # Используем централизованную логику проверки прав доступа
        from services.subscription_service import can_use_problem_solving
        
        can_solve, reason = can_use_problem_solving(self.id)
        return can_solve
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'User':
        """Create a User instance from dictionary data"""
        user = cls(
            user_id=data['id'],
            username=data.get('username'),
            first_name=data.get('first_name'),
            last_name=data.get('last_name')
        )
        
        user.free_request_used = data.get('free_request_used', False)
        
        if 'subscription_expiry' in data and data['subscription_expiry']:
            try:
                user.subscription_expiry = datetime.fromisoformat(data['subscription_expiry'])
            except (ValueError, TypeError):
                user.subscription_expiry = None
        
        # Добавляем загрузку данных о рефералах
        user.referral_code = data.get('referral_code')
        user.referrer_id = data.get('referrer_id')
        user.referrals = data.get('referrals', {
            "level1": [],  # 5% (прямые рефералы)
            "level2": [],  # 2% (рефералы 2-го уровня)
            "level3": [],  # 2% (рефералы 3-го уровня)
            "level4": [],  # 2% (рефералы 4-го уровня)
        })
        
        return user
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert User instance to dictionary for storage"""
        data = {
            'id': self.id,
            'username': self.username,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'free_request_used': self.free_request_used
        }
        
        if self.subscription_expiry:
            data['subscription_expiry'] = self.subscription_expiry.isoformat()
        else:
            data['subscription_expiry'] = None
        
        # Добавляем сохранение данных о рефералах
        data['referral_code'] = self.referral_code
        data['referrer_id'] = self.referrer_id
        data['referrals'] = self.referrals
            
        return data

class MathProblem:
    """Math problem model for tracking user problems"""
    user_id: int
    problem_text: str
    image_path: Optional[str] = None
    solution: Optional[str] = None
    created_at: datetime = datetime.now()
    
    def __init__(self, user_id: int, problem_text: str, image_path: Optional[str] = None):
        self.user_id = user_id
        self.problem_text = problem_text
        self.image_path = image_path
        self.solution = None
        self.created_at = datetime.now()