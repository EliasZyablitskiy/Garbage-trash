#!/usr/bin/env python
# coding: utf-8

"""
Проверка существующей структуры реферальной программы на соответствие требованиям
"""

import logging
from db_config import get_flask_app
from db_models import db, User, Transaction
from new_referral_models import ReferralCode, ReferralRelation, ReferralReward
from new_referral_code.optimized_referral_manager import OptimizedReferralManager

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger("check_existing_structure")

def check_commission_rates():
    """
    Проверяет настройки комиссий в реферальной программе
    """
    referral_manager = OptimizedReferralManager()
    
    # Проверяем комиссии
    logger.info("Текущие настройки комиссий в реферальной программе:")
    logger.info(f"Уровень 1: {referral_manager.LEVEL_COMMISSIONS.get(1, 'Не задано')*100}%")
    logger.info(f"Уровень 2: {referral_manager.LEVEL_COMMISSIONS.get(2, 'Не задано')*100}%")
    logger.info(f"Уровень 3: {referral_manager.LEVEL_COMMISSIONS.get(3, 'Не задано')*100}%")
    logger.info(f"Уровень 4: {referral_manager.LEVEL_COMMISSIONS.get(4, 'Не задано')*100}%")
    logger.info(f"Максимальный уровень: {referral_manager.MAX_LEVEL}")
    
    # Проверяем соответствие требованиям
    expected_commissions = {
        1: 0.05,  # 5% для прямых рефералов
        2: 0.02,  # 2% для рефералов 2-го уровня
        3: 0.02,  # 2% для рефералов 3-го уровня
        4: 0.02   # 2% для рефералов 4-го уровня
    }
    expected_max_level = 4
    
    commissions_match = True
    for level, expected_rate in expected_commissions.items():
        actual_rate = referral_manager.LEVEL_COMMISSIONS.get(level, 0)
        if actual_rate != expected_rate:
            logger.warning(f"Несоответствие комиссии для уровня {level}: "
                         f"ожидалось {expected_rate*100}%, фактически {actual_rate*100}%")
            commissions_match = False
    
    if referral_manager.MAX_LEVEL != expected_max_level:
        logger.warning(f"Несоответствие максимального уровня: "
                     f"ожидалось {expected_max_level}, фактически {referral_manager.MAX_LEVEL}")
        commissions_match = False
    
    if commissions_match:
        logger.info("РЕЗУЛЬТАТ: Настройки комиссий СООТВЕТСТВУЮТ требованиям")
    else:
        logger.warning("РЕЗУЛЬТАТ: Настройки комиссий НЕ СООТВЕТСТВУЮТ требованиям")
    
    return commissions_match

def check_referral_relations():
    """
    Проверяет реферальные отношения в базе данных на соответствие требуемой структуре
    """
    app = get_flask_app()
    
    with app.app_context():
        # Проверяем, есть ли в базе данных реферальные отношения
        total_relations = ReferralRelation.query.count()
        logger.info(f"Всего реферальных отношений в базе данных: {total_relations}")
        
        # Проверяем распределение отношений по уровням
        level_counts = {}
        for level in range(1, 5):
            count = ReferralRelation.query.filter_by(level=level).count()
            level_counts[level] = count
            logger.info(f"Количество отношений уровня {level}: {count}")
        
        # Проверяем, есть ли цепочки реферальных отношений глубиной до 4 уровней
        has_deep_chains = False
        deep_chain_users = []
        
        # Находим пользователей, у которых есть рефереры уровня 4
        users_with_level4 = ReferralRelation.query.filter_by(level=4).all()
        for relation in users_with_level4:
            user_id = relation.user_id
            user = User.query.filter_by(id=user_id).first()
            username = user.username if user else f"ID: {user_id}"
            deep_chain_users.append(username)
            has_deep_chains = True
        
        if has_deep_chains:
            logger.info(f"Найдены цепочки реферальных отношений глубиной до 4 уровней для пользователей: {', '.join(deep_chain_users)}")
        else:
            logger.warning("В базе данных нет цепочек реферальных отношений глубиной до 4 уровней")
        
        return {
            "total_relations": total_relations,
            "level_counts": level_counts,
            "has_deep_chains": has_deep_chains,
            "deep_chain_users": deep_chain_users
        }

def check_reward_distribution():
    """
    Проверяет распределение вознаграждений в базе данных
    """
    app = get_flask_app()
    
    with app.app_context():
        # Проверяем, есть ли в базе данных реферальные вознаграждения
        total_rewards = ReferralReward.query.count()
        logger.info(f"Всего реферальных вознаграждений в базе данных: {total_rewards}")
        
        if total_rewards == 0:
            logger.warning("В базе данных нет реферальных вознаграждений")
            return {"total_rewards": 0}
        
        # Находим транзакции с несколькими вознаграждениями
        # Это потенциальные транзакции с глубокой цепочкой рефералов
        rewards_counts = {}
        potential_transactions = []
        
        # Группируем вознаграждения по транзакциям
        transactions_with_rewards = (
            ReferralReward.query
            .with_entities(ReferralReward.source_transaction_id, db.func.count(ReferralReward.id).label('reward_count'))
            .group_by(ReferralReward.source_transaction_id)
            .all()
        )
        
        for transaction_id, count in transactions_with_rewards:
            rewards_counts[transaction_id] = count
            if count >= 3:  # Если есть 3 или более вознаграждений для одной транзакции
                potential_transactions.append(transaction_id)
        
        if potential_transactions:
            logger.info(f"Найдены транзакции с несколькими вознаграждениями: {potential_transactions}")
            
            # Анализируем вознаграждения для одной из потенциальных транзакций
            sample_transaction_id = potential_transactions[0]
            transaction = Transaction.query.filter_by(id=sample_transaction_id).first()
            
            if transaction:
                logger.info(f"Анализ транзакции {sample_transaction_id} (пользователь {transaction.user_id}, сумма {transaction.amount})")
                
                # Получаем все вознаграждения для этой транзакции
                rewards = (
                    ReferralReward.query
                    .filter_by(source_transaction_id=sample_transaction_id)
                    .all()
                )
                
                for reward in rewards:
                    relation = ReferralRelation.query.filter_by(id=reward.referral_relation_id).first()
                    if relation:
                        referrer = User.query.filter_by(id=relation.referrer_id).first()
                        referrer_name = referrer.username if referrer else f"ID: {relation.referrer_id}"
                        percent = round(reward.amount / transaction.amount * 100, 2)
                        logger.info(f"  - Уровень {relation.level}: {referrer_name} получил {reward.amount} ₽ ({percent}%)")
                
                # Проверяем соответствие проценту комиссии
                logger.info("Проверка соответствия процентов комиссии:")
                referral_manager = OptimizedReferralManager()
                
                for reward in rewards:
                    relation = ReferralRelation.query.filter_by(id=reward.referral_relation_id).first()
                    if relation:
                        expected_commission = referral_manager.LEVEL_COMMISSIONS.get(relation.level, 0)
                        expected_amount = transaction.amount * expected_commission
                        actual_amount = reward.amount
                        
                        # Допускаем небольшую погрешность из-за округления
                        if abs(expected_amount - actual_amount) < 0.1:
                            logger.info(f"  ✓ Уровень {relation.level}: комиссия соответствует ({actual_amount} ₽ ≈ {expected_amount} ₽)")
                        else:
                            logger.warning(f"  ✗ Уровень {relation.level}: комиссия НЕ соответствует (ожидалось {expected_amount} ₽, фактически {actual_amount} ₽)")
        else:
            logger.warning("Не найдены транзакции с глубокой структурой вознаграждений")
        
        return {
            "total_rewards": total_rewards,
            "rewards_distribution": rewards_counts,
            "potential_transactions": potential_transactions
        }

def main():
    """
    Основная функция проверки
    """
    logger.info("=== ПРОВЕРКА СТРУКТУРЫ РЕФЕРАЛЬНОЙ ПРОГРАММЫ ===")
    
    # Проверяем настройки комиссий
    commissions_match = check_commission_rates()
    
    # Проверяем реферальные отношения
    relations_info = check_referral_relations()
    
    # Проверяем распределение вознаграждений
    rewards_info = check_reward_distribution()
    
    # Итоговый результат
    logger.info("\n=== ИТОГОВЫЙ РЕЗУЛЬТАТ ===")
    logger.info(f"1. Настройки комиссий: {'СООТВЕТСТВУЮТ' if commissions_match else 'НЕ СООТВЕТСТВУЮТ'} требованиям")
    logger.info(f"2. Реферальные отношения: найдено {relations_info['total_relations']} отношений")
    logger.info(f"   Глубокие цепочки (4 уровня): {'НАЙДЕНЫ' if relations_info['has_deep_chains'] else 'НЕ НАЙДЕНЫ'}")
    logger.info(f"3. Реферальные вознаграждения: найдено {rewards_info['total_rewards']} вознаграждений")
    
    # Формирование вывода о соответствии требованиям
    structure_match = commissions_match and relations_info['has_deep_chains'] and rewards_info['total_rewards'] > 0
    logger.info(f"\nОБЩИЙ ВЫВОД: Структура реферальной программы {'СООТВЕТСТВУЕТ' if structure_match else 'НЕ ПОЛНОСТЬЮ СООТВЕТСТВУЕТ'} требованиям")
    logger.info("===============================================")

if __name__ == "__main__":
    main()