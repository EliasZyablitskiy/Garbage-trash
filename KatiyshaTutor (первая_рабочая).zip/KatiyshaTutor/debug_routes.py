#!/usr/bin/env python3
# debug_routes.py

from flask import url_for
from webhook_handler import app
import sys

def debug_url(endpoint, **kwargs):
    with app.test_request_context():
        try:
            url = url_for(endpoint, **kwargs)
            print(f"Success! URL for {endpoint}: {url}")
            return url
        except Exception as e:
            print(f"Error! Failed to generate URL for {endpoint}: {e}")
            return None

def debug_admin_endpoints():
    """Проверка эндпоинтов администратора"""
    print("Debugging admin endpoints...")
    
    # Проверяем различные варианты эндпоинтов
    endpoints = [
        "admin_blueprint.login",
        "admin_login",
        "admin_web.login",
        "admin_blueprint.dashboard",
        "admin_dashboard",
        "admin_web.dashboard"
    ]
    
    # Пытаемся сгенерировать URL для каждого эндпоинта
    for endpoint in endpoints:
        debug_url(endpoint)
    
    # Проверяем также варианты с точкой или без
    parts = [
        "admin_blueprint", 
        "admin_web"
    ]
    
    functions = [
        "login", 
        "dashboard", 
        "users", 
        "transactions", 
        "payouts", 
        "reports"
    ]
    
    for part in parts:
        for func in functions:
            debug_url(f"{part}.{func}")

if __name__ == "__main__":
    debug_admin_endpoints()