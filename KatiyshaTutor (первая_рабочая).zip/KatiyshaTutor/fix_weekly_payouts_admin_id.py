#!/usr/bin/env python3
"""
Скрипт для исправления еженедельных выплат без admin_id
"""
import logging
from sqlalchemy import text
from db_config import db, get_flask_app

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def fix_weekly_payouts_admin_id():
    """
    Исправляет записи WeeklyPayout с отсутствующим admin_id, 
    устанавливая admin_id на ID администратора системы
    """
    app = get_flask_app()

    with app.app_context():
        # Получаем ID администратора (используем первого администратора)
        admin_id = db.session.execute(text("SELECT id FROM users WHERE id = 5913639088 LIMIT 1")).scalar()
        
        if not admin_id:
            logger.error("❌ Не найден администратор для исправления выплат")
            return False
        
        # Подсчитываем количество выплат без admin_id
        invalid_count = db.session.execute(
            text("SELECT COUNT(*) FROM weekly_payouts WHERE admin_id IS NULL")
        ).scalar()
        
        if invalid_count == 0:
            logger.info("✅ Все выплаты уже имеют корректный admin_id")
            return True
        
        # Обновляем записи
        db.session.execute(
            text(f"UPDATE weekly_payouts SET admin_id = {admin_id} WHERE admin_id IS NULL")
        )
        
        # Проверяем, что amount заполнен (если нет, копируем из total_amount)
        db.session.execute(
            text("UPDATE weekly_payouts SET amount = total_amount WHERE amount IS NULL OR amount = 0")
        )
        
        db.session.commit()
        
        logger.info(f"✅ Обновлено {invalid_count} записей WeeklyPayout: установлен admin_id={admin_id}")
        
        # Проверяем, что исправления применены
        remaining = db.session.execute(
            text("SELECT COUNT(*) FROM weekly_payouts WHERE admin_id IS NULL")
        ).scalar()
        
        if remaining > 0:
            logger.error(f"❌ Остались выплаты без admin_id: {remaining}")
            return False
        
        logger.info("✅ Все выплаты имеют корректный admin_id")
        return True

if __name__ == "__main__":
    logger.info("Запуск исправления еженедельных выплат без admin_id...")
    if fix_weekly_payouts_admin_id():
        logger.info("✅ Исправление успешно завершено")
    else:
        logger.error("❌ Исправление не удалось")