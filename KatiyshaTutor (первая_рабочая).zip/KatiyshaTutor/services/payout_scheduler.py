#!/usr/bin/env python
# coding: utf-8

"""
Сервис для планирования выплат и мониторинга
"""

import asyncio
import logging
import datetime
import schedule
from typing import Dict, Any, List, Optional

from db_config import db
from db_models import WeeklyPayout, Transaction
from services.payout_logging_service import log_payout_operation
from services.payout_monitoring_service import check_payout_status, find_stuck_payouts
from services.payout_service import create_weekly_payout, process_payout_by_tiers, notify_users_with_pending_rewards

# Настройка логирования
logger = logging.getLogger(__name__)

# Константы
MIN_PAYOUT_AMOUNT = 1000.0  # Минимальная сумма для выплаты (рублей)
WEEKLY_PAYOUT_DAY = 1  # День недели для еженедельной выплаты (понедельник)
CHECK_INTERVAL_HOURS = 4  # Интервал проверки статуса выплат (часов)
NOTIFICATION_INTERVAL_DAYS = 7  # Интервал отправки уведомлений (дней)


async def schedule_weekly_payouts(bot) -> Dict[str, Any]:
    """
    Планирование и обработка еженедельных выплат
    
    Args:
        bot: Экземпляр бота Telegram
        
    Returns:
        Dict: Результат операции
    """
    try:
        logger.info("Starting weekly payout scheduling")
        
        # Проверяем, что сегодня подходящий день недели (по умолчанию понедельник)
        today = datetime.datetime.now()
        if today.weekday() != WEEKLY_PAYOUT_DAY:
            logger.info(f"Today is not day {WEEKLY_PAYOUT_DAY} of the week, skipping payout scheduling")
            return {
                "status": "skipped",
                "reason": f"Today is not day {WEEKLY_PAYOUT_DAY} of the week"
            }
        
        # Проверяем, не была ли уже создана выплата сегодня
        start_of_day = today.replace(hour=0, minute=0, second=0, microsecond=0)
        end_of_day = start_of_day + datetime.timedelta(days=1)
        
        query = await db.session.execute(
            db.select(WeeklyPayout).filter(
                WeeklyPayout.created_at >= start_of_day,
                WeeklyPayout.created_at < end_of_day
            )
        )
        existing_payout = query.scalar_one_or_none()
        
        if existing_payout:
            logger.info(f"Payout already created today (ID: {existing_payout.id}), skipping")
            return {
                "status": "skipped",
                "reason": "Payout already created today",
                "payout_id": existing_payout.id
            }
        
        # Создаем новую еженедельную выплату
        payout_id = await create_weekly_payout(min_amount=MIN_PAYOUT_AMOUNT)
        
        if not payout_id:
            logger.warning("Failed to create weekly payout")
            await log_payout_operation(
                operation_type="schedule_weekly_payouts",
                status="failed",
                error_message="Failed to create weekly payout"
            )
            return {
                "status": "error",
                "error": "Failed to create weekly payout"
            }
        
        logger.info(f"Weekly payout created with ID: {payout_id}")
        
        # Запускаем обработку созданной выплаты
        process_result = await process_payout_by_tiers(bot, payout_id)
        
        # Логируем результат
        await log_payout_operation(
            operation_type="schedule_weekly_payouts",
            payout_id=payout_id,
            status="success" if process_result.get("error") is None else "failed",
            response_data=process_result,
            error_message=process_result.get("error")
        )
        
        return {
            "status": "success",
            "payout_id": payout_id,
            "process_result": process_result
        }
    except Exception as e:
        logger.error(f"Error scheduling weekly payouts: {e}")
        
        # Логируем ошибку
        await log_payout_operation(
            operation_type="schedule_weekly_payouts",
            status="failed",
            error_message=str(e)
        )
        
        return {"status": "error", "error": str(e)}


async def schedule_payout_status_checks() -> Dict[str, Any]:
    """
    Планирование проверки статуса выплат
    
    Returns:
        Dict: Результат операции
    """
    try:
        logger.info("Starting payout status check scheduling")
        
        # Ищем выплаты в статусе "processing" или "partial"
        query = await db.session.execute(
            db.select(WeeklyPayout).filter(
                WeeklyPayout.status.in_(["processing", "partial"])
            )
        )
        payouts = query.scalars().all()
        
        if not payouts:
            logger.info("No payouts in processing or partial status found")
            return {
                "status": "skipped",
                "reason": "No payouts to check"
            }
        
        # Проверяем статус каждой выплаты
        check_results = []
        for payout in payouts:
            logger.info(f"Checking status of payout {payout.id}")
            check_result = await check_payout_status(payout.id)
            check_results.append({
                "payout_id": payout.id,
                "result": check_result
            })
        
        # Ищем зависшие выплаты
        stuck_payouts = await find_stuck_payouts()
        
        # Логируем результат
        await log_payout_operation(
            operation_type="schedule_payout_status_checks",
            status="success",
            response_data={
                "check_results": check_results,
                "stuck_payouts": stuck_payouts
            }
        )
        
        return {
            "status": "success",
            "checks_performed": len(check_results),
            "check_results": check_results,
            "stuck_payouts": stuck_payouts
        }
    except Exception as e:
        logger.error(f"Error scheduling payout status checks: {e}")
        
        # Логируем ошибку
        await log_payout_operation(
            operation_type="schedule_payout_status_checks",
            status="failed",
            error_message=str(e)
        )
        
        return {"status": "error", "error": str(e)}


async def schedule_pending_rewards_notifications(bot) -> Dict[str, Any]:
    """
    Планирование отправки уведомлений о доступных выплатах
    
    Args:
        bot: Экземпляр бота Telegram
        
    Returns:
        Dict: Результат операции
    """
    try:
        logger.info("Starting pending rewards notification scheduling")
        
        # Проверяем, прошло ли необходимое количество дней с последнего уведомления
        last_notification_query = await db.session.execute(
            db.select(PayoutOperationLog)
            .filter(PayoutOperationLog.operation_type == "schedule_pending_rewards_notifications")
            .order_by(PayoutOperationLog.created_at.desc())
            .limit(1)
        )
        last_notification = last_notification_query.scalar_one_or_none()
        
        if last_notification:
            days_since_last = (datetime.datetime.now() - last_notification.created_at).days
            if days_since_last < NOTIFICATION_INTERVAL_DAYS:
                logger.info(f"Last notification was sent {days_since_last} days ago, skipping")
                return {
                    "status": "skipped",
                    "reason": f"Last notification was sent {days_since_last} days ago"
                }
        
        # Отправляем уведомления пользователям с доступными выплатами
        message = (
            "💰 *Вам доступна выплата реферального вознаграждения*\n\n"
            "Вы можете запросить выплату, отправив команду /rewards боту."
        )
        
        notification_result = await notify_users_with_pending_rewards(message, min_amount=MIN_PAYOUT_AMOUNT)
        
        # Логируем результат
        await log_payout_operation(
            operation_type="schedule_pending_rewards_notifications",
            status="success" if notification_result.get("error") is None else "failed",
            response_data=notification_result,
            error_message=notification_result.get("error")
        )
        
        return {
            "status": "success",
            "notification_result": notification_result
        }
    except Exception as e:
        logger.error(f"Error scheduling pending rewards notifications: {e}")
        
        # Логируем ошибку
        await log_payout_operation(
            operation_type="schedule_pending_rewards_notifications",
            status="failed",
            error_message=str(e)
        )
        
        return {"status": "error", "error": str(e)}


def setup_payout_scheduler(bot) -> Dict[str, Any]:
    """
    Настройка планировщика выплат
    
    Args:
        bot: Экземпляр бота Telegram
        
    Returns:
        Dict: Результат настройки
    """
    try:
        logger.info("Setting up payout scheduler")
        
        # Функция для запуска асинхронного задания в планировщике
        def run_async_task(coro):
            loop = asyncio.get_event_loop()
            return loop.create_task(coro)
        
        # Планируем еженедельные выплаты (каждый понедельник в 3:00)
        schedule.every().monday.at("03:00").do(lambda: run_async_task(schedule_weekly_payouts(bot)))
        
        # Планируем проверку статуса выплат (каждые 4 часа)
        schedule.every(CHECK_INTERVAL_HOURS).hours.do(lambda: run_async_task(schedule_payout_status_checks()))
        
        # Планируем отправку уведомлений о доступных выплатах (каждую неделю в четверг в 12:00)
        schedule.every().thursday.at("12:00").do(lambda: run_async_task(schedule_pending_rewards_notifications(bot)))
        
        logger.info("Payout scheduler setup completed")
        
        return {
            "status": "success",
            "scheduled_tasks": {
                "weekly_payouts": "Every Monday at 03:00",
                "status_checks": f"Every {CHECK_INTERVAL_HOURS} hours",
                "notifications": "Every Thursday at 12:00"
            }
        }
    except Exception as e:
        logger.error(f"Error setting up payout scheduler: {e}")
        return {"status": "error", "error": str(e)}