#!/usr/bin/env python
# coding: utf-8

"""
Сервис отправки уведомлений пользователям
Предоставляет функции для отправки различных типов уведомлений через Telegram
Реализует многопоточную очередь для надежной доставки сообщений
"""

import os
import json
import logging
import threading
import time
import enum
from queue import Queue, PriorityQueue, Empty
from datetime import datetime, timedelta
from typing import Dict, Any, Tuple, Optional, List, Union
import pickle
import os.path

from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import TelegramError, Forbidden, BadRequest, TimedOut, NetworkError, RetryAfter

from db_models import db, Transaction, User, BatchPayout, WeeklyPayout
from config import ADMIN_IDS
from services.payment_verification_service import PAYMENT_STATUS, PAYMENT_SYSTEMS
from services.payment_result import PaymentResult
from services.payment_verification_service_v2 import PaymentResultCode

# Настройка логирования
logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Перечисления для типов уведомлений
class NotificationType(enum.Enum):
    """Типы уведомлений"""
    GENERAL = "general"
    PAYMENT_SUCCESS = "payment_success"
    PAYMENT_FAILURE = "payment_failure"
    PAYMENT_PENDING = "payment_pending"
    PAYMENT_DUPLICATE = "payment_duplicate"
    SUBSCRIPTION_REMINDER = "subscription_reminder"
    SYSTEM_NOTIFICATION = "system_notification"
    ERROR_NOTIFICATION = "error_notification"
    RECOVERY_NOTIFICATION = "recovery_notification"
    ADMIN_ALERT = "admin_alert"
    DEBUG = "debug"

class NotificationPriority(enum.Enum):
    """Приоритеты уведомлений (меньшее значение = выше приоритет)"""
    HIGH = 1  # Высокий приоритет (платежи, ошибки)
    NORMAL = 2  # Обычный приоритет
    LOW = 3  # Низкий приоритет (рассылки, информационные)

class NotificationTemplates:
    """Шаблоны уведомлений"""
    # Шаблоны уведомлений об оплате
    PAYMENT_SUCCESS_TEMPLATE = """
🎉 Оплата успешно проведена!

Ваша подписка активирована на {subscription_days} дней.
Срок действия: до {expiration_date}.

Спасибо за использование нашего сервиса! Теперь вы можете решать любое количество математических задач.
"""

    PAYMENT_FAILURE_TEMPLATE = """
❌ Ошибка при обработке платежа

Код ошибки: {error_code}
Сообщение: {error_message}

Пожалуйста, попробуйте снова или обратитесь в поддержку.
"""

    PAYMENT_PENDING_TEMPLATE = """
⏳ Платеж находится в обработке

Ваш платеж был получен и в данный момент обрабатывается. 
Подписка будет активирована автоматически после подтверждения оплаты.

Пожалуйста, подождите немного.
"""

    PAYMENT_DUPLICATE_TEMPLATE = """
ℹ️ Повторный платеж

Мы обнаружили, что этот платеж уже был обработан ранее.
Ваша подписка уже активна.

Если у вас есть вопросы, обратитесь в поддержку.
"""

    PAYMENT_INVALID_AMOUNT_TEMPLATE = """
❌ Неверная сумма платежа

Сумма платежа не соответствует стоимости подписки. 
Пожалуйста, попробуйте снова с правильной суммой (199 руб).

Если у вас возникли вопросы, обратитесь в поддержку.
"""

    PAYMENT_SECURITY_ERROR_TEMPLATE = """
🔒 Ошибка проверки безопасности платежа

Платеж не может быть обработан из-за ошибки проверки безопасности.
Пожалуйста, попробуйте снова или используйте другой способ оплаты.
"""

    PAYMENT_ALREADY_PROCESSED_TEMPLATE = """
ℹ️ Платеж уже обработан

Этот платеж уже был обработан ранее.
Ваша подписка уже активна.

Если у вас есть вопросы, обратитесь в поддержку.
"""

    # Прочие шаблоны
    SUBSCRIPTION_REMINDER_TEMPLATE = """
⏰ Напоминание о подписке

До окончания вашей подписки осталось {days_left} дней.
Чтобы продолжить пользоваться сервисом без ограничений, пожалуйста, продлите подписку.

Для продления используйте команду /pay
"""

    SYSTEM_NOTIFICATION_TEMPLATE = """
📢 Системное уведомление

{message}
"""

    ERROR_NOTIFICATION_TEMPLATE = """
❌ Ошибка

{error_message}

Пожалуйста, сообщите об этой ошибке разработчикам.
"""

    RECOVERY_NOTIFICATION_TEMPLATE = """
🔄 Восстановление платежа

Мы обнаружили незавершенный платеж #{transaction_id}.
Статус платежа: {status}

{additional_info}
"""

class QueuedNotification:
    """Класс для представления уведомления в очереди"""
    def __init__(
        self, 
        user_id: int, 
        message: str, 
        notification_type: NotificationType,
        priority: NotificationPriority = NotificationPriority.NORMAL,
        timestamp: float = None,
        keyboard: InlineKeyboardMarkup = None,
        retry_count: int = 0,
        error: str = None
    ):
        self.user_id = user_id
        self.message = message
        self.notification_type = notification_type
        self.priority = priority
        self.timestamp = timestamp or time.time()
        self.keyboard = keyboard
        self.retry_count = retry_count
        self.error = error
        
    def __lt__(self, other):
        """Сравнение по приоритету для PriorityQueue"""
        if self.priority.value != other.priority.value:
            return self.priority.value < other.priority.value
        return self.timestamp < other.timestamp

class NotificationQueue:
    """Реализация очереди уведомлений с приоритетами и персистентностью"""
    
    def __init__(self, queue_file_path="notification_queue.pickle"):
        self.queue = PriorityQueue()
        self.lock = threading.RLock()
        self.queue_file_path = queue_file_path
        self.stopped = False
        self.load_from_file()
        
    def put(self, notification: QueuedNotification, block=True, timeout=None):
        """Добавить уведомление в очередь"""
        with self.lock:
            self.queue.put(notification, block=block, timeout=timeout)
            self.save_to_file()
            
    def get(self, block=True, timeout=None) -> Optional[QueuedNotification]:
        """Получить уведомление из очереди"""
        with self.lock:
            try:
                notification = self.queue.get(block=block, timeout=timeout)
                self.save_to_file()
                return notification
            except Empty:
                return None
                
    def empty(self) -> bool:
        """Проверить, пуста ли очередь"""
        with self.lock:
            return self.queue.empty()
            
    def qsize(self) -> int:
        """Получить размер очереди"""
        with self.lock:
            return self.queue.qsize()
            
    def task_done(self):
        """Отметить задачу как выполненную"""
        with self.lock:
            self.queue.task_done()
            
    def save_to_file(self):
        """Сохранить очередь в файл"""
        if self.stopped:
            return
            
        try:
            with open(self.queue_file_path, 'wb') as f:
                items = []
                temp_queue = PriorityQueue()
                
                # Извлекаем все элементы из очереди
                while not self.queue.empty():
                    item = self.queue.get()
                    items.append(item)
                    temp_queue.put(item)
                
                # Восстанавливаем очередь
                self.queue = temp_queue
                
                # Сохраняем элементы в файл
                pickle.dump(items, f)
        except Exception as e:
            logger.error(f"Error saving queue to file: {e}")
            
    def load_from_file(self):
        """Загрузить очередь из файла"""
        if not os.path.exists(self.queue_file_path):
            return
            
        try:
            with open(self.queue_file_path, 'rb') as f:
                items = pickle.load(f)
                for item in items:
                    self.queue.put(item)
                logger.info(f"Loaded {len(items)} notifications from file")
        except Exception as e:
            logger.error(f"Error loading queue from file: {e}")
            
    def start(self):
        """Запустить работу очереди"""
        self.stopped = False
        logger.info("Notification queue started")
        
    def stop(self):
        """Остановить работу очереди"""
        self.stopped = True
        self.save_to_file()
        logger.info("Notification queue stopped and saved")

class NotificationService:
    """Сервис отправки уведомлений пользователям"""
    
    def __init__(self, bot: Bot = None, telegram_token: str = None, admin_ids: List[int] = None):
        """
        Инициализация сервиса уведомлений
        
        :param bot: Экземпляр бота Telegram
        :param telegram_token: Токен бота Telegram (если bot не указан)
        :param admin_ids: Список ID администраторов
        """
        self.bot = bot
        
        if bot is None and telegram_token:
            self.bot = Bot(token=telegram_token)
        elif bot is None and not telegram_token:
            telegram_token = os.environ.get('TELEGRAM_TOKEN')
            if not telegram_token:
                raise ValueError("Either bot or telegram_token must be provided")
            self.bot = Bot(token=telegram_token)
            
        self.admin_ids = admin_ids or ADMIN_IDS
        
        # Инициализация очереди уведомлений
        self.notification_queue = NotificationQueue()
        self.worker_thread = None
        self.is_processing_queue = False
        
        # Запуск обработки очереди
        self.start_queue_processing()
            
    def start_queue_processing(self):
        """Запуск обработки очереди уведомлений в отдельном потоке"""
        if self.is_processing_queue:
            logger.info("Queue processing is already running")
            return
            
        self.is_processing_queue = True
        self.notification_queue.start()
        
        # Создаем и запускаем поток обработки
        self.worker_thread = threading.Thread(
            target=self._process_notification_queue_thread,
            daemon=True
        )
        self.worker_thread.start()
        logger.info("Notification queue processing started")
        
    def stop_queue_processing(self):
        """Остановка обработки очереди уведомлений"""
        self.is_processing_queue = False
        if self.notification_queue:
            self.notification_queue.stop()
        
        if self.worker_thread and self.worker_thread.is_alive():
            self.worker_thread.join(timeout=2.0)
        logger.info("Notification queue processing stopped")
        
    def _process_notification_queue_thread(self):
        """Поток обработки очереди уведомлений"""
        logger.info("Starting notification queue processing thread")
        
        while self.is_processing_queue:
            try:
                # Проверяем, существует ли очередь
                if not hasattr(self, 'notification_queue') or self.notification_queue is None:
                    time.sleep(1)
                    continue
                
                # Если очередь пуста, ждем небольшой интервал и проверяем снова
                if self.notification_queue.empty():
                    time.sleep(1)
                    continue
                    
                # Получаем уведомление из очереди
                notification = self.notification_queue.get(block=False)
                
                if notification is None:
                    continue
                    
                # Отправляем уведомление
                success = False
                try:
                    success = self._send_notification_direct(
                        user_id=notification.user_id,
                        message=notification.message,
                        notification_type=notification.notification_type,
                        keyboard=notification.keyboard
                    )
                except Exception as send_error:
                    error_msg = str(send_error)
                    logger.error(f"Error sending notification: {error_msg}")
                    notification.error = error_msg
                
                # Если не удалось отправить, добавляем в очередь на повторную отправку
                if not success and notification.retry_count < 3:
                    try:
                        # Увеличиваем счетчик попыток
                        notification.retry_count += 1
                        
                        # Рассчитываем время следующей попытки (экспоненциальная задержка)
                        delay = 60 * (2 ** (notification.retry_count - 1))  # 1 минута, 2 минуты, 4 минуты
                        next_try_time = time.time() + delay
                        
                        # Обновляем временную метку для правильной сортировки в очереди
                        notification.timestamp = next_try_time
                        
                        # Помещаем обратно в очередь
                        self.notification_queue.put(notification)
                        logger.info(
                            f"Scheduled retry #{notification.retry_count} for user {notification.user_id} "
                            f"type {notification.notification_type} in {delay} seconds"
                        )
                    except Exception as retry_error:
                        logger.error(f"Error scheduling retry: {retry_error}")
                
                # Отмечаем задачу как выполненную
                self.notification_queue.task_done()
                
            except Exception as e:
                logger.error(f"Error processing notification queue: {e}")
                time.sleep(1)
                
    def _send_notification_direct(self, user_id: int, message: str, 
                                notification_type: NotificationType = NotificationType.GENERAL, 
                                keyboard: InlineKeyboardMarkup = None) -> bool:
        """
        Прямая отправка уведомления пользователю (без очереди)
        
        :param user_id: ID пользователя
        :param message: Сообщение для отправки
        :param notification_type: Тип уведомления
        :param keyboard: Клавиатура InlineKeyboardMarkup
        :return: True, если отправка успешна
        """
        if not message:
            logger.warning(f"Empty message for user {user_id}, type {notification_type}")
            return False
            
        try:
            # Проверяем, существует ли пользователь в базе
            user = User.query.filter_by(id=user_id).first()
            if not user:
                logger.warning(f"User {user_id} not found in database")
                return False
                
            # Отправляем сообщение через API Telegram
            self.bot.send_message(
                chat_id=user_id,
                text=message,
                parse_mode='HTML',
                reply_markup=keyboard
            )
            
            # Логируем успешную отправку
            logger.info(f"Notification sent to user {user_id}, type: {notification_type}")
            return True
            
        except Forbidden as e:
            # Пользователь заблокировал бота
            logger.warning(f"User {user_id} blocked the bot: {e}")
            
            # Обновляем статус пользователя в базе
            try:
                user = User.query.filter_by(id=user_id).first()
                if user:
                    user.is_blocked = True
                    db.session.commit()
            except Exception as db_error:
                logger.error(f"Error updating user blocked status: {db_error}")
                
            return False
            
        except BadRequest as e:
            # Ошибка в запросе (неверный chat_id, неверный формат сообщения и т.д.)
            logger.error(f"Bad request for user {user_id}: {e}")
            return False
            
        except TimedOut as e:
            # Тайм-аут запроса к API Telegram
            logger.error(f"Timed out sending notification to user {user_id}: {e}")
            return False
            
        except NetworkError as e:
            # Сетевая ошибка
            logger.error(f"Network error sending notification to user {user_id}: {e}")
            return False
            
        except RetryAfter as e:
            # Превышение лимита запросов, нужно повторить позже
            logger.warning(f"Retry after for user {user_id}: {e}")
            return False
            
        except TelegramError as e:
            # Прочие ошибки Telegram
            logger.error(f"Telegram error for user {user_id}: {e}")
            return False
            
        except Exception as e:
            # Другие непредвиденные ошибки
            logger.error(f"Unexpected error sending notification to user {user_id}: {e}")
            return False
    
    def send_notification(self, user_id: int, message: str, 
                       notification_type: NotificationType = NotificationType.GENERAL,
                       priority: NotificationPriority = NotificationPriority.NORMAL,
                       keyboard: InlineKeyboardMarkup = None) -> bool:
        """
        Синхронная отправка уведомления пользователю (блокирующий вызов)
        
        :param user_id: ID пользователя
        :param message: Сообщение для отправки
        :param notification_type: Тип уведомления
        :param priority: Приоритет уведомления
        :param keyboard: Клавиатура InlineKeyboardMarkup
        :return: True, если отправка успешна
        """
        if not message:
            return False
            
        return self._send_notification_direct(
            user_id=user_id,
            message=message,
            notification_type=notification_type,
            keyboard=keyboard
        )
        
    def send_notification_async(self, user_id: int, message: str, 
                             notification_type: NotificationType = NotificationType.GENERAL,
                             priority: NotificationPriority = NotificationPriority.NORMAL,
                             keyboard: InlineKeyboardMarkup = None) -> bool:
        """
        Асинхронная отправка уведомления через очередь
        
        :param user_id: ID пользователя
        :param message: Сообщение для отправки
        :param notification_type: Тип уведомления
        :param priority: Приоритет уведомления
        :param keyboard: Клавиатура InlineKeyboardMarkup
        :return: True, если уведомление добавлено в очередь
        """
        if not message:
            return False
            
        try:
            # Создаем объект уведомления
            notification = QueuedNotification(
                user_id=user_id,
                message=message,
                notification_type=notification_type,
                priority=priority,
                keyboard=keyboard
            )
            
            # Добавляем в очередь
            self.notification_queue.put(notification)
            
            # Если обработка очереди не запущена, запускаем
            if not self.is_processing_queue:
                self.start_queue_processing()
                
            return True
        except Exception as e:
            logger.error(f"Error adding notification to queue: {e}")
            return False
    
    def send_payment_verification_result(self, user_id: int, payment_result: PaymentResult) -> bool:
        """
        Отправка уведомления о результате проверки платежа
        
        :param user_id: ID пользователя
        :param payment_result: Результат проверки платежа
        :return: True, если уведомление отправлено успешно
        """
        if payment_result.success:
            # Формируем сообщение об успешном платеже
            message = NotificationTemplates.PAYMENT_SUCCESS_TEMPLATE.format(
                subscription_days=payment_result.subscription_days,
                expiration_date=payment_result.expiration_date.strftime("%d.%m.%Y")
            )
            
            # Отправляем уведомление
            return self.send_notification_async(
                user_id=user_id,
                message=message,
                notification_type=NotificationType.PAYMENT_SUCCESS,
                priority=NotificationPriority.HIGH
            )
        else:
            # Формируем сообщение об ошибке
            message = NotificationTemplates.PAYMENT_FAILURE_TEMPLATE.format(
                error_code=payment_result.error_code or "Неизвестная ошибка",
                error_message=payment_result.error_message or "Не удалось обработать платеж"
            )
            
            # Отправляем уведомление
            return self.send_notification_async(
                user_id=user_id,
                message=message,
                notification_type=NotificationType.PAYMENT_FAILURE,
                priority=NotificationPriority.HIGH
            )

    def send_payment_verification_result_v2(self, user_id: int, payment_result: PaymentResult, payment_link: str = None) -> bool:
        """
        Отправка уведомления о результате проверки платежа (версия 2)
        Поддерживает все статусы из PaymentResultCode
        
        :param user_id: ID пользователя
        :param payment_result: Результат проверки платежа
        :param payment_link: Ссылка на оплату (для кнопки повторной оплаты)
        :return: True, если уведомление отправлено успешно
        """
        # Клавиатура по умолчанию
        keyboard = None
        
        # По статусу платежа определяем сообщение и клавиатуру
        if payment_result.result_code == PaymentResultCode.SUCCESS:
            # Успешный платеж
            message = NotificationTemplates.PAYMENT_SUCCESS_TEMPLATE.format(
                subscription_days=30,  # По умолчанию 30 дней
                expiration_date=datetime.now() + timedelta(days=30)  # Примерная дата
            )
            
            return self.send_notification_async(
                user_id=user_id,
                message=message,
                notification_type=NotificationType.PAYMENT_SUCCESS,
                priority=NotificationPriority.HIGH
            )
            
        elif payment_result.result_code == PaymentResultCode.PENDING:
            # Платеж в обработке
            message = NotificationTemplates.PAYMENT_PENDING_TEMPLATE
            
            return self.send_notification_async(
                user_id=user_id,
                message=message,
                notification_type=NotificationType.PAYMENT_PENDING,
                priority=NotificationPriority.HIGH
            )
            
        elif payment_result.result_code == PaymentResultCode.DUPLICATE:
            # Дубликат платежа
            message = NotificationTemplates.PAYMENT_DUPLICATE_TEMPLATE
            
            return self.send_notification_async(
                user_id=user_id,
                message=message,
                notification_type=NotificationType.PAYMENT_DUPLICATE,
                priority=NotificationPriority.NORMAL
            )
            
        elif payment_result.result_code == PaymentResultCode.INVALID_AMOUNT:
            # Неверная сумма
            message = NotificationTemplates.PAYMENT_INVALID_AMOUNT_TEMPLATE
            
            return self.send_notification_async(
                user_id=user_id,
                message=message,
                notification_type=NotificationType.PAYMENT_FAILURE,
                priority=NotificationPriority.HIGH
            )
            
        elif payment_result.result_code == PaymentResultCode.SECURITY_ERROR:
            # Ошибка безопасности
            message = NotificationTemplates.PAYMENT_SECURITY_ERROR_TEMPLATE
            
            return self.send_notification_async(
                user_id=user_id,
                message=message,
                notification_type=NotificationType.PAYMENT_FAILURE,
                priority=NotificationPriority.HIGH
            )
            
        elif payment_result.result_code == PaymentResultCode.ALREADY_PROCESSED:
            # Уже обработан
            message = NotificationTemplates.PAYMENT_ALREADY_PROCESSED_TEMPLATE
            
            return self.send_notification_async(
                user_id=user_id,
                message=message,
                notification_type=NotificationType.PAYMENT_DUPLICATE,
                priority=NotificationPriority.NORMAL
            )
            
        else:
            # Прочие ошибки
            message = NotificationTemplates.PAYMENT_FAILURE_TEMPLATE.format(
                error_code=payment_result.result_code.value if hasattr(payment_result, 'result_code') else "UNKNOWN",
                error_message=payment_result.error_message or "Не удалось обработать платеж"
            )
            
            # Добавляем кнопку "Повторить оплату", если есть ссылка
            if payment_link:
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("Повторить оплату", url=payment_link)]
                ])
            
            # Отправляем через очередь
            return self.send_notification_async(
                user_id=user_id,
                message=message,
                notification_type=NotificationType.PAYMENT_FAILURE,
                priority=NotificationPriority.HIGH,
                keyboard=keyboard
            )