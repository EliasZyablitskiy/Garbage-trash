# Architecture Documentation

## 1. Overview

Katiysha is a Telegram bot that helps users solve mathematical problems using artificial intelligence. The bot offers a freemium model where users get one free mathematical problem solution and then require a subscription for additional solutions. It includes features such as:

- Mathematical problem-solving with detailed explanations
- Text extraction from photos (OCR)
- Speech recognition from voice messages
- Subscription management system
- Multi-level referral system with commissions up to 4 levels

The system is built as a Python application that combines a Telegram bot interface with a Flask web server for handling payment webhooks and administrative functions.

## 2. System Architecture

The architecture follows a modular design with separate components for:

1. **Telegram Bot Service**: Handles user interactions through the Telegram API
2. **Web Server**: Processes webhooks from payment systems and provides admin interfaces
3. **Database Layer**: Stores user data, subscriptions, and transaction history
4. **External Services**: Integrates with AI providers, OCR services, and payment gateways

### High-Level Architecture Diagram

```
┌───────────────────┐      ┌───────────────────┐      ┌───────────────────┐
│                   │      │                   │      │                   │
│   Telegram API    │<─────┤   Katiysha Bot    │<─────┤  External APIs    │
│                   │      │                   │      │  (AI, OCR, Speech) │
└───────────────────┘      └─────────┬─────────┘      └───────────────────┘
                                     │
                                     │
                           ┌─────────▼─────────┐
                           │                   │
                           │   Flask Server    │<─────┐
                           │   (Webhooks)      │      │
                           └─────────┬─────────┘      │
                                     │                │
                                     │                │
                           ┌─────────▼─────────┐      │
                           │                   │      │
                           │    PostgreSQL     │      │
                           │    Database       │      │
                           │                   │      │
                           └───────────────────┘      │
                                                      │
                                                      │
                           ┌───────────────────┐      │
                           │                   │      │
                           │  Payment Systems  │──────┘
                           │  (Robokassa)      │
                           │                   │
                           └───────────────────┘
```

## 3. Key Components

### 3.1 Telegram Bot

The bot is implemented using the `python-telegram-bot` library with an asynchronous architecture.

**Key Files:**
- `main.py`: Entry point that initializes both the bot and web server
- `bot.py`: Bot initialization and configuration
- `handlers.py`: Command and message handlers
- `keyboards.py`: Telegram UI keyboard definitions

The bot utilizes a rate limiting system to prevent abuse, implemented via a custom decorator in `services/rate_limiter.py`.

### 3.2 Web Server

A Flask application provides webhook endpoints for payment notifications and an administrative interface.

**Key Files:**
- `webhook_handler.py`: Main Flask application with webhook routes
- `app.py`: WSGI entry point for the Flask application
- `oauth_routes.py`: Yandex.Disk OAuth integration for backups

### 3.3 Database Layer

The system has been migrated from JSON file storage to PostgreSQL using SQLAlchemy ORM.

**Key Files:**
- `db_models.py`: SQLAlchemy model definitions
- `db_config.py`: Database connection configuration
- `database.py`: Legacy JSON database functions (maintained for backward compatibility)
- `create_migration.py` & `create_bigint_migration.py`: Database migration scripts

**Database Models:**
- User: Stores user information and subscription status
- MathProblem: Records of mathematical problems solved
- Transaction: Payment and referral reward transactions
- WeeklyPayout: Batch payouts for referral rewards
- YandexDiskToken: OAuth tokens for backup service

### 3.4 Service Modules

Functionality is modularized into service components:

**AI Services:**
- `services/deepseek_service.py`: Mathematical problem-solving via AI

**Media Processing:**
- `services/ocr_service.py`: Extracts text from images
- `services/speech_service.py`: Converts voice messages to text

**Payment and Rewards:**
- `services/payment_service.py`: Subscription and payment processing
- `services/payout_service.py`: Handles referral rewards
- `services/rate_limiter.py`: Rate limiting for API endpoints
- `services/antifraud_service.py`: Fraud detection for financial transactions

**Backup System:**
- `backup_database.py`: Creates database backups
- `backup_scheduler.py`: Schedules automatic backups
- `yandex_oauth_helper.py`: Manages Yandex.Disk authentication for storing backups

## 4. Data Flow

### 4.1 User Interaction Flow

1. User sends a message or command to the bot through Telegram
2. The bot's message handlers process the input based on type (text, photo, voice)
3. If solving a math problem:
   - The message is processed through appropriate services (OCR for images, speech recognition for voice)
   - The extracted problem is sent to AI services for solution
   - The solution is returned to the user
4. Subscription status is checked before providing solutions (beyond the free trial)

### 4.2 Payment Flow

1. User requests subscription through the bot
2. Bot generates payment link/instructions
3. User completes payment via external payment system (Robokassa)
4. Payment system sends webhook notification to the Flask server
5. Server verifies the payment signature and activates user subscription
6. Referral rewards are calculated and distributed if applicable

### 4.3 Referral System Flow

1. User invites others through a referral link
2. New users are tracked with the referrer's ID (up to 4 levels deep)
3. When a referred user makes a payment, rewards are calculated:
   - Level 1 (direct referral): 5% commission
   - Level 2: 2% commission
   - Level 3: 2% commission
   - Level 4: 1% commission
4. Administrators can approve and process payouts through the admin interface

### 4.4 Backup Flow

1. Scheduled backups run at configured intervals
2. Database schema and/or data is exported to SQL files
3. Files are uploaded to Yandex.Disk for storage
4. Backup logs are maintained in database and local files

## 5. External Dependencies

### 5.1 External APIs

- **Telegram Bot API**: Primary user interface
- **ProxyAPI**: Intermediary service for accessing AI models
  - DeepSeek: Primary AI model for mathematical problem solving
  - OpenAI (fallback): Secondary AI model when primary is unavailable
- **Free Online OCR API**: Text extraction from images
- **Robokassa**: Payment processing system

### 5.2 Key Libraries

- `python-telegram-bot`: Telegram bot framework
- `flask` & `flask-sqlalchemy`: Web server and ORM
- `gunicorn`: WSGI HTTP server
- `psycopg2-binary`: PostgreSQL adapter
- `aiohttp`: Asynchronous HTTP client for API calls
- `pytesseract`: OCR processing
- `pydub` & `speechrecognition`: Voice processing
- `pillow`: Image processing
- `qrcode`: QR code generation for payment links
- `schedule`: Task scheduling for backups

## 6. Deployment Strategy

The application is designed to run on Replit, a cloud-based development platform, with the following components:

1. **Main Application**: Runs the Telegram bot and Flask server in parallel using Gunicorn
2. **Database**: Uses a PostgreSQL database hosted on Neon (referenced by DATABASE_URL environment variable)
3. **Backup System**: Runs as a scheduled service using systemd or through the built-in scheduler

### Environment Configuration

The application relies on numerous environment variables for configuration:

- `TELEGRAM_TOKEN`: Authentication token for the Telegram Bot API
- `PROXYAPI_KEY`: API key for the ProxyAPI service
- `OCR_API_KEY`: API key for the OCR service
- `ROBOKASSA_SECRET_KEY`: Key for verifying Robokassa webhook signatures
- `DATABASE_URL`: PostgreSQL connection string
- `YANDEX_OAUTH_CLIENT_ID` & `YANDEX_OAUTH_CLIENT_SECRET`: For Yandex.Disk backup integration

### Resilience Mechanisms

1. **Cascading AI Services**: If the primary AI service fails, the system falls back to alternative services
2. **Rate Limiting**: Prevents API abuse and manages load
3. **Database Backups**: Regular automated backups to Yandex.Disk
4. **Anti-Fraud System**: Monitors and prevents suspicious transactions

## 7. Security Considerations

1. **Payment Validation**: Signatures are verified for all payment webhooks
2. **Admin Authentication**: Web admin interface requires authentication
3. **Rate Limiting**: Prevents brute force and DoS attacks
4. **Transaction Monitoring**: Anti-fraud system monitors for suspicious patterns
5. **Backup Encryption**: Database backups are securely stored in Yandex.Disk

## 8. Future Architecture Considerations

1. **Containerization**: Moving to Docker would improve deployment consistency
2. **Service Separation**: Splitting the bot and web server into separate microservices
3. **Message Queue**: Implementing a message queue for better scaling of async tasks
4. **Caching Layer**: Adding Redis or similar for caching frequent requests
5. **Monitoring**: Implementing comprehensive monitoring and alerting