import unittest
import sys
import os
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta

# Add the project root directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from models import User, ReferralSystem

class TestUser(unittest.TestCase):
    """Test cases for the User model"""
    
    def test_initialization(self):
        """Test basic user initialization"""
        user = User(123, "testuser", "Test", "User")
        
        self.assertEqual(user.id, 123)
        self.assertEqual(user.username, "testuser")
        self.assertEqual(user.first_name, "Test")
        self.assertEqual(user.last_name, "User")
        self.assertFalse(user.free_request_used)
        self.assertIsNone(user.subscription_expiry)
        self.assertIsNone(user.referral_code)
        self.assertIsNone(user.referrer_id)
        self.assertEqual(user.referrals, {
            "level1": [],
            "level2": [],
            "level3": [],
            "level4": []
        })
    
    def test_has_active_subscription(self):
        """Test subscription status check"""
        user = User(123, "testuser", "Test", "User")
        
        # No subscription
        self.assertFalse(user.has_active_subscription())
        
        # Expired subscription
        user.subscription_expiry = datetime.now() - timedelta(days=1)
        self.assertFalse(user.has_active_subscription())
        
        # Active subscription
        user.subscription_expiry = datetime.now() + timedelta(days=30)
        self.assertTrue(user.has_active_subscription())
    
    def test_generate_referral_code(self):
        """Test referral code generation"""
        user = User(123, "testuser", "Test", "User")
        
        # No code initially
        self.assertIsNone(user.referral_code)
        
        # Generate code
        code = user.generate_referral_code()
        self.assertIsNotNone(code)
        self.assertEqual(code, user.referral_code)
        
        # Code should be the same on second call
        code2 = user.generate_referral_code()
        self.assertEqual(code, code2)
    
    @patch("models.config")
    def test_get_referral_link(self, mock_config):
        """Test generating referral link"""
        mock_config.BOT_USERNAME = "testbot"
        
        user = User(123, "testuser", "Test", "User")
        user.referral_code = "ABC123"
        
        link = user.get_referral_link()
        self.assertEqual(link, "https://t.me/testbot?start=ref_ABC123")
    
    def test_can_solve_problem(self):
        """Test problem solving eligibility"""
        user = User(123, "testuser", "Test", "User")
        
        # Free request not used
        self.assertTrue(user.can_solve_problem())
        
        # Free request used, no subscription
        user.free_request_used = True
        self.assertFalse(user.can_solve_problem())
        
        # Free request used, active subscription
        user.subscription_expiry = datetime.now() + timedelta(days=30)
        self.assertTrue(user.can_solve_problem())
    
    def test_from_dict(self):
        """Test creating user from dictionary data"""
        data = {
            "id": 123,
            "username": "testuser",
            "first_name": "Test",
            "last_name": "User",
            "free_request_used": True,
            "subscription_expiry": (datetime.now() + timedelta(days=30)).isoformat(),
            "referral_code": "ABC123",
            "referrer_id": 456,
            "referrals": {
                "level1": [789],
                "level2": [456],
                "level3": [],
                "level4": []
            }
        }
        
        user = User.from_dict(data)
        
        self.assertEqual(user.id, 123)
        self.assertEqual(user.username, "testuser")
        self.assertEqual(user.first_name, "Test")
        self.assertEqual(user.last_name, "User")
        self.assertTrue(user.free_request_used)
        self.assertIsNotNone(user.subscription_expiry)
        self.assertEqual(user.referral_code, "ABC123")
        self.assertEqual(user.referrer_id, 456)
        self.assertEqual(user.referrals, {
            "level1": [789],
            "level2": [456],
            "level3": [],
            "level4": []
        })
    
    def test_to_dict(self):
        """Test converting user to dictionary"""
        user = User(123, "testuser", "Test", "User")
        user.free_request_used = True
        user.subscription_expiry = datetime.now() + timedelta(days=30)
        user.referral_code = "ABC123"
        user.referrer_id = 456
        user.referrals = {
            "level1": [789],
            "level2": [456],
            "level3": [],
            "level4": []
        }
        
        data = user.to_dict()
        
        self.assertEqual(data["id"], 123)
        self.assertEqual(data["username"], "testuser")
        self.assertEqual(data["first_name"], "Test")
        self.assertEqual(data["last_name"], "User")
        self.assertTrue(data["free_request_used"])
        self.assertIsNotNone(data["subscription_expiry"])
        self.assertEqual(data["referral_code"], "ABC123")
        self.assertEqual(data["referrer_id"], 456)
        self.assertEqual(data["referrals"], {
            "level1": [789],
            "level2": [456],
            "level3": [],
            "level4": []
        })


class TestReferralSystem(unittest.TestCase):
    """Test cases for the ReferralSystem class"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.patcher_db = patch('models.database')
        self.patcher_config = patch('models.config')
        
        self.mock_db = self.patcher_db.start()
        self.mock_config = self.patcher_config.start()
        
        # Configure mock settings
        self.mock_config.REFERRAL_LEVEL1_RATE = 0.05
        self.mock_config.REFERRAL_LEVEL2_RATE = 0.02
        self.mock_config.REFERRAL_LEVEL3_RATE = 0.02
        self.mock_config.REFERRAL_LEVEL4_RATE = 0.02
        
        # Create test users
        self.test_users = {
            "123": {
                "id": 123,
                "username": "user1",
                "first_name": "User One",
                "referral_code": "REF123",
                "referrer_id": None,
                "referrals": [],
                "referral_levels": {"1": [], "2": [], "3": [], "4": []},
                "total_earned": 0,
                "subscription_end_date": None,
                "wallet": "wallet123"
            },
            "456": {
                "id": 456,
                "username": "user2",
                "first_name": "User Two",
                "referral_code": "REF456",
                "referrer_id": 123,
                "referrals": [],
                "referral_levels": {"1": [], "2": [], "3": [], "4": []},
                "total_earned": 0,
                "subscription_end_date": None,
                "wallet": "wallet456"
            },
            "789": {
                "id": 789,
                "username": "user3",
                "first_name": "User Three",
                "referral_code": "REF789",
                "referrer_id": 456,
                "referrals": [],
                "referral_levels": {"1": [], "2": [], "3": [], "4": []},
                "total_earned": 0,
                "subscription_end_date": None,
                "wallet": "wallet789"
            }
        }
        
        # Configure database mocks
        self.mock_db.get_user_data.side_effect = lambda user_id: self.test_users.get(str(user_id))
        self.mock_db.get_all_users.return_value = self.test_users
        self.mock_db.update_user_data.side_effect = self.mock_update_user_data
        self.mock_db.get_transactions_by_user.return_value = {}
        
        # Initialize the system under test
        self.referral_system = ReferralSystem()
    
    def tearDown(self):
        """Tear down test fixtures"""
        self.patcher_db.stop()
        self.patcher_config.stop()
    
    def mock_update_user_data(self, user_id, updated_data):
        """Mock implementation for database.update_user_data"""
        user_id_str = str(user_id)
        if user_id_str in self.test_users:
            for key, value in updated_data.items():
                self.test_users[user_id_str][key] = value
            return True
        return False
    
    def test_generate_referral_code(self):
        """Test generating a referral code"""
        # Test for existing user with no code
        user_id = 123
        self.test_users[str(user_id)]["referral_code"] = None
        
        code = self.referral_system.generate_referral_code(user_id)
        
        self.assertIsNotNone(code)
        self.assertTrue(code.startswith("REF"))
        self.assertEqual(self.test_users[str(user_id)]["referral_code"], code)
        
        # Test for user with existing code
        existing_code = "EXISTING"
        self.test_users[str(user_id)]["referral_code"] = existing_code
        
        code = self.referral_system.generate_referral_code(user_id)
        
        self.assertEqual(code, existing_code)
        
        # Test for nonexistent user
        self.mock_db.get_user_data.return_value = None
        code = self.referral_system.generate_referral_code(999)
        self.assertIsNone(code)
        
        # Reset the mock
        self.mock_db.get_user_data.side_effect = lambda user_id: self.test_users.get(str(user_id))
    
    def test_get_user_by_referral_code(self):
        """Test finding a user by referral code"""
        # Test with valid code
        user = self.referral_system.get_user_by_referral_code("REF123")
        self.assertIsNotNone(user)
        self.assertEqual(user["id"], 123)
        
        # Test with invalid code
        user = self.referral_system.get_user_by_referral_code("NONEXISTENT")
        self.assertIsNone(user)
    
    def test_add_referral(self):
        """Test adding a referral relationship"""
        # Test adding user 789 as a referral of user 123
        result = self.referral_system.add_referral(789, "REF123")
        
        self.assertTrue(result)
        self.assertEqual(self.test_users["789"]["referrer_id"], 123)
        self.assertIn(789, self.test_users["123"]["referrals"])
        self.assertIn(789, self.test_users["123"]["referral_levels"]["1"])
        
        # Test adding a referral with invalid code
        result = self.referral_system.add_referral(456, "INVALID")
        self.assertFalse(result)
        
        # Test adding a referral that already has a referrer
        result = self.referral_system.add_referral(789, "REF456")
        self.assertFalse(result)
        
        # Test self-referral
        result = self.referral_system.add_referral(123, "REF123")
        self.assertFalse(result)
        
        # Test with nonexistent user
        self.mock_db.get_user_data.return_value = None
        result = self.referral_system.add_referral(999, "REF123")
        self.assertFalse(result)
        
        # Reset the mock
        self.mock_db.get_user_data.side_effect = lambda user_id: self.test_users.get(str(user_id))
    
    def test_update_referral_chain(self):
        """Test updating the referral chain for multiple levels"""
        # Setup: 123 refers 456, 456 refers 789
        self.test_users["456"]["referrer_id"] = 123
        self.test_users["123"]["referrals"] = [456]
        self.test_users["123"]["referral_levels"]["1"] = [456]
        
        self.test_users["789"]["referrer_id"] = 456
        self.test_users["456"]["referrals"] = [789]
        self.test_users["456"]["referral_levels"]["1"] = [789]
        
        # Test the chain update (789 should be in level 2 of user 123)
        self.referral_system._update_referral_chain(789, 456, level=2)
        
        self.assertIn(789, self.test_users["123"]["referral_levels"]["2"])
        
        # Add a level 3 user
        self.test_users["999"] = {
            "id": 999,
            "username": "user4",
            "first_name": "User Four",
            "referral_code": "REF999",
            "referrer_id": 789,
            "referrals": [],
            "referral_levels": {"1": [], "2": [], "3": [], "4": []},
            "total_earned": 0,
            "subscription_end_date": None,
            "wallet": "wallet999"
        }
        
        self.test_users["789"]["referrals"] = [999]
        self.test_users["789"]["referral_levels"]["1"] = [999]
        
        # Update the chain for the new user
        self.referral_system._update_referral_chain(999, 789, level=2)
        
        # Check level 2
        self.assertIn(999, self.test_users["456"]["referral_levels"]["2"])
        
        # Check level 3
        self.assertIn(999, self.test_users["123"]["referral_levels"]["3"])
    
    def test_calculate_commission(self):
        """Test calculating commission for a payment"""
        # Setup: 123 refers 456, 456 refers 789
        self.test_users["456"]["referrer_id"] = 123
        self.test_users["123"]["referrals"] = [456]
        self.test_users["123"]["referral_levels"]["1"] = [456]
        
        self.test_users["789"]["referrer_id"] = 456
        self.test_users["456"]["referrals"] = [789]
        self.test_users["456"]["referral_levels"]["1"] = [789]
        
        # Calculate commission for user 789's payment of 100
        commissions = self.referral_system.calculate_commission(100.0, 789)
        
        # Should have 2 commissions: 5% for level 1 and 2% for level 2
        self.assertEqual(len(commissions), 2)
        
        # Check level 1 commission (5%)
        self.assertEqual(commissions[0][0], 456)
        self.assertEqual(commissions[0][1], 5.0)
        
        # Check level 2 commission (2%)
        self.assertEqual(commissions[1][0], 123)
        self.assertEqual(commissions[1][1], 2.0)
        
        # Test with user that has no referrer
        commissions = self.referral_system.calculate_commission(100.0, 123)
        self.assertEqual(len(commissions), 0)
    
    def test_get_user_referrals(self):
        """Test getting detailed referral information"""
        # Setup referral relationships
        self.test_users["456"]["referrer_id"] = 123
        self.test_users["123"]["referrals"] = [456]
        self.test_users["123"]["referral_levels"]["1"] = [456]
        
        self.test_users["789"]["referrer_id"] = 456
        self.test_users["456"]["referrals"] = [789]
        self.test_users["456"]["referral_levels"]["1"] = [789]
        self.test_users["123"]["referral_levels"]["2"] = [789]
        
        # Mock transactions for user 456
        transactions_456 = {
            "tx1": {"user_id": 456, "amount": 50.0, "type": "subscription", "status": "completed"},
            "tx2": {"user_id": 456, "amount": 25.0, "type": "subscription", "status": "completed"}
        }
        self.mock_db.get_transactions_by_user.side_effect = lambda user_id: (
            transactions_456 if user_id == 456 else {}
        )
        
        # Get referrals for user 123
        referrals = self.referral_system.get_user_referrals(123)
        
        # Should have level 1 and level 2 referrals
        self.assertEqual(len(referrals["1"]), 1)
        self.assertEqual(len(referrals["2"]), 1)
        self.assertEqual(len(referrals["3"]), 0)
        self.assertEqual(len(referrals["4"]), 0)
        
        # Check level 1 referral details
        self.assertEqual(referrals["1"][0]["id"], 456)
        self.assertEqual(referrals["1"][0]["username"], "user2")
        self.assertEqual(referrals["1"][0]["total_spent"], 75.0)  # Sum of transaction amounts
        
        # Check level 2 referral details
        self.assertEqual(referrals["2"][0]["id"], 789)
        self.assertEqual(referrals["2"][0]["username"], "user3")
        self.assertEqual(referrals["2"][0]["total_spent"], 0.0)  # No transactions
    
    def test_get_referral_stats(self):
        """Test getting referral statistics"""
        # Setup referral relationships
        self.test_users["456"]["referrer_id"] = 123
        self.test_users["123"]["referrals"] = [456]
        self.test_users["123"]["referral_levels"]["1"] = [456]
        self.test_users["123"]["total_earned"] = 7.0
        
        self.test_users["789"]["referrer_id"] = 456
        self.test_users["456"]["referrals"] = [789]
        self.test_users["456"]["referral_levels"]["1"] = [789]
        self.test_users["123"]["referral_levels"]["2"] = [789]
        
        # Setup active subscription for one referral
        self.test_users["456"]["subscription_end_date"] = (datetime.now() + timedelta(days=30)).isoformat()
        
        # Get stats for user 123
        stats = self.referral_system.get_referral_stats(123)
        
        # Check totals
        self.assertEqual(stats["total_referrals"], 2)  # 1 level1 + 1 level2
        self.assertEqual(stats["active_referrals"], 1)  # Only one has active subscription
        self.assertEqual(stats["total_earned"], 7.0)
        
        # Check level counts
        self.assertEqual(stats["levels"]["1"], 1)
        self.assertEqual(stats["levels"]["2"], 1)
        self.assertEqual(stats["levels"]["3"], 0)
        self.assertEqual(stats["levels"]["4"], 0)
        
        # Test with user that has no referrals
        stats = self.referral_system.get_referral_stats(789)
        self.assertEqual(stats["total_referrals"], 0)
        self.assertEqual(stats["active_referrals"], 0)
        self.assertEqual(stats["total_earned"], 0)
        
        # Test with nonexistent user
        self.mock_db.get_user_data.return_value = None
        stats = self.referral_system.get_referral_stats(999)
        self.assertEqual(stats["total_referrals"], 0)
        

if __name__ == '__main__':
    unittest.main() 