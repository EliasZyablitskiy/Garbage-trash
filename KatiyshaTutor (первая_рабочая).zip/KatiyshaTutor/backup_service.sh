#!/bin/bash
# Скрипт для запуска планировщика резервного копирования в фоновом режиме
# Этот скрипт будет продолжать работать даже после закрытия веб-консоли

# Переход в рабочую директорию
cd "$(dirname "$0")"

# Установка переменных окружения
export PYTHONUNBUFFERED=1  # Отключение буферизации вывода Python
export PYTHONIOENCODING=utf-8

# Настройка логирования
LOG_DIR="./logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/backup_service_$(date +%Y%m%d_%H%M%S).log"

echo "Запуск сервиса резервного копирования..."
echo "Логи будут записаны в $LOG_FILE"

# Запуск процесса планировщика резервного копирования в фоновом режиме
nohup python backup_scheduler.py schedule >> "$LOG_FILE" 2>&1 &

# Сохранение PID процесса
PID=$!
echo $PID > backup_service.pid
echo "Сервис запущен, PID: $PID"
echo "Для остановки сервиса выполните: kill $(cat backup_service.pid)"