#!/usr/bin/env python
# coding: utf-8

"""
Унифицированные обработчики для реферальной системы бота Катюша
"""

import logging
import re
from typing import Dict, Any, Optional, List, Callable, Awaitable
from datetime import datetime, timedelta

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# Импортируем сервис реферальной системы
from services.referral_service import referral_service
import config
from database import add_transaction, get_user, save_user
from transactions import get_user_payout_summary, get_user_transactions_by_status

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def invite_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик команды /invite - генерирует и показывает реферальную ссылку
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    user_id = update.effective_user.id
    bot_username = context.bot.username
    
    # Получаем данные пользователя
    user_data = referral_service.get_user(user_id)
    
    if not user_data:
        # Создаем нового пользователя
        user_data = {
            "id": user_id,
            "username": update.effective_user.username,
            "first_name": update.effective_user.first_name,
            "last_name": update.effective_user.last_name,
            "free_request_used": False,
            "subscription_expiry": None,
            "referral_code": None,
            "referrer_id": None,
            "referrals": {
                "level1": [],  # 5% (прямые рефералы)
                "level2": [],  # 2% (рефералы 2-го уровня)
                "level3": [],  # 2% (рефералы 3-го уровня)
                "level4": [],  # 2% (рефералы 4-го уровня)
            }
        }
        referral_service.save_user(user_data)
        logger.info(f"Created new user {user_id} for referral system")
    
    # Получаем реферальную ссылку
    referral_link = referral_service.get_referral_link(user_id, bot_username)
    
    # Создаем клавиатуру с кнопкой для статистики рефералов
    keyboard = [
        [InlineKeyboardButton("📊 Моя реферальная статистика", callback_data="referral_stats")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Формируем сообщение с реферальной ссылкой
    message_text = (
        f"👥 *Приглашайте друзей и зарабатывайте с реферальной программой:*\n\n"
        f"🔗 Ваша реферальная ссылка: {referral_link}\n\n"
        f"💰 Получайте вознаграждения, когда приглашенные вами пользователи оплачивают подписку:\n"
        f"• 5% за прямых рефералов (1-й уровень)\n"
        f"• 2% за рефералов 2-го уровня\n"
        f"• 2% за рефералов 3-го уровня\n"
        f"• 2% за рефералов 4-го уровня\n\n"
        f"Чем больше людей вы пригласите, тем выше будет ваш доход!"
    )
    
    await update.message.reply_text(
        message_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )
    logger.info(f"Sent referral link to user {user_id}")

async def referral_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения статистики рефералов
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    user_id = query.from_user.id
    
    # Получаем статистику рефералов
    stats_text = referral_service.get_rewards_description(user_id)
    
    # Создаем клавиатуру с дополнительными опциями
    keyboard = [
        [InlineKeyboardButton("💰 Мои выплаты", callback_data="referral_payouts")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Отвечаем на колбэк
    await query.answer()
    await query.edit_message_text(
        text=stats_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )
    logger.info(f"Displayed referral stats for user {user_id}")

async def referral_payouts_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения информации о выплатах
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    user_id = query.from_user.id
    
    # Получаем данные о выплатах пользователя
    payout_summary = get_user_payout_summary(user_id)
    rewards_stats = payout_summary["rewards_stats"]
    
    # Создаем сообщение с информацией о выплатах
    message = (
        "💰 *Информация о реферальных выплатах*\n\n"
        f"Всего заработано: {rewards_stats['total_earned']:.2f}₽\n"
        f"Выплачено: {rewards_stats['total_paid']:.2f}₽\n"
        f"Ожидает выплаты: {rewards_stats['total_pending']:.2f}₽\n"
        f"В обработке: {rewards_stats['total_processing']:.2f}₽\n\n"
    )
    
    # Добавляем информацию о текущих выплатах в обработке
    if payout_summary["total_payout_count"] > 0:
        message += (
            "🔄 *Текущие выплаты в обработке:*\n"
            f"Количество выплат: {payout_summary['total_payout_count']}\n"
            f"Общая сумма: {payout_summary['total_payout_amount']:.2f}₽\n\n"
            "Выплаты обрабатываются автоматически раз в неделю. "
            f"Минимальная сумма для выплаты составляет {config.MIN_PAYOUT_AMOUNT}₽.\n\n"
        )
    else:
        message += (
            "ℹ️ У вас нет выплат в обработке.\n\n"
            f"Выплаты создаются автоматически при достижении {config.MIN_PAYOUT_AMOUNT}₽ "
            "и обрабатываются еженедельно.\n\n"
        )
    
    # Добавляем информацию о комиссии и способе получения
    message += (
        "📝 *Как получить выплату:*\n"
        "1. Накопите минимальную сумму для выплаты\n"
        "2. Дождитесь уведомления о доступной выплате\n"
        "3. Перейдите по ссылке в уведомлении\n"
        "4. Выберите удобный способ получения средств\n\n"
        "❓ Остались вопросы? Обратитесь в поддержку."
    )
    
    # Создаем клавиатуру с кнопкой возврата
    keyboard = [
        [InlineKeyboardButton("◀️ Назад к статистике", callback_data="referral_stats")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Отвечаем на колбэк
    await query.answer()
    await query.edit_message_text(
        text=message,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )
    logger.info(f"Displayed payout information for user {user_id}")

async def process_referral(update: Update, context: ContextTypes.DEFAULT_TYPE, referral_code: str) -> None:
    """
    Обработка реферального кода при переходе по реферальной ссылке
    
    Args:
        update: Telegram update
        context: Telegram context
        referral_code: Реферальный код из ссылки
    """
    user_id = update.effective_user.id
    
    # Обрабатываем реферальный код
    success = referral_service.process_new_referral(user_id, referral_code)
    
    # Если пользователь уже имеет реферера или код неверный
    if not success:
        from keyboards import get_main_keyboard
        await update.message.reply_text(
            config.WELCOME_MESSAGE,
            reply_markup=get_main_keyboard(),
            parse_mode='Markdown'
        )
        logger.info(f"Failed to process referral code {referral_code} for user {user_id}")
        return
    
    # Отправляем приветственное сообщение с упоминанием реферальной программы
    from keyboards import get_main_keyboard
    await update.message.reply_text(
        "👋 *Добро пожаловать в Катюшу!*\n\n"
        "Вы перешли по реферальной ссылке. Когда вы активируете подписку, "
        "пригласивший вас пользователь получит вознаграждение!\n\n" + 
        config.WELCOME_MESSAGE,
        reply_markup=get_main_keyboard(),
        parse_mode='Markdown'
    )
    logger.info(f"Successfully processed referral code {referral_code} for user {user_id}")

async def process_subscription_rewards(user_id: int, amount: float = 199.0) -> Dict[str, Any]:
    """
    Обработка вознаграждений при активации подписки
    
    Args:
        user_id: ID пользователя, активировавшего подписку
        amount: Сумма оплаты
        
    Returns:
        Dict[str, Any]: Информация о начисленных вознаграждениях
    """
    # Рассчитываем вознаграждения
    rewards_data = referral_service.calculate_rewards(user_id, amount)
    
    if not rewards_data or not rewards_data.get("rewards"):
        logger.info(f"No referral rewards to process for user {user_id}")
        return {"success": False, "rewards": []}
    
    logger.info(f"Processing referral rewards for user {user_id}: {rewards_data}")
    
    processed_rewards = []
    
    # Для каждого уровня рефералов создаем транзакции с вознаграждениями
    for level_key, reward_info in rewards_data["rewards"].items():
        referrer_id = reward_info["user_id"]
        reward_amount = reward_info["amount"]
        
        # Создаем транзакцию для реферального вознаграждения
        transaction_id = add_transaction(
            transaction_type="referral_reward",
            user_id=referrer_id,
            amount=reward_amount,
            description=f"Реферальное вознаграждение {level_key} от пользователя {user_id}",
            status="pending",
            payment_data={
                "source_user_id": user_id,
                "referral_level": level_key,
                "percentage": reward_info["percentage"],
                "subscription_amount": amount
            }
        )
        
        if transaction_id:
            processed_rewards.append({
                "level": level_key,
                "user_id": referrer_id,
                "amount": reward_amount,
                "transaction_id": transaction_id
            })
            
            # Отправляем уведомление пользователю о полученном вознаграждении
            await send_reward_notification(
                referrer_id=referrer_id,
                source_user_id=user_id,
                reward_amount=reward_amount,
                level=level_key
            )
    
    logger.info(f"Processed {len(processed_rewards)} referral rewards for user {user_id}")
    return {"success": True, "rewards": processed_rewards}

async def send_reward_notification(referrer_id: int, source_user_id: int, reward_amount: float, level: str) -> bool:
    """
    Отправляет уведомление пользователю о полученном реферальном вознаграждении
    
    Args:
        referrer_id: ID пользователя, получившего вознаграждение
        source_user_id: ID пользователя, от которого получено вознаграждение
        reward_amount: Сумма вознаграждения
        level: Уровень реферальной программы
        
    Returns:
        bool: True, если уведомление успешно отправлено, False в противном случае
    """
    try:
        # Формируем сообщение с уведомлением о вознаграждении
        message = (
            f"💰 *Вы получили реферальное вознаграждение!*\n\n"
            f"Пользователь, которого вы пригласили, оплатил подписку.\n"
            f"Уровень вознаграждения: {level}\n"
            f"Размер вознаграждения: {reward_amount:.2f}₽\n\n"
            f"Ваши вознаграждения будут автоматически выплачены, "
            f"когда их сумма достигнет {config.MIN_PAYOUT_AMOUNT}₽."
        )
        
        # Получаем бота из окружения
        from telegram.ext import ApplicationBuilder
        application = ApplicationBuilder().token(config.TELEGRAM_TOKEN).build()
        
        # Отправляем уведомление
        await application.bot.send_message(
            chat_id=referrer_id,
            text=message,
            parse_mode='Markdown'
        )
        
        logger.info(f"Sent reward notification to user {referrer_id}: {reward_amount:.2f}₽")
        return True
    except Exception as e:
        logger.error(f"Error sending reward notification: {e}")
        return False

def extract_referral_code(start_parameter: str) -> Optional[str]:
    """
    Извлечение реферального кода из параметра start
    
    Args:
        start_parameter: Параметр start из ссылки
        
    Returns:
        str: Реферальный код или None, если код не найден
    """
    if not start_parameter:
        return None
    
    # Проверяем, соответствует ли параметр формату реферального кода
    if start_parameter.startswith("ref_"):
        return start_parameter
    
    return None

def get_handlers() -> Dict[str, Callable[[Update, ContextTypes.DEFAULT_TYPE], Awaitable[None]]]:
    """
    Получение словаря обработчиков для реферальной системы
    
    Returns:
        Dict: Словарь обработчиков {command_name: handler_function}
    """
    return {
        "invite": invite_command,
        "referral_stats": referral_stats_callback,
        "referral_payouts": referral_payouts_callback
    }