#!/usr/bin/env python
# coding: utf-8

"""
Обработчики команд для новой реферальной системы
"""

import logging
import uuid
import os
from datetime import datetime
from typing import Dict, Any, List, Callable, Optional, Awaitable

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from config import get_base_url
from db_models import db, User, Transaction, WeeklyPayout
from new_referral_models import ReferralCode, ReferralRelation, ReferralReward
from new_referral_code.referral_manager import ReferralManager

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Инициализация менеджера реферальной системы
referral_manager = ReferralManager()

# Emoji для статистики
EMOJI_STATS = {
    "user": "👤",
    "users": "👥",
    "money": "💰",
    "check": "✅",
    "pending": "⏳",
    "level1": "1️⃣",
    "level2": "2️⃣",
    "level3": "3️⃣",
    "level4": "4️⃣"
}

async def invite_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик команды /invite - сгенерировать и показать реферальную ссылку
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    user_id = update.effective_user.id
    
    # Получаем или создаем реферальный код пользователя
    referral_code = referral_manager.get_or_create_referral_code(user_id)
    
    # Формируем реферальную ссылку
    bot_username = (await context.bot.get_me()).username
    referral_link = f"https://t.me/{bot_username}?start={referral_code}"
    
    # Получаем статистику реферальной программы пользователя
    referrer_data = referral_manager.get_referrer_data(user_id)
    
    # Формируем сообщение
    message_text = (
        f"*Ваша реферальная ссылка:*\n"
        f"`{referral_link}`\n\n"
        f"*Поделитесь этой ссылкой с друзьями и получайте вознаграждение!*\n\n"
        f"За каждую оплату подписки вашими рефералами вы получите:\n"
        f"• {EMOJI_STATS['level1']} Прямые рефералы: *5%*\n"
        f"• {EMOJI_STATS['level2']} Рефералы 2-го уровня: *2%*\n"
        f"• {EMOJI_STATS['level3']} Рефералы 3-го уровня: *2%*\n"
        f"• {EMOJI_STATS['level4']} Рефералы 4-го уровня: *2%*\n\n"
        f"*Ваша статистика:*\n"
        f"{EMOJI_STATS['users']} Всего рефералов: *{referrer_data['total_referrals']}*\n"
        f"{EMOJI_STATS['level1']} Уровень 1: *{referrer_data['stats']['level_1']}*\n"
        f"{EMOJI_STATS['level2']} Уровень 2: *{referrer_data['stats']['level_2']}*\n"
        f"{EMOJI_STATS['level3']} Уровень 3: *{referrer_data['stats']['level_3']}*\n"
        f"{EMOJI_STATS['level4']} Уровень 4: *{referrer_data['stats']['level_4']}*\n\n"
        f"{EMOJI_STATS['money']} Всего заработано: *{referrer_data['total_earned']:.2f}₽*\n"
        f"{EMOJI_STATS['check']} Выплачено: *{referrer_data['paid_amount']:.2f}₽*\n"
        f"{EMOJI_STATS['pending']} Ожидает выплаты: *{referrer_data['pending_amount']:.2f}₽*"
    )
    
    # Создаем клавиатуру с кнопкой для просмотра ожидающих выплат
    keyboard = None
    if referrer_data['pending_amount'] > 0:
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("Мои ожидающие выплаты", callback_data="referral_pending_rewards")]
        ])
    
    await update.message.reply_text(
        message_text,
        parse_mode="Markdown",
        reply_markup=keyboard
    )

async def process_referral(update: Update, context: ContextTypes.DEFAULT_TYPE, referral_code: str) -> None:
    """
    Обработка реферальной ссылки при первом входе пользователя
    
    Args:
        update: Telegram update
        context: Telegram context
        referral_code: Реферальный код из ссылки
    """
    user_id = update.effective_user.id
    
    if not referral_code:
        return
    
    # Пытаемся добавить реферальное отношение
    success = referral_manager.add_referral(user_id, referral_code)
    
    if success:
        await update.message.reply_text(
            "Приветствую! Вы пришли по реферальной ссылке. "
            "Теперь при покупке подписки, ваш реферер получит вознаграждение.",
            parse_mode="Markdown"
        )
        logger.info(f"User {user_id} successfully added as referral with code {referral_code}")
    else:
        logger.warning(f"Failed to process referral for user {user_id} with code {referral_code}")

async def referral_pending_rewards_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для просмотра ожидающих выплат
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    user_id = query.from_user.id
    
    # Получаем список ожидающих выплат для пользователя
    pending_rewards = referral_manager.get_pending_rewards(user_id)
    
    if not pending_rewards:
        await query.answer("У вас нет ожидающих выплат")
        await query.edit_message_text(
            "У вас пока нет ожидающих выплат.\n\n"
            "Приглашайте друзей по реферальной ссылке и зарабатывайте вознаграждение!",
            parse_mode="Markdown"
        )
        return
    
    # Формируем сообщение со списком выплат
    message_text = f"*Ваши ожидающие выплаты ({len(pending_rewards)}):*\n\n"
    
    for i, reward in enumerate(pending_rewards[:10], 1):  # Ограничение до 10 выплат
        message_text += (
            f"{i}. От пользователя: {reward['user_name']}\n"
            f"   Уровень: {reward['level']}, Сумма: {reward['amount']:.2f}₽\n"
            f"   Дата: {reward['created_at'].strftime('%d.%m.%Y')}\n\n"
        )
    
    if len(pending_rewards) > 10:
        message_text += f"... и еще {len(pending_rewards) - 10} выплат\n\n"
    
    total_amount = sum(reward['amount'] for reward in pending_rewards)
    message_text += f"*Общая сумма ожидающих выплат: {total_amount:.2f}₽*\n\n"
    message_text += "Выплаты производятся администрацией еженедельно."
    
    # Кнопка для возврата к реферальной программе
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("Назад к реферальной программе", callback_data="referral_back")]
    ])
    
    await query.answer()
    await query.edit_message_text(
        message_text,
        parse_mode="Markdown",
        reply_markup=keyboard
    )

async def referral_back_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для возврата к реферальной программе
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    user_id = query.from_user.id
    
    # Перенаправляем на команду /invite
    await query.answer()
    await invite_command(update, context)
    
async def referral_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения статистики реферальной программы
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    # По сути, invite_command уже показывает всю статистику, поэтому просто перенаправляем на него
    query = update.callback_query
    await query.answer()
    await query.delete_message()
    await invite_command(update, context)

async def referral_payouts_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения выплат рефералам
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    # Перенаправляем на callback для отображения ожидающих выплат
    query = update.callback_query
    user_id = query.from_user.id
    
    await query.answer()
    await referral_pending_rewards_callback(update, context)

def extract_referral_code(start_parameter: str) -> Optional[str]:
    """
    Извлечение реферального кода из start-параметра
    
    Args:
        start_parameter: Параметр из команды /start
        
    Returns:
        Optional[str]: Реферальный код или None
    """
    if not start_parameter:
        return None
    
    # Проверяем формат кода (должен быть только из букв и цифр)
    if all(c.isalnum() or c.isspace() for c in start_parameter):
        return start_parameter.strip()
    
    return None

async def process_subscription_rewards(user_id: int, amount: float = 199.0) -> List[Dict[str, Any]]:
    """
    Обработка реферальных вознаграждений при оплате подписки пользователем
    
    Args:
        user_id: ID пользователя, совершившего платеж
        amount: Сумма платежа (по умолчанию 199.0 рублей)
        
    Returns:
        List[Dict]: Список начисленных вознаграждений
    """
    import time
    from db_models import Transaction
    
    try:
        # Находим самую свежую транзакцию подписки для получения её ID
        latest_subscription = (
            Transaction.query
            .filter_by(user_id=user_id, transaction_type="subscription_payment")
            .order_by(Transaction.timestamp.desc())
            .first()
        )
        
        if not latest_subscription:
            logger.warning(f"No subscription transaction found for user {user_id}")
            # Создаем фиктивную транзакцию для работы реферальной системы
            # В реальной системе этот код не должен выполняться, так как
            # транзакция должна быть создана до вызова process_subscription_rewards
            transaction_id = int(time.time())
        else:
            transaction_id = latest_subscription.id
        
        # Использовать транзакцию из базы данных если найдена
        processed_amount = latest_subscription.amount if latest_subscription else amount
        
        # Запускаем начисление вознаграждений
        rewards = referral_manager.process_payment_rewards(user_id, processed_amount, transaction_id)
        
        return rewards
    except Exception as e:
        logger.error(f"Error processing subscription rewards: {e}")
        return []

def get_referral_handlers() -> Dict[str, Callable[[Update, ContextTypes.DEFAULT_TYPE], Awaitable[None]]]:
    """
    Получение словаря обработчиков команд и колбэков для реферальной системы
    
    Returns:
        Dict: Словарь {callback_data: handler_function}
    """
    return {
        "referral_pending_rewards": referral_pending_rewards_callback,
        "referral_back": referral_back_callback,
        "referral_stats": referral_stats_callback,
        "referral_payouts": referral_payouts_callback,
        "show_invite_link": invite_command
    }