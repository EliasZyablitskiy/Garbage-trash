"""
Модуль для обработки ошибок платежных систем
"""
import logging
import re
from typing import Tuple, Dict, Any, Optional, List

logger = logging.getLogger(__name__)

# Карта кодов ошибок Robokassa и их описаний
ROBOKASSA_ERROR_CODES = {
    # Ошибки валидации
    "VALIDATION_ERROR": {
        "action": "reject",  # reject, retry, manual_review
        "can_retry": False,
        "user_message": "Ошибка валидации данных. Пожалуйста, проверьте указанные реквизиты.",
        "admin_message": "Ошибка валидации данных платежа. Требуется ручная проверка реквизитов."
    },
    "INVALID_ACCOUNT": {
        "action": "reject",
        "can_retry": False,
        "user_message": "Проверьте правильность указанных реквизитов платежа.",
        "admin_message": "Некорректный счет получателя. Необходимо уточнить реквизиты у пользователя."
    },
    "INVALID_AMOUNT": {
        "action": "reject",
        "can_retry": False,
        "user_message": "Указана некорректная сумма выплаты.",
        "admin_message": "Некорректная сумма выплаты. Проверьте настройки реферальной системы."
    },
    
    # Ошибки временного характера (можно повторить)
    "SERVICE_UNAVAILABLE": {
        "action": "retry",
        "can_retry": True,
        "user_message": "Платежная система временно недоступна, повторите запрос через несколько минут.",
        "admin_message": "Сервис Robokassa временно недоступен. Будет выполнена повторная попытка."
    },
    "INSUFFICIENT_FUNDS": {
        "action": "retry",
        "can_retry": True,
        "user_message": "В данный момент недоступны средства для выплаты, повторите запрос позже.",
        "admin_message": "Недостаточно средств на счете Robokassa. Требуется пополнение баланса."
    },
    "TIMEOUT": {
        "action": "retry",
        "can_retry": True,
        "user_message": "Превышено время ожидания ответа от платежной системы. Повторите запрос позже.",
        "admin_message": "Таймаут соединения с Robokassa. Будет выполнена повторная попытка."
    },
    
    # Ошибки требующие ручного рассмотрения
    "ACCOUNT_BLOCKED": {
        "action": "manual_review",
        "can_retry": False,
        "user_message": "Счет получателя заблокирован или имеет ограничения.",
        "admin_message": "Счет получателя заблокирован. Требуется ручная проверка."
    },
    "LIMIT_EXCEEDED": {
        "action": "manual_review",
        "can_retry": False,
        "user_message": "Превышен лимит выплат. Пожалуйста, повторите запрос позже.",
        "admin_message": "Превышен лимит выплат. Возможно, требуется дополнительная верификация счета."
    },
    "MANUAL_CHECK_REQUIRED": {
        "action": "manual_review",
        "can_retry": False,
        "user_message": "Выплата требует дополнительной проверки. Наши специалисты свяжутся с вами.",
        "admin_message": "Операция отправлена на ручную проверку в Robokassa."
    },
    
    # Общая ошибка по умолчанию
    "TECHNICAL_ERROR": {
        "action": "retry",
        "can_retry": True,
        "user_message": "Техническая ошибка при обработке выплаты. Наша команда уже работает над её устранением.",
        "admin_message": "Неизвестная техническая ошибка. Рекомендуется связаться с поддержкой Robokassa."
    }
}

def analyze_robokassa_error(error_code: str, error_message: str) -> Dict[str, Any]:
    """
    Анализирует ошибку Robokassa и возвращает информацию о действии,
    возможности повтора и сообщения для пользователя и администратора
    
    Args:
        error_code: Код ошибки от Robokassa
        error_message: Сообщение об ошибке
        
    Returns:
        Dict: Информация об ошибке с полями action, can_retry, user_message, admin_message
    """
    # Нормализуем код ошибки (убираем пробелы, переводим в верхний регистр)
    normalized_code = error_code.strip().upper() if error_code else ""
    
    # Пытаемся найти код ошибки в словаре
    if normalized_code in ROBOKASSA_ERROR_CODES:
        return ROBOKASSA_ERROR_CODES[normalized_code]
    
    # Если код не найден, проверяем наличие ключевых слов в сообщении об ошибке
    error_message_upper = error_message.upper() if error_message else ""
    
    for code, details in ROBOKASSA_ERROR_CODES.items():
        # Проверяем, содержится ли код ошибки в сообщении
        if code in error_message_upper:
            return details
        
        # Дополнительные проверки по ключевым словам
        if "INVALID" in error_message_upper and "ACCOUNT" in error_message_upper:
            return ROBOKASSA_ERROR_CODES["INVALID_ACCOUNT"]
        elif "INSUFFICIENT" in error_message_upper and "FUNDS" in error_message_upper:
            return ROBOKASSA_ERROR_CODES["INSUFFICIENT_FUNDS"]
        elif "BLOCKED" in error_message_upper or "SUSPENDED" in error_message_upper:
            return ROBOKASSA_ERROR_CODES["ACCOUNT_BLOCKED"]
        elif "LIMIT" in error_message_upper and ("EXCEED" in error_message_upper or "REACHED" in error_message_upper):
            return ROBOKASSA_ERROR_CODES["LIMIT_EXCEEDED"]
        elif "TIMEOUT" in error_message_upper or "TIMED OUT" in error_message_upper:
            return ROBOKASSA_ERROR_CODES["TIMEOUT"]
        elif "UNAVAILABLE" in error_message_upper or "MAINTENANCE" in error_message_upper:
            return ROBOKASSA_ERROR_CODES["SERVICE_UNAVAILABLE"]
        elif "VALIDATION" in error_message_upper or "INVALID" in error_message_upper:
            return ROBOKASSA_ERROR_CODES["VALIDATION_ERROR"]
    
    # Если ничего не найдено, возвращаем информацию о технической ошибке
    logger.warning(f"Неизвестная ошибка Robokassa: {error_code} - {error_message}")
    return ROBOKASSA_ERROR_CODES["TECHNICAL_ERROR"]

def should_retry_error(error_code: str, error_message: str) -> bool:
    """
    Определяет, можно ли повторить операцию при данной ошибке
    
    Args:
        error_code: Код ошибки
        error_message: Сообщение об ошибке
        
    Returns:
        bool: True, если операцию можно повторить; False в противном случае
    """
    error_info = analyze_robokassa_error(error_code, error_message)
    return error_info.get("can_retry", False)

def get_error_action(error_code: str, error_message: str) -> str:
    """
    Определяет рекомендуемое действие для данной ошибки
    
    Args:
        error_code: Код ошибки
        error_message: Сообщение об ошибке
        
    Returns:
        str: Рекомендуемое действие (reject, retry, manual_review)
    """
    error_info = analyze_robokassa_error(error_code, error_message)
    return error_info.get("action", "manual_review")

def get_user_friendly_error(error_code: str, error_message: str) -> str:
    """
    Возвращает понятное пользователю сообщение об ошибке
    
    Args:
        error_code: Код ошибки
        error_message: Техническое сообщение об ошибке
        
    Returns:
        str: Понятное пользователю сообщение
    """
    error_info = analyze_robokassa_error(error_code, error_message)
    return error_info.get("user_message", "Произошла техническая ошибка при обработке выплаты. Наши специалисты уже работают над её устранением.")

def get_admin_error_message(error_code: str, error_message: str) -> str:
    """
    Возвращает подробное сообщение об ошибке для администратора
    
    Args:
        error_code: Код ошибки
        error_message: Техническое сообщение об ошибке
        
    Returns:
        str: Информативное сообщение для администратора
    """
    error_info = analyze_robokassa_error(error_code, error_message)
    admin_message = error_info.get("admin_message", "Неизвестная ошибка. Требуется ручная проверка.")
    
    # Добавляем технические детали для администратора
    return f"{admin_message}\n\nТехнические детали:\nКод: {error_code}\nСообщение: {error_message}"

async def rollback_failed_transactions(db, batch_id: int, failed_transactions: List[int]) -> Dict[str, Any]:
    """
    Откатывает только проблемные транзакции в пакете
    
    Args:
        db: Объект базы данных
        batch_id: ID пакетной выплаты
        failed_transactions: Список ID транзакций, которые нужно откатить
        
    Returns:
        Dict: Информация о результате отката
    """
    from db_models import Transaction, BatchPayout
    
    # Для отслеживания результатов
    results = {
        "status": "rolled_back",
        "batch_id": batch_id,
        "failed_transactions": len(failed_transactions),
        "details": []
    }
    
    try:
        # Начинаем транзакцию
        async with db.begin():
            # Получаем пакетную выплату
            batch = await db.get(BatchPayout, batch_id)
            
            if not batch:
                logger.error(f"Пакетная выплата с ID {batch_id} не найдена")
                return {
                    "status": "error",
                    "message": f"Пакетная выплата с ID {batch_id} не найдена"
                }
            
            # Обновляем статус каждой транзакции
            for tx_id in failed_transactions:
                # Получаем транзакцию
                tx = await db.get(Transaction, tx_id)
                
                if tx:
                    prev_status = tx.status
                    tx.status = "failed"
                    tx.updated_at = db.func.now()
                    
                    # Добавляем информацию в результаты
                    results["details"].append({
                        "transaction_id": tx_id,
                        "previous_status": prev_status,
                        "new_status": "failed"
                    })
                else:
                    logger.warning(f"Транзакция с ID {tx_id} не найдена")
                    results["details"].append({
                        "transaction_id": tx_id,
                        "status": "not_found"
                    })
            
            # Обновляем статистику пакетной выплаты
            if batch:
                # Получаем текущее количество успешных и неудачных транзакций
                successful_count_query = await db.execute(
                    db.select(db.func.count()).select_from(Transaction).filter(
                        Transaction.payout_id == batch.weekly_payout_id,
                        Transaction.status == "completed"
                    )
                )
                successful_count = successful_count_query.scalar() or 0
                
                failed_count_query = await db.execute(
                    db.select(db.func.count()).select_from(Transaction).filter(
                        Transaction.payout_id == batch.weekly_payout_id,
                        Transaction.status == "failed"
                    )
                )
                failed_count = failed_count_query.scalar() or 0
                
                processing_count_query = await db.execute(
                    db.select(db.func.count()).select_from(Transaction).filter(
                        Transaction.payout_id == batch.weekly_payout_id,
                        Transaction.status == "processing"
                    )
                )
                processing_count = processing_count_query.scalar() or 0
                
                # Обновляем статистику в пакете
                batch.successful_transactions = successful_count
                batch.failed_transactions = failed_count
                
                # Определяем новый статус пакета
                if processing_count == 0:  # Все транзакции обработаны
                    if successful_count > 0 and failed_count > 0:
                        batch.status = "partial"  # Частично успешно
                    elif successful_count > 0:
                        batch.status = "completed"  # Полностью успешно
                    else:
                        batch.status = "failed"  # Полностью неуспешно
                
                # Сохраняем статус в результаты
                results["batch_status"] = batch.status
            
            # Фиксируем транзакцию
            await db.commit()
        
        logger.info(f"Успешно откатили {len(failed_transactions)} транзакций для пакета {batch_id}")
        return results
    
    except Exception as e:
        # Откатываем транзакцию в случае ошибки
        await db.rollback()
        
        logger.error(f"Ошибка при откате транзакций: {e}")
        return {
            "status": "error",
            "message": f"Ошибка при откате транзакций: {e}"
        }