#!/usr/bin/env python
# coding: utf-8

"""
Сервис для работы с выплатами рефералам
"""

import os
import logging
import json
import datetime
import asyncio
import uuid
import aiohttp
import random
import time
from decimal import Decimal
from typing import Dict, Any, List, Optional, Tuple, Callable, TypeVar, Awaitable, cast, Union

import config
from services.robokassa_payout_service import robokassa_payout_service
from services.payout_logging_service import log_payout_operation, log_payout_operation_decorator
from telegram import Bot
from db_models import BatchPayout, batch_payout_transactions, WeeklyPayout, Transaction, User, PayoutOperationLog

logger = logging.getLogger(__name__)

# Минимальная сумма для выплаты (рублей)
MIN_PAYOUT_AMOUNT = config.MIN_PAYOUT_AMOUNT

# Строгие типы для работы с выплатами
PayoutID = int
BatchID = int
TransactionID = int
UserID = int
Amount = Union[float, Decimal]
Status = str

# Тип для асинхронных функций, которые будут использоваться с механизмом повторных попыток
T = TypeVar('T')
RetryableFunc = Callable[..., Awaitable[T]]

# Настройки повторных попыток
MAX_RETRY_ATTEMPTS = 5      # Максимальное количество попыток
BASE_RETRY_DELAY = 2.0      # Базовая задержка между попытками (секунды)
MAX_RETRY_DELAY = 60.0      # Максимальная задержка между попытками (секунды)
RETRY_JITTER = 0.25         # Случайные колебания задержки (25%)


async def with_retries(func: RetryableFunc[T], *args, **kwargs) -> T:
    """
    Декоратор для повторных попыток выполнения асинхронной функции с экспоненциальной задержкой
    
    Args:
        func: Асинхронная функция для выполнения
        *args: Аргументы функции
        **kwargs: Именованные аргументы функции
        
    Returns:
        Результат выполнения функции
        
    Raises:
        Exception: Если все попытки выполнения завершились неудачно
    """
    last_exception = None
    attempt = 0
    
    while attempt < MAX_RETRY_ATTEMPTS:
        try:
            # Выполняем функцию
            return await func(*args, **kwargs)
        except Exception as e:
            attempt += 1
            last_exception = e
            
            # Если это последняя попытка, выбрасываем исключение
            if attempt >= MAX_RETRY_ATTEMPTS:
                logger.error(f"Failed after {MAX_RETRY_ATTEMPTS} attempts: {e}")
                raise
            
            # Рассчитываем время задержки с экспоненциальным увеличением
            delay = min(BASE_RETRY_DELAY * (2 ** (attempt - 1)), MAX_RETRY_DELAY)
            
            # Добавляем случайную погрешность для предотвращения "шторма" запросов
            jitter = random.uniform(-RETRY_JITTER, RETRY_JITTER)
            delay = delay * (1 + jitter)
            
            logger.warning(f"Attempt {attempt} failed: {e}. Retrying in {delay:.2f}s...")
            
            # Ждем перед следующей попыткой
            await asyncio.sleep(delay)
    
    # Если мы здесь, значит все попытки не удались
    if last_exception:
        raise last_exception
        
    # Этот код не должен быть достигнут, но для типобезопасности
    # Указываем явное исключение
    raise RuntimeError("Unexpected condition in retry logic")


@log_payout_operation_decorator(operation_type="create_weekly_payout")
async def create_weekly_payout(min_amount: Amount = MIN_PAYOUT_AMOUNT) -> Optional[PayoutID]:
    """
    Создание еженедельной выплаты с сохранением в базе данных
    
    Args:
        min_amount: Минимальная сумма для выплаты (рублей)
        
    Returns:
        PayoutID: ID созданной выплаты или None в случае ошибки
    """
    from db_config import db
    
    try:
        # Получаем список пользователей с ожидающими выплатами выше минимальной суммы
        users = await get_users_with_pending_rewards(float(min_amount))
        
        if not users:
            logger.warning(f"No users with pending rewards above {min_amount}₽")
            await log_payout_operation(
                operation_type="create_weekly_payout",
                status="skipped",
                response_data={"reason": f"No users with pending rewards above {min_amount}₽"}
            )
            return None
        
        # Группируем пользователей по диапазону сумм выплат
        tiers = group_users_by_tiers(users)
        
        # Считаем общее количество транзакций и сумму
        transaction_count = sum(len(tier["users"]) for tier in tiers.values())
        total_amount = sum(sum(user.get("amount", 0) for user in tier["users"]) for tier in tiers.values())
        
        # Создаем объект выплаты в БД в транзакции
        async with db.begin():
            # Создаем запись о еженедельной выплате
            weekly_payout = WeeklyPayout(
                status='pending',
                total_amount=float(total_amount),
                total_users=int(transaction_count),
                payout_data={
                    "min_amount": float(min_amount),
                    "tiers": {tier_id: tier_data for tier_id, tier_data in tiers.items()},
                    "created_at": datetime.datetime.now().isoformat()
                }
            )
            
            # Добавляем запись в БД
            db.session.add(weekly_payout)
            await db.session.flush()  # Для получения ID
            
            # Получаем список транзакций для обновления
            transactions_to_update = []
            
            # Для каждой группы выплат
            for tier_id, tier_data in tiers.items():
                # Создаем запись о пакетной выплате
                batch_payout = BatchPayout(
                    weekly_payout_id=int(weekly_payout.id),
                    tier_name=str(tier_data.get("name", tier_id)),
                    status='pending',
                    total_amount=float(tier_data.get("total", 0)),
                    total_transactions=int(len(tier_data.get("users", [])))
                )
                
                # Добавляем запись в БД
                db.session.add(batch_payout)
                await db.session.flush()  # Для получения ID
                
                # Для каждого пользователя в группе
                for user_data in tier_data.get("users", []):
                    user_id = int(user_data.get("user_id"))
                    amount = float(user_data.get("amount", 0))
                    
                    # Получаем ожидающие транзакции этого пользователя
                    pending_tx_query = await db.session.execute(
                        db.select(Transaction).filter(
                            db.and_(
                                Transaction.user_id == user_id,
                                Transaction.type == "referral_reward",
                                Transaction.status == "pending"
                            )
                        )
                    )
                    
                    pending_transactions = pending_tx_query.scalars().all()
                    
                    # Связываем транзакции с этой выплатой
                    for tx in pending_transactions:
                        tx.payout_id = int(weekly_payout.id)
                        tx.status = "processing"
                        transactions_to_update.append(tx)
                        
                        # Связываем с пакетной выплатой через ассоциативную таблицу
                        stmt = batch_payout_transactions.insert().values(
                            batch_payout_id=int(batch_payout.id),
                            transaction_id=int(tx.id)
                        )
                        await db.session.execute(stmt)
                
            # Сохраняем все изменения
            await db.session.commit()
        
        logger.info(f"Weekly payout created in database: ID={weekly_payout.id}, Amount={total_amount}₽, Users={transaction_count}")
        
        # Логируем успешное создание выплаты
        await log_payout_operation(
            operation_type="create_weekly_payout",
            payout_id=int(weekly_payout.id),
            status="success",
            response_data={
                "total_amount": float(total_amount),
                "total_users": int(transaction_count),
                "tier_count": len(tiers)
            }
        )
        
        return int(weekly_payout.id)
    except Exception as e:
        # В случае ошибки откатываем транзакцию
        await db.session.rollback()
        logger.error(f"Error creating weekly payout in database: {e}")
        
        # Логируем ошибку
        await log_payout_operation(
            operation_type="create_weekly_payout",
            status="failed",
            error_message=str(e)
        )
        
        return None


def group_users_by_tiers(users: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """
    Группировка пользователей по диапазонам сумм выплат
    
    Args:
        users: Список пользователей с ожидающими выплатами
        
    Returns:
        Dict: Группы пользователей по диапазонам
    """
    tiers = {
        "1000-3000": {"name": "1000-3000₽", "users": [], "total": 0},
        "3000-5000": {"name": "3000-5000₽", "users": [], "total": 0},
        "5000-10000": {"name": "5000-10000₽", "users": [], "total": 0},
        "10000+": {"name": "10000+₽", "users": [], "total": 0}
    }
    
    for user in users:
        amount = user.get("amount", 0)
        
        if 1000 <= amount < 3000:
            tier = "1000-3000"
        elif 3000 <= amount < 5000:
            tier = "3000-5000"
        elif 5000 <= amount < 10000:
            tier = "5000-10000"
        else:
            tier = "10000+"
        
        tiers[tier]["users"].append(user)
        tiers[tier]["total"] += amount
    
    # Удаляем пустые группы
    return {k: v for k, v in tiers.items() if v["users"]}


@log_payout_operation_decorator(operation_type="get_users_with_pending_rewards")
async def get_users_with_pending_rewards(min_amount: Amount = 0) -> List[Dict[str, Any]]:
    """
    Получение списка пользователей с ожидающими выплатами из базы данных
    
    Args:
        min_amount: Минимальная сумма для выплаты (рублей)
        
    Returns:
        List[Dict]: Список пользователей с ожидающими выплатами
    """
    from db_config import db
    from db_models import Transaction, User
    from sqlalchemy import func, and_
    
    try:
        # Преобразуем тип входного параметра
        min_amount_float = float(min_amount)
        
        # Запрос на получение суммы всех транзакций типа "referral_reward" со статусом "pending" для каждого пользователя
        result = await db.session.execute(
            db.select(
                Transaction.user_id,
                func.sum(Transaction.amount).label("total_amount"),
                User.username,
                User.wallet_address,
                User.email
            ).join(
                User, Transaction.user_id == User.id
            ).filter(
                and_(
                    Transaction.type == "referral_reward",
                    Transaction.status == "pending"
                )
            ).group_by(
                Transaction.user_id,
                User.username,
                User.wallet_address,
                User.email
            ).having(
                func.sum(Transaction.amount) >= min_amount_float
            )
        )
        
        users_with_rewards = []
        for row in result.fetchall():
            # Добавляем дополнительные данные пользователя, которые могут быть полезны при выплате
            users_with_rewards.append({
                "user_id": int(row.user_id),
                "amount": float(row.total_amount),
                "username": str(row.username or f"user_{row.user_id}"),
                "wallet_address": str(row.wallet_address or ""),
                "email": str(row.email or "")
            })
        
        logger.info(f"Найдено {len(users_with_rewards)} пользователей с ожидающими выплатами >= {min_amount_float}₽")
        
        # Логируем результат
        await log_payout_operation(
            operation_type="get_users_with_pending_rewards",
            status="success",
            response_data={
                "min_amount": min_amount_float,
                "user_count": len(users_with_rewards),
                "total_amount": sum(user["amount"] for user in users_with_rewards)
            }
        )
        
        return users_with_rewards
    
    except Exception as e:
        logger.error(f"Ошибка при получении пользователей с ожидающими выплатами: {e}")
        
        # Логируем ошибку
        await log_payout_operation(
            operation_type="get_users_with_pending_rewards",
            status="failed",
            error_message=str(e)
        )
        
        # В случае ошибки возвращаем пустой список
        return []


async def get_weekly_payouts(page: int = 1, per_page: int = 10, status: Optional[str] = None) -> Tuple[List[Dict[str, Any]], int]:
    """
    Получение списка еженедельных выплат с пагинацией из базы данных
    
    Args:
        page: Номер страницы (начиная с 1)
        per_page: Количество выплат на странице
        status: Фильтр по статусу (pending, processing, completed)
        
    Returns:
        Tuple[List[Dict], int]: Список выплат и общее количество выплат
    """
    from db_config import db
    from db_models import WeeklyPayout, Transaction
    from sqlalchemy import func, and_, or_
    
    try:
        # Создаем базовый запрос
        query = db.select(WeeklyPayout)
        
        # Применяем фильтр по статусу, если указан
        if status:
            query = query.filter(WeeklyPayout.status == status)
            
        # Запрашиваем общее количество выплат для пагинации
        count_query = db.select(func.count()).select_from(query.subquery())
        total_result = await db.session.execute(count_query)
        total = total_result.scalar() or 0
        
        # Применяем сортировку и пагинацию
        query = query.order_by(WeeklyPayout.created_at.desc())
        query = query.offset((page - 1) * per_page).limit(per_page)
        
        # Выполняем запрос
        result = await db.session.execute(query)
        payouts_records = result.scalars().all()
        
        # Преобразуем записи в словари
        payouts = []
        for payout in payouts_records:
            # Запрашиваем количество транзакций для данной выплаты
            tx_count_query = db.select(func.count()).select_from(Transaction).filter(
                Transaction.payout_id == payout.id
            )
            tx_count_result = await db.session.execute(tx_count_query)
            tx_count = tx_count_result.scalar() or 0
            
            # Преобразуем запись в словарь
            payout_dict = payout.to_dict()
            payout_dict['transaction_count'] = tx_count
            
            payouts.append(payout_dict)
            
        logger.info(f"Найдено {len(payouts)} выплат{f' со статусом {status}' if status else ''}, всего: {total}")
        return payouts, total
        
    except Exception as e:
        logger.error(f"Ошибка при получении списка выплат: {e}")
        # В случае ошибки возвращаем пустой список и 0
        return [], 0


async def get_transactions_by_status(page: int = 1, per_page: int = 20, status: Optional[str] = None, type_filter: Optional[str] = None) -> Tuple[List[Dict[str, Any]], int]:
    """
    Получение списка транзакций с пагинацией и фильтрацией из базы данных
    
    Args:
        page: Номер страницы (начиная с 1)
        per_page: Количество транзакций на странице
        status: Фильтр по статусу (pending, processing, completed)
        type_filter: Фильтр по типу транзакции (referral_reward, etc.)
        
    Returns:
        Tuple[List[Dict], int]: Список транзакций и общее количество транзакций
    """
    from db_config import db
    from db_models import Transaction, User
    from sqlalchemy import and_, or_
    
    try:
        # Создаем базовый запрос
        query = db.select(Transaction).join(User, Transaction.user_id == User.id)
        
        # Применяем фильтры, если указаны
        filters = []
        if status:
            filters.append(Transaction.status == status)
        if type_filter:
            filters.append(Transaction.type == type_filter)
            
        if filters:
            query = query.filter(and_(*filters))
            
        # Запрашиваем общее количество транзакций для пагинации
        count_query = db.select(db.func.count()).select_from(query.subquery())
        total_result = await db.session.execute(count_query)
        total = total_result.scalar() or 0
        
        # Применяем сортировку и пагинацию
        query = query.order_by(Transaction.created_at.desc())
        query = query.offset((page - 1) * per_page).limit(per_page)
        
        # Выполняем запрос
        result = await db.session.execute(query)
        transactions_records = result.scalars().all()
        
        # Преобразуем записи в словари
        transactions = []
        for tx in transactions_records:
            tx_dict = tx.to_dict()
            # Добавляем информацию о пользователе, если нужно
            if hasattr(tx, 'user') and tx.user:
                tx_dict['username'] = tx.user.username
            
            transactions.append(tx_dict)
            
        filter_description = []
        if status:
            filter_description.append(f"статус={status}")
        if type_filter:
            filter_description.append(f"тип={type_filter}")
            
        filter_str = f" с фильтрами: {', '.join(filter_description)}" if filter_description else ""
        logger.info(f"Найдено {len(transactions)} транзакций{filter_str}, всего: {total}")
        
        return transactions, total
        
    except Exception as e:
        logger.error(f"Ошибка при получении списка транзакций: {e}")
        # В случае ошибки возвращаем пустой список и 0
        return [], 0


@log_payout_operation_decorator(operation_type="update_payout_status")
async def update_payout_status(payout_id: PayoutID, status: Status, error_message: Optional[str] = None) -> bool:
    """
    Обновление статуса выплаты в базе данных с использованием транзакции
    
    Args:
        payout_id: ID выплаты
        status: Новый статус (pending, processing, partial, completed, failed)
        error_message: Сообщение об ошибке (используется только для статуса failed)
        
    Returns:
        bool: True в случае успеха, False в случае ошибки
    """
    from db_config import db
    
    try:
        # Преобразуем тип входных параметров
        payout_id_int = int(payout_id)
        status_str = str(status)
        
        # Проверяем валидность статуса
        valid_statuses = ["pending", "processing", "partial", "completed", "failed"]
        if status_str not in valid_statuses:
            logger.warning(f"Invalid status value: {status_str}")
            await log_payout_operation(
                operation_type="update_payout_status",
                payout_id=payout_id_int,
                status="failed",
                error_message=f"Invalid status value: {status_str}"
            )
            return False
        
        # Ищем выплату в базе данных
        payout = await db.session.get(WeeklyPayout, payout_id_int)
        
        if not payout:
            logger.warning(f"Payout not found in database: {payout_id_int}")
            await log_payout_operation(
                operation_type="update_payout_status",
                payout_id=payout_id_int,
                status="failed",
                error_message=f"Payout not found in database: {payout_id_int}"
            )
            return False
        
        # Сохраняем предыдущий статус для логирования
        previous_status = payout.status
        
        # Выполняем обновление в транзакции
        async with db.begin():
            # Обновляем статус в зависимости от нового значения
            if status_str == "processing":
                payout.mark_as_processing()
            elif status_str == "completed":
                payout.mark_as_completed()
            elif status_str == "failed":
                payout.mark_as_failed(error_message or "Unknown error")
            else:
                # Для остальных статусов просто устанавливаем значение
                payout.status = status_str
                
            # Добавляем информацию об обновлении в данные выплаты
            payout_data = payout.payout_data or {}
            status_updates = payout_data.get("status_updates", [])
            status_updates.append({
                "timestamp": datetime.datetime.now().isoformat(),
                "previous_status": previous_status,
                "new_status": status_str,
                "error_message": error_message if status_str == "failed" else None
            })
            payout_data["status_updates"] = status_updates
            payout.payout_data = payout_data
                
            # Сохраняем изменения
            await db.session.commit()
        
        logger.info(f"Payout {payout_id_int} status updated from {previous_status} to {status_str} in database")
        
        # Логируем успешное обновление
        await log_payout_operation(
            operation_type="update_payout_status",
            payout_id=payout_id_int,
            status="success",
            response_data={
                "previous_status": previous_status,
                "new_status": status_str,
                "error_message": error_message if status_str == "failed" else None
            }
        )
        
        return True
        
    except Exception as e:
        # В случае ошибки откатываем транзакцию
        await db.session.rollback()
        logger.error(f"Error updating payout status in database: {e}")
        
        # Логируем ошибку
        await log_payout_operation(
            operation_type="update_payout_status",
            payout_id=int(payout_id) if isinstance(payout_id, (int, float)) else 0,
            status="failed",
            error_message=str(e)
        )
        
        return False


async def get_referral_statistics() -> Dict[str, Any]:
    """
    Получение статистики реферальной программы из базы данных
    
    Returns:
        Dict: Статистика реферальной программы
    """
    from db_config import db
    from db_models import User, Transaction, WeeklyPayout
    from sqlalchemy import func, and_, or_
    import datetime
    
    try:
        # Общее количество пользователей
        total_users_query = await db.session.execute(
            db.select(func.count(User.id))
        )
        total_users = total_users_query.scalar() or 0
        
        # Пользователи с активной подпиской
        active_users_query = await db.session.execute(
            db.select(func.count(User.id)).filter(
                User.subscription_expiry > func.now()
            )
        )
        active_users = active_users_query.scalar() or 0
        
        # Общее количество рефералов
        total_referrals_query = await db.session.execute(
            db.select(func.count(User.id)).filter(User.referrer_id != None)
        )
        total_referrals = total_referrals_query.scalar() or 0
        
        # Активные рефералы (с активной подпиской)
        active_referrals_query = await db.session.execute(
            db.select(func.count(User.id)).filter(
                and_(
                    User.referrer_id != None,
                    User.subscription_expiry > func.now()
                )
            )
        )
        active_referrals = active_referrals_query.scalar() or 0
        
        # Общая сумма подписок
        total_subscription_revenue_query = await db.session.execute(
            db.select(func.sum(Transaction.amount)).filter(
                Transaction.type == "subscription"
            )
        )
        total_subscription_revenue = float(total_subscription_revenue_query.scalar() or 0)
        
        # Количество активных подписок
        active_subscriptions = active_users  # То же самое, что и активные пользователи
        
        # Данные о пользователях с наградами
        users_with_rewards = await get_users_with_pending_rewards()
        total_pending = sum(user.get("amount", 0) for user in users_with_rewards)
        
        # Данные о выплатах
        payouts, _ = await get_weekly_payouts(page=1, per_page=100)
        total_payouts = sum(p.get("total_amount", 0) for p in payouts if p.get("status") == "completed")
        
        # Получаем последние события для блока активности
        # 1. Последние транзакции (подписки и реферальные начисления)
        transactions_query = await db.session.execute(
            db.select(
                Transaction.id,
                Transaction.type,
                Transaction.status,
                Transaction.created_at
            ).filter(
                or_(
                    Transaction.type == "subscription",
                    Transaction.type == "referral_reward"
                )
            ).order_by(
                Transaction.created_at.desc()
            ).limit(3)
        )
        transactions = transactions_query.fetchall()
        
        # 2. Последние выплаты
        payouts_query = await db.session.execute(
            db.select(
                WeeklyPayout.id,
                WeeklyPayout.status,
                WeeklyPayout.created_at
            ).order_by(
                WeeklyPayout.created_at.desc()
            ).limit(2)
        )
        weekly_payouts = payouts_query.fetchall()
        
        # Объединяем и сортируем все события по времени
        events = []
        for tx in transactions:
            description = ""
            if tx.type == "subscription":
                description = "Новая подписка оформлена"
            elif tx.type == "referral_reward" and tx.status == "pending":
                description = "Начислено реферальное вознаграждение"
            elif tx.type == "referral_reward" and tx.status == "completed":
                description = "Выплачено реферальное вознаграждение"
                
            if description:
                events.append({
                    "description": description,
                    "time": tx.created_at,
                    "timestamp": tx.created_at.timestamp()
                })
        
        for payout in weekly_payouts:
            description = ""
            if payout.status == "pending":
                description = "Создана новая еженедельная выплата"
            elif payout.status == "completed":
                description = "Выплата реферальных вознаграждений завершена"
            elif payout.status == "processing":
                description = "Запущена обработка реферальных выплат"
                
            if description:
                events.append({
                    "description": description,
                    "time": payout.created_at,
                    "timestamp": payout.created_at.timestamp()
                })
        
        # Сортируем события по времени (новые первыми)
        events.sort(key=lambda x: x["timestamp"], reverse=True)
        
        # Форматируем время для отображения
        now = datetime.datetime.now()
        recent_activities = []
        
        for event in events[:4]:  # Берем только 4 последних события
            event_time = event["time"]
            delta = now - event_time
            
            if delta.days == 0:
                hours = delta.seconds // 3600
                minutes = (delta.seconds % 3600) // 60
                
                if hours == 0:
                    if minutes == 0:
                        time_str = "только что"
                    else:
                        time_str = f"{minutes} минут назад"
                else:
                    time_str = f"{hours} часов назад"
            elif delta.days == 1:
                time_str = "вчера"
            else:
                time_str = f"{delta.days} дней назад"
            
            recent_activities.append({
                "description": event["description"],
                "time": time_str
            })
        
        # Формируем итоговую статистику
        stats = {
            "total_users": total_users,
            "active_users": active_users,
            "total_referrals": total_referrals,
            "active_referrals": active_referrals,
            "total_subscription_revenue": total_subscription_revenue,
            "active_subscriptions": active_subscriptions,
            "total_referral_payments": total_payouts,
            "pending_referral_payments": total_pending,
            "recent_activities": recent_activities
        }
        
        return stats
    except Exception as e:
        logger.error(f"Error getting referral statistics: {e}")
        # В случае ошибки возвращаем минимальную статистику
        return {
            "total_users": 0,
            "active_users": 0,
            "total_referrals": 0,
            "active_referrals": 0,
            "total_subscription_revenue": 0.0,
            "active_subscriptions": 0,
            "total_referral_payments": 0.0,
            "pending_referral_payments": 0.0,
            "recent_activities": [
                {"description": "Нет данных об активности", "time": ""}
            ]
        }


async def process_payout(payout_id: int, mode: str = "tier") -> Dict[str, Any]:
    """
    Обработка выплаты через API Robokassa с использованием базы данных
    
    Args:
        payout_id: ID выплаты
        mode: Режим обработки (tier - по группам, all - все сразу)
        
    Returns:
        Dict: Результат обработки выплаты
    """
    from db_config import db
    from db_models import WeeklyPayout, BatchPayout, Transaction
    
    try:
        # Получаем данные о выплате из базы данных
        payout = await db.session.get(WeeklyPayout, payout_id)
        
        if not payout:
            logger.warning(f"Payout not found in database: {payout_id}")
            return {"success": False, "error": "Payout not found"}
        
        # Проверяем, что выплата в статусе "processing"
        if payout.status != "processing":
            logger.warning(f"Payout {payout_id} has invalid status: {payout.status}")
            return {"success": False, "error": f"Invalid payout status: {payout.status}"}
        
        # Инициализируем результаты
        results = {
            "success": True,
            "total_processed": 0,
            "total_successful": 0,
            "total_failed": 0,
            "tiers": {}
        }
        
        # Получаем пакетные выплаты для данной еженедельной выплаты
        batch_query = await db.session.execute(
            db.select(BatchPayout).filter(BatchPayout.weekly_payout_id == payout_id)
        )
        
        batch_payouts = batch_query.scalars().all()
        
        if not batch_payouts:
            logger.warning(f"No batch payouts found for weekly payout {payout_id}")
            return {"success": False, "error": "No batch payouts found"}
        
        # Обрабатываем каждую пакетную выплату
        for batch in batch_payouts:
            tier_name = batch.tier_name
            logger.info(f"Processing batch {batch.id} (tier {tier_name}) with {batch.total_transactions} transactions")
            
            # Получаем транзакции для данной пакетной выплаты
            tx_query = await db.session.execute(
                db.select(Transaction)
                .join(batch_payout_transactions, Transaction.id == batch_payout_transactions.c.transaction_id)
                .filter(batch_payout_transactions.c.batch_payout_id == batch.id)
            )
            
            transactions = tx_query.scalars().all()
            
            # Формируем список транзакций для API
            transactions_for_api = []
            for tx in transactions:
                tx_data = {
                    "id": str(tx.id),
                    "user_id": tx.user_id,
                    "amount": tx.amount,
                    "description": tx.description or f"Реферальное вознаграждение (группа {tier_name})"
                }
                transactions_for_api.append(tx_data)
            
            # Отмечаем пакетную выплату как обрабатываемую
            async with db.begin():
                batch.mark_as_processing()
                batch.request_data = {
                    "transactions": transactions_for_api,
                    "mode": mode
                }
                await db.session.commit()
                
            try:
                # Обрабатываем группу выплат через API Robokassa
                tier_result = await robokassa_payout_service.process_payout_group(
                    payout_id=str(payout_id),
                    tier_name=tier_name,
                    transactions=transactions_for_api
                )
                
                # Обновляем результаты пакетной выплаты в БД
                async with db.begin():
                    batch.response_data = tier_result
                    
                    if tier_result.get("successful", 0) == batch.total_transactions:
                        batch.mark_as_completed()
                    elif tier_result.get("successful", 0) > 0:
                        batch.status = "partial"
                    else:
                        batch.mark_as_failed(tier_result.get("error", "Unknown error"))
                        
                    # Обновляем статусы транзакций
                    successful_ids = tier_result.get("successful_ids", [])
                    failed_ids = tier_result.get("failed_ids", [])
                    
                    for tx in transactions:
                        if str(tx.id) in successful_ids:
                            tx.status = "completed"
                        elif str(tx.id) in failed_ids:
                            tx.status = "failed"
                    
                    await db.session.commit()
                
                # Обновляем общие результаты
                results["total_processed"] += tier_result.get("total", 0)
                results["total_successful"] += tier_result.get("successful", 0)
                results["total_failed"] += tier_result.get("failed", 0)
                results["tiers"][str(batch.id)] = tier_result
                
            except Exception as tier_error:
                logger.error(f"Error processing tier {tier_name}: {tier_error}")
                
                # Отмечаем пакетную выплату как ошибочную
                async with db.begin():
                    batch.mark_as_failed(str(tier_error))
                    await db.session.commit()
                
                results["tiers"][str(batch.id)] = {
                    "error": str(tier_error),
                    "successful": 0,
                    "failed": batch.total_transactions,
                    "total": batch.total_transactions
                }
                results["total_failed"] += batch.total_transactions
                results["total_processed"] += batch.total_transactions
        
        # Обновляем статус еженедельной выплаты в зависимости от результатов
        async with db.begin():
            # Считаем количество успешных и проваленных пакетов
            successful_batches = sum(1 for batch in batch_payouts if batch.status == "completed")
            failed_batches = sum(1 for batch in batch_payouts if batch.status == "failed")
            
            # Получаем все обработанные транзакции из всех пакетов
            processed_tx_query = await db.session.execute(
                db.select(Transaction).filter(
                    Transaction.payout_id == payout_id,
                    Transaction.status.in_(["completed", "failed"])
                )
            )
            processed_transactions = processed_tx_query.scalars().all()
            
            payout.update_progress(
                processed_count=results["total_successful"] + results["total_failed"],
                transaction_ids=[tx.id for tx in processed_transactions]
            )
            
            # Обновляем данные о выплате
            payout_data = payout.payout_data or {}
            payout_data["results"] = results
            payout.payout_data = payout_data
            
            await db.session.commit()
        
        logger.info(f"Payout {payout_id} processed: {results['total_successful']} successful, {results['total_failed']} failed")
        
        return results
    except Exception as e:
        # В случае ошибки откатываем транзакцию и логируем
        await db.session.rollback()
        logger.error(f"Error processing payout: {e}")
        
        # Пытаемся пометить выплату как ошибочную
        try:
            await update_payout_status(payout_id, "failed", str(e))
        except Exception as status_error:
            logger.error(f"Error updating payout status: {status_error}")
        
        return {"success": False, "error": str(e)}


async def notify_users_with_pending_rewards(message: str, min_amount: float = 1000.0) -> Dict[str, Any]:
    """
    Отправка уведомлений пользователям с доступными выплатами
    
    Args:
        message: Текст уведомления
        min_amount: Минимальная сумма для уведомления
        
    Returns:
        Dict: Результат отправки уведомлений
    """
    try:
        # Получаем список пользователей с доступными выплатами
        users = await get_users_with_pending_rewards(min_amount)
        
        if not users:
            return {"success": True, "sent": 0, "total": 0, "message": "No users with pending rewards"}
        
        # Создаем экземпляр бота для отправки сообщений
        bot_token = config.TELEGRAM_TOKEN
        if not bot_token:
            return {"success": False, "error": "Bot token not found"}
        
        bot = Bot(token=bot_token)
        
        # Результаты отправки
        results = {
            "success": True,
            "sent": 0,
            "failed": 0,
            "total": len(users),
            "details": []
        }
        
        # Отправляем уведомления пользователям
        for user in users:
            user_id = user.get("user_id")
            amount = user.get("amount", 0)
            
            # Формируем персонализированное сообщение
            personalized_message = f"{message}\n\nДоступная сумма: {amount:.2f}₽"
            
            try:
                if config.USE_REAL_ROBOKASSA_API:
                    # В реальной реализации отправляем сообщение через Telegram API
                    await bot.send_message(chat_id=user_id, text=personalized_message)
                
                results["sent"] += 1
                results["details"].append({
                    "user_id": user_id,
                    "amount": amount,
                    "status": "sent"
                })
            except Exception as e:
                logger.error(f"Error sending notification to user {user_id}: {e}")
                results["failed"] += 1
                results["details"].append({
                    "user_id": user_id,
                    "amount": amount,
                    "status": "failed",
                    "error": str(e)
                })
        
        logger.info(f"Notifications sent: {results['sent']} successful, {results['failed']} failed")
        
        return results
    except Exception as e:
        logger.error(f"Error sending notifications: {e}")
        return {"success": False, "error": str(e)}


@log_payout_operation_decorator(operation_type="process_payout_by_tiers")
async def process_payout_by_tiers(bot: Bot, payout_id: PayoutID) -> Dict[str, Any]:
    """
    Обработка выплаты группами по диапазонам сумм с автоматическими повторными попытками
    
    Args:
        bot: Экземпляр бота Telegram
        payout_id: ID выплаты
        
    Returns:
        Dict: Результат обработки выплаты
    """
    try:
        # Преобразуем типы данных
        payout_id_int = int(payout_id)
        
        # Проверяем существование выплаты
        from db_config import db
        payout = await db.session.get(WeeklyPayout, payout_id_int)
        
        if not payout:
            error_message = f"Payout not found: {payout_id_int}"
            logger.error(error_message)
            await log_payout_operation(
                operation_type="process_payout_by_tiers",
                payout_id=payout_id_int,
                status="failed",
                error_message=error_message
            )
            return {"error": error_message}
        
        # Проверяем, что выплата в подходящем статусе для обработки
        if payout.status not in ["pending", "processing"]:
            error_message = f"Payout {payout_id_int} in invalid status for processing: {payout.status}"
            logger.warning(error_message)
            await log_payout_operation(
                operation_type="process_payout_by_tiers",
                payout_id=payout_id_int,
                status="skipped",
                response_data={"current_status": payout.status}
            )
            return {"status": "skipped", "reason": error_message}
            
        # Обновляем статус выплаты на "processing"
        await with_retries(update_payout_status, payout_id_int, "processing")
        
        # Логируем начало обработки
        logger.info(f"Starting payout processing for payout {payout_id_int}")
        await log_payout_operation(
            operation_type="process_payout_by_tiers",
            payout_id=payout_id_int,
            status="processing",
            response_data={"step": "started"}
        )
        
        # Запускаем процесс обработки выплаты с повторными попытками при сбоях
        async def process_with_validation(p_id: int, mode: str) -> Dict[str, Any]:
            result = await process_payout(p_id, mode)
            # Проверяем результат на успешность
            if not result.get("success", True):  # Если ключа success нет, считаем успешным
                error_message = f"Payout processing failed: {result.get('error', 'Unknown error')}"
                # Логируем ошибку
                await log_payout_operation(
                    operation_type="process_payout_validation",
                    payout_id=p_id,
                    status="failed",
                    error_message=error_message,
                    response_data=result
                )
                raise RuntimeError(error_message)
                
            # Логируем успешное выполнение валидации
            await log_payout_operation(
                operation_type="process_payout_validation",
                payout_id=p_id,
                status="success",
                response_data=result
            )
            return result
            
        try:
            # Запускаем процесс с повторными попытками
            results = await with_retries(process_with_validation, payout_id_int, "tier")
        except Exception as e:
            # В случае исчерпания всех попыток
            error_message = f"All retry attempts failed for payout {payout_id_int}: {e}"
            logger.error(error_message)
            
            # Обновляем статус выплаты на "failed"
            await with_retries(update_payout_status, payout_id_int, "failed", error_message)
            
            # Логируем ошибку
            await log_payout_operation(
                operation_type="process_payout_by_tiers",
                payout_id=payout_id_int,
                status="failed",
                error_message=error_message
            )
            
            return {"error": str(e)}
        
        # Проверяем, были ли ошибки в процессе обработки
        if results.get("total_failed", 0) > 0 and results.get("total_successful", 0) > 0:
            # Если есть и успешные, и неудачные выплаты, отмечаем как partially completed
            await with_retries(update_payout_status, payout_id_int, "partial")
            status_message = "partial"
        elif results.get("total_failed", 0) > 0 and results.get("total_successful", 0) == 0:
            # Если все выплаты неудачные, отмечаем как failed
            await with_retries(update_payout_status, payout_id_int, "failed", "All payments failed")
            status_message = "failed"
        else:
            # Если все успешно, обновляем статус выплаты на "completed"
            await with_retries(update_payout_status, payout_id_int, "completed")
            status_message = "completed"
        
        # Формируем результаты для ответа
        summary = {
            "status": status_message,
            "total_users": results.get("total_processed", 0),
            "total_amount": float(results.get("total_amount", 0)),
            "success": results.get("total_successful", 0),
            "failed": results.get("total_failed", 0),
            "tiers": {}
        }
        
        # Добавляем информацию по группам
        for tier_id, tier_result in results.get("tiers", {}).items():
            summary["tiers"][tier_id] = {
                "name": tier_result.get("name", tier_id),
                "total": tier_result.get("total", 0),
                "success": tier_result.get("successful", 0),
                "failed": tier_result.get("failed", 0),
                "amount": float(tier_result.get("amount", 0))
            }
        
        # Логируем успешное завершение
        logger.info(f"Payout processing completed for payout {payout_id_int}: {status_message}")
        await log_payout_operation(
            operation_type="process_payout_by_tiers",
            payout_id=payout_id_int,
            status="success",
            response_data=summary
        )
        
        # После завершения выплаты планируем проверку статуса через некоторое время
        # для выявления зависших или неподтвержденных транзакций
        from services.payout_monitoring_service import check_payout_status
        asyncio.create_task(check_payout_status(payout_id_int))
        
        return summary
    
    except Exception as e:
        # Определяем payout_id для логирования
        payout_id_for_log = int(payout_id) if isinstance(payout_id, (int, float)) else 0
        
        error_message = f"Error in process_payout_by_tiers for payout {payout_id_for_log}: {e}"
        logger.error(error_message)
        
        # Обновляем статус выплаты на "failed"
        await update_payout_status(payout_id_for_log, "failed", str(e))
        
        # Логируем ошибку
        await log_payout_operation(
            operation_type="process_payout_by_tiers",
            payout_id=payout_id_for_log,
            status="failed",
            error_message=error_message
        )
        
        return {"error": str(e)}


async def group_notify_about_pending_payouts(bot: Bot, min_amount: float = MIN_PAYOUT_AMOUNT) -> Dict[str, Any]:
    """
    Отправка групповых уведомлений пользователям с доступными выплатами
    с автоматическими повторными попытками при сбоях
    
    Args:
        bot: Экземпляр бота Telegram
        min_amount: Минимальная сумма для уведомления
        
    Returns:
        Dict: Результат отправки уведомлений
    """
    try:
        # Получаем список пользователей с доступными выплатами с повторными попытками
        async def get_users_with_retry() -> List[Dict[str, Any]]:
            return await get_users_with_pending_rewards(min_amount)
            
        users = await with_retries(get_users_with_retry)
        
        if not users:
            return {
                "status": "no_eligible_users",
                "min_amount": min_amount,
                "message": f"No users with pending rewards above {min_amount:.2f}₽"
            }
        
        # Сообщение для уведомления
        message = (
            "💰 *Вам доступна выплата реферального вознаграждения*\n\n"
            "Вы можете запросить выплату, отправив команду /rewards боту."
        )
        
        # Результаты отправки
        results = {
            "total_users": len(users),
            "notified": 0,
            "failed": 0,
            "details": []
        }
        
        # Максимальное количество сообщений в минуту (защита от спама)
        max_messages_per_minute = 30
        delay_between_messages = 60 / max_messages_per_minute  # секунд
        
        # Отправляем уведомления пользователям
        for i, user in enumerate(users):
            user_id = user.get("user_id")
            amount = user.get("amount", 0)
            
            # Формируем персонализированное сообщение
            personalized_message = f"{message}\n\nДоступная сумма: {amount:.2f}₽"
            
            try:
                # Отправляем сообщение с механизмом повторных попыток
                if config.USE_REAL_ROBOKASSA_API:
                    async def send_message_with_retry(uid: int, msg: str) -> None:
                        await bot.send_message(
                            chat_id=uid,
                            text=msg,
                            parse_mode='Markdown'
                        )
                    
                    # Используем повторные попытки для отправки сообщений
                    await with_retries(send_message_with_retry, user_id, personalized_message)
                
                results["notified"] += 1
                results["details"].append({
                    "user_id": user_id,
                    "amount": amount,
                    "status": "sent"
                })
                
                # Добавляем задержку между сообщениями
                if i < len(users) - 1:
                    await asyncio.sleep(delay_between_messages)
            except Exception as e:
                logger.error(f"Error sending notification to user {user_id}: {e}")
                results["failed"] += 1
                results["details"].append({
                    "user_id": user_id,
                    "amount": amount,
                    "status": "failed",
                    "error": str(e)
                })
        
        logger.info(f"Group notifications sent: {results['notified']} successful, {results['failed']} failed")
        
        return results
    except Exception as e:
        logger.error(f"Error in group_notify_about_pending_payouts: {e}")
        return {"status": "error", "error": str(e)}