import unittest
from unittest.mock import patch, AsyncMock, MagicMock
import pytest

# Import handlers to test
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from handlers import (
    start_command, help_command, invite_command, 
    refcode_command, process_refcode, admin_command
)

# Sample test data
MOCK_USER = {
    "id": 12345,
    "username": "test_user",
    "first_name": "Test",
    "subscription_end": None,
    "subscription_type": None,
    "referral_code": "TEST123",
    "referrer_id": None,
    "referrals": [],
    "level_1_referrals": [],
    "level_2_referrals": [],
    "level_3_referrals": [],
    "level_4_referrals": [],
    "total_earned": 0
}

MOCK_ADMIN_USER = {
    "id": 67890,
    "username": "admin_user",
    "first_name": "Admin",
    "is_admin": True
}

class MockUpdate:
    def __init__(self, user_id, username=None, first_name=None, text=None):
        self.effective_user = MagicMock()
        self.effective_user.id = user_id
        self.effective_user.username = username
        self.effective_user.first_name = first_name
        
        self.message = MagicMock()
        self.message.text = text
        
        self.callback_query = None
    
    def set_callback_query(self, data):
        self.callback_query = MagicMock()
        self.callback_query.data = data
        return self

class TestHandlers(unittest.TestCase):
    
    @pytest.mark.asyncio
    @patch("handlers.get_user_data", return_value=MOCK_USER)
    @patch("handlers.save_user_data")
    async def test_start_command(self, mock_save, mock_get):
        # Create mock objects
        update = MockUpdate(12345, "test_user", "Test")
        context = AsyncMock()
        
        # Call the function
        await start_command(update, context)
        
        # Verify the function called context.bot.send_message
        context.bot.send_message.assert_called_once()
        # Check if the message contains "Welcome"
        assert "Welcome" in context.bot.send_message.call_args[0][1]
    
    @pytest.mark.asyncio
    async def test_help_command(self):
        # Create mock objects
        update = MockUpdate(12345)
        context = AsyncMock()
        
        # Call the function
        await help_command(update, context)
        
        # Verify the function called context.bot.send_message
        context.bot.send_message.assert_called_once()
        # Check if the message contains help text
        assert "commands" in context.bot.send_message.call_args[0][1].lower()
    
    @pytest.mark.asyncio
    @patch("handlers.get_user_data", return_value=MOCK_USER)
    async def test_invite_command(self, mock_get):
        # Create mock objects
        update = MockUpdate(12345)
        context = AsyncMock()
        context.bot.get_me.return_value = MagicMock(username="katiysha_bot")
        
        # Call the function
        await invite_command(update, context)
        
        # Verify the function called context.bot.send_message
        context.bot.send_message.assert_called_once()
        # Check if the message contains the referral link
        message = context.bot.send_message.call_args[0][1]
        assert "https://t.me/katiysha_bot?start=TEST123" in message
    
    @pytest.mark.asyncio
    async def test_refcode_command(self):
        # Create mock objects
        update = MockUpdate(12345)
        context = AsyncMock()
        
        # Call the function
        await refcode_command(update, context)
        
        # Verify the function called context.bot.send_message
        context.bot.send_message.assert_called_once()
        # Check if the message asks for a referral code
        assert "enter the referral code" in context.bot.send_message.call_args[0][1].lower()
    
    @pytest.mark.asyncio
    @patch("handlers.get_user_data")
    @patch("handlers.save_user_data")
    async def test_process_refcode_valid(self, mock_save, mock_get):
        # Setup two users - one with the referral code and one using it
        referrer = MOCK_USER.copy()
        referrer["id"] = 67890
        referrer["username"] = "referrer"
        
        new_user = MOCK_USER.copy()
        new_user["referrer_id"] = None
        
        # Mock get_user_data to return different data based on user ID
        def mock_get_user_data(user_id):
            if user_id == 12345:
                return new_user
            elif user_id == 67890:
                return referrer
            else:
                return {}
        
        mock_get.side_effect = mock_get_user_data
        
        # Create mock objects
        update = MockUpdate(12345, "test_user", "Test", "TEST123")
        context = AsyncMock()
        
        # Call the function with a valid referral code from another user
        await process_refcode(update, context)
        
        # Verify user data was updated with referrer_id
        called_with = mock_save.call_args[0][0]
        assert called_with["referrer_id"] == 67890
        
        # Verify the function sent a success message
        context.bot.send_message.assert_called()
        success_call = context.bot.send_message.call_args_list[0]
        assert "successfully" in success_call[0][1].lower()
    
    @pytest.mark.asyncio
    @patch("handlers.get_user_data", return_value=MOCK_USER)
    @patch("handlers.save_user_data")
    async def test_process_refcode_self_referral(self, mock_save, mock_get):
        # Create mock objects
        update = MockUpdate(12345, "test_user", "Test", "TEST123")
        context = AsyncMock()
        
        # Call the function with user's own referral code
        await process_refcode(update, context)
        
        # Verify save_user_data was not called
        mock_save.assert_not_called()
        
        # Verify the function sent an error message
        context.bot.send_message.assert_called_once()
        assert "cannot use your own" in context.bot.send_message.call_args[0][1].lower()
    
    @pytest.mark.asyncio
    @patch("handlers.get_user_data", return_value=MOCK_USER)
    @patch("handlers.save_user_data")
    async def test_process_refcode_invalid(self, mock_save, mock_get):
        # Create mock objects
        update = MockUpdate(12345, "test_user", "Test", "INVALID")
        context = AsyncMock()
        
        # Mock get_user_data to return None for any user ID lookup by referral code
        mock_get.side_effect = [MOCK_USER, None]
        
        # Call the function with an invalid referral code
        await process_refcode(update, context)
        
        # Verify the function sent an error message
        context.bot.send_message.assert_called_once()
        assert "invalid" in context.bot.send_message.call_args[0][1].lower()
    
    @pytest.mark.asyncio
    @patch("handlers.get_user_data", return_value=MOCK_ADMIN_USER)
    @patch("handlers.check_admin", return_value=True)
    async def test_admin_command_authorized(self, mock_check, mock_get):
        # Create mock objects
        update = MockUpdate(67890, "admin_user", "Admin")
        context = AsyncMock()
        
        # Call the function
        await admin_command(update, context)
        
        # Verify the function called context.bot.send_message with admin panel
        context.bot.send_message.assert_called_once()
        # Check if the message contains admin panel elements
        message = context.bot.send_message.call_args[0][1]
        assert "Admin Panel" in message
    
    @pytest.mark.asyncio
    @patch("handlers.get_user_data", return_value=MOCK_USER)
    @patch("handlers.check_admin", return_value=False)
    async def test_admin_command_unauthorized(self, mock_check, mock_get):
        # Create mock objects
        update = MockUpdate(12345, "test_user", "Test")
        context = AsyncMock()
        
        # Call the function
        await admin_command(update, context)
        
        # Verify the function called context.bot.send_message with access denied
        context.bot.send_message.assert_called_once()
        # Check if the message contains access denied
        message = context.bot.send_message.call_args[0][1]
        assert "not authorized" in message.lower()


if __name__ == "__main__":
    pytest.main() 