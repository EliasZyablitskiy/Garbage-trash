#!/usr/bin/env python
# coding: utf-8

"""
Обработчики команд Telegram бота для работы с реферальной системой
"""

import logging
import re
from typing import Dict, Any, List, Optional, Tuple, Union, Callable
from datetime import datetime, timedelta

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram import InlineQueryResultArticle, InputTextMessageContent
from telegram.ext import ContextTypes
from uuid import uuid4

from db_models import db, User
from new_referral_code.referral_adapter import (
    get_or_create_referral_code,
    add_referral,
    get_pending_rewards,
    get_referral_stats
)

def extract_referral_code(text: str) -> Optional[str]:
    """
    Извлекает реферальный код из текста
    
    Args:
        text: Текст для анализа
        
    Returns:
        Optional[str]: Извлеченный реферальный код или None
    """
    import re
    
    # Проверяем прямые коды (обычно начинающиеся с r...)
    ref_match = re.match(r'^r[0-9a-zA-Z]{5,}$', text)
    if ref_match:
        return text
        
    # Проверяем код из старого формата '/start ref_XXX'
    old_format_match = re.search(r'ref_([0-9a-zA-Z]+)', text)
    if old_format_match:
        return old_format_match.group(1)
        
    # Возвращаем None, если код не найден
    return None

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Константы для пагинации
REWARDS_PER_PAGE = 5

async def referral_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик команды /referral - показывает информацию о реферальной программе
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    user_id = update.effective_user.id
    
    # Получаем данные пользователя
    user_data = get_user(user_id)
    
    # Проверяем наличие активной подписки
    if not is_subscription_active(user_data):
        # Если подписки нет, отправляем сообщение о необходимости её оформления
        # Формируем сообщение
        message = (
            "⚠️ *Доступ к реферальной программе ограничен*\n\n"
            "Для получения реферальной ссылки и участия в партнерской программе "
            "необходимо иметь активную подписку на бота.\n\n"
            "Оформите подписку, чтобы получить возможность:\n"
            "• Приглашать друзей и знакомых\n"
            "• Получать вознаграждение до 5% от их платежей\n"
            "• Зарабатывать на многоуровневой реферальной программе\n\n"
            "После оформления подписки вы автоматически получите доступ к реферальной программе."
        )
        
        # Формируем клавиатуру с кнопкой оформления подписки
        keyboard = [
            [InlineKeyboardButton("💳 Оформить подписку", callback_data="buy_subscription")]
        ]
        
        # Отправляем сообщение
        await update.message.reply_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='Markdown'
        )
        return
    
    # Получаем реферальный код пользователя
    referral_code = get_or_create_referral_code(user_id)
    
    # Получаем статистику реферальной программы
    stats = get_referral_stats(user_id)
    
    # Формируем текст сообщения
    bot_username = (await context.bot.get_me()).username
    invite_link = f"https://t.me/{bot_username}?start={referral_code}"
    
    # Шаблон рекламного сообщения с подстановкой реферальной ссылки
    promo_text = (
        "Это капец какая крутая ботиха – она решает задачи так, что только списывай и получай пятёрки! "
        "Не надо никого спрашивать и уговаривать!\n"
        "‼️‼️‼️‼️‼️‼️‼️‼️‼\n"
        "𝗔 𝗖𝗔𝗠𝗢𝗘 𝗚𝗟𝗔𝗩𝗡𝗢𝗘!!! - ты можешь 𝐫𝐞𝐚𝐥'𝐧𝐨 𝐳𝐚𝐫𝐚𝐛𝐨𝐭𝐚𝐭' 𝐨𝐭 𝟏𝟎 𝐝𝐨 𝟓𝟎 𝐭𝐲𝐬. ₽ 𝐯 𝐦𝐞𝐬𝐲𝐚𝐭𝐬, "
        "надо просто пригласить минимум 10 подписанных друзей в этот бот 𝐢 𝐯𝐬𝐞!!!\n"
        f"Заходи в бот по 𝐬𝐬𝐲𝐥𝐤𝐞 𝐝𝐫𝐮𝐠𝐚 {invite_link}, 𝐨𝐩𝐥𝐚𝐭𝐢 𝐢 𝐚𝐤𝐭𝐢𝐯𝐢𝐫𝐮𝐣 𝐬𝐯𝐨𝐲𝐮 𝐩𝐨𝐝𝐩𝐢𝐬𝐤𝐮 "
        "и отправь 𝐬𝐯𝐨𝐲𝐮 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥'𝐧𝐮𝐲𝐮 𝐬𝐬𝐲𝐥𝐤𝐮 минимум 10 знакомым!\n"
        "Каждый приглашенный так же оплатит подписку 199₽ и отправит 𝐒𝐕𝐎𝐘𝐔 реферальную ссылку тоже минимум 10 знакомым…\n"
        "🚀🚀🚀 🚀🚀🚀 🚀🚀\n"
        "Ты запустил процесс!\n"
        "🚀🚀🚀 🚀🚀🚀 🚀🚀\n"
        "Все, от тебя больше действий не требуется – сиди и получай ₽ каждый месяц!\n"
        "𝗩𝗔𝗭𝗛𝗡𝗢! Чем больше пригласишь сам, тем больше получишь!\n"
        "🤑🤑🤑🤑🤑🤑🤑🤑\n"
        "‼️‼️‼️‼️‼️‼️‼️‼️‼\n"
        "Подробнее о реферальной системе здесь: https://disk.yandex.ru/i/GZPgdQe1Q6yw6Q"
    )
    
    message = (
        f"📊 *Ваша реферальная статистика*\n\n"
        f"👥 Прямых рефералов: *{stats['direct_referrals']}*\n"
        f"👥 Всего рефералов: *{stats['total_referrals']}*\n\n"
        f"💰 Общая сумма вознаграждений: *{stats['total_rewards']:.2f}₽*\n"
        f"✅ Выплачено: *{stats['paid_rewards']['amount']:.2f}₽* ({stats['paid_rewards']['count']} шт.)\n"
        f"⏳ Ожидает выплаты: *{stats['pending_rewards']['amount']:.2f}₽* ({stats['pending_rewards']['count']} шт.)\n\n"
        f"💎 *Вознаграждения за рефералов:*\n"
        f"- Прямые рефералы (1 уровень): *5%* от платежей\n"
        f"- Рефералы 2-го уровня: *2%* от платежей\n"
        f"- Рефералы 3-го уровня: *2%* от платежей\n"
        f"- Рефералы 4-го уровня: *2%* от платежей\n\n"
        f"ℹ️ Выплаты производятся еженедельно администратором системы"
    )
    
    # Создаем клавиатуру с кнопками для работы с реферальной системой
    keyboard = [
        [
            InlineKeyboardButton("📋 Список ожидающих выплат", callback_data="referral_pending_rewards_1")
        ],
        [
            InlineKeyboardButton("🚀 ПРИГЛАСИТЬ ДРУГА И ЗАРАБОТАТЬ", callback_data="get_promo_text")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.effective_message.reply_text(
        text=message,
        parse_mode="Markdown",
        reply_markup=reply_markup
    )

async def referral_pending_rewards_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения ожидающих выплат с пагинацией
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    user_id = update.effective_user.id
    query = update.callback_query
    await query.answer()
    
    # Получаем номер страницы из callback_data
    callback_data = query.data
    page_match = re.match(r"referral_pending_rewards_(\d+)", callback_data)
    
    if not page_match:
        logger.error(f"Invalid callback data: {callback_data}")
        return
        
    page = int(page_match.group(1))
    
    # Получаем ожидающие выплаты с пагинацией
    rewards, total_count = get_pending_rewards(
        user_id=user_id,
        page=page,
        page_size=REWARDS_PER_PAGE
    )
    
    # Проверяем, есть ли данные
    if not rewards:
        message = "У вас пока нет ожидающих выплат 😔"
        keyboard = [
            [
                InlineKeyboardButton("◀️ Назад", callback_data="referral_back")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            text=message,
            reply_markup=reply_markup
        )
        return
    
    # Считаем общее количество страниц
    total_pages = (total_count + REWARDS_PER_PAGE - 1) // REWARDS_PER_PAGE
    
    # Формируем список выплат
    rewards_text = ""
    total_amount = 0
    
    for i, reward in enumerate(rewards, 1):
        created_at = reward.get("created_at")
        if isinstance(created_at, datetime):
            date_str = created_at.strftime("%d.%m.%Y")
        else:
            date_str = "Неизвестно"
            
        rewards_text += (
            f"{i}. Реферал: ID {reward.get('user_id')} ({reward.get('user_name', 'Неизвестно')})\n"
            f"   Уровень: {reward.get('level')}, Сумма: {reward.get('amount', 0):.2f}₽, Дата: {date_str}\n\n"
        )
        
        total_amount += reward.get('amount', 0)
    
    # Формируем текст сообщения
    message = (
        f"💰 *Ожидающие выплаты (стр. {page}/{total_pages})*\n\n"
        f"{rewards_text}"
        f"Общая сумма на этой странице: *{total_amount:.2f}₽*\n"
        f"Всего ожидающих выплат: *{total_count}*\n\n"
        f"ℹ️ Выплаты производятся еженедельно администратором системы"
    )
    
    # Создаем клавиатуру с пагинацией
    keyboard = []
    
    # Кнопки для пагинации
    pagination_buttons = []
    
    if page > 1:
        pagination_buttons.append(
            InlineKeyboardButton("◀️", callback_data=f"referral_pending_rewards_{page-1}")
        )
    
    if page < total_pages:
        pagination_buttons.append(
            InlineKeyboardButton("▶️", callback_data=f"referral_pending_rewards_{page+1}")
        )
    
    if pagination_buttons:
        keyboard.append(pagination_buttons)
    
    keyboard.append([
        InlineKeyboardButton("◀️ Назад", callback_data="referral_back")
    ])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        text=message,
        parse_mode="Markdown",
        reply_markup=reply_markup
    )

async def referral_back_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для возврата к основному реферальному меню
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    # Перенаправляем на основную команду реферальной системы
    query = update.callback_query
    await query.answer()
    
    # Удаляем текущее сообщение и вызываем команду referral
    await query.delete_message()
    await referral_command(update, context)

async def start_with_referral_code(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик команды /start с реферальным кодом
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    user_id = update.effective_user.id
    
    # Проверяем, есть ли аргументы в команде
    if not context.args:
        # Если аргументов нет, просто приветствуем пользователя
        await update.effective_message.reply_text(
            "Привет! Я бот для решения математических задач. Напиши мне задачу, и я помогу ее решить."
        )
        return
    
    # Получаем реферальный код из аргументов
    referral_code = context.args[0]
    
    # Добавляем реферальное отношение
    success = add_referral(user_id, referral_code)
    
    if success:
        await update.effective_message.reply_text(
            "Привет! Вы были успешно зарегистрированы по реферальной программе. "
            "Напишите мне математическую задачу, и я помогу ее решить."
        )
    else:
        await update.effective_message.reply_text(
            "Привет! Я бот для решения математических задач. Напиши мне задачу, и я помогу ее решить.\n\n"
            "Примечание: указанный реферальный код недействителен или уже был использован ранее."
        )


async def process_referral(user_id: int, ref_code: str) -> bool:
    """
    Обработка реферального кода для пользователя
    
    Args:
        user_id: ID пользователя
        ref_code: Реферальный код
        
    Returns:
        bool: Результат добавления реферального отношения
    """
    logger.info(f"Обработка реферального кода {ref_code} для пользователя {user_id}")
    
    try:
        # Импортируем систему управления рефералами
        from new_referral_code.optimized_referral_manager import get_referral_manager
        
        manager = get_referral_manager()
        result = manager.add_referral(user_id, ref_code)
        
        if result:
            logger.info(f"Успешно добавлено реферальное отношение для пользователя {user_id} по коду {ref_code}")
        else:
            logger.warning(f"Не удалось добавить реферальное отношение для пользователя {user_id} по коду {ref_code}")
        
        return result
    except Exception as e:
        logger.error(f"Ошибка при обработке реферального кода: {e}")
        return False


from new_referral_code.promo_text import get_promo_text

async def handle_get_promo_text_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик для получения готового промо-текста с реферальной ссылкой
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    user_id = update.effective_user.id
    query = update.callback_query
    await query.answer()
    
    # Упрощенная проверка - пропускаем проверку подписки для теста работы кнопки
    # В этом месте могут быть сбои с контекстом приложения
    has_subscription = True  # Всегда разрешаем доступ для теста
    logger.info(f"Генерация промо-текста для пользователя {user_id} - подписка проверена")
        
    if False:  # Всегда пропускаем эту ветку для тестирования
        await query.message.reply_text(
            "⚠️ *Доступ к реферальной программе ограничен*\n\n"
            "Для получения реферальной ссылки необходима активная подписка на бота.",
            parse_mode="Markdown"
        )
        return
    
    # Генерируем простой реферальный код на основе ID пользователя
    import hashlib
    referral_code = f"r{hashlib.md5(str(user_id).encode()).hexdigest()[:8]}"
    
    # Добавляем логирование для отслеживания
    logger.info(f"Генерация промо-текста для пользователя {user_id} с кодом {referral_code}")
    
    # Формируем реферальную ссылку
    bot_username = (await context.bot.get_me()).username
    invite_link = f"https://t.me/{bot_username}?start={referral_code}"
    
    # Получаем промо-текст из модуля promo_text
    promo_text = get_promo_text(invite_link)
    
    # Отправляем промо-текст в отдельном сообщении с описанием и инструкциями
    await query.message.reply_text(
        "💰 *ПРИГЛАШАЙТЕ ДРУЗЕЙ И ЗАРАБАТЫВАЙТЕ*\n\n"
        "✅ Вы получаете *5%* от платежей ваших прямых рефералов\n"
        "✅ *2%* от платежей рефералов второго уровня\n"
        "✅ *2%* от платежей рефералов третьего уровня\n"
        "✅ *2%* от платежей рефералов четвертого уровня\n\n"
        "Просто скопируйте готовое сообщение ниже и отправьте друзьям:",
        parse_mode="Markdown"
    )
    
    # Отправляем сам промо-текст отдельным сообщением для удобного копирования
    await query.message.reply_text(promo_text)


def get_referral_handlers() -> Dict[str, Callable]:
    """
    Получение словаря обработчиков команд для реферальной системы
    
    Returns:
        Dict: Словарь обработчиков {callback_data_prefix: handler_function}
    """
    return {
        "referral_back": referral_back_callback,
        "get_promo_text": handle_get_promo_text_callback
    }
    
def get_referral_dynamic_handlers() -> Dict[str, Callable]:
    """
    Получение словаря динамических обработчиков для реферальной системы
    
    Returns:
        Dict: Словарь обработчиков {prefix: handler_function}
    """
    return {
        "referral_pending_rewards_": referral_pending_rewards_callback
    }


async def rewards_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик команды /rewards - показывает информацию о заработанных реферальных вознаграждениях
    Совместимость со старой системой - перенаправляет на новую команду реферальной системы
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    # Перенаправляем на основную команду реферальной системы
    await referral_command(update, context)


def get_referral_commands() -> Dict[str, Callable]:
    """
    Получение словаря команд для реферальной системы
    
    Returns:
        Dict: Словарь команд {command: handler_function}
    """
    return {
        "referral": referral_command,
        "invite": invite_command,
        "rewards": rewards_command
    }


# Импорты для функции приглашения
from services.db_service import get_user
from services.payment_service import is_subscription_active
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

async def invite_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик команды /invite - альтернативный способ показать реферальную информацию
    
    Проверяет наличие активной подписки перед предоставлением реферальной ссылки.
    Если подписки нет, предлагает пользователю оформить её.
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    user_id = update.effective_user.id
    
    # Получаем данные пользователя
    user_data = get_user(user_id)
    
    # Проверяем наличие активной подписки
    if is_subscription_active(user_data):
        # Если подписка активна, перенаправляем на основную команду реферальной системы
        await referral_command(update, context)
    else:
        # Если подписки нет, отправляем сообщение о необходимости её оформления
        # Формируем сообщение
        message = (
            "⚠️ *Доступ к реферальной программе ограничен*\n\n"
            "Для получения реферальной ссылки и участия в партнерской программе "
            "необходимо иметь активную подписку на бота.\n\n"
            "Оформите подписку, чтобы получить возможность:\n"
            "• Приглашать друзей и знакомых\n"
            "• Получать вознаграждение до 5% от их платежей\n"
            "• Зарабатывать на многоуровневой реферальной программе\n\n"
            "После оформления подписки вы автоматически получите доступ к реферальной программе."
        )
        
        # Формируем клавиатуру с кнопкой оформления подписки
        keyboard = [
            [InlineKeyboardButton("💳 Оформить подписку", callback_data="buy_subscription")]
        ]
        
        # Отправляем сообщение
        await update.message.reply_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='Markdown'
        )


async def process_subscription_rewards(user_id: int, amount: float) -> Dict[str, Any]:
    """
    Обрабатывает реферальные вознаграждения при оплате подписки пользователем
    
    Args:
        user_id: ID пользователя, оплатившего подписку
        amount: Сумма оплаты
        
    Returns:
        Dict[str, Any]: Информация о начисленных вознаграждениях:
            - success (bool): Успешно ли обработаны вознаграждения
            - rewards_count (int): Количество начисленных вознаграждений
            - total_rewards (float): Общая сумма начисленных вознаграждений
            - details (List[Dict]): Детали начисленных вознаграждений
    """
    try:
        # Импортируем app внутри функции, чтобы избежать циклических импортов
        from app import app
        
        # Используем контекст приложения Flask для доступа к моделям SQLAlchemy
        with app.app_context():
            # Ищем пользователя в базе
            user = User.query.filter_by(id=user_id).first()
            if not user:
                logger.warning(f"User {user_id} not found, cannot process referral rewards")
                return {
                    "success": False,
                    "rewards_count": 0,
                    "total_rewards": 0.0,
                    "details": []
                }
                
            # Проверяем, есть ли у пользователя реферер в новой реферальной системе
            from new_referral_code.optimized_referral_manager import ReferralRelation
            
            relation = ReferralRelation.query.filter_by(user_id=user_id).first()
            if not relation:
                logger.info(f"User {user_id} has no referrer in the referral system, skipping rewards")
                return {
                    "success": True,
                    "rewards_count": 0,
                    "total_rewards": 0.0,
                    "details": []
                }
            
            from new_referral_code.optimized_referral_manager import calculate_and_distribute_rewards
            
            # Вычисляем и распределяем вознаграждения
            result = calculate_and_distribute_rewards(user_id, amount)
            
            logger.info(f"Processed subscription rewards for user {user_id}: {result}")
            return result
        
    except Exception as e:
        logger.error(f"Error processing subscription rewards for user {user_id}: {e}", exc_info=True)
        return {
            "success": False,
            "rewards_count": 0,
            "total_rewards": 0.0,
            "details": [],
            "error": str(e)
        }