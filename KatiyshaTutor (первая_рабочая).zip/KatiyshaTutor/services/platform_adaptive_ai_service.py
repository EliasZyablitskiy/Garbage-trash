#!/usr/bin/env python
# coding: utf-8

"""
Адаптивный сервис для работы с AI моделями с учетом платформы пользователя
Обеспечивает кроссплатформенную совместимость запросов к AI
"""

import logging
import traceback
from typing import Dict, Any, Optional, Tuple

from services.deepseek_service import solve_math_problem, test_proxyapi_status
from services.platform_data_service import get_ai_model_settings
from services.platform_detection_service import get_user_platform, PLATFORM_IOS, PLATFORM_ANDROID

# Настройка логирования
logger = logging.getLogger(__name__)

class PlatformAdaptiveAIService:
    """
    Адаптивный сервис для взаимодействия с AI моделями с учетом платформы пользователя
    """
    
    @staticmethod
    async def solve_math_problem(user_id: int, problem_text: str) -> str:
        """
        Решает математическую задачу с учетом платформы пользователя
        
        Args:
            user_id: ID пользователя
            problem_text: Текст задачи
            
        Returns:
            str: Решение задачи или сообщение об ошибке
        """
        try:
            # Получаем информацию о платформе пользователя
            user_platform = get_user_platform(user_id)
            
            if user_platform:
                platform_type = user_platform.platform_type
                platform_version = user_platform.platform_version
                
                # Получаем специфичные для платформы настройки AI моделей
                ai_settings = get_ai_model_settings(platform_type, platform_version)
                
                if platform_type == PLATFORM_IOS and ai_settings.get("use_compatible_mode", False):
                    logger.info(f"Using iOS compatible mode for user {user_id} with iOS {platform_version}")
                    # На проблемных версиях iOS используем более совместимый режим запроса
                    return await PlatformAdaptiveAIService._solve_for_problematic_ios(problem_text)
                    
                if platform_type == PLATFORM_ANDROID and ai_settings.get("format_fix_enabled", False):
                    logger.info(f"Using Android format fixes for user {user_id} with Android {platform_version}")
                    # На некоторых версиях Android могут быть проблемы с форматированием - применяем исправления
                    solution = await solve_math_problem(problem_text)
                    return PlatformAdaptiveAIService._fix_formatting_for_android(solution)
            
            # Для остальных платформ или если платформа не определена, используем стандартное решение
            return await solve_math_problem(problem_text)
            
        except Exception as e:
            logger.error(f"Error in adaptive AI service: {str(e)}")
            logger.error(traceback.format_exc())
            # В случае ошибки возвращаем стандартное решение
            return await solve_math_problem(problem_text)
    
    @staticmethod
    async def _solve_for_problematic_ios(problem_text: str) -> str:
        """
        Специализированная версия решения задач для проблемных версий iOS
        
        Args:
            problem_text: Текст задачи
            
        Returns:
            str: Решение задачи
        """
        try:
            # Используем стандартное решение, но добавляем дополнительную обработку
            solution = await solve_math_problem(problem_text)
            
            # Удаляем потенциально проблемные элементы форматирования для iOS
            solution = solution.replace('\\\\', '\\')  # Двойные обратные слэши могут вызывать проблемы
            solution = solution.replace('\\(', '(').replace('\\)', ')')  # Экранированные скобки
            solution = solution.replace('\\[', '[').replace('\\]', ']')  # Экранированные квадратные скобки
            
            # Заменяем сложные математические символы на более простые
            replacements = {
                '±': '+/-',
                '×': '*',
                '÷': '/',
                '≤': '<=',
                '≥': '>=',
                '≠': '!=',
                '≈': '~=',
                '∞': 'бесконечность',
                '√': 'корень',
                '∑': 'сумма',
                '∫': 'интеграл',
                '∂': 'частная производная',
                '∇': 'набла',
                '∆': 'дельта',
                '∏': 'произведение',
                '∈': 'принадлежит',
                '∉': 'не принадлежит',
                '∩': 'пересечение',
                '∪': 'объединение',
                '∅': 'пустое множество',
                '∀': 'для всех',
                '∃': 'существует',
                '∄': 'не существует',
                '⊆': 'подмножество',
                '⊇': 'надмножество',
                '⊂': 'строгое подмножество',
                '⊃': 'строгое надмножество',
            }
            
            for original, replacement in replacements.items():
                solution = solution.replace(original, replacement)
            
            return solution
            
        except Exception as e:
            logger.error(f"Error in iOS compatible mode: {str(e)}")
            logger.error(traceback.format_exc())
            # В случае ошибки возвращаем результат стандартного решения
            return await solve_math_problem(problem_text)
    
    @staticmethod
    def _fix_formatting_for_android(solution: str) -> str:
        """
        Исправляет форматирование решения для Android устройств
        
        Args:
            solution: Решение задачи
            
        Returns:
            str: Исправленное решение
        """
        # Исправляем потенциальные проблемы с отображением на Android
        # Иногда встречаются проблемы с отступами и переносами строк
        solution = solution.replace('\t', '    ')  # Заменяем табуляции на пробелы
        
        # Ограничиваем длину строк
        max_line_length = 60
        lines = solution.split('\n')
        wrapped_lines = []
        for line in lines:
            while len(line) > max_line_length:
                # Ищем подходящее место для разрыва строки
                break_point = max_line_length
                while break_point > 0 and line[break_point] not in ' ,.;:':
                    break_point -= 1
                
                if break_point == 0:  # Если не нашли подходящего места
                    break_point = max_line_length
                
                wrapped_lines.append(line[:break_point].rstrip())
                line = line[break_point:].lstrip()
            wrapped_lines.append(line)
        
        return '\n'.join(wrapped_lines)
    
    @staticmethod
    async def test_ai_service() -> Tuple[bool, Dict[str, Any]]:
        """
        Тестирует доступность AI сервиса с учетом потенциальных проблем совместимости
        
        Returns:
            Tuple[bool, Dict[str, Any]]: Результат теста и дополнительная информация
        """
        success = await test_proxyapi_status()
        
        result_info = {
            "service_available": success,
            "ios_compatible_mode_available": True,
            "android_format_fix_available": True,
            "platform_detection_enabled": True
        }
        
        return success, result_info