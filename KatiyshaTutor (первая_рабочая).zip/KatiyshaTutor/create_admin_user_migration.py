#!/usr/bin/env python
# coding: utf-8

"""
Migration script to create AdminUser table for enhanced authentication
"""

import os
import sys
from sqlalchemy import create_engine, text, Column, Integer, BigInteger, String, Boolean, DateTime, Text
from sqlalchemy.orm import sessionmaker, declarative_base
from werkzeug.security import generate_password_hash
from datetime import datetime

# Настройка SQLAlchemy
Base = declarative_base()

# Определение моделей для миграции
class AdminUser(Base):
    """Модель для администраторов с расширенной аутентификацией и ограничением попыток входа"""
    __tablename__ = 'admin_users'
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, nullable=False, unique=True)  # Telegram user ID
    password_hash = Column(String(256), nullable=False)
    role = Column(String(50), default='support_admin')  # super_admin, finance_admin, monitoring_admin, support_admin
    login_attempts = Column(Integer, default=0)
    last_login_attempt = Column(DateTime, nullable=True)
    is_locked = Column(Boolean, default=False)
    lock_until = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)
    last_login = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    two_factor_enabled = Column(Boolean, default=False)
    two_factor_secret = Column(String(32), nullable=True)
    temporary_access_token = Column(String(64), nullable=True)
    temporary_access_expires = Column(DateTime, nullable=True)

def create_admin_users_table():
    """Create admin_users table and update admin_action_logs table"""
    try:
        # Получаем URL базы данных из переменной окружения
        DATABASE_URL = os.environ.get('DATABASE_URL')
        if not DATABASE_URL:
            print("Error: DATABASE_URL environment variable is not set.")
            sys.exit(1)

        # Создаем соединение с базой данных
        engine = create_engine(DATABASE_URL)
        
        # Проверяем, существует ли уже таблица admin_users
        with engine.connect() as connection:
            result = connection.execute(text("SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'admin_users')"))
            table_exists = result.scalar()
            
            if table_exists:
                print("The admin_users table already exists. Migration will not be performed.")
                return
        
        # Создаем таблицу admin_users
        Base.metadata.create_all(engine, tables=[AdminUser.__table__])
        print("Created admin_users table.")
        
        # Проверяем существует ли таблица admin_action_logs
        with engine.connect() as connection:
            result = connection.execute(text("SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'admin_action_logs')"))
            table_exists = result.scalar()
            
            if table_exists:
                # Проверяем существует ли колонка admin_user_id в таблице admin_action_logs
                result = connection.execute(
                    text("SELECT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'admin_action_logs' AND column_name = 'admin_user_id')")
                )
                column_exists = result.scalar()
                
                if not column_exists:
                    # Добавляем колонки admin_user_id, is_verified и verification_hash в таблицу admin_action_logs
                    connection.execute(text("""
                        ALTER TABLE admin_action_logs 
                        ADD COLUMN admin_user_id INTEGER,
                        ADD COLUMN is_verified BOOLEAN DEFAULT FALSE,
                        ADD COLUMN verification_hash VARCHAR(64)
                    """))
                    # Добавляем FK constraint после добавления колонки
                    connection.execute(text("""
                        ALTER TABLE admin_action_logs
                        ADD CONSTRAINT admin_action_logs_admin_user_id_fkey 
                        FOREIGN KEY (admin_user_id) REFERENCES admin_users(id)
                    """))
                    print("Added admin_user_id, is_verified and verification_hash columns to admin_action_logs table.")
            else:
                print("Warning: admin_action_logs table does not exist. Unable to add new columns.")
        
        # Создаем сессию для добавления данных
        Session = sessionmaker(bind=engine)
        session = Session()
        
        # Получаем ID администраторов из существующей системы
        # Предполагается, что это список ID Telegram пользователей
        with engine.connect() as connection:
            result = connection.execute(text("SELECT id FROM users WHERE id = 5913639088"))
            admin_ids = [row[0] for row in result]
        
        if admin_ids:
            for admin_id in admin_ids:
                # Проверяем, существует ли уже запись для данного администратора
                result = session.execute(text(f"SELECT id FROM admin_users WHERE telegram_id = {admin_id}"))
                admin_exists = result.scalar()
                
                if not admin_exists:
                    # Создаем запись администратора с усиленным паролем
                    new_password = 'Easdfx1423'  # Новый сильный пароль
                    password_hash = generate_password_hash(new_password)
                    
                    # Определяем роль администратора
                    role = 'super_admin' if admin_id == 5913639088 else 'support_admin'
                    
                    # Вставляем запись в таблицу admin_users
                    session.execute(text(f"""
                        INSERT INTO admin_users 
                        (telegram_id, password_hash, role, login_attempts, is_locked, is_active, created_at, updated_at, two_factor_enabled)
                        VALUES
                        ({admin_id}, '{password_hash}', '{role}', 0, FALSE, TRUE, NOW(), NOW(), FALSE)
                    """))
                    print(f"Created admin user for telegram_id {admin_id} with role '{role}'")
            
            # Фиксируем изменения
            session.commit()
            print("Migration completed successfully.")
        else:
            print("Warning: No admin_ids found. No admin users were created.")
    
    except Exception as e:
        print(f"Error during migration: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    create_admin_users_table()