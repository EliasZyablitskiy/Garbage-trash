#!/usr/bin/env python
# coding: utf-8

"""
Обработчики команд и колбэков для системы реферальных вознаграждений
"""

import logging
from typing import Dict, Any, List, Optional, Awaitable, Callable

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from database import get_user
from transactions import (
    get_user_total_rewards,
    get_user_pending_rewards,
    process_referral_rewards
)

logger = logging.getLogger(__name__)

async def rewards_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик команды /rewards - показывает информацию о заработанных реферальных вознаграждениях
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    user_id = update.effective_user.id
    
    # Получаем данные о вознаграждениях пользователя
    rewards_stats = get_user_total_rewards(user_id)
    
    # Получаем данные о пользователе
    user_data = get_user(user_id)
    if not user_data:
        await update.message.reply_text(
            "❌ Не удалось получить данные о вашем аккаунте.\n"
            "Пожалуйста, попробуйте позже или обратитесь в поддержку."
        )
        return
    
    # Формируем сообщение о вознаграждениях
    message = (
        "💰 *Ваши реферальные вознаграждения*\n\n"
        f"💵 *Всего заработано:* {rewards_stats['total_earned']:.2f}₽\n"
        f"✅ *Выплачено:* {rewards_stats['total_paid']:.2f}₽\n"
        f"⏳ *Ожидает выплаты:* {rewards_stats['total_pending']:.2f}₽\n"
        f"🔄 *В обработке:* {rewards_stats['total_processing']:.2f}₽\n\n"
    )
    
    # Добавляем информацию о рефералах
    referrals = user_data.get("referrals", {})
    
    level1_count = len(referrals.get("level1", []))
    level2_count = len(referrals.get("level2", []))
    level3_count = len(referrals.get("level3", []))
    level4_count = len(referrals.get("level4", []))
    
    message += (
        "👥 *Ваши рефералы:*\n"
        f"• 1-й уровень: {level1_count} рефералов (5% вознаграждения)\n"
        f"• 2-й уровень: {level2_count} рефералов (2% вознаграждения)\n"
        f"• 3-й уровень: {level3_count} рефералов (2% вознаграждения)\n"
        f"• 4-й уровень: {level4_count} рефералов (2% вознаграждения)\n\n"
    )
    
    # Информация о том, как заработать больше
    message += (
        "💡 *Как заработать больше:*\n"
        "• Приглашайте друзей по вашей реферальной ссылке\n"
        "• Получайте 5% от каждой их оплаты\n"
        "• Также вы получаете вознаграждения с 2-го, 3-го и 4-го уровней приглашений\n\n"
        "Используйте команду /invite, чтобы получить вашу реферальную ссылку!"
    )
    
    # Создаем кнопки
    keyboard = [
        [InlineKeyboardButton("Пригласить друзей", callback_data="show_invite_link")],
        [InlineKeyboardButton("Статистика рефералов", callback_data="referral_stats")]
    ]
    
    await update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def process_subscription_rewards(user_id: int, amount: float = 199.0) -> List[int]:
    """
    Обработка вознаграждений при активации подписки
    
    Args:
        user_id: ID пользователя, активировавшего подписку
        amount: Сумма оплаты (по умолчанию стоимость подписки)
        
    Returns:
        List[int]: Список ID созданных транзакций
    """
    # Получаем данные пользователя
    user_data = get_user(user_id)
    if not user_data:
        logger.error(f"Не удалось найти пользователя {user_id} для обработки реферальных вознаграждений")
        return []
    
    # Проверяем, есть ли у пользователя реферер
    referrer_id = user_data.get("referrer_id")
    if not referrer_id:
        logger.info(f"У пользователя {user_id} нет реферера, вознаграждения не начисляются")
        return []
    
    # Обрабатываем реферальные вознаграждения
    logger.info(f"Обработка реферальных вознаграждений для пользователя {user_id}, реферер: {referrer_id}")
    transaction_ids = process_referral_rewards(user_id, referrer_id)
    
    # Уведомляем реферера о полученном вознаграждении, если есть транзакции
    if transaction_ids:
        try:
            from telegram.bot import Bot
            import config
            
            # Получаем токен бота
            bot_token = config.TELEGRAM_TOKEN
            if not bot_token:
                logger.error("Bot token not found")
                return transaction_ids
            
            # Создаем экземпляр бота
            bot = Bot(token=bot_token)
            
            # Получаем сумму вознаграждения для первого уровня
            referrer_reward = get_user_pending_rewards(referrer_id)
            
            # Отправляем уведомление реферу
            await bot.send_message(
                chat_id=referrer_id,
                text=(
                    "🎉 *Поздравляем!*\n\n"
                    f"Ваш реферал активировал подписку!\n"
                    f"Вы получаете {referrer_reward:.2f}₽ вознаграждения.\n\n"
                    "Продолжайте приглашать друзей, чтобы зарабатывать больше!\n\n"
                    "Используйте команду /rewards, чтобы увидеть ваши вознаграждения."
                ),
                parse_mode='Markdown'
            )
            logger.info(f"Отправлено уведомление о вознаграждении реферу {referrer_id}")
            
        except Exception as e:
            logger.error(f"Ошибка отправки уведомления о вознаграждении: {e}")
    
    return transaction_ids

def get_handlers() -> Dict[str, Callable[[Update, ContextTypes.DEFAULT_TYPE], Awaitable[None]]]:
    """
    Получение словаря обработчиков для системы вознаграждений
    
    Returns:
        Dict: Словарь обработчиков {command_name: handler_function}
    """
    return {
        "rewards": rewards_command
    }