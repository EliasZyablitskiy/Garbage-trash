#!/usr/bin/env python3
"""
Скрипт для создания индексов в таблицах реферальной системы
"""
import os
import sys
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from new_referral_models import ReferralCode, ReferralRelation, ReferralReward

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def create_referral_indexes():
    """
    Создание индексов для оптимизации запросов к таблицам реферальной системы
    """
    # Инициализация Flask приложения
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db = SQLAlchemy(app)
    migrate = Migrate(app, db)
    
    # Создание контекста приложения
    with app.app_context():
        # Создаем новую миграцию для добавления индексов
        from alembic.config import Config
        from alembic import command
        from alembic.operations import Operations
        from alembic.migration import MigrationContext
        
        # Получаем соединение с базой данных
        connection = db.engine.connect()
        
        # Создаем контекст миграции
        context = MigrationContext.configure(connection)
        op = Operations(context)
        
        try:
            # Создание индекса для поля code в таблице referral_codes
            logger.info("Creating index on referral_codes.code")
            op.create_index('ix_referral_code_code', 'referral_codes', ['code'])
            
            # Создание составного индекса для user_id и level в таблице referral_relations
            logger.info("Creating composite index on referral_relations(user_id, level)")
            op.create_index('ix_referral_relation_user_id_level', 'referral_relations', ['user_id', 'level'])

            # Создание индекса для referrer_id в таблице referral_relations
            logger.info("Creating index on referral_relations.referrer_id")
            op.create_index('ix_referral_relation_referrer_id', 'referral_relations', ['referrer_id'])

            # Создание индекса для status в таблице referral_rewards
            logger.info("Creating index on referral_rewards.status")
            op.create_index('ix_referral_reward_status', 'referral_rewards', ['status'])
            
            # Создание составного индекса для улучшения поиска наград пользователей
            logger.info("Creating composite index for user rewards retrieval")
            op.create_index(
                'ix_referral_rewards_relations_user', 
                'referral_rewards', 
                ['status'], 
                postgresql_where="status = 'pending'"
            )
            
            logger.info("All indexes created successfully!")
        except Exception as e:
            logger.error(f"Error creating indexes: {e}")
            return False
    
    return True

def main():
    """
    Основная функция
    """
    logger.info("Starting referral indexes creation")
    success = create_referral_indexes()
    
    if success:
        logger.info("Referral indexes created successfully")
        sys.exit(0)
    else:
        logger.error("Failed to create referral indexes")
        sys.exit(1)

if __name__ == "__main__":
    main()