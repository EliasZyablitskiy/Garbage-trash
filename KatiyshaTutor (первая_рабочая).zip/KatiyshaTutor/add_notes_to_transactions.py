#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для добавления колонки notes в таблицу transactions
"""

import logging
import os
from sqlalchemy import create_engine, MetaData, Table, Column, JSON, text
from sqlalchemy.exc import SQLAlchemyError, ProgrammingError

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

# Database URL
DATABASE_URL = os.environ.get("DATABASE_URL")

def add_notes_column():
    """
    Добавляет колонку notes в таблицу transactions
    """
    if not DATABASE_URL:
        logger.error("DATABASE_URL не найден в переменных окружения")
        return False

    engine = create_engine(DATABASE_URL)
    metadata = MetaData()
    connection = engine.connect()

    try:
        # Проверим, существует ли колонка notes в таблице transactions
        try:
            query = text("SELECT column_name FROM information_schema.columns WHERE table_name = 'transactions' AND column_name = 'notes'")
            result = connection.execute(query)
            if result.fetchone():
                logger.info("Колонка notes уже существует в таблице transactions")
                return True
            else:
                logger.info("Колонка notes не найдена, добавляем...")
        except SQLAlchemyError as e:
            logger.error(f"Ошибка при проверке колонки notes: {e}")
            pass  # Продолжаем с добавлением в любом случае

        # Добавляем колонку notes
        query = text("""
        ALTER TABLE transactions
        ADD COLUMN IF NOT EXISTS notes JSONB;
        """)
        connection.execute(query)
        logger.info("Колонка notes успешно добавлена в таблицу transactions")
        return True

    except SQLAlchemyError as e:
        logger.error(f"Ошибка при добавлении колонки notes: {e}")
        return False
    finally:
        connection.close()
        engine.dispose()

def main():
    """
    Основная функция
    """
    logger.info("Запуск миграции для добавления колонки notes в таблицу transactions")
    success = add_notes_column()
    
    if success:
        logger.info("Миграция успешно завершена")
    else:
        logger.error("Миграция завершилась с ошибками")

if __name__ == "__main__":
    main()