#!/usr/bin/env python
# coding: utf-8

"""
Сервис индикации прогресса для долгих операций
Обеспечивает обновление сообщений в Telegram с индикатором прогресса
"""

import asyncio
import logging
import time
from datetime import datetime
from typing import Dict, Optional, Union, List, Tuple

# Настройка логирования
logger = logging.getLogger(__name__)

# Символы для анимации прогресса
PROGRESS_CHARS = ['⣾', '⣽', '⣻', '⢿', '⡿', '⣟', '⣯', '⣷']

# Шаблоны сообщений
PROGRESS_MESSAGE = "{animation} {operation}: {status}...\n{progress_bar} {percentage}%"
PROGRESS_BAR_LENGTH = 10  # Длина полосы прогресса в символах

# Словарь для хранения задач и их статусов
_progress_tasks: Dict[str, Dict] = {}
_message_locks: Dict[str, asyncio.Lock] = {}

async def start_progress_indicator(
    bot,
    chat_id: int,
    operation_name: str,
    task_id: Optional[str] = None,
    reply_to_message_id: Optional[int] = None
) -> Tuple[str, int]:
    """
    Запускает индикатор прогресса для долгой операции
    
    Args:
        bot: Экземпляр бота Telegram
        chat_id: ID чата для отправки сообщения
        operation_name: Название операции для отображения
        task_id: Уникальный идентификатор задачи (если None, будет сгенерирован)
        reply_to_message_id: ID сообщения, на которое нужно ответить
        
    Returns:
        Tuple[str, int]: Кортеж (ID задачи, ID сообщения с индикатором)
    """
    try:
        if task_id is None:
            task_id = f"{operation_name}_{int(time.time())}"
            
        # Создаем запись о задаче
        _progress_tasks[task_id] = {
            'operation': operation_name,
            'status': 'Начало работы',
            'progress': 0,
            'start_time': time.time(),
            'last_update': time.time(),
            'animation_index': 0,
            'is_complete': False
        }
        
        # Создаем блокировку для сообщения
        _message_locks[task_id] = asyncio.Lock()
        
        # Отправляем начальное сообщение
        message = await bot.send_message(
            chat_id=chat_id,
            text=_format_progress_message(task_id),
            reply_to_message_id=reply_to_message_id,
            parse_mode='Markdown'
        )
        
        # Сохраняем ID сообщения
        _progress_tasks[task_id]['message_id'] = message.message_id
        
        # Запускаем фоновую задачу для анимации
        asyncio.create_task(_animate_progress(bot, chat_id, task_id))
        
        logger.debug(f"Started progress indicator for task {task_id}")
        return task_id, message.message_id
    except Exception as e:
        logger.error(f"Error starting progress indicator: {e}")
        # Возвращаем псевдо-значения, чтобы код не сломался
        return task_id or f"error_{int(time.time())}", 0

async def update_progress(
    bot,
    chat_id: int,
    task_id: str,
    progress: Optional[float] = None,
    status: Optional[str] = None,
    is_complete: bool = False
) -> bool:
    """
    Обновляет индикатор прогресса
    
    Args:
        bot: Экземпляр бота Telegram
        chat_id: ID чата
        task_id: ID задачи
        progress: Прогресс (0-100)
        status: Статус текст
        is_complete: Флаг завершения
        
    Returns:
        bool: True если обновление успешно, False в противном случае
    """
    try:
        if task_id not in _progress_tasks:
            logger.warning(f"Task {task_id} not found for progress update")
            return False
            
        task = _progress_tasks[task_id]
        
        # Обновляем данные
        if progress is not None:
            task['progress'] = min(100, max(0, progress))  # Ограничиваем 0-100
        
        if status is not None:
            task['status'] = status
            
        task['last_update'] = time.time()
        task['is_complete'] = is_complete
        
        # Получаем ID сообщения
        message_id = task.get('message_id')
        if not message_id:
            logger.warning(f"Message ID not found for task {task_id}")
            return False
            
        # Обновляем сообщение, используя блокировку
        lock = _message_locks.get(task_id)
        if lock:
            async with lock:
                try:
                    await bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=message_id,
                        text=_format_progress_message(task_id),
                        parse_mode='Markdown'
                    )
                except Exception as e:
                    logger.warning(f"Error updating progress message: {e}")
        
        # Если задача завершена, очищаем данные через 10 секунд
        if is_complete:
            logger.debug(f"Task {task_id} marked as complete")
            asyncio.create_task(_cleanup_task(task_id, delay=10))
            
        return True
    except Exception as e:
        logger.error(f"Error updating progress: {e}")
        return False

async def complete_progress(
    bot,
    chat_id: int,
    task_id: str, 
    final_status: str = "Завершено",
    success: bool = True
) -> bool:
    """
    Завершает индикатор прогресса
    
    Args:
        bot: Экземпляр бота Telegram
        chat_id: ID чата
        task_id: ID задачи
        final_status: Итоговый статус
        success: Флаг успешного завершения
        
    Returns:
        bool: True если обновление успешно, False в противном случае
    """
    try:
        if task_id not in _progress_tasks:
            logger.warning(f"Task {task_id} not found for completion")
            return False
            
        # Финальное обновление
        emoji = "✅" if success else "❌"
        final_text = f"{emoji} *{_progress_tasks[task_id]['operation']}*: {final_status}"
        
        # Если задача не успешна, устанавливаем прогресс в текущее значение
        progress = 100 if success else _progress_tasks[task_id].get('progress', 0)
        
        # Обновляем сообщение последний раз
        result = await update_progress(
            bot=bot,
            chat_id=chat_id,
            task_id=task_id,
            progress=progress,
            status=final_status,
            is_complete=True
        )
        
        return result
    except Exception as e:
        logger.error(f"Error completing progress: {e}")
        return False

def _format_progress_message(task_id: str) -> str:
    """
    Форматирует сообщение о прогрессе
    
    Args:
        task_id: ID задачи
        
    Returns:
        str: Отформатированное сообщение
    """
    if task_id not in _progress_tasks:
        return "Задача не найдена"
        
    task = _progress_tasks[task_id]
    
    # Получаем текущий символ анимации
    animation_char = PROGRESS_CHARS[task['animation_index'] % len(PROGRESS_CHARS)]
    
    # Формируем полосу прогресса
    progress_percentage = task['progress']
    filled_length = int(PROGRESS_BAR_LENGTH * progress_percentage / 100)
    progress_bar = '█' * filled_length + '░' * (PROGRESS_BAR_LENGTH - filled_length)
    
    # Для завершенных задач меняем формат
    if task['is_complete']:
        icon = "✅" if progress_percentage == 100 else "❌"
        return f"{icon} *{task['operation']}*: {task['status']}"
    
    # Форматируем сообщение
    return PROGRESS_MESSAGE.format(
        animation=animation_char,
        operation=task['operation'],
        status=task['status'],
        progress_bar=progress_bar,
        percentage=int(progress_percentage)
    )

async def _animate_progress(bot, chat_id: int, task_id: str) -> None:
    """
    Анимирует индикатор прогресса
    
    Args:
        bot: Экземпляр бота Telegram
        chat_id: ID чата
        task_id: ID задачи
    """
    try:
        while task_id in _progress_tasks and not _progress_tasks[task_id]['is_complete']:
            # Обновляем индекс анимации
            if task_id in _progress_tasks:
                _progress_tasks[task_id]['animation_index'] += 1
                
                # Обновляем сообщение только если прошло достаточно времени с последнего обновления
                current_time = time.time()
                if current_time - _progress_tasks[task_id]['last_update'] >= 1.5:
                    lock = _message_locks.get(task_id)
                    if lock:
                        async with lock:
                            try:
                                message_id = _progress_tasks[task_id].get('message_id')
                                if message_id:
                                    await bot.edit_message_text(
                                        chat_id=chat_id,
                                        message_id=message_id,
                                        text=_format_progress_message(task_id),
                                        parse_mode='Markdown'
                                    )
                                    _progress_tasks[task_id]['last_update'] = current_time
                            except Exception as e:
                                logger.debug(f"Animation update failed: {e}")
            
            # Ждем перед следующим обновлением
            await asyncio.sleep(0.5)
    except Exception as e:
        logger.error(f"Error in progress animation: {e}")
    finally:
        logger.debug(f"Animation task for {task_id} stopped")

async def _cleanup_task(task_id: str, delay: int = 10) -> None:
    """
    Очищает данные о задаче после завершения
    
    Args:
        task_id: ID задачи
        delay: Задержка в секундах перед очисткой
    """
    try:
        # Ждем указанное время
        await asyncio.sleep(delay)
        
        # Удаляем данные о задаче
        if task_id in _progress_tasks:
            del _progress_tasks[task_id]
            
        # Удаляем блокировку
        if task_id in _message_locks:
            del _message_locks[task_id]
            
        logger.debug(f"Cleaned up task {task_id}")
    except Exception as e:
        logger.error(f"Error cleaning up task: {e}")