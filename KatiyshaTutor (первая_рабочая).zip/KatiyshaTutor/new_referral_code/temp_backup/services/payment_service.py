#!/usr/bin/env python
# coding: utf-8

"""
Service for handling payment processing
"""

import logging
import re
import datetime
from telegram import Update, LabeledPrice, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

import config
from database import get_user
from keyboards import get_main_keyboard

logger = logging.getLogger(__name__)

def is_valid_provider_token(token):
    """
    Проверяет, соответствует ли токен платежного провайдера необходимому формату
    
    Формат может быть:
    - 123456789:ЖИВОЙ_КЛЮЧ_ДЛЯ_ТЕСТИРОВАНИЯ
    - live_123456789:ЖИВОЙ_КЛЮЧ
    - test_123456789:ТЕСТОВЫЙ_КЛЮЧ
    
    Args:
        token: Токен платежного провайдера
        
    Returns:
        bool: True если формат токена правильный, иначе False
    """
    # Отключаем проверку формата токена - принимаем любой непустой токен
    return bool(token and len(token) > 10)

async def create_external_payment_link(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Create and send an external payment link for subscription using Robokassa iFrame
    
    Args:
        update: Telegram update object
        context: Telegram context object
    """
    # Получаем ID пользователя
    user_id = update.effective_user.id
    
    # Получаем BASE_URL из окружения (URL веб-сервера)
    base_url = config.get_base_url()
    
    # Формируем URL нашей страницы оплаты с iframe Robokassa
    payment_url = f"{base_url}/payment/{user_id}"
    
    # Создаем инлайн-клавиатуру с кнопкой для перехода на страницу оплаты
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("Оплатить 199₽", url=payment_url)]
    ])
    
    await update.effective_message.reply_text(
        "Для оплаты подписки нажмите на кнопку ниже. "
        "После успешной оплаты подписка должна активироваться автоматически.\n\n"
        "Если этого не произошло, отправьте команду /activate_subscription, "
        "чтобы активировать подписку вручную.",
        reply_markup=keyboard
    )
    
    logger.debug(f"Отправлена ссылка на оплату через iFrame пользователю {user_id} с URL: {payment_url}")
    
async def create_invoice(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Временно заменено на отправку сообщения о ручной активации подписки
    
    Args:
        update: Telegram update object
        context: Telegram context object
    """
    user_id = update.effective_user.id
    
    # Проверяем, есть ли уже подписка
    user_data = get_user(user_id)
    if user_data and 'subscription_expiry' in user_data and user_data['subscription_expiry']:
        try:
            expiry_date = datetime.datetime.fromisoformat(user_data['subscription_expiry'])
            if datetime.datetime.now() < expiry_date:
                await update.message.reply_text(
                    f"✅ У вас уже есть активная подписка до {expiry_date.strftime('%d.%m.%Y')}.",
                    reply_markup=get_main_keyboard()
                )
                return
        except:
            pass
    
    # Отправляем сообщение о ручной активации
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("Активировать подписку", callback_data="manual_activate")]
    ])
    
    await update.effective_message.reply_text(
        "🔐 *Система оплаты* 🔐\n\n"
        "Для продолжения работы с ботом нажмите кнопку ниже, чтобы активировать подписку на 1 месяц. "
        "Стоимость 199₽.\n\n"
        "Нажимая кнопку, вы подтверждаете, что провели оплату и хотите активировать подписку.",
        reply_markup=keyboard,
        parse_mode='Markdown'
    )
    
    logger.debug(f"Отправлено предложение по ручной активации подписки пользователю {user_id}")
