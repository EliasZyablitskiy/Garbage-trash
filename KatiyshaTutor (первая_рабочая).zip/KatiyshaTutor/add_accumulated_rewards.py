#!/usr/bin/env python
# coding: utf-8

"""
Скрипт миграции для добавления поля накопленных реферальных вознаграждений
"""

import os
import sys
import logging
from datetime import datetime

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from sqlalchemy import Column, Float, BigInteger, text

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Инициализация Flask и SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Определение моделей для миграции
class User(db.Model):
    __tablename__ = 'users'
    id = Column(BigInteger, primary_key=True)
    
class AccumulatedReward(db.Model):
    """Модель для отслеживания накопленных малых вознаграждений до порога выплаты"""
    __tablename__ = 'accumulated_rewards'
    
    id = Column(BigInteger, primary_key=True)
    user_id = Column(BigInteger, db.ForeignKey('users.id'), nullable=False)
    amount = Column(Float, default=0.0, nullable=False)
    last_updated = Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
def run_migration():
    """Выполнение миграции"""
    try:
        with app.app_context():
            # Проверка существования таблицы
            inspector = db.inspect(db.engine)
            if 'accumulated_rewards' not in inspector.get_table_names():
                logger.info("Создаем таблицу accumulated_rewards")
                db.create_all()
                logger.info("Таблица accumulated_rewards успешно создана")
            else:
                logger.info("Таблица accumulated_rewards уже существует")
                
            # Проверка наличия колонки в таблице users
            users_columns = [c['name'] for c in inspector.get_columns('users')]
            
            # Если колонки нет, то добавляем ее
            if 'accumulated_amount' not in users_columns:
                logger.info("Добавляем колонку accumulated_amount в таблицу users")
                with db.engine.connect() as connection:
                    connection.execute(text('ALTER TABLE users ADD COLUMN accumulated_amount FLOAT DEFAULT 0.0'))
                logger.info("Колонка accumulated_amount успешно добавлена")
            else:
                logger.info("Колонка accumulated_amount уже существует в таблице users")
                
            logger.info("Миграция успешно завершена")
            return True
    except Exception as e:
        logger.error(f"Ошибка при выполнении миграции: {e}")
        return False

if __name__ == "__main__":
    if run_migration():
        sys.exit(0)
    else:
        sys.exit(1)