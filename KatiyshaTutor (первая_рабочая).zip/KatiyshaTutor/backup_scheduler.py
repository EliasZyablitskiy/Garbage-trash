#!/usr/bin/env python3
"""
Скрипт для планирования автоматических резервных копий базы данных
"""
import os
import sys
import time
import logging
import subprocess
import datetime
from typing import Optional
import schedule

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('scheduler.log')
    ]
)
logger = logging.getLogger(__name__)

def perform_backup(schema_only: bool = False, timeout: Optional[int] = None) -> bool:
    """
    Запуск процесса создания резервной копии
    
    Args:
        schema_only: Создать бэкап только схемы (без данных)
        timeout: Таймаут в секундах (по умолчанию None - без таймаута)
    
    Returns:
        bool: True в случае успеха, False в случае ошибки
    """
    try:
        # Формируем команду
        cmd = ["python", "backup_database.py"]
        if schema_only:
            cmd.append("--schema-only")
            
        # Запускаем скрипт создания бэкапа
        logger.info(f"Запуск создания резервной копии (режим: {'только схема' if schema_only else 'полный'})...")
        
        # Запускаем процесс в фоновом режиме
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=os.environ.copy()
        )
        
        if timeout is not None:
            try:
                stdout, stderr = process.communicate(timeout=timeout)
                
                # Проверяем результат выполнения
                if process.returncode != 0:
                    logger.error(f"Ошибка при создании резервной копии: {stderr.decode()}")
                    return False
                
                logger.info("Резервная копия успешно создана")
                if stdout:
                    logger.debug(f"Вывод скрипта: {stdout.decode()}")
                
                return True
            except subprocess.TimeoutExpired:
                logger.warning(f"Процесс создания резервной копии превысил таймаут {timeout} секунд")
                logger.warning("Процесс продолжает выполняться в фоновом режиме")
                # Не убиваем процесс, чтобы он мог завершиться нормально
                return True
        else:
            # Без таймаута - ждем завершения
            stdout, stderr = process.communicate()
            
            # Проверяем результат выполнения
            if process.returncode != 0:
                logger.error(f"Ошибка при создании резервной копии: {stderr.decode()}")
                return False
            
            logger.info("Резервная копия успешно создана")
            if stdout:
                logger.debug(f"Вывод скрипта: {stdout.decode()}")
            
            return True
    except Exception as e:
        logger.error(f"Ошибка при запуске процесса создания резервной копии: {e}")
        return False

def run_scheduler() -> None:
    """
    Запуск планировщика задач
    """
    logger.info("Запуск планировщика резервного копирования...")
    
    # Таймауты для разных типов бэкапов
    SCHEMA_TIMEOUT = 300  # 5 минут для резервного копирования схемы
    FULL_TIMEOUT = 600    # 10 минут для полного резервного копирования
    
    # Настройка расписания
    # Ежедневное резервное копирование только схемы в 03:00
    schedule.every().day.at("03:00").do(perform_backup, schema_only=True, timeout=SCHEMA_TIMEOUT)
    logger.info(f"Запланировано ежедневное резервное копирование схемы в 03:00 (таймаут: {SCHEMA_TIMEOUT}с)")
    
    # Еженедельное полное резервное копирование (схема + данные) в понедельник в 02:00
    schedule.every().monday.at("02:00").do(perform_backup, schema_only=False, timeout=FULL_TIMEOUT)
    logger.info(f"Запланировано еженедельное полное резервное копирование в понедельник в 02:00 (таймаут: {FULL_TIMEOUT}с)")
    
    # Полумесячное полное резервное копирование 15-го числа каждого месяца
    schedule.every().day.at("01:00").do(
        lambda: perform_backup(schema_only=False, timeout=FULL_TIMEOUT) if datetime.datetime.now().day == 15 else None
    )
    logger.info(f"Запланировано полумесячное полное резервное копирование 15-го числа в 01:00 (таймаут: {FULL_TIMEOUT}с)")
    
    # Выводим информацию о ближайших запланированных задачах
    next_run = schedule.next_run()
    logger.info(f"Следующее резервное копирование: {next_run}")
    
    logger.info("Планировщик запущен")
    
    try:
        # Выполняем первое резервное копирование сразу при запуске (только схема для скорости)
        logger.info("Выполнение начального резервного копирования (только схема)...")
        perform_backup(schema_only=True, timeout=SCHEMA_TIMEOUT)
        
        # Бесконечный цикл для выполнения задач по расписанию
        while True:
            schedule.run_pending()
            time.sleep(60)  # Проверяем задачи каждую минуту
    except KeyboardInterrupt:
        logger.info("Планировщик остановлен пользователем")
    except Exception as e:
        logger.error(f"Ошибка в планировщике: {e}")

def main() -> None:
    """
    Основная функция
    """
    import argparse
    
    # Парсинг аргументов командной строки
    parser = argparse.ArgumentParser(description='Планировщик резервного копирования базы данных')
    parser.add_argument('--schema-only', action='store_true', help='Создать бэкап только схемы (без данных)')
    parser.add_argument('action', nargs='?', default='schedule', choices=['now', 'schedule'], 
                      help='Действие: now - создать бэкап сейчас, schedule - запустить планировщик')
    
    args = parser.parse_args()
    
    # Выполнение действия согласно аргументам
    if args.action == 'now':
        logger.info(f"Запуск разового резервного копирования (режим: {'только схема' if args.schema_only else 'полный'})...")
        perform_backup(schema_only=args.schema_only)
    elif args.action == 'schedule':
        logger.info(f"Запуск планировщика резервного копирования (режим: {'по умолчанию включает полные и схемные бэкапы'})...")
        run_scheduler()
    else:
        logger.error(f"Неизвестное действие: {args.action}")
        parser.print_help()

if __name__ == "__main__":
    main()