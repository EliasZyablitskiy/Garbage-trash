#!/usr/bin/env python
# coding: utf-8

"""
Расширенные обработчики административных команд для анти-фрод системы и расширенной отчетности
"""

import logging
import datetime
import io
import json
from typing import Dict, Any, List, Optional, Set, Tuple, Union
from sqlalchemy import select

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputFile
from telegram.ext import ContextTypes

import config
from db_models import db, User, Transaction, BatchPayout, AdminActionLog, FraudDetectionLog
from config import ADMIN_IDS

# Подключаем базовые административные функции
from admin_handlers import admin_back_callback, is_admin, log_admin_action

# Импортируем сервисы для работы с анти-фрод системой и мониторингом
from services.db_transaction_service import DBSessionManager
from services.payout_monitoring_service import PayoutMonitoringService, ReportFormat, get_monitoring_service
from services.antifraud_service import get_antifraud_service, FraudRiskLevel

logger = logging.getLogger(__name__)

# Функции для анти-фрод системы

async def admin_antifraud_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для анти-фрод системы
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Формируем меню анти-фрод системы
    keyboard = [
        [InlineKeyboardButton("🔍 Пользователи с высоким риском", callback_data="admin_high_risk_users")],
        [InlineKeyboardButton("📊 Статистика обнаружения мошенничества", callback_data="admin_fraud_stats")],
        [InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]
    ]
    
    await query.edit_message_text(
        "⚠️ *Анти-фрод система*\n\n"
        "Система мониторинга и предотвращения мошенничества позволяет обнаруживать подозрительную активность "
        "в реферальной системе и предпринимать меры для защиты от злоупотреблений.\n\n"
        "Выберите действие из меню ниже:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def admin_high_risk_users_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения пользователей с высоким риском мошенничества
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Сообщение о загрузке
    progress_message = await query.edit_message_text(
        "⏳ *Анализ пользователей...*\n\n"
        "Выполняется поиск пользователей с высоким риском мошенничества. Это может занять некоторое время.",
        parse_mode='Markdown'
    )
    
    try:
        # Получаем пользователей с высоким риском
        async with DBSessionManager() as session:
            # Логируем действие администратора
            await log_admin_action(
                session=session,
                admin_id=query.from_user.id,
                action_type="view_high_risk_users",
                details={"timestamp": datetime.datetime.now().isoformat()}
            )
            
            antifraud_service = await get_antifraud_service()
            high_risk_users = await antifraud_service.get_high_risk_users(session, min_risk_score=0.7)
            
            if not high_risk_users:
                await progress_message.edit_text(
                    "🔍 *Результаты проверки*\n\n"
                    "Пользователей с высоким риском мошенничества не обнаружено.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("◀️ Назад к анти-фрод системе", callback_data="admin_antifraud")]
                    ]),
                    parse_mode='Markdown'
                )
                return
            
            # Формируем сообщение
            message = (
                "⚠️ *Пользователи с высоким риском мошенничества*\n\n"
                f"Найдено пользователей: {len(high_risk_users)}\n\n"
            )
            
            # Добавляем информацию о пользователях (топ 10)
            for i, user_data in enumerate(high_risk_users[:10], 1):
                user_id = user_data["user_id"]
                fraud_score = user_data["fraud_score"]
                risk_level = user_data["risk_level"]
                
                # Эмодзи для разных уровней риска
                risk_emoji = {
                    "low": "🟢",
                    "medium": "🟡",
                    "high": "🟠",
                    "critical": "🔴"
                }.get(risk_level, "⚠️")
                
                triggered_rules = len(user_data["rules_triggered"])
                
                message += (
                    f"{risk_emoji} *Пользователь #{i}*\n"
                    f"ID: {user_id}\n"
                    f"Оценка риска: {fraud_score:.2f}\n"
                    f"Уровень риска: {risk_level}\n"
                    f"Сработало правил: {triggered_rules}\n\n"
                )
            
            if len(high_risk_users) > 10:
                message += f"... и еще {len(high_risk_users) - 10} пользователей"
            
            # Добавляем кнопки
            keyboard = [
                [InlineKeyboardButton("◀️ Назад к анти-фрод системе", callback_data="admin_antifraud")]
            ]
            
            await progress_message.edit_text(
                message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='Markdown'
            )
    
    except Exception as e:
        logger.error(f"Error getting high risk users: {e}")
        await progress_message.edit_text(
            "❌ *Произошла ошибка при получении данных*\n\n"
            f"Детали ошибки: {str(e)}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад к анти-фрод системе", callback_data="admin_antifraud")]
            ]),
            parse_mode='Markdown'
        )

async def admin_fraud_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения статистики обнаружения мошенничества
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Сообщение о загрузке
    progress_message = await query.edit_message_text(
        "⏳ *Загрузка статистики...*\n\n"
        "Выполняется сбор данных о работе анти-фрод системы.",
        parse_mode='Markdown'
    )
    
    try:
        # Получаем статистику обнаружения мошенничества
        async with DBSessionManager() as session:
            # Логируем действие администратора
            await log_admin_action(
                session=session,
                admin_id=query.from_user.id,
                action_type="view_fraud_stats",
                details={"timestamp": datetime.datetime.now().isoformat()}
            )
            
            antifraud_service = await get_antifraud_service()
            fraud_stats = await antifraud_service.get_fraud_statistics(session)
            
            # Формируем сообщение
            message = (
                "📊 *Статистика обнаружения мошенничества*\n\n"
                f"🚫 Заблокировано транзакций: {fraud_stats['total_blocked_transactions']}\n"
                f"⚠️ Предупреждений: {fraud_stats['total_warnings']}\n\n"
                "*Топ сработавших правил:*\n"
            )
            
            # Добавляем информацию о правилах
            for i, rule in enumerate(fraud_stats["top_rules"][:5], 1):
                rule_name = rule["rule_name"].replace("_", " ").title()
                rule_type = rule["rule_type"]
                risk_level = rule["risk_level"]
                
                # Эмодзи для разных уровней риска
                risk_emoji = {
                    "low": "🟢",
                    "medium": "🟡",
                    "high": "🟠",
                    "critical": "🔴"
                }.get(risk_level, "⚠️")
                
                message += f"{i}. {risk_emoji} {rule_name} ({rule_type})\n"
            
            # Добавляем статистику по дням
            message += "\n*Активность по дням:*\n"
            for day_stat in fraud_stats["daily_stats"][-5:]:  # Последние 5 дней
                date = datetime.datetime.fromisoformat(day_stat["date"]).strftime("%d.%m")
                count = day_stat["count"]
                message += f"{date}: {count} срабатываний\n"
            
            # Добавляем кнопки
            keyboard = [
                [InlineKeyboardButton("◀️ Назад к анти-фрод системе", callback_data="admin_antifraud")]
            ]
            
            await progress_message.edit_text(
                message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='Markdown'
            )
    
    except Exception as e:
        logger.error(f"Error getting fraud statistics: {e}")
        await progress_message.edit_text(
            "❌ *Произошла ошибка при получении статистики*\n\n"
            f"Детали ошибки: {str(e)}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад к анти-фрод системе", callback_data="admin_antifraud")]
            ]),
            parse_mode='Markdown'
        )

# Функции для расширенной отчетности

async def admin_advanced_reports_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для расширенной отчетности
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Формируем меню расширенной отчетности
    keyboard = [
        [InlineKeyboardButton("📊 Статистика по выплатам", callback_data="admin_payout_stats")],
        [InlineKeyboardButton("📈 Данные дашборда", callback_data="admin_dashboard_data")],
        [InlineKeyboardButton("👤 Экспорт данных пользователя", callback_data="admin_export_user_data")],
        [InlineKeyboardButton("📄 Отчет по выплате", callback_data="admin_payout_report")],
        [InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]
    ]
    
    await query.edit_message_text(
        "📈 *Расширенная отчетность*\n\n"
        "Система расширенной отчетности позволяет получать детальную информацию о работе реферальной программы, "
        "выплатах и пользователях.\n\n"
        "Выберите тип отчета из меню ниже:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def admin_payout_report_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отчета по выплате
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Получаем ID выплаты из контекста или запрашиваем у пользователя
    payout_id = context.user_data.get("payout_id") if context and context.user_data else None
    
    if not payout_id:
        # Получаем список последних выплат
        async with DBSessionManager() as session:
            # Используем существующую функцию для получения списка выплат
            from admin_handlers import get_weekly_payouts
            payouts = get_weekly_payouts()
            
            if not payouts:
                await query.edit_message_text(
                    "🔍 Нет созданных выплат для формирования отчета.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("◀️ Назад к расширенной отчетности", callback_data="admin_advanced_reports")]
                    ])
                )
                return
            
            # Сортируем выплаты по дате создания (новые первыми)
            sorted_payouts = sorted(
                payouts,
                key=lambda x: x["created_at"],
                reverse=True
            )[:5]  # Показываем только 5 последних
            
            message = "📄 *Выберите выплату для формирования отчета*\n\n"
            
            # Формируем список выплат с кнопками
            keyboard = []
            for payout in sorted_payouts:
                status_emoji = {
                    "pending": "⏳",
                    "processing": "🔄",
                    "completed": "✅",
                    "failed": "❌"
                }.get(payout["status"], "❓")
                
                created_at = datetime.datetime.fromisoformat(payout["created_at"]).strftime("%d.%m.%Y")
                button_text = f"{status_emoji} Выплата #{payout['id']} ({created_at})"
                
                keyboard.append([InlineKeyboardButton(
                    button_text, 
                    callback_data=f"admin_payout_report:{payout['id']}"
                )])
            
            keyboard.append([InlineKeyboardButton("◀️ Назад к расширенной отчетности", callback_data="admin_advanced_reports")])
            
            await query.edit_message_text(
                message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='Markdown'
            )
            return
    
    # Если ID выплаты уже известен, формируем отчет
    try:
        # Сообщение о загрузке
        progress_message = await query.edit_message_text(
            "⏳ *Формирование отчета...*\n\n"
            "Выполняется сбор данных и формирование отчета по выплате. Это может занять некоторое время.",
            parse_mode='Markdown'
        )
        
        async with DBSessionManager() as session:
            # Логируем действие администратора
            await log_admin_action(
                session=session,
                admin_id=query.from_user.id,
                action_type="generate_payout_report",
                details={
                    "payout_id": payout_id,
                    "timestamp": datetime.datetime.now().isoformat()
                }
            )
            
            # Получаем отчет в различных форматах
            monitoring_service = await get_monitoring_service()
            
            # Получаем краткую информацию о выплате для сообщения
            from admin_handlers import get_weekly_payouts
            payouts = get_weekly_payouts()
            payout_info = next((p for p in payouts if p["id"] == payout_id), None)
            
            if not payout_info:
                await progress_message.edit_text(
                    "❌ *Произошла ошибка при получении данных*\n\n"
                    f"Выплата с ID {payout_id} не найдена.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("◀️ Назад к расширенной отчетности", callback_data="admin_advanced_reports")]
                    ]),
                    parse_mode='Markdown'
                )
                return
            
            # Формируем отчеты в разных форматах и отправляем их
            formats = {
                "JSON": ReportFormat.JSON,
                "CSV": ReportFormat.CSV,
                "HTML": ReportFormat.HTML
            }
            
            # Начинаем с текстового отчета в сообщении
            mime_type, content = await monitoring_service.get_payout_report(
                session=session,
                payout_id=payout_id,
                format=ReportFormat.TEXT
            )
            
            text_report = content.decode('utf-8')
            
            # Ограничиваем размер отчета для сообщения
            if len(text_report) > 3000:
                text_report = text_report[:3000] + "\n\n... (отчет слишком большой, полная версия доступна в файлах)"
            
            # Формируем сообщение с кратким отчетом
            status_emoji = {
                "pending": "⏳",
                "processing": "🔄",
                "completed": "✅",
                "failed": "❌"
            }.get(payout_info["status"], "❓")
            
            message = (
                f"📄 *Отчет по выплате #{payout_id}*\n\n"
                f"Статус: {status_emoji} {payout_info['status']}\n"
                f"Сумма: {payout_info['total_amount']}₽\n"
                f"Пользователей: {payout_info['total_users']}\n\n"
                f"{text_report}"
            )
            
            # Отправляем файлы отчетов
            for format_name, format_enum in formats.items():
                mime_type, content = await monitoring_service.get_payout_report(
                    session=session,
                    payout_id=payout_id,
                    format=format_enum
                )
                
                file_extension = mime_type.split('/')[-1]
                file_name = f"payout_report_{payout_id}.{file_extension}"
                
                # Отправляем файл отчета
                await context.bot.send_document(
                    chat_id=query.message.chat_id,
                    document=InputFile(io.BytesIO(content), filename=file_name),
                    caption=f"Отчет по выплате #{payout_id} ({format_name})"
                )
            
            # Отображаем сообщение с кратким отчетом и кнопкой возврата
            await progress_message.edit_text(
                message,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("◀️ Назад к расширенной отчетности", callback_data="admin_advanced_reports")]
                ]),
                parse_mode='Markdown'
            )
    
    except Exception as e:
        logger.error(f"Error generating payout report: {e}")
        await query.edit_message_text(
            "❌ *Произошла ошибка при формировании отчета*\n\n"
            f"Детали ошибки: {str(e)}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад к расширенной отчетности", callback_data="admin_advanced_reports")]
            ]),
            parse_mode='Markdown'
        )

async def admin_dashboard_data_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для данных дашборда
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Сообщение о загрузке
    progress_message = await query.edit_message_text(
        "⏳ *Загрузка данных дашборда...*\n\n"
        "Выполняется сбор статистики за последние 30 дней.",
        parse_mode='Markdown'
    )
    
    try:
        async with DBSessionManager() as session:
            # Логируем действие администратора
            await log_admin_action(
                session=session,
                admin_id=query.from_user.id,
                action_type="view_dashboard_data",
                details={"timestamp": datetime.datetime.now().isoformat()}
            )
            
            # Получаем данные дашборда
            monitoring_service = await get_monitoring_service()
            dashboard_data = await monitoring_service.get_referral_dashboard_data(session, period_days=30)
            
            # Формируем сообщение
            summary = dashboard_data["summary"]
            message = (
                "📊 *Данные дашборда реферальной программы*\n\n"
                "*Сводная статистика:*\n"
                f"👥 Всего пользователей: {summary['total_users']}\n"
                f"👨‍👩‍👧‍👦 Всего рефералов: {summary['total_referrals']}\n"
                f"💳 Всего подписчиков: {summary['total_subscribers']}\n\n"
                
                f"*За последние 30 дней:*\n"
                f"🆕 Новых пользователей: {summary['new_users']}\n"
                f"👪 Новых рефералов: {summary['new_referrals']}\n"
                f"💰 Начислено вознаграждений: {summary['period_rewards']:.2f}₽\n"
                f"💵 Доход от подписок: {summary['period_revenue']:.2f}₽\n\n"
                
                f"*Общая статистика:*\n"
                f"💰 Всего начислено вознаграждений: {summary['total_rewards']:.2f}₽\n"
                f"💵 Общий доход от подписок: {summary['total_revenue']:.2f}₽\n"
                f"📈 Процент выплат от дохода: {summary['reward_ratio']:.2f}%\n\n"
                
                "*Топ рефереры:*\n"
            )
            
            # Добавляем информацию о топ реферерах
            for i, referrer in enumerate(dashboard_data["top_referrers"][:5], 1):
                user_id = referrer["user_id"]
                referral_count = referrer["referral_count"]
                message += f"{i}. ID: {user_id} - {referral_count} рефералов\n"
            
            # Добавляем кнопки
            keyboard = [
                [InlineKeyboardButton("📄 Скачать полный отчет (JSON)", callback_data="admin_dashboard_data_json")],
                [InlineKeyboardButton("◀️ Назад к расширенной отчетности", callback_data="admin_advanced_reports")]
            ]
            
            await progress_message.edit_text(
                message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='Markdown'
            )
            
            # Сохраняем данные в контексте для возможности скачивания полного отчета
            if context and context.user_data:
                context.user_data["dashboard_data"] = dashboard_data
    
    except Exception as e:
        logger.error(f"Error getting dashboard data: {e}")
        await progress_message.edit_text(
            "❌ *Произошла ошибка при получении данных дашборда*\n\n"
            f"Детали ошибки: {str(e)}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад к расширенной отчетности", callback_data="admin_advanced_reports")]
            ]),
            parse_mode='Markdown'
        )

async def admin_export_user_data_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для экспорта данных пользователя
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Запрашиваем ID пользователя для экспорта данных
    await query.edit_message_text(
        "👤 *Экспорт данных пользователя*\n\n"
        "Введите ID пользователя, данные которого необходимо экспортировать.\n\n"
        "Пример: /export_user 123456789",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("◀️ Назад к расширенной отчетности", callback_data="admin_advanced_reports")]
        ]),
        parse_mode='Markdown'
    )
    
    # Устанавливаем состояние для ожидания ввода ID пользователя
    if context and context.user_data:
        context.user_data["waiting_for_user_id"] = True

# Дополнительный обработчик для экспорта данных пользователя после ввода ID
async def process_export_user_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик команды /export_user для экспорта данных пользователя
    
    Args:
        update: Update object from telegram
        context: Context object from telegram
    """
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔️ У вас нет прав администратора.")
        return
    
    # Извлекаем ID пользователя из команды
    message_text = update.message.text.strip()
    parts = message_text.split()
    
    if len(parts) != 2 or not parts[1].isdigit():
        await update.message.reply_text(
            "❌ *Неверный формат команды*\n\n"
            "Используйте формат: /export_user ID\n"
            "Пример: /export_user 123456789",
            parse_mode='Markdown'
        )
        return
    
    user_id = int(parts[1])
    
    # Сообщение о загрузке
    progress_message = await update.message.reply_text(
        "⏳ *Экспорт данных пользователя...*\n\n"
        f"Выполняется сбор и экспорт данных пользователя с ID {user_id}. Это может занять некоторое время.",
        parse_mode='Markdown'
    )
    
    try:
        async with DBSessionManager() as session:
            # Логируем действие администратора
            await log_admin_action(
                session=session,
                admin_id=update.effective_user.id,
                action_type="export_user_data",
                details={
                    "user_id": user_id,
                    "timestamp": datetime.datetime.now().isoformat()
                }
            )
            
            # Проверяем существование пользователя
            result = await session.execute(
                select(User).where(User.id == user_id)
            )
            user = result.scalars().first()
            
            if not user:
                await progress_message.edit_text(
                    "❌ *Пользователь не найден*\n\n"
                    f"Пользователь с ID {user_id} не найден в базе данных.",
                    parse_mode='Markdown'
                )
                return
            
            # Получаем данные пользователя в различных форматах
            monitoring_service = await get_monitoring_service()
            
            # Формируем отчеты в разных форматах и отправляем их
            formats = {
                "JSON": ReportFormat.JSON,
                "CSV": ReportFormat.CSV,
                "HTML": ReportFormat.HTML
            }
            
            # Начинаем с текстового отчета в сообщении
            mime_type, content = await monitoring_service.export_user_data(
                session=session,
                user_id=user_id,
                format=ReportFormat.TEXT
            )
            
            text_report = content.decode('utf-8')
            
            # Ограничиваем размер отчета для сообщения
            if len(text_report) > 3000:
                text_report = text_report[:3000] + "\n\n... (отчет слишком большой, полная версия доступна в файлах)"
            
            # Отправляем сообщение с кратким отчетом
            await progress_message.edit_text(
                f"👤 *Данные пользователя с ID {user_id}*\n\n{text_report}",
                parse_mode='Markdown'
            )
            
            # Отправляем файлы отчетов
            for format_name, format_enum in formats.items():
                mime_type, content = await monitoring_service.export_user_data(
                    session=session,
                    user_id=user_id,
                    format=format_enum
                )
                
                file_extension = mime_type.split('/')[-1]
                file_name = f"user_data_{user_id}.{file_extension}"
                
                # Отправляем файл отчета
                await context.bot.send_document(
                    chat_id=update.effective_chat.id,
                    document=InputFile(io.BytesIO(content), filename=file_name),
                    caption=f"Данные пользователя {user_id} ({format_name})"
                )
    
    except Exception as e:
        logger.error(f"Error exporting user data: {e}")
        await progress_message.edit_text(
            "❌ *Произошла ошибка при экспорте данных пользователя*\n\n"
            f"Детали ошибки: {str(e)}",
            parse_mode='Markdown'
        )

# Дополнительный обработчик для динамического callback_data
async def dynamic_antifraud_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Динамический обработчик для колбэков с параметрами
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    callback_data = query.data
    
    # Обработка запроса отчета по выплате с указанным ID
    if callback_data.startswith("admin_payout_report:"):
        payout_id = int(callback_data.split(":")[1])
        
        # Сохраняем ID выплаты в контексте
        if context and context.user_data:
            context.user_data["payout_id"] = payout_id
        
        # Вызываем обработчик отчета по выплате
        await admin_payout_report_callback(update, context)
        return
    
    # Обработка запроса JSON-данных дашборда
    if callback_data == "admin_dashboard_data_json":
        if context and context.user_data and "dashboard_data" in context.user_data:
            dashboard_data = context.user_data["dashboard_data"]
            
            # Отправляем файл с данными дашборда
            json_data = json.dumps(dashboard_data, ensure_ascii=False, indent=2).encode('utf-8')
            
            await context.bot.send_document(
                chat_id=query.message.chat_id,
                document=InputFile(io.BytesIO(json_data), filename="dashboard_data.json"),
                caption="Полные данные дашборда реферальной программы (JSON)"
            )
            
            await query.edit_message_text(
                "📄 *Данные дашборда успешно экспортированы*\n\n"
                "Полные данные дашборда были отправлены в виде JSON-файла.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("◀️ Назад к расширенной отчетности", callback_data="admin_advanced_reports")]
                ]),
                parse_mode='Markdown'
            )
        else:
            await query.edit_message_text(
                "❌ *Данные дашборда не найдены*\n\n"
                "Необходимо сначала загрузить данные дашборда.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("📊 Загрузить данные дашборда", callback_data="admin_dashboard_data")],
                    [InlineKeyboardButton("◀️ Назад к расширенной отчетности", callback_data="admin_advanced_reports")]
                ]),
                parse_mode='Markdown'
            )
        return
    
    # Если колбэк не обработан, возвращаемся в админ-меню
    await admin_back_callback(update, context)

# Получение словаря с новыми обработчиками для регистрации
def get_antifraud_admin_handlers() -> Dict[str, callable]:
    """
    Получение словаря обработчиков для анти-фрод системы и расширенной отчетности
    
    Returns:
        Dict: Словарь обработчиков {callback_data: handler_function}
    """
    # Создаем словарь обработчиков для антифрод-системы
    handlers = {
        "admin_antifraud": admin_antifraud_callback,
        "admin_high_risk_users": admin_high_risk_users_callback,
        "admin_fraud_stats": admin_fraud_stats_callback,
        "admin_advanced_reports": admin_advanced_reports_callback,
        "admin_payout_report": admin_payout_report_callback,
        "admin_dashboard_data": admin_dashboard_data_callback,
        "admin_export_user_data": admin_export_user_data_callback
    }
    
    return handlers

# Получение словаря с командами для регистрации
def get_antifraud_admin_commands() -> Dict[str, callable]:
    """
    Получение словаря команд для анти-фрод системы и расширенной отчетности
    
    Returns:
        Dict: Словарь команд {command: handler_function}
    """
    commands = {
        "export_user": process_export_user_command
    }
    
    return commands

# Получение словаря с динамическими обработчиками
def get_antifraud_dynamic_handlers() -> Dict[str, callable]:
    """
    Получение словаря динамических обработчиков для анти-фрод системы и расширенной отчетности
    
    Returns:
        Dict: Словарь обработчиков {prefix: handler_function}
    """
    # Регистрируем динамические обработчики антифрод-системы
    handlers = {
        "admin_payout_report:": dynamic_antifraud_handler,
        "admin_dashboard_data_json": dynamic_antifraud_handler
    }
    
    return handlers