#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для очистки старых файлов реферальной системы,
которые больше не используются после миграции на PostgreSQL
"""

import os
import shutil
import logging

# Настраиваем логирование
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('cleanup.log')
    ]
)

logger = logging.getLogger('cleanup')

def cleanup_files():
    """
    Удаляет файлы, связанные со старой реферальной системой
    """
    # Список файлов для удаления
    files_to_remove = [
        'referral_manager.py',
        'referral_handlers.py',
        'initialize_referrals.py',
        'test_referral.py',
    ]
    
    # Список файлов для сохранения в архивной папке
    files_to_archive = [
        'migrate_referral_to_postgres.py',
        'migrate_referrals.py',
        'fix_referral_ids.py',
        'test_referral_migration.py'
    ]
    
    # Создаем архивную папку, если её нет
    archive_folder = 'referral_migration_archive'
    if not os.path.exists(archive_folder):
        os.makedirs(archive_folder)
    
    # Удаляем файлы
    for file_name in files_to_remove:
        if os.path.exists(file_name):
            try:
                os.remove(file_name)
                logger.info(f"Удален файл: {file_name}")
            except Exception as e:
                logger.error(f"Ошибка при удалении файла {file_name}: {e}")
    
    # Перемещаем файлы в архив
    for file_name in files_to_archive:
        if os.path.exists(file_name):
            try:
                shutil.move(file_name, os.path.join(archive_folder, file_name))
                logger.info(f"Файл перемещен в архив: {file_name}")
            except Exception as e:
                logger.error(f"Ошибка при перемещении файла {file_name} в архив: {e}")
    
    logger.info("Очистка успешно завершена")
    return True

if __name__ == "__main__":
    logger.info("Начало удаления старых файлов реферальной системы")
    cleanup_files()