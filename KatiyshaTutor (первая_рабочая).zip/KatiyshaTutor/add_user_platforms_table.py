#!/usr/bin/env python
# coding: utf-8

"""
Скрипт миграции для добавления таблицы user_platforms в базу данных
"""

import logging
import os
import sys
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, DateTime, Text, inspect
from sqlalchemy.exc import SQLAlchemyError
from datetime import datetime

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

# Database URL
DATABASE_URL = os.environ.get("DATABASE_URL")

def create_user_platforms_table():
    """
    Создает таблицу user_platforms для хранения информации о платформах пользователей
    """
    if not DATABASE_URL:
        logger.error("DATABASE_URL не найден в переменных окружения")
        return False

    engine = create_engine(DATABASE_URL)
    metadata = MetaData()
    inspector = inspect(engine)
    
    # Проверяем, существует ли уже таблица user_platforms
    if 'user_platforms' in inspector.get_table_names():
        logger.info("Таблица user_platforms уже существует")
        return True
    
    try:
        # Определение таблицы
        user_platforms = Table(
            'user_platforms', 
            metadata,
            Column('id', Integer, primary_key=True),
            Column('user_id', Integer, nullable=False, unique=True, index=True),
            Column('platform_type', String(20), nullable=False, default='unknown'),
            Column('platform_version', String(50), nullable=True),
            Column('device_model', String(100), nullable=True),
            Column('user_agent', Text, nullable=True),
            Column('last_updated', DateTime, default=datetime.now),
        )
        
        # Создание таблицы
        metadata.create_all(engine)
        logger.info("Таблица user_platforms успешно создана")
        return True
    
    except SQLAlchemyError as e:
        logger.error(f"Ошибка при создании таблицы user_platforms: {e}")
        return False
    finally:
        engine.dispose()

def main():
    """
    Основная функция
    """
    logger.info("Запуск миграции для создания таблицы user_platforms")
    
    success = create_user_platforms_table()
    
    if success:
        logger.info("Миграция успешно завершена")
    else:
        logger.error("Миграция завершилась с ошибками")
        sys.exit(1)

if __name__ == "__main__":
    main()