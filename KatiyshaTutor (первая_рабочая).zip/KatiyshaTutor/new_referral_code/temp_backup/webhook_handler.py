#!/usr/bin/env python
# coding: utf-8

"""
Обработчик вебхуков от платежных систем (Robokassa) и веб-страниц оплаты
"""

import logging
import datetime
import hashlib
import os
import asyncio
from flask import Flask, request, abort, send_from_directory, render_template
from telegram.ext import Application

import config
from database import update_user_subscription, get_user
import bot

# Настройка логирования
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

app = Flask(__name__, static_folder='static')
bot_app = None

# Используем секретный ключ из конфигурации
ROBOKASSA_SECRET_KEY = config.ROBOKASSA_SECRET_KEY

@app.route('/payment/<int:user_id>')
def payment_page(user_id):
    """
    Страница оплаты с iFrame Robokassa
    
    Args:
        user_id: Telegram ID пользователя
    """
    try:
        # Проверяем существование пользователя
        user_data = get_user(user_id)
        if not user_data:
            logger.error(f"User with ID {user_id} not found when accessing payment page")
            return "Пользователь не найден", 404
        
        # Отдаем HTML страницу
        return send_from_directory('static', 'robokassa_payment.html')
    
    except Exception as e:
        logger.error(f"Error serving payment page: {str(e)}")
        return "Ошибка при загрузке страницы оплаты", 500

@app.route('/static/<path:filename>')
def serve_static(filename):
    """
    Обработчик для статических файлов
    """
    try:
        return send_from_directory('static', filename)
    except Exception as e:
        logger.error(f"Error serving static file {filename}: {str(e)}")
        abort(404)

@app.route('/robokassa/webhook', methods=['POST', 'GET'])
def robokassa_webhook():
    """
    Обработчик уведомлений от Robokassa
    
    Документация по Result URL: https://docs.robokassa.ru/ru/knowledge-base/integration/notifications-paymentcompleted
    """
    # Получение параметров запроса
    inv_id = request.args.get('InvId')  # Идентификатор заказа в Robokassa
    out_sum = request.args.get('OutSum')  # Сумма платежа
    signature = request.args.get('SignatureValue')  # Подпись для проверки
    user_id = request.args.get('Shp_user')  # Передаем идентификатор пользователя через ShopParameter
    
    # Логирование получения уведомления
    logger.info(f"Received Robokassa webhook: inv_id={inv_id}, out_sum={out_sum}, user_id={user_id}")
    
    # Проверка наличия всех необходимых параметров
    if not all([inv_id, out_sum, signature, user_id]):
        logger.error("Missing required parameters in Robokassa webhook")
        abort(400)  # Bad Request
    
    # Проверка подписи для верификации уведомления
    calculated_signature = hashlib.md5(f"{out_sum}:{inv_id}:{ROBOKASSA_SECRET_KEY}:Shp_user={user_id}".encode()).hexdigest()
    
    if signature.lower() != calculated_signature.lower():
        logger.error("Invalid signature in Robokassa webhook")
        abort(403)  # Forbidden
    
    try:
        # Преобразуем user_id в число
        user_id_int = int(user_id)
        
        # Проверяем существование пользователя
        user_data = get_user(user_id_int)
        if not user_data:
            logger.error(f"User with ID {user_id_int} not found")
            return "ERROR: User not found", 404
        
        # Активируем подписку
        now = datetime.datetime.now()
        expiry_date = now + datetime.timedelta(days=config.SUBSCRIPTION_DURATION_DAYS)
        update_user_subscription(user_id_int, expiry_date.isoformat())
        
        # Отправляем уведомление пользователю через бота если возможно
        if bot_app:
            asyncio.run(send_subscription_notification(user_id_int))
        
        # Отвечаем успешным статусом для Robokassa
        logger.info(f"Subscription activated for user {user_id_int} until {expiry_date.isoformat()}")
        return "OK"
    
    except Exception as e:
        logger.error(f"Error processing Robokassa webhook: {str(e)}")
        abort(500)  # Internal Server Error

async def send_subscription_notification(user_id):
    """
    Отправить уведомление пользователю о успешной активации подписки
    
    Args:
        user_id: Telegram ID пользователя
    """
    try:
        bot_instance = await bot.create_bot()
        await bot_instance.send_message(
            chat_id=user_id,
            text=config.SUBSCRIPTION_SUCCESS_MESSAGE
        )
        logger.info(f"Subscription notification sent to user {user_id}")
    except Exception as e:
        logger.error(f"Failed to send subscription notification to user {user_id}: {str(e)}")

def run_webhook_server(port=5000):
    """
    Запускает сервер для обработки вебхуков
    
    Args:
        port: Порт для веб-сервера
    """
    # Устанавливаем переменную окружения для Flask
    os.environ['FLASK_ENV'] = 'production'
    
    # Запускаем веб-сервер
    app.run(host='0.0.0.0', port=port)

if __name__ == "__main__":
    run_webhook_server()