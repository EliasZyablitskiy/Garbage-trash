#!/usr/bin/env python
# coding: utf-8

"""
Handlers for the Katiysha bot commands and messages
"""

import logging
import datetime
import os
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from telegram import LabeledPrice

import config
from keyboards import get_main_keyboard, get_problem_keyboard
from services.deepseek_service import solve_math_problem
from services.ocr_service import extract_text_from_image
from services.speech_service import convert_voice_to_text
from services.payment_service import create_invoice, create_external_payment_link
from database import save_user, get_user, update_user_subscription

logger = logging.getLogger(__name__)

# State dictionary to track user problem input
user_states = {}

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /start command - introduce the bot and show main keyboard."""
    user = update.effective_user
    
    # Initialize user data if not already exists
    user_data = get_user(user.id)
    if not user_data:
        user_data = {
            'id': user.id,
            'username': user.username,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'free_request_used': False,
            'subscription_expiry': None,
        }
        save_user(user_data)
    
    logger.info(f"User {user.id} started the bot")
    
    await update.message.reply_text(
        config.WELCOME_MESSAGE,
        reply_markup=get_main_keyboard()
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /help command - show help text and main keyboard."""
    await update.message.reply_text(
        config.HELP_MESSAGE,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=get_main_keyboard()
    )

async def solve_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /solve command - prompt user to send a problem."""
    user_id = update.effective_user.id
    
    # Check if user has subscription or free request
    user_data = get_user(user_id)
    
    if not user_data.get('free_request_used', False) or is_subscription_active(user_data):
        # User can solve a problem
        user_states[user_id] = {'waiting_for_problem': True}
        await update.message.reply_text(
            "Пожалуйста, отправьте математическую задачу текстом или сфотографируйте страницу учебника 📝",
            reply_markup=get_main_keyboard()
        )
    else:
        # User needs subscription
        await update.message.reply_text(
            "Ваша бесплатная попытка была использована. Пожалуйста, приобретите подписку, чтобы продолжать решать задачи.",
            reply_markup=get_main_keyboard()
        )

async def subscribe_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /subscribe command - send payment link."""
    user_id = update.effective_user.id
    
    # Check if user already has active subscription
    user_data = get_user(user_id)
    if is_subscription_active(user_data):
        expiry_date = datetime.datetime.fromisoformat(user_data['subscription_expiry'])
        await update.message.reply_text(
            f"✅ У вас уже есть активная подписка до {expiry_date.strftime('%d.%m.%Y')}.",
            reply_markup=get_main_keyboard()
        )
        return
    
    # Send Telegram invoice for payment
    await create_invoice(update, context)

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle text messages - process math problems."""
    user_id = update.effective_user.id
    text = update.message.text
    
    # Handle keyboard button clicks
    logger.debug(f"Полученный текст: '{text}'")
    
    if text == "🧮 Решить задачу":
        logger.debug("Обрабатываю кнопку 'Решить задачу'")
        await solve_command(update, context)
        return
    elif "Купить подписку" in text:  # Проверяем по подстроке, чтобы избежать проблем с невидимыми символами
        logger.debug("Обрабатываю кнопку 'Купить подписку'")
        await subscribe_command(update, context)
        return
    
    # Check if user is in waiting_for_problem state
    if user_id in user_states and user_states[user_id].get('waiting_for_problem'):
        # Clear the state
        user_states[user_id] = {'waiting_for_problem': False, 'problem': text}
        
        # Check if user has subscription or free request
        user_data = get_user(user_id)
        
        if not user_data.get('free_request_used', False) or is_subscription_active(user_data):
            # Process the problem
            await process_problem(update, context, text)
        else:
            # User needs subscription
            await update.message.reply_text(
                config.SUBSCRIPTION_NEEDED_MESSAGE,
                reply_markup=get_main_keyboard()
            )
    else:
        # User sent text without being prompted
        await update.message.reply_text(
            "Если вы хотите решить математическую задачу, пожалуйста, нажмите кнопку 'Решить задачу' или используйте команду /solve.",
            reply_markup=get_main_keyboard()
        )

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle photo messages - extract text using OCR and process math problems."""
    user_id = update.effective_user.id
    
    # Check if user has subscription or free request
    user_data = get_user(user_id)
    
    if not user_data.get('free_request_used', False) or is_subscription_active(user_data):
        # User can process a photo
        photo_file = await update.message.photo[-1].get_file()
        
        # Send processing message
        processing_msg = await update.message.reply_text(config.PROCESSING_MESSAGE)
        
        try:
            # Download the photo
            file_path = f"temp_{user_id}.jpg"
            await photo_file.download_to_drive(file_path)
            
            # Extract text from image using OCR
            extracted_text = await extract_text_from_image(file_path)
            
            # Delete the temporary file
            if os.path.exists(file_path):
                os.remove(file_path)
            
            if extracted_text:
                # Store the problem in user state
                user_states[user_id] = {
                    'waiting_for_problem': False,
                    'problem': extracted_text
                }
                
                # Show the extracted text and ask for confirmation
                await processing_msg.delete()
                await update.message.reply_text(
                    f"📝 Я извлек следующий текст из вашего изображения:\n\n{extracted_text}\n\nРешить эту задачу?",
                    reply_markup=get_problem_keyboard()
                )
            else:
                await processing_msg.delete()
                await update.message.reply_text(config.OCR_ERROR_MESSAGE)
        except Exception as e:
            logger.error(f"Error processing photo: {e}")
            await processing_msg.delete()
            await update.message.reply_text(config.ERROR_MESSAGE)
    else:
        # User needs subscription
        await update.message.reply_text(
            config.SUBSCRIPTION_NEEDED_MESSAGE,
            reply_markup=get_main_keyboard()
        )
        
async def handle_voice(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle voice messages - convert speech to text and process math problems."""
    user_id = update.effective_user.id
    
    # Check if user has subscription or free request
    user_data = get_user(user_id)
    
    if not user_data.get('free_request_used', False) or is_subscription_active(user_data):
        # User can process a voice message
        voice_file = await update.message.voice.get_file()
        
        # Send processing message
        processing_msg = await update.message.reply_text(config.VOICE_PROCESSING_MESSAGE)
        
        try:
            # Download the voice file
            file_path = f"temp_voice_{user_id}.oga"
            await voice_file.download_to_drive(file_path)
            
            # Convert voice to text
            extracted_text = await convert_voice_to_text(file_path)
            
            # Delete the temporary file
            if os.path.exists(file_path):
                os.remove(file_path)
            
            if extracted_text:
                # Store the problem in user state
                user_states[user_id] = {
                    'waiting_for_problem': False,
                    'problem': extracted_text
                }
                
                # Show the extracted text and ask for confirmation
                await processing_msg.delete()
                await update.message.reply_text(
                    f"🎤 Я распознал следующий текст из вашего голосового сообщения:\n\n{extracted_text}\n\nРешить эту задачу?",
                    reply_markup=get_problem_keyboard()
                )
            else:
                await processing_msg.delete()
                await update.message.reply_text(config.VOICE_ERROR_MESSAGE)
        except Exception as e:
            logger.error(f"Error processing voice message: {e}")
            await processing_msg.delete()
            await update.message.reply_text(config.ERROR_MESSAGE)
    else:
        # User needs subscription
        await update.message.reply_text(
            config.SUBSCRIPTION_NEEDED_MESSAGE,
            reply_markup=get_main_keyboard()
        )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle callback queries from inline keyboards."""
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    
    if query.data == "solve_problem":
        # User clicked "Solve Problem" button from main menu
        await query.edit_message_text(config.SEND_PROBLEM_MESSAGE)
        user_states[user_id] = {'waiting_for_problem': True}
    
    elif query.data == "subscribe":
        # User clicked "Subscribe" button from main menu
        await query.delete_message()
        await create_invoice(update, context)
    
    elif query.data == "manual_activate":
        # User confirmed manual subscription activation
        await query.delete_message()
        await activate_subscription_command(update, context)
    
    elif query.data == "confirm_solve":
        # User confirmed the extracted text for solving
        if user_id in user_states and 'problem' in user_states[user_id]:
            problem = user_states[user_id]['problem']
            await query.delete_message()
            await process_problem(update, context, problem, is_callback=True)
        else:
            await query.edit_message_text("Извините, я не могу найти вашу задачу. Пожалуйста, попробуйте снова.")
    
    elif query.data == "cancel_solve":
        # User cancelled the problem solving
        await query.edit_message_text("Операция отменена. Вы можете отправить новую задачу в любое время.")
        if user_id in user_states:
            user_states.pop(user_id, None)

async def process_problem(update: Update, context: ContextTypes.DEFAULT_TYPE, problem: str, is_callback: bool = False) -> None:
    """Process and solve a math problem."""
    user_id = update.effective_user.id
    
    # Send processing message
    if is_callback:
        processing_msg = await context.bot.send_message(
            chat_id=user_id,
            text=config.PROCESSING_MESSAGE
        )
    else:
        processing_msg = await update.message.reply_text(config.PROCESSING_MESSAGE)
    
    try:
        # Get solution from DeepSeek
        solution = await solve_math_problem(problem)
        
        # Mark free request as used if this is the user's first request
        user_data = get_user(user_id)
        if not user_data.get('free_request_used', False) and not is_subscription_active(user_data):
            user_data['free_request_used'] = True
            save_user(user_data)
        
        # Send the solution
        await processing_msg.delete()
        
        if is_callback:
            await context.bot.send_message(
                chat_id=user_id,
                text=f"📝 Задача:\n{problem}\n\n✅ Решение:\n{solution}",
                reply_markup=get_main_keyboard()
            )
        else:
            await update.message.reply_text(
                f"📝 Задача:\n{problem}\n\n✅ Решение:\n{solution}",
                reply_markup=get_main_keyboard()
            )
    except Exception as e:
        logger.error(f"Error processing problem: {e}")
        await processing_msg.delete()
        
        if is_callback:
            await context.bot.send_message(
                chat_id=user_id,
                text=config.ERROR_MESSAGE,
                reply_markup=get_main_keyboard()
            )
        else:
            await update.message.reply_text(
                config.ERROR_MESSAGE,
                reply_markup=get_main_keyboard()
            )

async def handle_pre_checkout(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the pre-checkout callback."""
    # Always approve the pre-checkout
    query = update.pre_checkout_query
    await query.answer(ok=True)

async def handle_successful_payment(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle successful payments."""
    user_id = update.effective_user.id
    
    # Update user's subscription status
    now = datetime.datetime.now()
    expiry_date = now + datetime.timedelta(days=config.SUBSCRIPTION_DURATION_DAYS)
    
    user_data = get_user(user_id)
    update_user_subscription(user_id, expiry_date.isoformat())
    
    # Notify user about successful subscription
    await update.message.reply_text(
        config.SUBSCRIPTION_SUCCESS_MESSAGE,
        reply_markup=get_main_keyboard()
    )
    
async def activate_subscription_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /activate_subscription command - manually activate subscription after payment
    This is a fallback for when Robokassa webhook doesn't work
    """
    user_id = update.effective_user.id
    
    # Check if user already has active subscription
    user_data = get_user(user_id)
    if is_subscription_active(user_data):
        expiry_date = datetime.datetime.fromisoformat(user_data['subscription_expiry'])
        await update.message.reply_text(
            f"✅ У вас уже есть активная подписка до {expiry_date.strftime('%d.%m.%Y')}.",
            reply_markup=get_main_keyboard()
        )
        return
    
    # Update user's subscription status
    now = datetime.datetime.now()
    expiry_date = now + datetime.timedelta(days=config.SUBSCRIPTION_DURATION_DAYS)
    
    update_user_subscription(user_id, expiry_date.isoformat())
    
    # Notify user about successful subscription
    await update.message.reply_text(
        "✅ Спасибо за оплату! Ваша подписка активирована на 1 месяц до "
        f"{expiry_date.strftime('%d.%m.%Y')}. Теперь вы можете неограниченно "
        "пользоваться ботом Катюша!",
        reply_markup=get_main_keyboard()
    )
    logger.info(f"Manual subscription activation for user {user_id} until {expiry_date.isoformat()}")

def is_subscription_active(user_data: dict) -> bool:
    """Check if a user has an active subscription."""
    if not user_data or 'subscription_expiry' not in user_data or not user_data['subscription_expiry']:
        return False
    
    try:
        expiry_date = datetime.datetime.fromisoformat(user_data['subscription_expiry'])
        return datetime.datetime.now() < expiry_date
    except (ValueError, TypeError):
        return False

async def error_handler(update, context):
    """Log errors caused by updates."""
    logger.error(f"Update {update} caused error: {context.error}")
