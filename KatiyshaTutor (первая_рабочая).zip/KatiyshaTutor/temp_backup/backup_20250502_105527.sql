-- Database Backup created on 2025-05-02T10:55:27.855331
-- Database: neondb
-- Type: Full (schema and data)

-- Reset and recreate schema
BEGIN;
SET client_min_messages TO WARNING;


-- Table: users
DROP TABLE IF EXISTS users CASCADE;

-- Table: yandex_disk_tokens
DROP TABLE IF EXISTS yandex_disk_tokens CASCADE;

-- Table: backup_logs
DROP TABLE IF EXISTS backup_logs CASCADE;

-- Table: math_problems
DROP TABLE IF EXISTS math_problems CASCADE;

-- Table: transactions
DROP TABLE IF EXISTS transactions CASCADE;

-- Table: weekly_payouts
DROP TABLE IF EXISTS weekly_payouts CASCADE;
COMMIT;
