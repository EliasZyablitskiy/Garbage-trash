-- Database Backup created on 2025-05-02T10:58:18.508453
-- Database: neondb
-- Type: Schema only

-- Reset and recreate schema
BEGIN;
SET client_min_messages TO WARNING;

