#!/usr/bin/env python3

import sys
import os
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

# Подключение к БД используя переменную окружения
DATABASE_URL = os.environ.get("DATABASE_URL")

if not DATABASE_URL:
    print("Ошибка: Переменная окружения DATABASE_URL не найдена")
    sys.exit(1)

engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
session = Session()

# Проверка пользователя iPhone
try:
    # Выполнение запроса к БД
    result = session.execute(text("""
        SELECT user_id, platform_type, platform_version, device_model
        FROM user_platforms 
        WHERE user_id = 852123125
    """))
    
    # Вывод результатов
    rows = result.fetchall()
    if rows:
        print("Данные о пользователе iPhone найдены:")
        for row in rows:
            print(f"ID: {row[0]}")
            print(f"Тип платформы: {row[1]}")
            print(f"Версия платформы: {row[2]}")
            print(f"Модель устройства: {row[3]}")
    else:
        print("Данные о пользователе iPhone не найдены")
    
    print("\nПроверка флагов проблемной iOS 16.5:")
    # Симуляция проверки функции is_problematic_ios для iOS 16.5
    version = "16.5"
    major_version = int(version.split('.')[0]) if version and version.split('.')[0].isdigit() else 0
    minor_version = int(version.split('.')[1]) if version and len(version.split('.')) > 1 and version.split('.')[1].isdigit() else 0
    
    print(f"iOS версия: {version}")
    print(f"Основная версия: {major_version}")
    print(f"Дополнительная версия: {minor_version}")
    
    is_problematic = False
    if major_version < 11:
        is_problematic = True
        print("iOS < 11: Проблемная версия - Да")
    elif major_version == 13 and minor_version < 4:
        is_problematic = True
        print("iOS 13.0-13.3: Проблемная версия - Да")
    elif major_version == 16 and minor_version in [5, 6]:
        is_problematic = True
        print("iOS 16.5-16.6: Проблемная версия - Да")
    else:
        print("Не является проблемной версией iOS")
    
    print(f"Итоговый результат is_problematic_ios: {is_problematic}")
    
except Exception as e:
    print(f"Ошибка при выполнении запроса: {e}")
finally:
    session.close()