#!/usr/bin/env python
# coding: utf-8

"""
Проверка конфигурации комиссий в реферальной программе
"""

import logging
from new_referral_code.optimized_referral_manager import OptimizedReferralManager

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger("check_referral_commission")

def check_referral_commissions():
    """
    Проверяет соответствие комиссий в реферальной программе требованиям
    """
    # Создаем экземпляр менеджера реферальной программы
    referral_manager = OptimizedReferralManager()
    
    # Проверяем комиссии
    logger.info("Текущие настройки комиссий в реферальной программе:")
    logger.info(f"Уровень 1: {referral_manager.LEVEL_COMMISSIONS.get(1, 'Не задано')*100}%")
    logger.info(f"Уровень 2: {referral_manager.LEVEL_COMMISSIONS.get(2, 'Не задано')*100}%")
    logger.info(f"Уровень 3: {referral_manager.LEVEL_COMMISSIONS.get(3, 'Не задано')*100}%")
    logger.info(f"Уровень 4: {referral_manager.LEVEL_COMMISSIONS.get(4, 'Не задано')*100}%")
    logger.info(f"Максимальный уровень: {referral_manager.MAX_LEVEL}")
    
    # Проверяем соответствие требованиям
    expected_commissions = {
        1: 0.05,  # 5% для прямых рефералов
        2: 0.02,  # 2% для рефералов 2-го уровня
        3: 0.02,  # 2% для рефералов 3-го уровня
        4: 0.02   # 2% для рефералов 4-го уровня
    }
    expected_max_level = 4
    
    commissions_match = True
    for level, expected_rate in expected_commissions.items():
        actual_rate = referral_manager.LEVEL_COMMISSIONS.get(level, 0)
        if actual_rate != expected_rate:
            logger.warning(f"Несоответствие комиссии для уровня {level}: "
                         f"ожидалось {expected_rate*100}%, фактически {actual_rate*100}%")
            commissions_match = False
    
    if referral_manager.MAX_LEVEL != expected_max_level:
        logger.warning(f"Несоответствие максимального уровня: "
                     f"ожидалось {expected_max_level}, фактически {referral_manager.MAX_LEVEL}")
        commissions_match = False
    
    if commissions_match:
        logger.info("РЕЗУЛЬТАТ: Комиссии СООТВЕТСТВУЮТ требованиям")
    else:
        logger.warning("РЕЗУЛЬТАТ: Комиссии НЕ СООТВЕТСТВУЮТ требованиям")
    
    result = {
        "commissions_match": commissions_match,
        "expected": expected_commissions,
        "actual": referral_manager.LEVEL_COMMISSIONS,
        "expected_max_level": expected_max_level,
        "actual_max_level": referral_manager.MAX_LEVEL
    }
    
    return result

if __name__ == "__main__":
    check_referral_commissions()