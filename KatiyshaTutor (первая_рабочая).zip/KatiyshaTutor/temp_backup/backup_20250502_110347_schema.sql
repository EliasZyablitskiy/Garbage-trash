-- Database Backup created on 2025-05-02T11:03:47.810825
-- Database: neondb
-- Type: Schema only
-- Created by Katiysha Bot Backup Script

-- Reset and recreate schema
BEGIN;
SET client_min_messages TO WARNING;

