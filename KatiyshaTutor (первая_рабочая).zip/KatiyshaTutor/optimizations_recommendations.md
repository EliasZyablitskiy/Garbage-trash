# Рекомендации по оптимизации системы для масштабирования

## Введение

Данный документ содержит рекомендации по оптимизации системы бота Катюша для поддержки большого количества пользователей (100,000 - 1,000,000). Рекомендации основаны на анализе текущей архитектуры и результатах нагрузочного тестирования.

## Оптимизация базы данных

### 1. Индексы

Для оптимизации наиболее часто выполняемых запросов следует добавить следующие индексы:

```sql
-- Индекс для ускорения поиска по дате истечения подписки
CREATE INDEX IF NOT EXISTS idx_users_subscription_expiry ON users (subscription_expiry);

-- Индекс для поиска транзакций по типу и дате
CREATE INDEX IF NOT EXISTS idx_transactions_type_created ON transactions (type, created_at);

-- Индекс для реферальных отношений
CREATE INDEX IF NOT EXISTS idx_referral_relations_referrer ON referral_relations (referrer_id);

-- Составной индекс для поиска по статусу транзакции и пользователю
CREATE INDEX IF NOT EXISTS idx_transactions_status_user ON transactions (status, user_id);

-- Индекс для быстрого поиска реферальных кодов
CREATE INDEX IF NOT EXISTS idx_referral_codes_code ON referral_codes (code);
```

### 2. Партиционирование

При достижении 500,000+ пользователей рекомендуется реализовать партиционирование таблиц:

- Таблицу `transactions` партиционировать по дате (`created_at`) для ускорения доступа к недавним транзакциям
- Таблицу `users` можно партиционировать по ID (диапазоны) при достижении 1,000,000+ пользователей

Пример партиционирования для транзакций:

```sql
-- Создание партиционированной таблицы
CREATE TABLE transactions_partitioned (
    id SERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    type VARCHAR(50) NOT NULL,
    amount NUMERIC(10, 2) NOT NULL,
    status VARCHAR(20) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) PARTITION BY RANGE (created_at);

-- Создание партиций по месяцам
CREATE TABLE transactions_y2025m01 PARTITION OF transactions_partitioned
    FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');

CREATE TABLE transactions_y2025m02 PARTITION OF transactions_partitioned
    FOR VALUES FROM ('2025-02-01') TO ('2025-03-01');

-- ... и так далее по месяцам
```

### 3. Архивация данных

Внедрить стратегию архивации старых данных:

- Транзакции старше 1 года перемещать в архивные таблицы
- Информацию о неактивных пользователях (без активности >6 месяцев) можно переносить в отдельные таблицы
- Создать процедуры для периодической архивации и очистки

### 4. Оптимизация запросов к реферальной системе

Текущие рекурсивные запросы к реферальной системе могут стать узким местом. Рекомендуется:

1. Материализовать структуру реферального дерева для пользователей (кеширование топологии)
2. Ограничить глубину рекурсии до 4-х уровней
3. Оптимизировать запросы к реферальной системе

## Масштабирование серверной части

### 1. Кэширование

Внедрить многоуровневую систему кэширования:

```python
# Пример реализации кэширования с использованием Redis
import redis
import json
from functools import wraps

redis_client = redis.Redis(host='localhost', port=6379, db=0)

def redis_cache(expiration=3600):
    """Декоратор для кэширования результатов функций в Redis"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Формируем ключ кэша на основе аргументов
            cache_key = f"cache:{func.__name__}:{str(args)}:{str(kwargs)}"
            
            # Проверяем наличие результата в кэше
            cached_result = redis_client.get(cache_key)
            if cached_result:
                return json.loads(cached_result)
            
            # Выполняем функцию и кэшируем результат
            result = func(*args, **kwargs)
            redis_client.setex(cache_key, expiration, json.dumps(result))
            return result
        return wrapper
    return decorator

# Пример использования
@redis_cache(expiration=300)  # Кэширование на 5 минут
def get_user_subscription_status(user_id):
    """Получение статуса подписки пользователя"""
    # Логика получения статуса подписки
    pass
```

Кэшировать следует:
- Статусы подписок пользователей
- Реферальные коды и деревья
- Результаты частых запросов
- Сессионные данные

### 2. Асинхронная обработка

Для обработки тяжелых операций перейти на асинхронную модель с использованием очередей задач:

```python
# Пример использования Celery для асинхронной обработки задач
from celery import Celery

celery_app = Celery('katiysha_bot', broker='redis://localhost:6379/1')

@celery_app.task
def process_weekly_payouts():
    """Асинхронная обработка еженедельных выплат"""
    # Логика обработки выплат
    pass

@celery_app.task
def send_bulk_notifications(user_ids, message):
    """Асинхронная отправка массовых уведомлений"""
    for user_id in user_ids:
        try:
            # Отправка уведомления пользователю
            pass
        except Exception as e:
            # Обработка ошибок
            pass
```

### 3. Горизонтальное масштабирование

Подготовить систему к горизонтальному масштабированию:

1. Разделить приложение на микросервисы:
   - Сервис обработки сообщений бота
   - Сервис платежей и подписок
   - Сервис реферальной системы
   - Сервис аналитики и административной панели

2. Использовать балансировщик нагрузки между инстансами

```
                  ┌────────────────┐
                  │Load Balancer   │
                  └───────┬────────┘
                          │
           ┌──────────────┼──────────────┐
           │              │              │
  ┌────────▼─────┐ ┌──────▼───────┐ ┌────▼──────────┐
  │Bot Service 1 │ │Bot Service 2 │ │Bot Service N  │
  └────────┬─────┘ └──────┬───────┘ └────┬──────────┘
           │              │              │
    ┌──────▼──────────────▼──────────────▼───────┐
    │            Message Queue System            │
    └──────────────────────┬───────────────────┬─┘
                           │                   │
           ┌───────────────▼────┐     ┌────────▼──────────┐
           │Payment Processor   │     │Referral Processor │
           └────────────────────┘     └───────────────────┘
```

## Оптимизация обработки запросов

### 1. Пакетная обработка

Внедрить механизмы пакетной обработки для операций с высокой нагрузкой:

```python
def bulk_update_user_statuses(user_status_map):
    """
    Обновляет статусы нескольких пользователей за один запрос к БД
    
    Args:
        user_status_map: Словарь {user_id: new_status}
    """
    with db.session.begin():
        # Создаем массовое обновление
        case_stmt = sqlalchemy.case(
            {user_id: status for user_id, status in user_status_map.items()},
            value=User.id
        )
        
        # Выполняем обновление одним запросом
        db.session.query(User).filter(
            User.id.in_(user_status_map.keys())
        ).update(
            {User.status: case_stmt},
            synchronize_session=False
        )
```

### 2. Ограничение частоты запросов (Rate Limiting)

Усилить существующую систему ограничения частоты запросов:

```python
class RateLimiter:
    def __init__(self, redis_client, limit=10, window=60):
        """
        Инициализирует ограничитель частоты запросов
        
        Args:
            redis_client: Клиент Redis
            limit: Максимальное количество запросов
            window: Период в секундах
        """
        self.redis = redis_client
        self.limit = limit
        self.window = window
    
    def is_rate_limited(self, key):
        """
        Проверяет, превышен ли лимит запросов
        
        Args:
            key: Ключ для идентификации пользователя/сессии
            
        Returns:
            bool: True если превышен лимит, False в противном случае
        """
        current_time = int(time.time())
        bucket_key = f"rate:{key}:{current_time // self.window}"
        
        # Увеличиваем счетчик запросов
        count = self.redis.incr(bucket_key)
        
        # Устанавливаем TTL при первом запросе
        if count == 1:
            self.redis.expire(bucket_key, self.window)
        
        # Проверяем превышение лимита
        return count > self.limit
```

### 3. Оптимизация работы с Telegram API

Реализовать более эффективную работу с Telegram API:

```python
async def process_updates_batch(updates):
    """
    Оптимизированная обработка пакета обновлений от Telegram
    
    Args:
        updates: Список объектов Update от Telegram
    """
    # Группируем обновления по типу для оптимизации
    message_updates = []
    callback_updates = []
    other_updates = []
    
    for update in updates:
        if update.message:
            message_updates.append(update)
        elif update.callback_query:
            callback_updates.append(update)
        else:
            other_updates.append(update)
    
    # Обрабатываем обновления пакетно
    await asyncio.gather(
        process_message_updates(message_updates),
        process_callback_updates(callback_updates),
        process_other_updates(other_updates)
    )
```

## Мониторинг и диагностика

### 1. Комплексная система мониторинга

Внедрить систему мониторинга с использованием Prometheus и Grafana:

```python
from prometheus_client import Counter, Histogram, start_http_server

# Счетчики метрик
REQUEST_COUNT = Counter(
    'katiysha_bot_requests_total',
    'Total number of requests',
    ['endpoint', 'method', 'status']
)

RESPONSE_TIME = Histogram(
    'katiysha_bot_response_time_seconds',
    'Response time in seconds',
    ['endpoint']
)

# Функция-декоратор для измерения времени ответа и счетчика запросов
def track_metrics(endpoint):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            with RESPONSE_TIME.labels(endpoint).time():
                try:
                    result = await func(*args, **kwargs)
                    REQUEST_COUNT.labels(
                        endpoint=endpoint,
                        method='POST',
                        status='success'
                    ).inc()
                    return result
                except Exception as e:
                    REQUEST_COUNT.labels(
                        endpoint=endpoint,
                        method='POST',
                        status='error'
                    ).inc()
                    raise e
        return wrapper
    return decorator

# Пример использования
@track_metrics(endpoint='/solve_math')
async def solve_math_problem(update, context):
    # Логика обработки
    pass
```

### 2. Логирование

Улучшить систему логирования для более эффективного выявления проблем:

```python
import logging
import json
from pythonjsonlogger import jsonlogger

# Настройка JSON-логирования
logger = logging.getLogger()
logHandler = logging.StreamHandler()
formatter = jsonlogger.JsonFormatter(
    '%(asctime)s %(name)s %(levelname)s %(message)s %(pathname)s %(lineno)s'
)
logHandler.setFormatter(formatter)
logger.addHandler(logHandler)
logger.setLevel(logging.INFO)

# Логирование с дополнительным контекстом
def log_with_context(level, message, **context):
    """
    Логирует сообщение с дополнительным контекстом
    
    Args:
        level: Уровень логирования (info, error и т.д.)
        message: Сообщение для логирования
        context: Дополнительные поля контекста
    """
    log_method = getattr(logger, level)
    log_method(message, extra=context)
```

## Архитектурные улучшения для масштабирования до 1,000,000 пользователей

### 1. Реализация шардирования

Внедрить шардирование для распределения нагрузки на несколько баз данных:

```python
class ShardManager:
    """Менеджер шардирования для распределения данных по нескольким БД"""
    
    def __init__(self, shard_count):
        self.shard_count = shard_count
        self.engines = {}
        
        # Инициализация соединений с каждым шардом
        for i in range(shard_count):
            shard_url = os.environ.get(f"DATABASE_URL_SHARD_{i}")
            self.engines[i] = sqlalchemy.create_engine(shard_url)
    
    def get_shard_for_user(self, user_id):
        """
        Определяет шард для пользователя на основе ID
        
        Args:
            user_id: ID пользователя
            
        Returns:
            int: Номер шарда
        """
        return user_id % self.shard_count
    
    def get_engine_for_user(self, user_id):
        """
        Возвращает движок базы данных для пользователя
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Engine: SQLAlchemy движок для шарда
        """
        shard = self.get_shard_for_user(user_id)
        return self.engines[shard]
```

### 2. Очереди сообщений для межсервисной коммуникации

Внедрить RabbitMQ или Apache Kafka для надежной межсервисной коммуникации:

```python
import pika
import json

# Производитель сообщений
class MessageProducer:
    def __init__(self, rabbitmq_url):
        self.connection = pika.BlockingConnection(
            pika.URLParameters(rabbitmq_url)
        )
        self.channel = self.connection.channel()
        
        # Объявляем очереди
        self.channel.queue_declare(queue='subscription_events')
        self.channel.queue_declare(queue='referral_events')
    
    def publish_subscription_event(self, user_id, event_type, data):
        """Публикует событие, связанное с подпиской"""
        self._publish_event('subscription_events', {
            'user_id': user_id,
            'event_type': event_type,
            'data': data,
            'timestamp': time.time()
        })
    
    def publish_referral_event(self, user_id, referrer_id, event_type, data):
        """Публикует событие, связанное с реферальной системой"""
        self._publish_event('referral_events', {
            'user_id': user_id,
            'referrer_id': referrer_id,
            'event_type': event_type,
            'data': data,
            'timestamp': time.time()
        })
    
    def _publish_event(self, queue, message):
        """Публикует сообщение в указанную очередь"""
        self.channel.basic_publish(
            exchange='',
            routing_key=queue,
            body=json.dumps(message),
            properties=pika.BasicProperties(
                delivery_mode=2,  # Сообщение будет сохранено
            )
        )
```

### 3. Разделение чтения и записи (CQRS)

Внедрить шаблон Command Query Responsibility Segregation для высоконагруженных сценариев:

```python
# Пример разделения чтения и записи для пользовательских данных

# Репозиторий записи (основная БД)
class UserWriteRepository:
    def __init__(self, db_session):
        self.session = db_session
    
    def create_user(self, user_data):
        """Создает нового пользователя"""
        user = User(**user_data)
        self.session.add(user)
        self.session.commit()
        return user
    
    def update_subscription(self, user_id, expiry_date):
        """Обновляет подписку пользователя"""
        user = self.session.query(User).filter_by(id=user_id).first()
        if user:
            user.subscription_expiry = expiry_date
            self.session.commit()
            return True
        return False

# Репозиторий чтения (может быть оптимизированная реплика)
class UserReadRepository:
    def __init__(self, db_session):
        self.session = db_session
    
    def get_user_by_id(self, user_id):
        """Получает пользователя по ID"""
        return self.session.query(User).filter_by(id=user_id).first()
    
    def get_subscription_status(self, user_id):
        """Получает статус подписки пользователя"""
        user = self.session.query(User).filter_by(id=user_id).first()
        if not user:
            return None
        
        return {
            'active': user.subscription_expiry and user.subscription_expiry > datetime.datetime.now(),
            'expiry_date': user.subscription_expiry.isoformat() if user.subscription_expiry else None
        }
```

## Тестирование производительности

Регулярно проводить нагрузочное тестирование для проверки эффективности оптимизаций:

1. Тестирование с постепенным увеличением нагрузки (от 1,000 до 1,000,000 пользователей)
2. Тестирование пиковых нагрузок (2-3x от обычной)
3. Тестирование пропускной способности каждого компонента системы

## Заключение

Для успешного масштабирования системы до 1,000,000 пользователей необходимо:

1. Оптимизировать базу данных (индексы, партиционирование, архивация)
2. Внедрить многоуровневое кэширование
3. Перейти на асинхронную обработку задач
4. Подготовить систему к горизонтальному масштабированию
5. Улучшить мониторинг и диагностику
6. При достижении 500,000+ пользователей внедрить шардирование и CQRS

Рекомендуется внедрять оптимизации поэтапно, проводя тестирование после каждого этапа для оценки эффективности и выявления новых узких мест.