#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для миграции данных из JSON-файлов в PostgreSQL базу данных
"""

import os
import sys
import json
import logging
import asyncio
from datetime import datetime

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(f'migration_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
    ]
)
logger = logging.getLogger(__name__)

async def main():
    """
    Главная функция для запуска миграции данных из JSON-файлов в PostgreSQL
    """
    try:
        # Проверка наличия переменной окружения DATABASE_URL
        if not os.environ.get('DATABASE_URL'):
            logger.error("DATABASE_URL environment variable is not set")
            print("Error: DATABASE_URL environment variable is not set")
            sys.exit(1)
            
        logger.info("Starting migration from JSON to PostgreSQL...")
        print("Starting migration from JSON to PostgreSQL...")
        
        # Инициализация базы данных
        from db_config import get_flask_app
        app = get_flask_app()
        
        with app.app_context():
            from db_models import db
            from services.db_migration_service import run_migration
            
            logger.info("Checking database connection...")
            # Тестируем соединение с базой данных
            try:
                db.engine.connect()
                logger.info("Database connection successful")
            except Exception as e:
                logger.error(f"Database connection failed: {str(e)}")
                print(f"Error: Database connection failed: {str(e)}")
                sys.exit(1)
            
            # Запускаем миграцию
            logger.info("Running migration...")
            results = await run_migration()
            
            # Выводим результаты
            if results['status'] == 'success':
                logger.info("Migration completed successfully")
                print("Migration completed successfully")
                print(f"Total processed: {results['total_processed']}")
                print(f"Total added: {results['total_added']}")
                print(f"Total errors: {results['total_errors']}")
                
                # Детали по каждому типу данных
                for data_type in ['users', 'transactions', 'weekly_payouts']:
                    print(f"{data_type.capitalize()}: processed {results[data_type]['processed']}, added {results[data_type]['added']}, errors {len(results[data_type]['errors'])}")
                
                # Если были ошибки, сохраняем их в лог-файл
                if results['total_errors'] > 0:
                    error_file = f'migration_errors_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
                    logger.info(f"Saving errors to {error_file}")
                    print(f"Saving errors to {error_file}")
                    
                    with open(error_file, 'w', encoding='utf-8') as f:
                        json.dump(results, f, ensure_ascii=False, indent=2)
            
            elif results['status'] == 'completed_with_errors':
                logger.warning("Migration completed with errors")
                print("Migration completed with errors")
                print(f"Total processed: {results['total_processed']}")
                print(f"Total added: {results['total_added']}")
                print(f"Total errors: {results['total_errors']}")
                
                # Детали по каждому типу данных
                for data_type in ['users', 'transactions', 'weekly_payouts']:
                    print(f"{data_type.capitalize()}: processed {results[data_type]['processed']}, added {results[data_type]['added']}, errors {len(results[data_type]['errors'])}")
                
                # Сохраняем ошибки в лог-файл
                error_file = f'migration_errors_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
                logger.info(f"Saving errors to {error_file}")
                print(f"Saving errors to {error_file}")
                
                with open(error_file, 'w', encoding='utf-8') as f:
                    json.dump(results, f, ensure_ascii=False, indent=2)
            
            else:
                logger.error(f"Migration failed: {results.get('error', 'Unknown error')}")
                print(f"Error: Migration failed: {results.get('error', 'Unknown error')}")
                sys.exit(1)
    
    except Exception as e:
        logger.error(f"Error in migration script: {str(e)}")
        print(f"Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    # Запускаем асинхронную функцию
    asyncio.run(main())