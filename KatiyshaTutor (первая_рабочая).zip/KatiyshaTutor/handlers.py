#!/usr/bin/env python
# coding: utf-8

"""
Handlers for the Katiysha bot commands and messages
"""

import os
import time
import logging
import datetime
import tempfile
from typing import Dict, Any, Optional

from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ContextTypes

import config
from services.db_service import get_user, save_user, update_user_subscription
from keyboards import get_main_keyboard, get_problem_keyboard
from models import User
from services.deepseek_service import solve_math_problem
from services.ocr_service import extract_text_from_image
from services.speech_service import convert_voice_to_text
from services.payment_service import create_external_payment_link, create_manual_activation
# импорт QR-сервиса удален
from services.rate_limiter import rate_limit
from services.platform_detection_service import (
    get_platform_from_update, store_user_platform, get_user_platform,
    is_problematic_ios, get_platform_compatibility_flags
)
from services.platform_data_service import (
    get_platform_settings, get_message_format_settings, get_ai_model_settings,
    get_emoji
)
from services.message_formatter_service import (
    format_adaptive_message, adapt_solution_message, adapt_text_for_platform
)

logger = logging.getLogger(__name__)


def safe_get_user_data(context, key, default=None):
    """
    Безопасное получение данных из context.user_data
    
    Args:
        context: Контекст телеграм-бота
        key: Ключ для получения значения
        default: Значение по умолчанию, если ключ не найден
        
    Returns:
        Any: Значение по указанному ключу или значение по умолчанию
    """
    if hasattr(context, 'user_data') and context.user_data:
        if hasattr(context.user_data, 'get'):
            return context.user_data.get(key, default)
        elif isinstance(context.user_data, dict):
            return context.user_data.get(key, default)
    return default


def safe_update_user_data(context, data_dict):
    """
    Безопасное обновление данных в context.user_data
    
    Args:
        context: Контекст телеграм-бота
        data_dict: Словарь с данными для обновления
        
    Returns:
        bool: True если обновление успешно, False в противном случае
    """
    if hasattr(context, 'user_data') and context.user_data:
        if hasattr(context.user_data, 'update'):
            context.user_data.update(data_dict)
            return True
        elif isinstance(context.user_data, dict):
            for key, value in data_dict.items():
                context.user_data[key] = value
            return True
    return False

# Хранилище состояний пользователей для отслеживания контекста разговора
user_states = {}

def synchronize_subscription_fields(user_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Синхронизирует поля subscription_expiry и subscription_end,
    чтобы избежать рассинхронизации данных.
    
    Args:
        user_data: Словарь с данными пользователя
        
    Returns:
        Dict[str, Any]: Обновленный словарь данных пользователя
    """
    if not user_data:
        return user_data
        
    if 'subscription_expiry' in user_data and 'subscription_end' not in user_data:
        user_data['subscription_end'] = user_data['subscription_expiry']
    elif 'subscription_end' in user_data and 'subscription_expiry' not in user_data:
        user_data['subscription_expiry'] = user_data['subscription_end']
    return user_data

def validate_user_data(user_data: Dict[str, Any]) -> bool:
    """
    Проверяет наличие всех необходимых полей в данных пользователя.
    
    Args:
        user_data: Словарь с данными пользователя
        
    Returns:
        bool: True если все обязательные поля присутствуют, иначе False
    """
    if not user_data:
        return False
        
    required_fields = ['id', 'free_request_used']
    for field in required_fields:
        if field not in user_data:
            logger.warning(f"Missing required field {field} in user data for user_id {user_data.get('id', 'unknown')}")
            return False
    return True

@rate_limit(limit=5, window=60, cooldown=30)
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /start command - introduce the bot and show main keyboard."""
    user = update.effective_user
    user_id = user.id
    message_text = update.message.text
    
    # Определение платформы пользователя
    platform_info = get_platform_from_update(update)
    platform_type = platform_info.get("platform")
    platform_version = platform_info.get("version")
    
    # Логирование информации о платформе
    if platform_type != "unknown":
        logger.info(f"Detected platform for user {user_id}: {platform_type} {platform_version or ''}")
        # Сохраняем информацию о платформе
        store_user_platform(user_id, platform_info)
        
        # Проверка на проблемные платформы
        if is_problematic_ios(platform_info):
            logger.warning(f"User {user_id} is using problematic iOS version: {platform_version}")
    
    # Получение или создание данных пользователя
    user_data = get_user(user_id)
    if not user_data:
        user_data = {
            "id": user_id,
            "username": user.username or "",  # Обеспечиваем, что username всегда строка, даже если None
            "first_name": user.first_name or "",  # Также проверяем first_name
            "last_name": user.last_name or "",    # Проверяем last_name
            "free_request_used": False,
            "subscription_expiry": None,
            "subscription_end": None,  # Дублируем поле для совместимости
            "referral_code": None,
            "referrer_id": None,
            "referrals": {
                "level1": [],  # 5% (прямые рефералы)
                "level2": [],  # 2% (рефералы 2-го уровня)
                "level3": [],  # 2% (рефералы 3-го уровня)
                "level4": [],  # 2% (рефералы 4-го уровня)
            }
        }
        save_user(user_data)
        # Используем безопасную форму логирования, чтобы избежать ошибок с None
        username_display = user.username or 'без username'
        logger.info(f"New user registered: {user_id} ({username_display})")
    
    # Синхронизируем поля подписки для гарантии согласованности данных
    user_data = synchronize_subscription_fields(user_data)
    
    # Сохраняем информацию о платформе в контексте
    # В python-telegram-bot нельзя присваивать новое значение context.user_data,
    # можно только обновлять его содержимое
    context.user_data["platform_info"] = platform_info
    context.user_data["platform_compatibility"] = get_platform_compatibility_flags(user_id)
    
    # Проверяем, не является ли это переходом по реферальной ссылке
    if context.args:
        # Новый формат реферальных ссылок использует параметр start без префикса
        referral_code = context.args[0]
        # Используем напрямую новую реферальную систему
        from new_referral_code.referral_handlers import process_referral, extract_referral_code
        
        # Проверяем и извлекаем валидный реферальный код
        valid_code = extract_referral_code(referral_code)
        if valid_code:
            user_id = update.effective_user.id
            success = await process_referral(user_id, valid_code)
            if success:
                await update.effective_message.reply_text(
                    "Привет! Вы были успешно зарегистрированы по реферальной программе. "
                    "Напишите мне математическую задачу, и я помогу ее решить."
                )
                return
            else:
                await update.effective_message.reply_text(
                    "Привет! Я бот для решения математических задач. Напиши мне задачу, и я помогу ее решить.\n\n"
                    "Примечание: указанный реферальный код недействителен или уже был использован ранее."
                )
                return
    
    # Поддержка старого формата для совместимости
    if message_text and message_text.startswith('/start ref_'):
        # Извлекаем реферальный код
        referral_code = message_text.split('ref_')[1]
        # Используем новую реферальную систему через интеграционный модуль
        from new_referral_code.referral_handlers import process_referral
        user_id = update.effective_user.id
        success = await process_referral(user_id, referral_code)
        if success:
            await update.effective_message.reply_text(
                "Привет! Вы были успешно зарегистрированы по реферальной программе. "
                "Напишите мне математическую задачу, и я помогу ее решить."
            )
            return
        else:
            await update.effective_message.reply_text(
                "Привет! Я бот для решения математических задач. Напиши мне задачу, и я помогу ее решить.\n\n"
                "Примечание: указанный реферальный код недействителен или уже был использован ранее."
            )
            return
    else:
        # Используем приветственное сообщение из конфигурации
        welcome_message = config.WELCOME_MESSAGE
        
        # Используем адаптивную клавиатуру с учетом данных пользователя
        await update.message.reply_text(
            welcome_message,
            reply_markup=get_main_keyboard(user_data),
            parse_mode='Markdown'
        )

@rate_limit(limit=5, window=60, cooldown=30)
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /help command - show help text and main keyboard."""
    user_id = update.effective_user.id
    user_data = get_user(user_id)
    
    # Синхронизируем поля подписки для гарантии согласованности данных
    if user_data:
        user_data = synchronize_subscription_fields(user_data)
    
    await update.message.reply_text(
        config.HELP_MESSAGE,
        reply_markup=get_main_keyboard(user_data)
    )

@rate_limit(limit=3, window=60, cooldown=30, custom_message="⚠️ Слишком много запросов на решение задач! Пожалуйста, подождите немного перед отправкой новой задачи.")
async def solve_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /solve command - prompt user to send a problem."""
    user_id = update.effective_user.id
    user_data = get_user(user_id)
    
    # Синхронизируем поля подписки для гарантии согласованности данных
    if user_data:
        user_data = synchronize_subscription_fields(user_data)
    
    # Проверяем права пользователя на решение задач, используем централизованный сервис
    from services.subscription_service import can_use_problem_solving
    can_solve, reason = can_use_problem_solving(user_id)
    if not can_solve:
        await update.message.reply_text(
            config.SUBSCRIPTION_NEEDED_MESSAGE,
            reply_markup=get_main_keyboard(user_data),
            parse_mode='Markdown'
        )
        return
    
    await update.message.reply_text(
        config.SEND_PROBLEM_MESSAGE,
        reply_markup=get_main_keyboard(user_data)
    )
    
    # Устанавливаем состояние пользователя - ожидаем от него задачу
    user_states[user_id] = {'waiting_for_problem': True}

@rate_limit(limit=5, window=60, cooldown=30)
async def subscribe_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /subscribe command - send payment link."""
    # Используем функцию для создания ссылки на оплату
    # await create_external_payment_link(update, context)
    # Для упрощения пока используем ручную активацию
    await create_manual_activation(update, context)

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle text messages - process math problems."""
    text = update.message.text
    user_id = update.effective_user.id
    
    # Получаем или обновляем информацию о платформе пользователя
    platform_info = get_platform_from_update(update)
    if platform_info.get("platform") != "unknown":
        # Сохраняем информацию о платформе
        store_user_platform(user_id, platform_info)
        
        # Сохраняем информацию о платформе в контексте
        if not context.user_data:
            context.user_data = {}
        context.user_data["platform_info"] = platform_info
        context.user_data["platform_compatibility"] = get_platform_compatibility_flags(user_id)
    
    # Адаптируем текст сообщений в зависимости от платформы
    platform_type = platform_info.get("platform", "unknown")
    platform_version = platform_info.get("version")
    
    # Получаем настройки форматирования для платформы
    message_settings = get_message_format_settings(platform_type, platform_version)
    
    # Если текст похож на команду из основной клавиатуры, используем адаптированный подход
    # для обработки команд в зависимости от платформы
    if text == "Решить задачу" or text == adapt_text_for_platform("Решить задачу", platform_type, platform_version):
        await solve_command(update, context)
        return
    elif "Купить подписку" in text or "199₽" in text:  # Более гибкая проверка для разных платформ
        await subscribe_command(update, context)
        return
    elif "Пригласить" in text or "реферал" in text:  # Более гибкая проверка для разных платформ
        # Используем напрямую новую реферальную систему
        from new_referral_code.referral_handlers import invite_command
        await invite_command(update, context)
        return
    
    # Получаем данные пользователя для проверки доступа
    user_data = get_user(user_id)
    
    # Если пользователь отправляет текст задачи после команды /solve
    if user_id in user_states and user_states[user_id].get('waiting_for_problem', False):
        # Сохраняем задачу в состоянии пользователя
        user_states[user_id]['problem'] = text
        user_states[user_id]['waiting_for_problem'] = False
        
        # Адаптируем форматирование сообщения на основе платформы пользователя
        emoji = get_emoji("pencil", platform_type)
        
        # Используем новый сервис форматирования сообщений
        confirm_message, parse_mode = format_adaptive_message(
            f"{emoji} Задача получена:\n\n{text}\n\nРешить эту задачу?",
            platform_type, 
            platform_version
        )
        
        # Отправляем подтверждение с учетом специфики платформы
        await update.message.reply_text(
            confirm_message,
            reply_markup=get_problem_keyboard(),
            parse_mode=parse_mode
        )
    else:
        # Если пользователь просто отправил сообщение без предварительной команды,
        # воспринимаем его как задачу
        
        # Используем централизованный сервис для проверки прав доступа
        from services.subscription_service import can_use_problem_solving
        can_solve, reason = can_use_problem_solving(user_id)
        
        if not can_solve:
            await update.message.reply_text(
                config.SUBSCRIPTION_NEEDED_MESSAGE,
                reply_markup=get_main_keyboard(user_data),
                parse_mode='Markdown'
            )
            return
            
        user_states[user_id] = {'problem': text}
        
        # Адаптируем форматирование сообщения на основе платформы пользователя
        emoji = get_emoji("pencil", platform_type)
        
        # Используем новый сервис форматирования сообщений
        confirm_message, parse_mode = format_adaptive_message(
            f"{emoji} Задача получена:\n\n{text}\n\nРешить эту задачу?",
            platform_type, 
            platform_version
        )
        
        # Отправляем подтверждение с учетом специфики платформы
        await update.message.reply_text(
            confirm_message,
            reply_markup=get_problem_keyboard(),
            parse_mode=parse_mode
        )

@rate_limit(limit=2, window=60, cooldown=60, custom_message="⚠️ Слишком много отправляемых фотографий! Пожалуйста, подождите минуту перед отправкой новой фотографии.")
async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle photo messages - extract text using OCR and process math problems."""
    user_id = update.effective_user.id
    
    # Проверяем права доступа пользователя перед обработкой изображения
    user_data = get_user(user_id)
    
    # Синхронизируем поля подписки для гарантии согласованности данных
    if user_data:
        user_data = synchronize_subscription_fields(user_data)
    
    # Используем централизованный сервис для проверки прав доступа
    from services.subscription_service import can_use_problem_solving
    can_solve, reason = can_use_problem_solving(user_id)
    if not can_solve:
        await update.message.reply_text(
            config.SUBSCRIPTION_NEEDED_MESSAGE,
            reply_markup=get_main_keyboard(user_data),
            parse_mode='Markdown'
        )
        return
    
    # Получаем информацию о фото
    photo = update.message.photo[-1]  # Берем фото с наилучшим качеством
    
    # Импортируем сервис индикатора прогресса
    from services.progress_indicator_service import start_progress_indicator, update_progress, complete_progress
    
    # Начинаем индикацию прогресса
    task_id, message_id = await start_progress_indicator(
        bot=context.bot,
        chat_id=user_id,
        operation_name="Распознавание текста",
        reply_to_message_id=update.message.message_id
    )
    
    try:
        # Обновляем прогресс - начинаем скачивание
        await update_progress(
            bot=context.bot,
            chat_id=user_id,
            task_id=task_id,
            progress=10,
            status="Получение изображения"
        )
        
        # Скачиваем фото во временный файл
        photo_file = await context.bot.get_file(photo.file_id)
        
        # Создаем временную директорию, если её нет
        temp_dir = "temp_images"
        os.makedirs(temp_dir, exist_ok=True)
        
        # Формируем имя файла и путь
        timestamp = int(time.time())
        photo_path = f"{temp_dir}/photo_{user_id}_{timestamp}.jpg"
        
        # Скачиваем фото
        await photo_file.download_to_drive(photo_path)
        
        # Обновляем прогресс - начинаем распознавание
        await update_progress(
            bot=context.bot,
            chat_id=user_id,
            task_id=task_id,
            progress=40,
            status="Распознавание текста"
        )
        
        # Используем OCR для извлечения текста из изображения
        extracted_text = await extract_text_from_image(photo_path)
        
        # Обновляем прогресс - завершаем распознавание
        await update_progress(
            bot=context.bot,
            chat_id=user_id,
            task_id=task_id,
            progress=90,
            status="Анализ результатов"
        )
        
        if not extracted_text or extracted_text.strip() == "":
            # Если текст не распознан - завершаем с ошибкой
            await complete_progress(
                bot=context.bot,
                chat_id=user_id,
                task_id=task_id,
                final_status="Текст не распознан",
                success=False
            )
            
            await update.message.reply_text(
                config.OCR_ERROR_MESSAGE,
                reply_markup=get_main_keyboard(user_data)
            )
            return
        
        # Успешно завершаем индикацию прогресса
        await complete_progress(
            bot=context.bot,
            chat_id=user_id,
            task_id=task_id,
            final_status="Текст успешно распознан",
            success=True
        )
        
        # Импортируем сервис предварительного просмотра текста
        from services.text_preview_service import send_text_preview, handle_edited_text
        
        # Функция, которая будет вызвана при подтверждении текста
        async def on_text_confirm(update_obj, context_obj, confirmed_text):
            # Сохраняем подтвержденный текст в состоянии пользователя
            user_states[user_id] = {
                'problem': confirmed_text,
                'image_path': photo_path
            }
            
            # Спрашиваем, хочет ли пользователь решить задачу
            await context_obj.bot.send_message(
                chat_id=user_id,
                text="Решить эту задачу?",
                reply_markup=get_problem_keyboard()
            )
        
        # Функция, которая будет вызвана при отмене
        async def on_text_cancel(update_obj, context_obj):
            await context_obj.bot.send_message(
                chat_id=user_id,
                text="Операция отменена. Вы можете отправить новое изображение.",
                reply_markup=get_main_keyboard(user_data)
            )
        
        # Отправляем предварительный просмотр распознанного текста с возможностью редактирования
        await send_text_preview(
            update=update,
            context=context,
            text=extracted_text,
            operation_type="ocr",
            on_confirm=on_text_confirm,
            on_cancel=on_text_cancel
        )
        
    except Exception as e:
        logger.error(f"Error processing photo: {e}", exc_info=True)
        
        # Завершаем индикацию прогресса с ошибкой
        try:
            await complete_progress(
                bot=context.bot,
                chat_id=user_id,
                task_id=task_id,
                final_status="Произошла ошибка",
                success=False
            )
        except Exception:
            pass
            
        # Отправляем сообщение об ошибке
        await update.message.reply_text(
            config.ERROR_MESSAGE,
            reply_markup=get_main_keyboard(user_data)
        )

@rate_limit(limit=2, window=60, cooldown=60, custom_message="⚠️ Слишком много голосовых сообщений! Пожалуйста, подождите минуту перед отправкой нового сообщения.")
async def handle_voice(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle voice messages - convert speech to text and process math problems."""
    user_id = update.effective_user.id
    
    # Проверяем права доступа пользователя перед обработкой голосового сообщения
    user_data = get_user(user_id)
    
    # Синхронизируем поля подписки для гарантии согласованности данных
    if user_data:
        user_data = synchronize_subscription_fields(user_data)
    
    # Используем централизованный сервис для проверки прав доступа
    from services.subscription_service import can_use_problem_solving
    can_solve, reason = can_use_problem_solving(user_id)
    if not can_solve:
        await update.message.reply_text(
            config.SUBSCRIPTION_NEEDED_MESSAGE,
            reply_markup=get_main_keyboard(user_data),
            parse_mode='Markdown'
        )
        return
    
    # Получаем информацию о голосовом сообщении
    voice = update.message.voice
    
    # Импортируем сервис индикатора прогресса
    from services.progress_indicator_service import start_progress_indicator, update_progress, complete_progress
    
    # Начинаем индикацию прогресса
    task_id, message_id = await start_progress_indicator(
        bot=context.bot,
        chat_id=user_id,
        operation_name="Распознавание речи",
        reply_to_message_id=update.message.message_id
    )
    
    try:
        # Обновляем прогресс - начинаем скачивание
        await update_progress(
            bot=context.bot,
            chat_id=user_id,
            task_id=task_id,
            progress=10,
            status="Получение аудио"
        )
        
        # Скачиваем голосовое сообщение во временный файл
        voice_file = await context.bot.get_file(voice.file_id)
        
        # Создаем временную директорию, если её нет
        temp_dir = "temp_voices"
        os.makedirs(temp_dir, exist_ok=True)
        
        # Формируем имя файла и путь
        timestamp = int(time.time())
        voice_path = f"{temp_dir}/voice_{user_id}_{timestamp}.oga"
        
        # Скачиваем голосовое сообщение
        await voice_file.download_to_drive(voice_path)
        
        # Обновляем прогресс - начинаем конвертацию
        await update_progress(
            bot=context.bot,
            chat_id=user_id,
            task_id=task_id,
            progress=30,
            status="Конвертация аудио"
        )
        
        # Обновляем прогресс - начинаем распознавание
        await update_progress(
            bot=context.bot,
            chat_id=user_id,
            task_id=task_id,
            progress=50,
            status="Распознавание речи"
        )
        
        # Конвертируем голосовое сообщение в текст
        extracted_text = await convert_voice_to_text(voice_path)
        
        # Обновляем прогресс - завершаем распознавание
        await update_progress(
            bot=context.bot,
            chat_id=user_id,
            task_id=task_id,
            progress=90,
            status="Анализ результатов"
        )
        
        if not extracted_text or extracted_text.strip() == "":
            # Если текст не распознан - завершаем с ошибкой
            await complete_progress(
                bot=context.bot,
                chat_id=user_id,
                task_id=task_id,
                final_status="Речь не распознана",
                success=False
            )
            
            await update.message.reply_text(
                config.VOICE_ERROR_MESSAGE,
                reply_markup=get_main_keyboard(user_data)
            )
            return
        
        # Успешно завершаем индикацию прогресса
        await complete_progress(
            bot=context.bot,
            chat_id=user_id,
            task_id=task_id,
            final_status="Речь успешно распознана",
            success=True
        )
        
        # Импортируем сервис предварительного просмотра текста
        from services.text_preview_service import send_text_preview, handle_edited_text
        
        # Функция, которая будет вызвана при подтверждении текста
        async def on_text_confirm(update_obj, context_obj, confirmed_text):
            # Сохраняем подтвержденный текст в состоянии пользователя
            user_states[user_id] = {'problem': confirmed_text}
            
            # Спрашиваем, хочет ли пользователь решить задачу
            await context_obj.bot.send_message(
                chat_id=user_id,
                text="Решить эту задачу?",
                reply_markup=get_problem_keyboard()
            )
        
        # Функция, которая будет вызвана при отмене
        async def on_text_cancel(update_obj, context_obj):
            await context_obj.bot.send_message(
                chat_id=user_id,
                text="Операция отменена. Вы можете отправить новое голосовое сообщение.",
                reply_markup=get_main_keyboard(user_data)
            )
        
        # Отправляем предварительный просмотр распознанного текста с возможностью редактирования
        await send_text_preview(
            update=update,
            context=context,
            text=extracted_text,
            operation_type="speech",
            on_confirm=on_text_confirm,
            on_cancel=on_text_cancel
        )
        
    except Exception as e:
        logger.error(f"Error processing voice: {e}", exc_info=True)
        
        # Завершаем индикацию прогресса с ошибкой
        try:
            await complete_progress(
                bot=context.bot,
                chat_id=user_id,
                task_id=task_id,
                final_status="Произошла ошибка",
                success=False
            )
        except Exception:
            pass
            
        # Отправляем сообщение об ошибке
        await update.message.reply_text(
            config.ERROR_MESSAGE,
            reply_markup=get_main_keyboard(user_data)
        )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle callback queries from inline keyboards."""
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    callback_data = query.data
    
    logger.debug(f"Обработка callback_data: {callback_data} от пользователя {user_id}")
    
    try:
        # Обработка административных колбэков
        if callback_data.startswith("admin_"):
            # Сначала проверяем в обычных админ-обработчиках
            from admin_handlers import get_admin_handlers
            admin_static_handlers, admin_dynamic_handlers = get_admin_handlers()
            
            # Проверяем статические обработчики
            if callback_data in admin_static_handlers:
                return await admin_static_handlers[callback_data](update, context)
            
            # Проверяем динамические обработчики админов
            for prefix, dyn_handler in admin_dynamic_handlers.items():
                if callback_data.startswith(prefix):
                    return await dyn_handler(update, context)
            
            # Если обработчик не найден, проверяем в новых обработчиках для анти-фрод системы
            from admin_new_handlers import get_antifraud_admin_handlers, get_antifraud_dynamic_handlers
            antifraud_handlers = get_antifraud_admin_handlers()
            
            if callback_data in antifraud_handlers:
                return await antifraud_handlers[callback_data](update, context)
            
            # Проверяем динамические обработчики анти-фрод системы
            dynamic_handlers = get_antifraud_dynamic_handlers()
            for prefix, dyn_handler in dynamic_handlers.items():
                if callback_data.startswith(prefix):
                    return await dyn_handler(update, context)
        
        # Обработка колбэков для системы вознаграждений и рефералов из новой системы
        from new_referral_code.referral_handlers import get_referral_handlers
        referral_handlers = get_referral_handlers()
        
        if callback_data in referral_handlers:
            return await referral_handlers[callback_data](update, context)
        
        # Стандартные колбэки
        if callback_data == "solve_problem":
            # User clicked "Solve Problem" button from main menu
            # Получаем информацию о платформе
            platform_data = context.user_data.get("platform_info", {})
            platform_type = platform_data.get("platform", "unknown")
            platform_version = platform_data.get("version")
            
            # Используем адаптивное форматирование для сообщения
            message_text, parse_mode = format_adaptive_message(
                config.SEND_PROBLEM_MESSAGE,
                platform_type,
                platform_version
            )
            
            await query.edit_message_text(
                message_text,
                parse_mode=parse_mode
            )
            user_states[user_id] = {'waiting_for_problem': True}
        
        elif callback_data == "subscribe":
            # User clicked "Subscribe" button from main menu
            await query.delete_message()
            await create_manual_activation(update, context)
        
        elif callback_data == "manual_activate":
            # User confirmed manual subscription activation
            await query.delete_message()
            await activate_subscription_command(update, context)
        
        elif callback_data == "buy_subscription" or callback_data == "show_payment_qr":
            # User clicked "Buy Subscription" button
            await query.delete_message()
            from services.payment_service import send_direct_payment_info
            await send_direct_payment_info(update, context)
            
        elif callback_data == "payment_help":
            # User clicked "Help with payment" button
            # Получаем информацию о платформе пользователя
            from datetime import datetime
            from services.platform_detection_service import get_platform_from_update
            from services.platform_data_service import get_message_format_settings, get_emoji, get_platform_compatibility_flags
            from services.payment_service import is_problematic_ios
            
            platform_info = get_platform_from_update(update)
            platform_type = platform_info.get("platform", "unknown")
            platform_version = platform_info.get("version")
            
            # Сохраняем информацию о платформе пользователя если ее еще нет
            from services.platform_detection_service import store_user_platform
            if platform_type != "unknown":
                store_user_platform(update.effective_user.id, platform_info)
            
            # Получаем настройки форматирования и эмодзи с учетом платформы
            format_settings = get_message_format_settings(platform_type, platform_version)
            payment_emoji = get_emoji("payment", platform_type)
            help_emoji = get_emoji("help", platform_type)
            info_emoji = get_emoji("info", platform_type)
            bank_emoji = get_emoji("bank", platform_type)
            card_emoji = get_emoji("card", platform_type)
            alert_emoji = get_emoji("alert", platform_type)
            success_emoji = get_emoji("success", platform_type)
            
            # Получаем флаги совместимости для платформы
            compatibility_flags = get_platform_compatibility_flags(platform_type, platform_version)
            qr_compatible = compatibility_flags.get("qr_compatible", False)
            sbp_compatible = compatibility_flags.get("sbp_compatible", True)
            
            # Проверяем iOS на проблемы с QR-кодами
            problematic_ios_device = platform_type == "ios" and is_problematic_ios(platform_version)
            
            # Формируем помощь с учетом платформы и флагов совместимости
            help_message = f"{info_emoji} *Помощь с оплатой подписки* {info_emoji}\n\n"
            
            # Текст сообщения в зависимости от платформы и совместимости
            if qr_compatible and not problematic_ios_device:
                # Сообщение для совместимых платформ
                help_message += (
                    f"На вашем устройстве ({platform_type}) все функции оплаты должны работать корректно.\n\n"
                    f"*Способы оплаты:*\n"
                    f"1️⃣ {bank_emoji} Нажмите кнопку 'Оплатить через СБП' и следуйте инструкциям\n"
                    f"2️⃣ {card_emoji} Сканируйте QR-код из приложения вашего банка\n\n"
                    f"*Советы:*\n"
                    f"• {success_emoji} Для быстрой оплаты используйте СБП - нажмите на кнопку ниже\n"
                    f"• {success_emoji} Для безналичной оплаты картой нажмите 'Оплатить' и выберите способ 'Банковская карта'\n\n"
                )
            else:
                # Сообщение для несовместимых платформ
                help_message += (
                    f"{alert_emoji} На вашем устройстве ({platform_type}{' '+platform_version if platform_version else ''}) "
                    f"могут возникнуть сложности со сканированием QR-кодов.\n\n"
                    f"*Альтернативные способы оплаты:*\n"
                    f"1️⃣ {bank_emoji} Нажмите кнопку 'Оплатить через СБП' и следуйте инструкциям на открывшейся странице\n"
                )
                
                # Разные инструкции в зависимости от платформы
                if platform_type == "ios":
                    if problematic_ios_device:
                        # Более подробные инструкции для проблемных iOS устройств
                        help_message += (
                            f"2️⃣ {card_emoji} Сохраните QR-код в галерею длинным нажатием → Отсканируйте его из приложения банка\n"
                            f"3️⃣ {bank_emoji} Используйте прямую оплату картой (доступно после нажатия кнопки оплаты)\n"
                        )
                    else:
                        help_message += (
                            f"2️⃣ {card_emoji} Сохраните QR-код в галерею и отсканируйте его из приложения банка\n"
                            f"3️⃣ {bank_emoji} Вы можете использовать стандартный сканер QR-кодов телефона\n"
                        )
                elif platform_type == "android":
                    help_message += (
                        f"2️⃣ {card_emoji} Используйте прямую оплату через СБП или карту\n"
                        f"3️⃣ {bank_emoji} Откройте приложение вашего банка и отсканируйте QR-код напрямую\n"
                    )
                elif platform_type == "desktop":
                    help_message += (
                        f"2️⃣ {card_emoji} Сохраните QR-код и отсканируйте его с мобильного устройства\n"
                        f"3️⃣ {bank_emoji} Используйте прямую оплату картой или электронным кошельком\n"
                    )
                else:
                    help_message += (
                        f"2️⃣ {card_emoji} Сохраните QR-код и отсканируйте его с другого устройства\n"
                        f"3️⃣ {bank_emoji} Вы можете использовать любой удобный способ оплаты из предложенных\n"
                    )
                
                help_message += "\n"
            
            # Для проблемных версий iOS добавляем специальную инструкцию
            if problematic_ios_device:
                help_message += (
                    f"*{alert_emoji} Особенности для iOS {platform_version}:*\n"
                    f"• {help_emoji} Долгое нажатие на QR-код → 'Сохранить изображение'\n"
                    f"• {bank_emoji} Откройте приложение банка → Платежи → Сканировать QR\n"
                    f"• {card_emoji} Выберите сохраненное изображение из галереи\n"
                    f"• {success_emoji} При сложностях используйте альтернативные способы оплаты\n\n"
                )
            
            # Универсальное завершение для всех устройств
            help_message += (
                f"{success_emoji} *После оплаты:*\n"
                f"• Обязательно вернитесь в бот и нажмите 'Активировать подписку после оплаты'\n"
                f"• Подписка активируется автоматически в течение 1-2 минуты после оплаты\n"
                f"• Если подписка не активировалась, нажмите кнопку активации подписки\n"
            )
            
            # Адаптируем сообщение для платформы
            adapted_message = format_adaptive_message(help_message, platform_type, platform_version)
            
            # Клавиатура с кнопками - более адаптивная в зависимости от платформы
            from telegram import InlineKeyboardButton, InlineKeyboardMarkup
            
            # Базовый URL для оплаты через Робокассу
            payment_url = "https://telegrampay.robokassa.ru/Pay/19296?culture=ru"
            
            # Адаптируем URL в зависимости от платформы
            if platform_type in ["ios", "android"]:
                payment_url += "&mobile=true"
            
            # Адаптивная клавиатура в зависимости от типа устройства
            keyboard_buttons = []
            
            # Основные кнопки оплаты в зависимости от платформы
            if sbp_compatible:
                # Для совместимых с СБП устройств
                keyboard_buttons.append([
                    InlineKeyboardButton(f"{payment_emoji} Оплатить через СБП", url=payment_url)
                ])
            else:
                # Для устройств, где лучше использовать оплату картой
                keyboard_buttons.append([
                    InlineKeyboardButton(f"{payment_emoji} Оплатить подписку", url=payment_url)
                ])
            
            # Для мобильных устройств добавляем отдельную кнопку оплаты картой
            if platform_type in ["ios", "android"]:
                keyboard_buttons.append([
                    InlineKeyboardButton(f"{card_emoji} Оплата картой", url=f"{payment_url}&method=card")
                ])
            
            # Если QR совместим, добавляем кнопку показа QR-кода
            if qr_compatible or platform_type != "unknown":
                keyboard_buttons.append([
                    InlineKeyboardButton(f"{help_emoji} Показать QR-код снова", callback_data="show_payment_qr")
                ])
            
            # Добавляем кнопку активации подписки для всех платформ
            keyboard_buttons.append([
                InlineKeyboardButton(f"{success_emoji} Активировать подписку после оплаты", callback_data="activate_subscription")
            ])
            
            keyboard = InlineKeyboardMarkup(keyboard_buttons)
            
            # Используем соответствующий метод форматирования для платформы
            parse_mode = format_settings.get("preferred", "Markdown")
            
            # Записываем информацию о взаимодействии с помощью для аналитики
            from services.db_service import add_transaction
            try:
                add_transaction(
                    transaction_type="subscription_help",
                    user_id=update.effective_user.id,
                    amount=0.0,
                    description=f"Запрос помощи с оплатой (платформа: {platform_type} {platform_version})",
                    status="info",
                    payment_data={
                        "platform_type": platform_type, 
                        "platform_version": platform_version,
                        "qr_compatible": qr_compatible,
                        "sbp_compatible": sbp_compatible,
                        "problematic_ios": problematic_ios_device if platform_type == "ios" else False,
                        "timestamp": datetime.now().isoformat()
                    }
                )
            except Exception as e:
                logger.error(f"Ошибка при создании записи о запросе помощи: {e}")
                
            # Отправляем сообщение с помощью
            await query.edit_message_text(
                text=adapted_message,
                reply_markup=keyboard,
                parse_mode=parse_mode
            )
        
        elif callback_data == "confirm_solve":
            # User confirmed the extracted text for solving
            if user_id in user_states and 'problem' in user_states[user_id]:
                problem = user_states[user_id]['problem']
                await query.delete_message()
                await process_problem(update, context, problem, is_callback=True)
            else:
                # Получаем информацию о платформе
                platform_data = context.user_data.get("platform_info", {})
                platform_type = platform_data.get("platform", "unknown")
                platform_version = platform_data.get("version")
                
                # Используем адаптивное форматирование для сообщения об ошибке
                message_text, parse_mode = format_adaptive_message(
                    "Извините, я не могу найти вашу задачу. Пожалуйста, попробуйте снова.",
                    platform_type,
                    platform_version
                )
                
                await query.edit_message_text(
                    message_text,
                    parse_mode=parse_mode
                )
        
        elif callback_data == "cancel_solve":
            # User cancelled the problem solving
            # Получаем информацию о платформе
            platform_data = context.user_data.get("platform_info", {})
            platform_type = platform_data.get("platform", "unknown")
            platform_version = platform_data.get("version")
            
            # Используем адаптивное форматирование для сообщения об отмене
            message_text, parse_mode = format_adaptive_message(
                "Операция отменена. Вы можете отправить новую задачу в любое время.",
                platform_type,
                platform_version
            )
            
            await query.edit_message_text(
                message_text,
                parse_mode=parse_mode
            )
            if user_id in user_states:
                user_states.pop(user_id, None)
        
        else:
            # Неизвестный callback_data
            logger.warning(f"Неизвестный callback_data: {callback_data} от пользователя {user_id}")
            # По умолчанию просто удаляем или редактируем сообщение
            try:
                # Получаем информацию о платформе
                platform_data = context.user_data.get("platform_info", {})
                platform_type = platform_data.get("platform", "unknown")
                platform_version = platform_data.get("version")
                
                # Используем адаптивное форматирование для сообщения об ошибке
                message_text, parse_mode = format_adaptive_message(
                    "Команда не распознана. Пожалуйста, вернитесь в главное меню.",
                    platform_type,
                    platform_version
                )
                
                await query.edit_message_text(
                    message_text,
                    parse_mode=parse_mode
                )
            except Exception:
                try:
                    await query.delete_message()
                except Exception:
                    pass
                
    except Exception as e:
        logger.error(f"Ошибка при обработке callback_data '{callback_data}': {e}", exc_info=True)
        try:
            # Получаем данные пользователя для адаптивной клавиатуры
            user_data = get_user(user_id)
            
            await context.bot.send_message(
                chat_id=user_id,
                text="Произошла ошибка при обработке вашего запроса. Пожалуйста, попробуйте еще раз.",
                reply_markup=get_main_keyboard(user_data)
            )
        except Exception:
            pass

async def process_problem(update: Update, context: ContextTypes.DEFAULT_TYPE, problem: str, is_callback: bool = False) -> None:
    """Process and solve a math problem."""
    user_id = update.effective_user.id
    
    # Получаем данные пользователя
    user_data = get_user(user_id)
    if not user_data:
        # Если данных нет, создаем нового пользователя
        user = update.effective_user
        user_data = {
            "id": user_id,
            "username": user.username,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "free_request_used": False,
            "subscription_expiry": None,
            "subscription_end": None,
            "referral_code": None,
            "referrer_id": None,
        }
        save_user(user_data)
    
    # Используем централизованный сервис для проверки прав доступа
    from services.subscription_service import can_use_problem_solving
    can_solve, reason = can_use_problem_solving(user_id)
    
    if not can_solve:
        if is_callback:
            await context.bot.send_message(
                chat_id=user_id,
                text=config.SUBSCRIPTION_NEEDED_MESSAGE,
                reply_markup=get_main_keyboard(user_data),
                parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(
                config.SUBSCRIPTION_NEEDED_MESSAGE,
                reply_markup=get_main_keyboard(user_data),
                parse_mode='Markdown'
            )
        return
    
    # Send processing message
    if is_callback:
        processing_msg = await context.bot.send_message(
            chat_id=user_id,
            text=config.PROCESSING_MESSAGE
        )
    else:
        processing_msg = await update.message.reply_text(config.PROCESSING_MESSAGE)
    
    try:
        # Используем адаптивный сервис с учетом платформы пользователя
        logger.info(f"Solving problem for user {user_id}: {problem}")
        
        # Используем платформенно-адаптивный сервис
        from services.platform_adaptive_ai_service import PlatformAdaptiveAIService
        solution = await PlatformAdaptiveAIService.solve_math_problem(user_id, problem)
        
        logger.info(f"Got platform-adapted solution: {solution[:100]}..." if solution else "No solution received")
        
        # Проверяем, что решение не пустое
        if not solution or len(solution.strip()) == 0:
            solution = "Извините, не удалось получить решение. Пожалуйста, проверьте формат задачи и попробуйте снова."
        
        # Используем централизованную логику обработки бесплатного запроса
        from services.subscription_service import has_free_request, use_free_request
        if has_free_request(user_id):
            use_free_request(user_id)
        
        # Send the solution
        await processing_msg.delete()
        
        # Получаем информацию о платформе пользователя
        platform_info = context.user_data.get("platform_info") if context.user_data else None
        if not platform_info:
            # Если нет информации в контексте, пытаемся получить из базы данных
            from services.platform_detection_service import get_user_platform
            platform_db = get_user_platform(user_id)
            platform_type = platform_db.platform_type if platform_db else "unknown"
            platform_version = platform_db.platform_version if platform_db else None
        else:
            platform_type = platform_info.get("platform", "unknown")
            platform_version = platform_info.get("version")
        
        # Используем новый сервис адаптивного форматирования
        message_settings = get_message_format_settings(platform_type, platform_version)
        
        # Используем усовершенствованную функцию для адаптации сообщения с решением
        # из message_formatter_service, импортированную выше
        
        solution_message = adapt_solution_message(
            problem, 
            solution,
            platform_type, 
            platform_version
        )
        
        # Получаем предпочтительный формат из настроек сообщения
        # (HTML или MarkdownV2 в зависимости от платформы)
        parse_mode = message_settings.get("preferred", "HTML")
        
        if is_callback:
            await context.bot.send_message(
                chat_id=user_id,
                text=solution_message,
                reply_markup=get_main_keyboard(user_data),
                parse_mode=parse_mode
            )
        else:
            await update.message.reply_text(
                solution_message,
                reply_markup=get_main_keyboard(user_data),
                parse_mode=parse_mode
            )
    except Exception as e:
        logger.error(f"Error processing problem: {e}")
        await processing_msg.delete()
        
        # Адаптируем сообщение об ошибке под платформу пользователя
        platform_info = context.user_data.get("platform_info") if context.user_data else None
        if not platform_info:
            # Если нет информации в контексте, пытаемся получить из базы данных
            from services.platform_detection_service import get_user_platform
            platform_db = get_user_platform(user_id)
            platform_type = platform_db.platform_type if platform_db else "unknown"
            platform_version = platform_db.platform_version if platform_db else None
        else:
            platform_type = platform_info.get("platform", "unknown")
            platform_version = platform_info.get("version")
        
        # Используем новый сервис адаптивного форматирования сообщений об ошибках
        error_emoji = get_emoji("error", platform_type)
        
        # Адаптируем сообщение об ошибке с помощью нового сервиса
        error_message, parse_mode = format_adaptive_message(
            f"{error_emoji} {config.ERROR_MESSAGE}",
            platform_type,
            platform_version
        )
        
        if is_callback:
            await context.bot.send_message(
                chat_id=user_id,
                text=error_message,
                reply_markup=get_main_keyboard(user_data),
                parse_mode=parse_mode
            )
        else:
            await update.message.reply_text(
                error_message,
                reply_markup=get_main_keyboard(user_data),
                parse_mode=parse_mode
            )

async def activate_subscription_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /activate_subscription command - manually activate subscription after payment
    This is a fallback for when Robokassa webhook doesn't work
    """
    # Импортируем необходимые функции
    from services.payment_service import add_transaction, is_subscription_active
    
    user_id = update.effective_user.id
    
    # Check if user already has active subscription
    user_data = get_user(user_id)
    if is_subscription_active(user_data, user_id):
        expiry_date = datetime.datetime.fromisoformat(user_data['subscription_expiry'])
        
        # Проверяем, откуда пришел запрос - из callback или из сообщения
        if update.callback_query:
            await update.callback_query.message.reply_text(
                f"✅ У вас уже есть *активная подписка* до {expiry_date.strftime('%d.%m.%Y')}.\n\n"
                "Вы можете продолжать пользоваться всеми функциями бота Катюша!",
                reply_markup=get_main_keyboard(user_data),
                parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(
                f"✅ У вас уже есть *активная подписка* до {expiry_date.strftime('%d.%m.%Y')}.\n\n"
                "Вы можете продолжать пользоваться всеми функциями бота Катюша!",
                reply_markup=get_main_keyboard(user_data),
                parse_mode='Markdown'
            )
        return
    
    # Проверяем, пришел ли запрос от текущего месяца
    # это простая проверка для минимизации случаев активации без оплаты
    current_month = datetime.datetime.now().month
    if safe_get_user_data(context, 'last_activation_month', None) == current_month:
        # Если уже была активация в этом месяце, проверяем "баланс активаций"
        if safe_get_user_data(context, 'monthly_activations', 0) >= 1:
            # Проверяем, откуда пришел запрос - из callback или из сообщения
            if update.callback_query:
                await update.callback_query.message.reply_text(
                    "⚠️ *Превышение лимита активаций*\n\n"
                    "Система обнаружила, что вы уже активировали подписку в этом месяце.\n"
                    "Если вы считаете, что произошла ошибка, напишите в поддержку.\n\n"
                    "Если вы хотите активировать подписку для другого пользователя, пожалуйста, "
                    "воспользуйтесь его аккаунтом.",
                    reply_markup=get_main_keyboard(user_data),
                    parse_mode='Markdown'
                )
            else:
                await update.message.reply_text(
                    "⚠️ *Превышение лимита активаций*\n\n"
                    "Система обнаружила, что вы уже активировали подписку в этом месяце.\n"
                    "Если вы считаете, что произошла ошибка, напишите в поддержку.\n\n"
                    "Если вы хотите активировать подписку для другого пользователя, пожалуйста, "
                    "воспользуйтесь его аккаунтом.",
                    reply_markup=get_main_keyboard(user_data),
                    parse_mode='Markdown'
                )
            return
        
    # Update user's subscription status
    now = datetime.datetime.now()
    expiry_date = now + datetime.timedelta(days=config.SUBSCRIPTION_DURATION_DAYS)
    
    # Получаем больше информации о пользователе для транзакции, с защитой от None
    user_info = {
        'username': update.effective_user.username or 'unknown',
        'first_name': update.effective_user.first_name or 'unknown',
        'last_name': update.effective_user.last_name or 'unknown',
    }
    
    # Создаем расширенные детали платежа для записи в транзакцию
    payment_data = {
        'payment_method': 'manual_activation',
        'payment_date': now.isoformat(),
        'expiry_date': expiry_date.isoformat(),
        'source': 'telegram_command',
        'platform': 'telegram',
        'user_info': user_info,
        'plan': 'monthly',
        'price': config.SUBSCRIPTION_PRICE / 100.0,
        'currency': 'RUB',
        'client_ip': getattr(update, 'get_client_ip', lambda: 'unknown')(),
    }
    
    # Добавляем запись о платеже в транзакции
    transaction_id = add_transaction(
        transaction_type="subscription_payment",
        user_id=user_id,
        amount=config.SUBSCRIPTION_PRICE / 100.0,  # Цена в рублях
        description="Ручная активация подписки через команду /activate_subscription",
        status="completed",
        payment_data=payment_data
    )
    
    if transaction_id:
        logger.info(f"Added transaction {transaction_id} for manual subscription activation from user {user_id}")
    else:
        logger.warning(f"Failed to add transaction for manual subscription activation from user {user_id}")
    
    # Обновляем подписку пользователя
    update_user_subscription(user_id, expiry_date.isoformat())
    
    # Обновляем счетчик активаций для этого месяца используя безопасную функцию
    safe_update_user_data(context, {
        'last_activation_month': now.month,
        'monthly_activations': safe_get_user_data(context, 'monthly_activations', 0) + 1
    })
    
    # Обработка реферальных вознаграждений напрямую из новой системы
    try:
        from new_referral_code.referral_handlers import process_subscription_rewards
        rewards_result = await process_subscription_rewards(user_id, config.SUBSCRIPTION_PRICE / 100.0)
        logger.info(f"Processed referral rewards for user {user_id}: {rewards_result}")
    except Exception as e:
        logger.error(f"Error processing referral rewards: {e}")
    
    # Получаем информацию о транзакции для уведомления
    from webhook_handler import send_subscription_notification
    
    # Отправляем уведомление через общую функцию для согласованности
    try:
        await send_subscription_notification(user_id, transaction_id, payment_data)
        logger.info(f"Sent subscription notification to user {user_id}")
    except Exception as e:
        logger.error(f"Error sending subscription notification: {e}")
        
        # Запасной вариант, если не удалось вызвать общую функцию уведомления
        success_message = (
            "✅ *Спасибо за оплату!* Ваша подписка успешно активирована до "
            f"{expiry_date.strftime('%d.%m.%Y')}.\n\n"
            "Теперь вы можете *неограниченно* пользоваться ботом Катюша!\n\n"
            "🔹 *Что вы можете делать с подпиской:*\n"
            "• Решать неограниченное количество математических задач\n"
            "• Отправлять фотографии задач для распознавания текста\n"
            "• Отправлять голосовые сообщения для решения задач\n\n"
            "🔹 *Как использовать бота:*\n"
            "• Просто напишите свою задачу в чат\n"
            "• Или нажмите кнопку \"Решить задачу\" и следуйте инструкциям\n"
            "• Загрузите фото с задачей или отправьте голосовое сообщение\n\n"
            "Приятного использования! 🎓✨"
        )
        
        # Проверяем, откуда пришел запрос - из callback или из сообщения
        # Получаем обновленные данные пользователя после активации подписки
        updated_user_data = get_user(user_id)
        
        if update.callback_query:
            await update.callback_query.message.reply_text(
                success_message,
                reply_markup=get_main_keyboard(updated_user_data),
                parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(
                success_message,
                reply_markup=get_main_keyboard(updated_user_data),
                parse_mode='Markdown'
            )
    
    logger.info(f"Manual subscription activation for user {user_id} until {expiry_date.isoformat()}")

def is_subscription_active(user_data: Optional[Dict[str, Any]], user_id: Optional[int] = None) -> bool:
    """
    Check if a user has an active subscription with platform-specific adaptations.
    
    Args:
        user_data: User data dictionary
        user_id: Optional user ID, if available, for platform detection
        
    Returns:
        bool: True if subscription is active, False otherwise
    """
    # Если есть ID пользователя, используем платформо-зависимую проверку
    if user_id:
        from services.payment_service import get_platform_aware_subscription_status
        return get_platform_aware_subscription_status(user_id, user_data)
    
    # Иначе делаем стандартную проверку
    if not user_data or 'subscription_expiry' not in user_data or not user_data['subscription_expiry']:
        return False
    
    try:
        expiry_date = datetime.datetime.fromisoformat(user_data['subscription_expiry'])
        return datetime.datetime.now() < expiry_date
    except (ValueError, TypeError):
        return False

async def invite_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /invite command - generate and show referral link
    """
    # Делегируем выполнение обработчику из новой реферальной системы напрямую
    from new_referral_code.referral_handlers import invite_command as new_invite_command
    await new_invite_command(update, context)

async def process_referral(update: Update, context: ContextTypes.DEFAULT_TYPE, referral_code: str) -> None:
    """
    Process referral when a user comes from a referral link
    
    Args:
        update: Telegram update
        context: Telegram context
        referral_code: Referral code from the link
    """
    # Делегируем выполнение обработчику из новой реферальной системы напрямую
    from new_referral_code.referral_handlers import process_referral as new_process_referral
    await new_process_referral(update, context, referral_code)

async def error_handler(update, context):
    """Log errors caused by updates."""
    logger.error(f"Update {update} caused error: {context.error}")