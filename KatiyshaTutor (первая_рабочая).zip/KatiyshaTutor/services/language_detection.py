#!/usr/bin/env python
# coding: utf-8

"""
Сервис для определения языка текста
Используется для автоматического определения языка в OCR и распознавании речи
"""

import os
import re
import logging
from logging.handlers import RotatingFileHandler
from typing import Dict, Tuple

# Настройка оптимизированного логирования
logger = logging.getLogger(__name__)

# Определяем уровень логирования в зависимости от среды
is_production = os.environ.get('ENVIRONMENT') == 'production'
log_level = logging.INFO if is_production else logging.DEBUG
logger.setLevel(log_level)

# Создаем обработчик для вывода в консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(log_level)

# Создаем обработчик для ротации файлов логов
log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')
os.makedirs(log_dir, exist_ok=True)
file_handler = RotatingFileHandler(
    os.path.join(log_dir, 'language_detection.log'),
    maxBytes=10*1024*1024,  # 10 МБ
    backupCount=5
)
file_handler.setLevel(log_level)

# Определяем формат сообщений
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)

# Добавляем обработчики к логгеру
logger.addHandler(console_handler)
logger.addHandler(file_handler)

# Словари символов для разных языков
LANGUAGE_PATTERNS = {
    'ru': re.compile(r'[а-яА-ЯёЁ]'),    # Русский
    'en': re.compile(r'[a-zA-Z]'),      # Английский
    'de': re.compile(r'[äöüÄÖÜß]'),     # Немецкий
    'fr': re.compile(r'[àâçéèêëîïôùûüÿÀÂÇÉÈÊËÎÏÔÙÛÜŸ]'),  # Французский
    'es': re.compile(r'[áéíóúüñÁÉÍÓÚÜÑ]'),  # Испанский
    'it': re.compile(r'[àèéìòóùÀÈÉÌÒÓÙ]'),  # Итальянский
    'zh': re.compile(r'[\u4e00-\u9fff]'),    # Китайский
    'ja': re.compile(r'[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]'),  # Японский
    'ko': re.compile(r'[\uac00-\ud7af]'),    # Корейский
    'ar': re.compile(r'[\u0600-\u06ff]'),    # Арабский
}

# Соответствие языков для OCR
OCR_LANGUAGE_CODES = {
    'ru': 'rus',
    'en': 'eng',
    'de': 'deu',
    'fr': 'fra',
    'es': 'spa',
    'it': 'ita',
    'zh': 'chi_sim',
    'ja': 'jpn',
    'ko': 'kor',
    'ar': 'ara',
}

# Соответствие языков для Google Speech Recognition
SPEECH_LANGUAGE_CODES = {
    'ru': 'ru-RU',
    'en': 'en-US',
    'de': 'de-DE',
    'fr': 'fr-FR',
    'es': 'es-ES',
    'it': 'it-IT',
    'zh': 'zh-CN',
    'ja': 'ja-JP',
    'ko': 'ko-KR',
    'ar': 'ar-SA',
}

def detect_language(text: str, default_language: str = 'ru') -> Tuple[str, float]:
    """
    Определяет язык текста по характерным символам
    
    Args:
        text: Текст для анализа
        default_language: Язык по умолчанию, если не удалось определить
        
    Returns:
        Tuple[str, float]: Кортеж из кода языка и уверенности (0.0-1.0)
    """
    if not text:
        logger.warning("Empty text provided for language detection")
        return default_language, 0.0
        
    # Подсчитываем количество характерных символов для каждого языка
    language_counts: Dict[str, int] = {lang: 0 for lang in LANGUAGE_PATTERNS.keys()}
    
    # Проходим по тексту и считаем символы
    for char in text:
        for lang, pattern in LANGUAGE_PATTERNS.items():
            if pattern.match(char):
                language_counts[lang] += 1
                
    # Если нет характерных символов ни для одного языка, возвращаем английский
    total_chars = sum(language_counts.values())
    if total_chars == 0:
        # Если нет характерных символов, проверяем, содержит ли текст латинские буквы
        # Если да, то скорее всего это английский
        if re.search(r'[a-zA-Z]', text):
            return 'en', 0.6
        return default_language, 0.0
        
    # Находим язык с наибольшим количеством характерных символов
    most_common_language = max(language_counts.items(), key=lambda x: x[1])
    language_code = most_common_language[0]
    confidence = most_common_language[1] / total_chars
    
    logger.debug(f"Detected language: {language_code} with confidence {confidence:.2f}")
    logger.debug(f"Language counts: {language_counts}")
    
    # Если уверенность меньше порога, возвращаем язык по умолчанию
    if confidence < 0.3:
        logger.info(f"Low confidence ({confidence:.2f}) in language detection, using default: {default_language}")
        return default_language, confidence
        
    return language_code, confidence

def get_ocr_language_code(text_sample: str = None) -> str:
    """
    Возвращает код языка для OCR на основе образца текста
    
    Args:
        text_sample: Образец текста для определения языка (если None, используется русский)
        
    Returns:
        str: Код языка для OCR
    """
    if text_sample:
        language_code, confidence = detect_language(text_sample)
        return OCR_LANGUAGE_CODES.get(language_code, 'rus')
    return 'rus'  # По умолчанию используем русский

def get_speech_language_code(text_sample: str = None) -> str:
    """
    Возвращает код языка для распознавания речи на основе образца текста
    
    Args:
        text_sample: Образец текста для определения языка (если None, используется русский)
        
    Returns:
        str: Код языка для распознавания речи
    """
    if text_sample:
        language_code, confidence = detect_language(text_sample)
        return SPEECH_LANGUAGE_CODES.get(language_code, 'ru-RU')
    return 'ru-RU'  # По умолчанию используем русский