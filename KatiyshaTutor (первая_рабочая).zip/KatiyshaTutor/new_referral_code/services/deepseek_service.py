#!/usr/bin/env python
# coding: utf-8

"""
Service for interacting with AI models through ProxyAPI to solve math problems
Supports DeepSeek, OpenAI and local fallback mechanisms
"""

import os
import json
import logging
import traceback
import aiohttp
import config

# Настройка расширенного логирования
logger = logging.getLogger(__name__)
# Установка уровня логирования (DEBUG - самый подробный)
logger.setLevel(logging.DEBUG)
# Создаем обработчик для вывода в консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
# Определяем формат сообщений
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
# Добавляем обработчик к логгеру
logger.addHandler(console_handler)

# Конфигурация API
PROXY_API_KEY = config.PROXYAPI_KEY

# API URLs для разных моделей через ProxyAPI
SERVICES = {
    "deepseek": {
        "url": "https://api.proxyapi.ru/openai/v1/chat/completions",  # DeepSeek API не работает, используем URL OpenAI
        "model": "deepseek-chat",
        "active": False  # DeepSeek API отключен из-за проблем с доступностью
    },
    "openai": {
        "url": "https://api.proxyapi.ru/openai/v1/chat/completions", 
        "model": "gpt-4o",
        "active": True  # OpenAI API доступен и работает через ProxyAPI
    }
}

# Тестовые URL для различных форматов ProxyAPI
TEST_URLS = [
    # OpenAI форматы
    "https://api.proxyapi.ru/openai/v1/chat/completions",
    "https://api.proxyapi.ru/openai/v1/completions",
    # DeepSeek форматы
    "https://api.proxyapi.ru/deepseek/v1/chat/completions",
    "https://api.proxyapi.ru/deepseek/v1/completions",
    # Альтернативные форматы
    "https://api.proxyapi.ru/api/v1/chat/completions",
    "https://api.proxyapi.ru/v1/chat/completions",
    # Базовые URL
    "https://api.proxyapi.ru/chat/completions"
]

# Счетчик и временная метка последней успешной проверки ключа API
API_STATUS = {
    "last_success_time": 0,
    "consecutive_failures": 0, 
    "is_testing_mode": False  # Режим тестирования - пробовать все URL каждый раз
}

# Логирование информации о настроенных сервисах
logger.info(f"ProxyAPI Key: {PROXY_API_KEY[:5]}..." if PROXY_API_KEY else "ProxyAPI Key not set")
for name, service in SERVICES.items():
    logger.info(f"Service {name}: URL={service['url']}, model={service['model']}, active={service['active']}")

async def solve_math_problem(problem_text: str) -> str:
    """
    Solve a math problem using the optimal API service:
    1. Uses OpenAI API (GPT-4o) through ProxyAPI (working solution)
    2. Returns a friendly error message if API fails
    
    Args:
        problem_text: The math problem to solve
        
    Returns:
        str: The solution to the problem or error message
    """
    import time
    
    logger.info(f"Solving math problem: {problem_text[:50]}...")
    logger.info(f"API status: {API_STATUS}")
    
    # Если у нас было слишком много последовательных ошибок, временно пропускаем вызовы API
    if not API_STATUS["is_testing_mode"] and API_STATUS["consecutive_failures"] >= 5:
        # Проверяем, прошло ли достаточно времени с последней неудачной попытки
        current_time = int(time.time())
        time_since_last_attempt = current_time - API_STATUS["last_success_time"]
        
        # Если прошло менее 5 минут с последней попытки и у нас много ошибок, не вызываем API
        if time_since_last_attempt < 300:  # 5 минут в секундах
            logger.error(f"Skipping API calls due to too many consecutive failures: {API_STATUS['consecutive_failures']}")
            return """⚠️ Сервис временно перегружен. 

Наши AI-сервисы временно недоступны из-за технических проблем с доступом к API. 
Система автоматически восстановится через несколько минут.

Пожалуйста, повторите запрос через 5-10 минут."""
    
    # Формируем запрос для модели
    prompt = config.SOLUTION_PROMPT.format(problem=problem_text)
    
    # Используем OpenAI через ProxyAPI (работающий метод)
    if SERVICES["openai"]["active"]:
        try:
            logger.info("Solving with OpenAI via ProxyAPI...")
            solution = await solve_with_api("openai", prompt)
            if solution:
                # Сбрасываем счетчик ошибок при успехе
                API_STATUS["consecutive_failures"] = 0
                API_STATUS["last_success_time"] = int(time.time())
                return solution
        except Exception as e:
            logger.error(f"OpenAI API failed: {str(e)}")
            SERVICES["openai"]["active"] = False  # Отмечаем сервис как неактивный
            API_STATUS["consecutive_failures"] += 1
    else:
        logger.warning("OpenAI is not available, trying to restore connection...")
        # Пробуем восстановить соединение
        for test_url in TEST_URLS:
            try:
                logger.info(f"Testing URL: {test_url} for OpenAI...")
                success, solution, error = await test_proxyapi_url(test_url, SERVICES["openai"]["model"], "2+2=?")
                if success:
                    logger.info(f"Found working URL: {test_url}")
                    SERVICES["openai"]["url"] = test_url
                    SERVICES["openai"]["active"] = True
                    
                    # Теперь пробуем решить исходную задачу
                    solution = await solve_with_api("openai", prompt)
                    if solution:
                        API_STATUS["consecutive_failures"] = 0
                        API_STATUS["last_success_time"] = int(time.time())
                        return solution
                    break
            except Exception:
                continue
    
    # Если API недоступно, сообщаем пользователю
    logger.error(f"API failed, returning error message. Consecutive failures: {API_STATUS['consecutive_failures']}")
    
    # Сбрасываем состояние для следующих попыток
    SERVICES["openai"]["active"] = True
    
    return """⚠️ В данный момент сервис временно недоступен. 

К сожалению, AI-модели для решения математических задач сейчас не работают из-за технических ограничений доступа к API. 

Наша команда уже работает над:
1) Обновлением ключей доступа к API
2) Настройкой альтернативных провайдеров
3) Восстановлением работы сервиса

Пожалуйста, попробуйте повторить запрос позже.

Для бесперебойного доступа в будущем, мы рекомендуем:
• Следить за обновлениями в канале бота
• Сообщить о проблеме администратору, если она повторяется
• Заранее благодарим за понимание и терпение!"""

async def test_proxyapi_url(url, model, prompt) -> tuple:
    """
    Проверяет работу ProxyAPI с разными URL форматами
    
    Args:
        url: URL для проверки
        model: Модель для использования
        prompt: Запрос для отправки
        
    Returns:
        tuple: (success: bool, solution: str, error: str)
    """
    try:
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {PROXY_API_KEY}"
        }
        
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": "Ты математический помощник, который помогает решать задачи. Твои ответы лаконичны, ясны и содержательны. Используй только обычный текст без LaTeX и специальных символов."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.3,
            "max_tokens": 1000
        }
        
        logger.info(f"Testing URL: {url} with model: {model}")
        
        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers, json=payload) as response:
                response_text = await response.text()
                
                if response.status == 200:
                    try:
                        data = json.loads(response_text)
                        solution = data.get("choices", [{}])[0].get("message", {}).get("content", "")
                        if solution:
                            logger.info(f"Success with URL: {url}")
                            return True, solution, ""
                        else:
                            return False, "", "Empty solution"
                    except json.JSONDecodeError:
                        return False, "", f"Invalid JSON response: {response_text[:100]}..."
                else:
                    logger.error(f"API error: {response.status} - {response_text[:200]}...")
                    return False, "", f"HTTP {response.status}: {response_text[:100]}..."
    except Exception as e:
        logger.error(f"Error testing URL {url}: {str(e)}")
        return False, "", str(e)

async def solve_with_api(service_name: str, prompt: str) -> str:
    """
    Solve a problem using the specified API service
    
    Args:
        service_name: Name of the service to use (as defined in SERVICES)
        prompt: Problem prompt to send to the API
        
    Returns:
        str: Solution or empty string if failed
    """
    try:
        service = SERVICES[service_name]
        api_url = service["url"]
        model = service["model"]
        
        logger.info(f"Making API request to {service_name} model={model} using URL={api_url}...")
        
        # Сначала пробуем заданный URL для сервиса
        success, solution, error = await test_proxyapi_url(api_url, model, prompt)
        if success:
            return solution
        
        logger.warning(f"Failed with primary URL: {api_url}. Error: {error}")
        logger.info("Trying alternative URL formats...")
        
        # Если основной URL не сработал, пробуем альтернативные форматы
        for test_url in TEST_URLS:
            if test_url != api_url:  # Не повторяем уже протестированный URL
                success, solution, error = await test_proxyapi_url(test_url, model, prompt)
                if success:
                    # Обновляем URL для данного сервиса, чтобы использовать его в будущем
                    SERVICES[service_name]["url"] = test_url
                    logger.info(f"Updated {service_name} URL to: {test_url}")
                    return solution
        
        # Если все URL не сработали, возвращаем пустую строку
        logger.error(f"All URL formats failed for {service_name}")
        return ""
    
    except Exception as e:
        logger.error(f"Error using {service_name}: {str(e)}")
        logger.error(traceback.format_exc())
        return ""

# Сервисная функция для тестирования доступности ProxyAPI
async def test_proxyapi_status():
    """
    Тестирует доступность ProxyAPI с текущим ключом и всеми доступными URL-форматами
    Обновляет глобальные настройки сервисов на основе полученных результатов
    
    Returns:
        bool: True если хотя бы один сервис доступен, False если все недоступны
    """
    test_prompt = "Реши задачу: 2+2=?"
    
    logger.info("Testing ProxyAPI availability...")
    logger.info(f"Current services configuration: {SERVICES}")
    
    # Временно включаем режим тестирования
    old_testing_mode = API_STATUS["is_testing_mode"]
    API_STATUS["is_testing_mode"] = True
    
    # Сбрасываем активность сервисов для тестирования
    for service_name in SERVICES:
        SERVICES[service_name]["active"] = True
    
    # Пробуем DeepSeek
    logger.info("Testing DeepSeek...")
    deepseek_solution = await solve_with_api("deepseek", test_prompt)
    deepseek_works = bool(deepseek_solution)
    
    # Пробуем OpenAI
    logger.info("Testing OpenAI...")
    openai_solution = await solve_with_api("openai", test_prompt)
    openai_works = bool(openai_solution)
    
    # Восстанавливаем режим тестирования
    API_STATUS["is_testing_mode"] = old_testing_mode
    
    # Обновляем состояние API_STATUS на основе результатов
    if deepseek_works or openai_works:
        API_STATUS["consecutive_failures"] = 0
        import time
        API_STATUS["last_success_time"] = int(time.time())
        logger.info("At least one API service is working")
    else:
        API_STATUS["consecutive_failures"] += 1
        logger.error(f"All API services failed. Consecutive failures: {API_STATUS['consecutive_failures']}")
    
    logger.info(f"Test results - DeepSeek: {deepseek_works}, OpenAI: {openai_works}")
    logger.info(f"Updated services configuration: {SERVICES}")
    logger.info(f"Updated API status: {API_STATUS}")
    
    return deepseek_works or openai_works

# Заметка: встроенный решатель удален по запросу пользователя
# Бот теперь полностью зависит от внешних API-сервисов для решения задач