#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для добавления новых полей в таблицу payout_operation_logs
"""

import sys
import logging
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import text
from db_config import get_flask_app
from db_models import db

# Настройка логгера
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def add_new_fields_to_payout_operation_logs():
    """
    Добавляет новые поля в таблицу payout_operation_logs для поддержки атомарных операций
    """
    try:
        # Выполняем SQL запросы напрямую для добавления полей
        queries = [
            # Универсальные поля ID сущности
            text("ALTER TABLE payout_operation_logs ADD COLUMN IF NOT EXISTS entity_id BIGINT"),
            text("ALTER TABLE payout_operation_logs ADD COLUMN IF NOT EXISTS entity_type VARCHAR(50)"),
            
            # Поля для идентификации источника операции
            text("ALTER TABLE payout_operation_logs ADD COLUMN IF NOT EXISTS source_user_id BIGINT"),
            text("ALTER TABLE payout_operation_logs ADD COLUMN IF NOT EXISTS amount FLOAT"),
            
            # Поле для хранения метаданных
            text("ALTER TABLE payout_operation_logs ADD COLUMN IF NOT EXISTS operation_metadata JSONB"),
            
            # Поле для отслеживания обновлений
            text("ALTER TABLE payout_operation_logs ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
        ]
        
        for query in queries:
            db.session.execute(query)
        
        # Проверяем, существует ли уже функция update_timestamp
        check_function_query = text("SELECT 1 FROM pg_proc WHERE proname = 'update_timestamp'")
        result = db.session.execute(check_function_query).fetchone()
        
        # Если функция не существует, создаем её
        if not result:
            create_function_query = text("""
            CREATE OR REPLACE FUNCTION update_timestamp()
            RETURNS TRIGGER AS $$
            BEGIN
                NEW.updated_at = CURRENT_TIMESTAMP;
                RETURN NEW;
            END;
            $$ LANGUAGE plpgsql;
            """)
            db.session.execute(create_function_query)
        
        # Добавляем триггер для автоматического обновления updated_at
        trigger_query = text("""
        DO $$
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_payout_operation_logs_timestamp') THEN
                CREATE TRIGGER update_payout_operation_logs_timestamp
                BEFORE UPDATE ON payout_operation_logs
                FOR EACH ROW
                EXECUTE FUNCTION update_timestamp();
            END IF;
        END
        $$;
        """)
        
        # Создаем триггер
        db.session.execute(trigger_query)
        
        # Коммит всех изменений
        db.session.commit()
        logger.info("Успешно добавлены новые поля в таблицу payout_operation_logs")
        return True
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Ошибка при добавлении полей: {e}")
        return False
    except Exception as e:
        db.session.rollback()
        logger.error(f"Непредвиденная ошибка: {e}")
        return False

def main():
    """
    Основная функция
    """
    try:
        app = get_flask_app()
        with app.app_context():
            success = add_new_fields_to_payout_operation_logs()
            if not success:
                sys.exit(1)
    except Exception as e:
        logger.error(f"Ошибка: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()