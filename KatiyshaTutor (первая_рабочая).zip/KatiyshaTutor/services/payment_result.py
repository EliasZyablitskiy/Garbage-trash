#!/usr/bin/env python
# coding: utf-8

"""
Класс PaymentResult для унификации результатов проверки платежей
Предоставляет универсальный интерфейс для результатов из разных платежных систем
"""

import json
import logging
from typing import Dict, Any, Optional, List, Union
from datetime import datetime
from enum import Enum

from services.payment_constants import PAYMENT_STATUS, PAYMENT_SYSTEMS

# Настройка логирования
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Создание обработчика для вывода в консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

# Создание файлового обработчика
import os
os.makedirs('logs', exist_ok=True)
file_handler = logging.FileHandler('logs/payment_result.log')
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

# Импортируем PaymentResultCode из centralized модуля
from services.payment_constants import PaymentResultCode

class PaymentResult:
    """
    Универсальный класс для результатов проверки платежей
    """
    
    def __init__(self, 
                 success: bool = False,
                 payment_system: Optional[str] = None,
                 transaction_id: Optional[int] = None,
                 user_id: Optional[int] = None,
                 amount: Optional[float] = None,
                 status: Optional[str] = None,
                 result_code: PaymentResultCode = PaymentResultCode.UNKNOWN,
                 message: str = "",
                 raw_data: Optional[Dict[str, Any]] = None,
                 additional_data: Optional[Dict[str, Any]] = None,
                 payment_link: Optional[str] = None):
        """
        Инициализация результата проверки платежа
        
        Args:
            success: Успешность проверки
            payment_system: Платежная система (из PAYMENT_SYSTEMS)
            transaction_id: ID транзакции в нашей системе
            user_id: ID пользователя
            amount: Сумма платежа
            status: Статус платежа (из PAYMENT_STATUS)
            result_code: Код результата (из ResultCode)
            message: Сообщение о результате
            raw_data: Исходные данные от платежной системы
            additional_data: Дополнительные данные для обработки
            payment_link: Ссылка для повторной оплаты, если платеж не был успешным
        """
        self.success = success
        self.payment_system = payment_system
        self.transaction_id = transaction_id
        self.user_id = user_id
        self.amount = amount
        self.status = status
        self.result_code = result_code
        self.message = message
        self.raw_data = raw_data or {}
        self.additional_data = additional_data or {}
        self.payment_link = payment_link
        self.created_at = datetime.now()
        self.logs = []
        
        # Добавляем первую запись в лог
        self.add_log(f"PaymentResult created: success={success}, system={payment_system}, code={result_code.name}")
    
    def add_log(self, message: str) -> None:
        """
        Добавление записи в лог результата
        
        Args:
            message: Сообщение для добавления в лог
        """
        self.logs.append({
            "timestamp": datetime.now().isoformat(),
            "message": message
        })
        logger.info(f"[PaymentResult] {message}")
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Преобразование результата в словарь
        
        Returns:
            Dict[str, Any]: Словарь с данными результата
        """
        return {
            "success": self.success,
            "payment_system": self.payment_system,
            "transaction_id": self.transaction_id,
            "user_id": self.user_id,
            "amount": self.amount,
            "status": self.status,
            "result_code": self.result_code.name,
            "message": self.message,
            "created_at": self.created_at.isoformat(),
            "logs": self.logs,
            "additional_data": self.additional_data
        }
    
    def to_json(self) -> str:
        """
        Преобразование результата в JSON
        
        Returns:
            str: JSON-строка с данными результата
        """
        return json.dumps(self.to_dict(), ensure_ascii=False, default=str)
    
    @classmethod
    def from_robokassa_notification(cls, notification_data: Dict[str, Any], validation_result: dict) -> 'PaymentResult':
        """
        Создание результата из уведомления Robokassa
        
        Args:
            notification_data: Данные уведомления от Robokassa
            validation_result: Результат валидации уведомления
            
        Returns:
            PaymentResult: Результат проверки платежа
        """
        success = validation_result.get('success', False)
        transaction_id = validation_result.get('transaction_id')
        user_id = validation_result.get('user_id')
        message = validation_result.get('message', '')
        
        # Определяем код результата
        result_code = PaymentResultCode.SUCCESS if success else PaymentResultCode.UNKNOWN
        
        if not success:
            if 'signature' in message.lower():
                result_code = PaymentResultCode.SECURITY_ERROR
            elif 'not found' in message.lower():
                result_code = PaymentResultCode.PAYMENT_NOT_FOUND
            elif 'amount mismatch' in message.lower():
                result_code = PaymentResultCode.INVALID_AMOUNT
            elif 'database' in message.lower():
                result_code = PaymentResultCode.DATABASE_ERROR
            elif 'duplicate' in message.lower():
                result_code = PaymentResultCode.DUPLICATE
        
        # Получаем сумму из уведомления
        amount = None
        if 'OutSum' in notification_data:
            try:
                amount = float(notification_data['OutSum'])
            except (ValueError, TypeError):
                pass
        
        # Собираем дополнительные данные о платеже
        additional_data = {
            'validation_result': validation_result,
            'notification_timestamp': datetime.now().isoformat(),
            'inv_id': notification_data.get('InvId', ''),
            'shp_user': notification_data.get('Shp_user', '')
        }
        
        # Добавляем информацию о платформе, если она есть
        if 'Shp_platform' in notification_data:
            additional_data['platform'] = notification_data.get('Shp_platform')
        
        # Создаем результат
        result = cls(
            success=success,
            payment_system=PAYMENT_SYSTEMS['ROBOKASSA'],
            transaction_id=transaction_id,
            user_id=user_id,
            amount=amount,
            status=PAYMENT_STATUS['COMPLETED'] if success else None,
            result_code=result_code,
            message=message,
            raw_data=notification_data,
            additional_data=additional_data
        )
        
        # Добавляем информацию о полученных данных в лог
        inv_id = notification_data.get('InvId', 'N/A')
        result.add_log(f"Processed Robokassa notification for InvId={inv_id}, result={success}")
        
        # Добавляем информацию о пользователе, если она есть
        if user_id:
            result.add_log(f"Notification for user_id={user_id}")
        
        # Добавляем информацию о сумме, если она есть
        if amount:
            result.add_log(f"Payment amount: {amount}")
        
        return result
    
    @classmethod
    def from_sbp_notification(cls, notification_data: Dict[str, Any], validation_result: dict) -> 'PaymentResult':
        """
        Создание результата из уведомления СБП
        
        Args:
            notification_data: Данные уведомления от СБП
            validation_result: Результат валидации уведомления
            
        Returns:
            PaymentResult: Результат проверки платежа
        """
        success = validation_result.get('success', False)
        transaction_id = validation_result.get('transaction_id')
        user_id = validation_result.get('user_id')
        message = validation_result.get('message', '')
        
        # Определяем код результата
        result_code = PaymentResultCode.SUCCESS if success else PaymentResultCode.UNKNOWN
        
        if not success:
            if 'not found' in message.lower():
                result_code = PaymentResultCode.PAYMENT_NOT_FOUND
            elif 'amount' in message.lower():
                result_code = PaymentResultCode.INVALID_AMOUNT
            elif 'database' in message.lower():
                result_code = PaymentResultCode.DATABASE_ERROR
            elif 'duplicate' in message.lower():
                result_code = PaymentResultCode.DUPLICATE
            elif 'expired' in message.lower():
                result_code = PaymentResultCode.EXPIRED
            elif 'cancelled' in message.lower() or 'canceled' in message.lower():
                result_code = PaymentResultCode.FAILED
        
        # Получаем сумму и статус из уведомления
        amount = None
        status = None
        
        if 'amount' in notification_data:
            try:
                amount = float(notification_data['amount'])
            except (ValueError, TypeError):
                pass
        
        # Маппинг статусов СБП на наши статусы
        sbp_status = notification_data.get('status', '').lower()
        status_mapping = {
            'pending': PAYMENT_STATUS['PENDING'],
            'processing': PAYMENT_STATUS['PENDING'],
            'completed': PAYMENT_STATUS['COMPLETED'],
            'success': PAYMENT_STATUS['COMPLETED'],
            'failed': PAYMENT_STATUS['FAILED'],
            'error': PAYMENT_STATUS['FAILED'],
            'canceled': PAYMENT_STATUS['CANCELLED'],
            'cancelled': PAYMENT_STATUS['CANCELLED'],
            'expired': PAYMENT_STATUS['EXPIRED']
        }
        
        status = status_mapping.get(sbp_status, None)
        
        # Собираем дополнительные данные о платеже
        additional_data = {
            'validation_result': validation_result,
            'notification_timestamp': datetime.now().isoformat(),
            'payment_id': notification_data.get('payment_id', ''),
            'order_id': notification_data.get('order_id', ''),
            'sbp_status': sbp_status
        }
        
        # Добавляем информацию о платформе, если она есть
        if 'platform' in notification_data:
            additional_data['platform'] = notification_data.get('platform')
        
        # Создаем результат
        result = cls(
            success=success,
            payment_system=PAYMENT_SYSTEMS['SBP_LINK'],
            transaction_id=transaction_id,
            user_id=user_id,
            amount=amount,
            status=status,
            result_code=result_code,
            message=message,
            raw_data=notification_data,
            additional_data=additional_data
        )
        
        # Добавляем информацию о полученных данных в лог
        payment_id = notification_data.get('payment_id', notification_data.get('order_id', 'N/A'))
        result.add_log(f"Processed SBP notification for payment_id={payment_id}, result={success}")
        
        # Добавляем информацию о пользователе, если она есть
        if user_id:
            result.add_log(f"Notification for user_id={user_id}")
        
        # Добавляем информацию о сумме, если она есть
        if amount:
            result.add_log(f"Payment amount: {amount}")
        
        # Добавляем информацию о статусе платежа
        if status:
            result.add_log(f"Payment status: {status}")
        
        return result
    
    @classmethod
    def error(cls, message: str, result_code: PaymentResultCode = PaymentResultCode.UNKNOWN, 
              payment_system: Optional[str] = None) -> 'PaymentResult':
        """
        Создание результата с ошибкой
        
        Args:
            message: Сообщение об ошибке
            result_code: Код результата
            payment_system: Платежная система
            
        Returns:
            PaymentResult: Результат с ошибкой
        """
        result = cls(
            success=False,
            payment_system=payment_system,
            result_code=result_code,
            message=message
        )
        
        result.add_log(f"Error result created: {message}")
        
        return result
    
    @classmethod
    def create_success(cls, transaction_id: int, status: str, message: str = "Операция выполнена успешно",
                payment_system: Optional[str] = None, additional_data: Optional[Dict[str, Any]] = None) -> 'PaymentResult':
        """
        Создание успешного результата
        
        Args:
            transaction_id: ID транзакции
            status: Статус платежа
            message: Сообщение о результате
            payment_system: Платежная система
            additional_data: Дополнительные данные
            
        Returns:
            PaymentResult: Успешный результат
        """
        result = cls(
            success=True,
            payment_system=payment_system,
            transaction_id=transaction_id,
            status=status,
            result_code=PaymentResultCode.SUCCESS,
            message=message,
            additional_data=additional_data
        )
        
        result.add_log(f"Success result created for transaction {transaction_id}")
        
        return result