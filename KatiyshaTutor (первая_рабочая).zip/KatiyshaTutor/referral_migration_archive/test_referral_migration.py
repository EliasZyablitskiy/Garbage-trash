#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для тестирования миграции реферальной системы
Проверяет работоспособность основных функций новой реферальной системы
и сравнивает с результатами старой системы для проверки корректности миграции
"""

import os
import json
import asyncio
import logging
from typing import Dict, Any, List, Tuple, Optional

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Импортируем новый сервис реферальной системы
from services.referral_service import referral_service
from new_referral_code.referral_manager import ReferralManager

# Пути к базам данных
OLD_DB_PATH = "users_db.json"
NEW_DB_PATH = "users_db.json"  # Тот же путь, так как миграция in-place

class ReferralTester:
    """Класс для тестирования реферальной системы"""
    
    def __init__(self):
        """Инициализация тестера"""
        self.results = {
            "code_generation": {
                "success": 0,
                "failure": 0,
                "duplicate": 0
            },
            "referral_process": {
                "success": 0,
                "failure": 0,
                "self_referral": 0
            },
            "reward_calculation": {
                "success": 0,
                "failure": 0,
                "mismatch": 0
            },
            "total_users": 0,
            "total_referrals": 0,
            "users_with_referrers": 0,
            "users_with_referrals": 0
        }
        # Создаем экземпляр новой реферальной системы для тестирования
        self.referral_manager = ReferralManager(database_path=NEW_DB_PATH)
        self._load_test_data()
    
    def _load_test_data(self) -> None:
        """Загрузка тестовых данных из базы"""
        try:
            self.db = self.referral_manager.load_database()
            logger.info(f"Loaded test database with {len(self.db.get('users', {}))} users")
            self.results["total_users"] = len(self.db.get("users", {}))
        except Exception as e:
            logger.error(f"Failed to load test database: {e}")
            self.db = {"users": {}}
    
    async def test_code_generation(self, num_tests: int = 10) -> Dict[str, Any]:
        """
        Тестирование генерации реферальных кодов
        
        Args:
            num_tests: Количество тестов для выполнения
            
        Returns:
            Dict[str, Any]: Результаты тестирования
        """
        logger.info(f"Testing referral code generation (n={num_tests})")
        
        generated_codes = set()
        
        for i in range(num_tests):
            try:
                # Генерируем случайный ID пользователя для теста
                test_user_id = 1000000 + i
                
                # Генерируем реферальный код, используя новую систему
                code = self.referral_manager.generate_referral_code(test_user_id)
                
                # Проверяем, что код соответствует ожидаемому формату
                if not code.startswith("ref_") or len(code) < 8:
                    logger.warning(f"Code format check failed: {code}")
                    self.results["code_generation"]["failure"] += 1
                    continue
                
                # Проверяем на дубликаты
                if code in generated_codes:
                    logger.warning(f"Duplicate code detected: {code}")
                    self.results["code_generation"]["duplicate"] += 1
                    continue
                
                # Добавляем код в набор
                generated_codes.add(code)
                self.results["code_generation"]["success"] += 1
                
            except Exception as e:
                logger.error(f"Error in code generation test {i}: {e}")
                self.results["code_generation"]["failure"] += 1
        
        logger.info(f"Code generation test results: {self.results['code_generation']}")
        return self.results["code_generation"]
    
    async def test_referral_process(self, num_tests: int = 5) -> Dict[str, Any]:
        """
        Тестирование процесса обработки рефералов
        
        Args:
            num_tests: Количество тестов для выполнения
            
        Returns:
            Dict[str, Any]: Результаты тестирования
        """
        logger.info(f"Testing referral processing (n={num_tests})")
        
        # Создаем тестовых пользователей для проверки
        for i in range(num_tests):
            try:
                # Создаем данные реферера
                referrer_id = 2000000 + i
                referrer_data = {
                    "id": referrer_id,
                    "username": f"test_referrer_{i}",
                    "first_name": "Test",
                    "last_name": "Referrer",
                    "free_request_used": False,
                    "subscription_expiry": None,
                    "referrals": {
                        "level1": [],
                        "level2": [],
                        "level3": [],
                        "level4": []
                    }
                }
                
                # Генерируем реферальный код, используя новую систему
                referrer_data["referral_code"] = self.referral_manager.generate_referral_code(referrer_id)
                
                # Сохраняем реферера, используя новую систему
                self.referral_manager.save_user(referrer_data)
                
                # Создаем данные реферала
                referral_id = 3000000 + i
                
                # Обрабатываем реферальный код, используя новую систему
                success = self.referral_manager.process_new_referral(referral_id, referrer_data["referral_code"])
                
                if success:
                    self.results["referral_process"]["success"] += 1
                    
                    # Проверяем корректность структуры, используя новую систему
                    referrer_updated = self.referral_manager.get_user(referrer_id)
                    referral_updated = self.referral_manager.get_user(referral_id)
                    
                    # Проверка наличия реферала в уровне 1 реферера
                    if referral_id not in referrer_updated["referrals"]["level1"]:
                        logger.warning(f"Referral {referral_id} not found in referrer's level1 list")
                        
                    # Проверка установки referrer_id у реферала
                    if referral_updated.get("referrer_id") != referrer_id:
                        logger.warning(f"Referral {referral_id} has incorrect referrer_id: {referral_updated.get('referrer_id')}")
                else:
                    self.results["referral_process"]["failure"] += 1
                
                # Проверка защиты от самореферралов, используя новую систему
                self_referral_success = self.referral_manager.process_new_referral(referrer_id, referrer_data["referral_code"])
                if self_referral_success:
                    self.results["referral_process"]["self_referral"] += 1
                    logger.warning(f"Self-referral check failed for user {referrer_id}")
            
            except Exception as e:
                logger.error(f"Error in referral process test {i}: {e}")
                self.results["referral_process"]["failure"] += 1
        
        logger.info(f"Referral process test results: {self.results['referral_process']}")
        return self.results["referral_process"]
    
    async def test_reward_calculation(self, num_tests: int = 3) -> Dict[str, Any]:
        """
        Тестирование расчета вознаграждений
        
        Args:
            num_tests: Количество тестов для выполнения
            
        Returns:
            Dict[str, Any]: Результаты тестирования
        """
        logger.info(f"Testing reward calculation (n={num_tests})")
        
        # Создаем цепочку рефералов для тестирования
        for i in range(num_tests):
            try:
                # Создаем новую базу данных для каждого теста
                # для гарантированной изоляции тестов друг от друга
                test_db_file = f"test_users_db_{i}.json"
                
                # Создаем новую базу с начальной структурой
                test_db = {"users": {}}
                with open(test_db_file, "w") as f:
                    json.dump(test_db, f)
                
                # Создаем отдельный экземпляр сервиса реферальной системы
                test_referral_service = ReferralManager(database_path=test_db_file)
                
                # Создаем новый уникальный идентификатор для каждого тестового прогона
                # Используем числа в диапазоне нескольких миллионов,
                # чтобы гарантированно избежать конфликтов с существующими пользователями
                test_id_base = 5000000 + (i + 1) * 100000
                
                # Создаем цепочку: level1 <- level2 <- level3 <- level4 <- user
                user_ids = {
                    "level1": test_id_base + 1,
                    "level2": test_id_base + 2,
                    "level3": test_id_base + 3,
                    "level4": test_id_base + 4,
                    "user": test_id_base + 5
                }
                
                # Создаем всех пользователей в цепочке
                for level, user_id in user_ids.items():
                    user_data = {
                        "id": user_id,
                        "username": f"test_{level}_{i}",
                        "first_name": f"Test {level}",
                        "last_name": "User",
                        "free_request_used": False,
                        "subscription_expiry": None,
                        "referral_code": f"ref_test_{level}_{i}",  # Уникальный, предсказуемый код
                        "referrals": {
                            "level1": [],
                            "level2": [],
                            "level3": [],
                            "level4": []
                        }
                    }
                    
                    # Устанавливаем реферера для всех, кроме level1,
                    # гарантированно используя целочисленные значения
                    if level != "level1":
                        previous_level = "level" + str(int(level[-1]) - 1)
                        user_data["referrer_id"] = int(user_ids[previous_level])
                        logger.info(f"Устанавливаем referrer_id={user_data['referrer_id']} для пользователя {user_id}")
                    else:
                        # Явно устанавливаем referrer_id как None для level1
                        user_data["referrer_id"] = None
                        logger.info(f"Устанавливаем referrer_id=None для пользователя {user_id}")
                    
                    # Сохраняем пользователя
                    test_referral_service.save_user(user_data)
                
                # Настраиваем структуру рефералов вручную для гарантии правильности
                # в отдельной тестовой базе
                for level_idx in range(1, 4):  # Уровни 1-3
                    current_level = f"level{level_idx}"
                    next_level = f"level{level_idx+1}"
                    
                    if current_level in user_ids and next_level in user_ids:
                        current_id = user_ids[current_level]
                        next_id = user_ids[next_level]
                        
                        # Получаем текущего пользователя из тестовой базы
                        ref_data = test_referral_service.get_user(current_id)
                        if ref_data and "referrals" in ref_data:
                            # Добавляем связь
                            if next_id not in ref_data["referrals"]["level1"]:
                                ref_data["referrals"]["level1"].append(next_id)
                                test_referral_service.save_user(ref_data)
                                logger.info(f"Добавлена связь: {current_id} -> {next_id}")
                                
                # Устанавливаем реферральную связь между level4 и user
                if "level4" in user_ids and "user" in user_ids:
                    level4_id = user_ids["level4"]
                    user_id = user_ids["user"]
                    
                    ref_data = test_referral_service.get_user(level4_id)
                    if ref_data and "referrals" in ref_data:
                        if user_id not in ref_data["referrals"]["level1"]:
                            ref_data["referrals"]["level1"].append(user_id)
                            test_referral_service.save_user(ref_data)
                            logger.info(f"Добавлена связь: {level4_id} -> {user_id}")
                
                # Распечатаем все содержимое базы для отладки
                logger.info("========= Отладка начало ===========")
                try:
                    with open("users_db.json", "r") as f:
                        db_content = json.load(f)
                        for user_str, user_data in db_content.get("users", {}).items():
                            referrer_id = user_data.get("referrer_id")
                            if isinstance(referrer_id, str) and referrer_id.startswith("r"):
                                logger.info(f"Найдена проблемная запись: user_id={user_str}, referrer_id={referrer_id}")
                                
                                # Исправляем запись прямо здесь
                                numeric_part = ''.join(c for c in referrer_id if c.isdigit())
                                if numeric_part:
                                    db_content["users"][user_str]["referrer_id"] = int(numeric_part)
                                    logger.info(f"Исправлено на: {int(numeric_part)}")
                                
                    # Сохраняем исправленную базу
                    with open("users_db.json", "w") as f:
                        json.dump(db_content, f, indent=2)
                    logger.info("База данных была исправлена")
                except Exception as e:
                    logger.error(f"Ошибка при исправлении базы: {e}")
                
                logger.info("========= Отладка конец ===========")
                
                # Рассчитываем ожидаемые вознаграждения
                # В новой системе, каждый уровень с ID реферера соответствует определенному проценту
                expected_rewards = {
                    user_ids["level1"]: round(199.0 * 0.05, 2),
                    user_ids["level2"]: round(199.0 * 0.02, 2),
                    user_ids["level3"]: round(199.0 * 0.02, 2),
                    user_ids["level4"]: round(199.0 * 0.01, 2)
                }
                
                # Рассчитываем вознаграждения
                try:
                    user_id = user_ids["user"]
                    logger.info(f"Вызываем calculate_rewards для пользователя {user_id}")
                    
                    # Используем тестовый экземпляр сервиса с нашей изолированной базой данных
                    test_db = test_referral_service.load_database()
                    user_data = test_db["users"].get(str(user_id))
                    
                    referrer_id = user_data.get("referrer_id") if user_data else None
                    logger.info(f"Данные пользователя ID={user_id}: referrer_id={referrer_id}, тип={type(referrer_id)}")
                    
                    # Если у пользователя есть реферер, проверяем его данные
                    if referrer_id:
                        referrer_data = test_db["users"].get(str(referrer_id))
                        if referrer_data:
                            logger.info(f"Данные реферера ID={referrer_id}: {referrer_data.get('referrer_id')}")
                        else:
                            logger.error(f"Не найден реферер с ID={referrer_id}")
                            
                    # Проверяем всю цепочку рефералов в базе
                    logger.info("Проверка цепочки рефералов в тестовой базе")
                    chain = []
                    current_id = referrer_id
                    while current_id:
                        chain.append(current_id)
                        current_data = test_db["users"].get(str(current_id))
                        if not current_data:
                            logger.error(f"Не найден пользователь с ID={current_id} в цепочке рефералов")
                            break
                            
                        next_id = current_data.get("referrer_id")
                        logger.info(f"Уровень в цепочке: ID={current_id}, referrer_id={next_id}, тип={type(next_id)}")
                        
                        if next_id in chain:
                            logger.warning(f"Зацикливание в цепочке рефералов на ID={next_id}")
                            break
                            
                        if not next_id:
                            break
                            
                        current_id = next_id
                    
                    # Теперь вызываем функцию расчета вознаграждений с нашим тестовым экземпляром
                    # В ReferralManager возвращается словарь {user_id: reward}
                    rewards = test_referral_service.calculate_rewards(user_id)
                except Exception as e:
                    # Получаем данные пользователя для отладки
                    user_data = test_referral_service.get_user(user_ids["user"]) 
                    referrer_id = user_data.get("referrer_id") if user_data else None
                    logger.error(f"Ошибка при расчете вознаграждений: {e}")
                    logger.error(f"Данные пользователя: {user_data}")
                    
                    # Проверим цепочку рефереров
                    if user_data and referrer_id:
                        referrer_data = test_referral_service.get_user(referrer_id)
                        logger.error(f"Данные реферера: {referrer_data}")
                        
                        if referrer_data and referrer_data.get("referrer_id"):
                            next_referrer_id = referrer_data.get("referrer_id")
                            next_referrer_data = test_referral_service.get_user(next_referrer_id)
                            logger.error(f"Данные реферера 2-го уровня: {next_referrer_data}")
                    
                    # Анализируем структуру тестовой базы данных
                    logger.error("Анализ содержимого тестовой базы данных:")
                    with open(test_db_file, "r") as f:
                        db_content = json.load(f)
                        user_entries = len(db_content.get("users", {}))
                        logger.error(f"Всего пользователей в базе: {user_entries}")
                        
                        # Выбираем до 5 пользователей для анализа
                        sample_count = min(5, user_entries)
                        for idx, (user_str, user_data) in enumerate(db_content.get("users", {}).items()):
                            if idx >= sample_count:
                                break
                            ref_id = user_data.get("referrer_id")
                            logger.error(f"Пользователь {user_str}: referrer_id={ref_id}, тип={type(ref_id)}")
                    
                    raise
                
                # Проверяем результаты
                # В новой системе rewards - это словарь {user_id: reward_amount}
                mismatch = False
                logger.info(f"Полученные вознаграждения: {rewards}")
                logger.info(f"Ожидаемые вознаграждения: {expected_rewards}")
                
                # Проверяем, что все ожидаемые вознаграждения присутствуют
                for referrer_id, expected_amount in expected_rewards.items():
                    if referrer_id not in rewards:
                        logger.warning(f"Missing reward for referrer {referrer_id} in calculated rewards")
                        mismatch = True
                        continue
                    
                    actual_amount = rewards[referrer_id]
                    if abs(actual_amount - expected_amount) > 0.01:
                        logger.warning(f"Reward amount mismatch for referrer {referrer_id}: expected {expected_amount}, got {actual_amount}")
                        mismatch = True
                
                if mismatch:
                    self.results["reward_calculation"]["mismatch"] += 1
                else:
                    self.results["reward_calculation"]["success"] += 1
            
            except Exception as e:
                logger.error(f"Error in reward calculation test {i}: {e}")
                self.results["reward_calculation"]["failure"] += 1
        
        logger.info(f"Reward calculation test results: {self.results['reward_calculation']}")
        return self.results["reward_calculation"]
    
    async def test_stats_gathering(self) -> Dict[str, Any]:
        """
        Тестирование сбора статистики по реферальной системе
        
        Returns:
            Dict[str, Any]: Результаты тестирования
        """
        logger.info("Testing referral stats gathering")
        
        try:
            # Загружаем базу данных используя новую систему
            db = self.referral_manager.load_database()
            users = db.get("users", {})
            
            # Подсчитываем статистику
            total_referrals = 0
            users_with_referrers = 0
            users_with_referrals = 0
            
            for user_id, user_data in users.items():
                # Подсчитываем пользователей с реферерами
                if user_data.get("referrer_id"):
                    users_with_referrers += 1
                
                # Подсчитываем пользователей с рефералами
                referrals = user_data.get("referrals", {})
                has_referrals = False
                
                for level in range(1, 5):
                    level_key = f"level{level}"
                    level_referrals = referrals.get(level_key, [])
                    
                    if level_referrals and len(level_referrals) > 0:
                        has_referrals = True
                        total_referrals += len(level_referrals)
                
                if has_referrals:
                    users_with_referrals += 1
            
            self.results["total_referrals"] = total_referrals
            self.results["users_with_referrers"] = users_with_referrers
            self.results["users_with_referrals"] = users_with_referrals
            
            logger.info(f"Stats gathering results:")
            logger.info(f"  Total users: {self.results['total_users']}")
            logger.info(f"  Total referrals: {total_referrals}")
            logger.info(f"  Users with referrers: {users_with_referrers}")
            logger.info(f"  Users with referrals: {users_with_referrals}")
        
        except Exception as e:
            logger.error(f"Error in stats gathering test: {e}")
        
        return {
            "total_users": self.results["total_users"],
            "total_referrals": self.results["total_referrals"],
            "users_with_referrers": self.results["users_with_referrers"],
            "users_with_referrals": self.results["users_with_referrals"]
        }
    
    async def run_all_tests(self) -> Dict[str, Any]:
        """
        Запуск всех тестов
        
        Returns:
            Dict[str, Any]: Результаты всех тестов
        """
        logger.info("Starting all referral system tests")
        
        # Запускаем тесты
        await self.test_code_generation()
        await self.test_referral_process()
        await self.test_reward_calculation()
        await self.test_stats_gathering()
        
        # Суммируем результаты
        summary = {
            "code_generation": self.results["code_generation"],
            "referral_process": self.results["referral_process"],
            "reward_calculation": self.results["reward_calculation"],
            "stats": {
                "total_users": self.results["total_users"],
                "total_referrals": self.results["total_referrals"],
                "users_with_referrers": self.results["users_with_referrers"],
                "users_with_referrals": self.results["users_with_referrals"]
            }
        }
        
        success_rate = (
            self.results["code_generation"]["success"] +
            self.results["referral_process"]["success"] +
            self.results["reward_calculation"]["success"]
        ) / (
            sum(self.results["code_generation"].values()) +
            sum(self.results["referral_process"].values()) +
            sum(self.results["reward_calculation"].values())
        ) * 100 if (
            sum(self.results["code_generation"].values()) +
            sum(self.results["referral_process"].values()) +
            sum(self.results["reward_calculation"].values())
        ) > 0 else 0
        
        summary["success_rate"] = round(success_rate, 2)
        
        logger.info(f"All tests completed. Overall success rate: {summary['success_rate']}%")
        return summary

async def main() -> None:
    """Основная функция для запуска тестов"""
    try:
        tester = ReferralTester()
        results = await tester.run_all_tests()
        
        # Выводим результаты в JSON
        print(json.dumps(results, indent=2))
        
        # Оцениваем общую успешность тестов
        if results["success_rate"] >= 90:
            logger.info("✅ Тестирование прошло успешно")
        elif results["success_rate"] >= 70:
            logger.warning("⚠️ Тестирование прошло с предупреждениями")
        else:
            logger.error("❌ Тестирование выявило серьезные проблемы")
    
    except Exception as e:
        logger.error(f"Error during test execution: {e}")

if __name__ == "__main__":
    # Запускаем тесты
    asyncio.run(main())