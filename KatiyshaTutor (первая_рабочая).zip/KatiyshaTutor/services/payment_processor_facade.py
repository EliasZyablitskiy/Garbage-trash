#!/usr/bin/env python
# coding: utf-8

"""
Фасад процессора платежей
Предоставляет централизованный интерфейс для обработки платежей различных типов
"""

import os
import json
import logging
import hashlib
import uuid
import random
import time
from datetime import datetime, timedelta
from typing import Dict, Any, Tuple, Optional, List, Union
from flask import current_app, Flask

from db_models import db, Transaction, User
from config import SUBSCRIPTION_DURATION_DAYS as SUBSCRIPTION_DAYS, SUBSCRIPTION_PRICE
from services.payment_constants import PAYMENT_STATUS, PAYMENT_SYSTEMS, PaymentResultCode

# Настройка логирования
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Создание обработчика для вывода в консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

# Создание файлового обработчика
import os
os.makedirs('logs', exist_ok=True)
file_handler = logging.FileHandler('logs/payment_processor.log')
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

# Получаем секреты для платежных систем
ROBOKASSA_SECRET_KEY = os.environ.get('ROBOKASSA_SECRET_KEY', '')
ROBOKASSA_LOGIN = os.environ.get('ROBOKASSA_LOGIN', 'test_shop')
ROBOKASSA_PASSWORD1 = os.environ.get('ROBOKASSA_PASSWORD1', '')
ROBOKASSA_PASSWORD2 = os.environ.get('ROBOKASSA_PASSWORD2', '')

# URL для платежных систем
ROBOKASSA_URL = "https://auth.robokassa.ru/Merchant/Index.aspx"
SBP_BASE_URL = os.environ.get('SBP_BASE_URL', 'https://api.example.com/sbp')
APP_BASE_URL = os.environ.get('APP_BASE_URL', 'https://katiysha.bot')

class PaymentProcessorFacade:
    """
    Фасад для работы с платежными системами
    """
    
    def __init__(self):
        """
        Инициализация фасада
        """
        self.app = None
        
        # Предустановленные реквизиты для ручных платежей
        self.manual_payment_details = {
            'account': '40817810100000123456',
            'bank_name': 'Тинькофф Банк',
            'recipient': 'Иванов Иван Иванович'
        }
        
    def init_app(self, app: Flask):
        """
        Инициализация приложения Flask
        
        Args:
            app: Flask-приложение
        """
        self.app = app
        
        with app.app_context():
            logger.info("Payment processor facade initialized with Flask application context")
    
    def create_payment_for_user(self, user_id: int, 
                               preferred_method: str = PAYMENT_SYSTEMS['SBP_LINK'],
                               amount: float = SUBSCRIPTION_PRICE,
                               description: str = "Подписка на бота Катюша") -> Tuple[bool, str, Optional[int]]:
        """
        Создание платежа для пользователя
        
        Args:
            user_id: ID пользователя
            preferred_method: Предпочтительный метод оплаты
            amount: Сумма платежа
            description: Описание платежа
            
        Returns:
            Tuple[bool, str, Optional[int]]: Кортеж (успех, сообщение, ID транзакции)
        """
        try:
            # Получаем пользователя
            user = User.query.get(user_id)
            
            if not user:
                logger.warning(f"User {user_id} not found")
                return False, f"Пользователь с ID {user_id} не найден", None
            
            # Проверяем тип платежа и создаем соответствующую транзакцию
            if preferred_method == PAYMENT_SYSTEMS['ROBOKASSA']:
                return self._create_robokassa_payment(user_id, amount, description)
            
            elif preferred_method in [PAYMENT_SYSTEMS['SBP_LINK'], PAYMENT_SYSTEMS['SBP_LINK_AUTO'], PAYMENT_SYSTEMS['SBP_LINK_DESKTOP']]:
                return self._create_sbp_payment(user_id, amount, description, preferred_method)
            
            else:
                logger.warning(f"Unknown payment method: {preferred_method}")
                return False, f"Неизвестный метод оплаты: {preferred_method}", None
            
        except Exception as e:
            logger.error(f"Error creating payment for user {user_id}: {str(e)}")
            return False, f"Ошибка при создании платежа: {str(e)}", None
    
    def check_payment_status(self, transaction_id: int) -> Tuple[bool, str, Dict[str, Any]]:
        """
        Проверка статуса платежа
        
        Args:
            transaction_id: ID транзакции
            
        Returns:
            Tuple[bool, str, Dict[str, Any]]: Кортеж (успех, сообщение, данные о платеже)
        """
        try:
            # Получаем транзакцию по ID
            transaction = Transaction.query.get(transaction_id)
            
            if not transaction:
                logger.warning(f"Transaction {transaction_id} not found")
                return False, f"Транзакция {transaction_id} не найдена", {}
            
            # Проверяем, не истек ли срок ожидания платежа
            if transaction.status == PAYMENT_STATUS['INITIATED'] and transaction.payment_expires_at:
                if datetime.now() > transaction.payment_expires_at:
                    # Обновляем статус на "EXPIRED"
                    from services.payment_verification_service_v2 import payment_verification_service_v2
                    
                    payment_verification_service_v2.update_payment_status(
                        transaction_id=transaction_id,
                        new_status=PAYMENT_STATUS['EXPIRED'],
                        additional_data={
                            'expired_at': datetime.now().isoformat(),
                            'reason': 'Payment timeout expired'
                        }
                    )
                    
                    transaction = Transaction.query.get(transaction_id)
            
            # Если платеж в статусе "PENDING", проверяем его статус через API платежной системы
            if transaction.status == PAYMENT_STATUS['PENDING']:
                payment_method = transaction.payment_method
                
                if payment_method == PAYMENT_SYSTEMS['ROBOKASSA']:
                    # Для Robokassa используем внешний API для проверки статуса
                    # Это реализовано в отдельном сервисе и вызывается периодически
                    pass
                
                elif payment_method in [PAYMENT_SYSTEMS['SBP_LINK'], PAYMENT_SYSTEMS['SBP_LINK_AUTO'], PAYMENT_SYSTEMS['SBP_LINK_DESKTOP']]:
                    # Для СБП проверяем статус через API банка
                    # Это также реализовано в отдельном сервисе
                    pass
            
            # Формируем данные о транзакции
            transaction_data = {
                'id': transaction.id,
                'user_id': transaction.user_id,
                'amount': transaction.amount,
                'description': transaction.description,
                'payment_method': transaction.payment_method,
                'status': transaction.status,
                'created_at': transaction.created_at.isoformat() if transaction.created_at else None,
                'updated_at': transaction.updated_at.isoformat() if transaction.updated_at else None,
                'completed_at': transaction.completed_at.isoformat() if transaction.completed_at else None,
                'payment_expires_at': transaction.payment_expires_at.isoformat() if transaction.payment_expires_at else None,
                'metadata': transaction.metadata or {}
            }
            
            # Получаем текстовые описания статусов
            status_messages = {
                PAYMENT_STATUS['INITIATED']: "Платеж создан и ожидает оплаты",
                PAYMENT_STATUS['PENDING']: "Платеж в обработке",
                PAYMENT_STATUS['COMPLETED']: "Платеж успешно выполнен",
                PAYMENT_STATUS['FAILED']: "Ошибка при обработке платежа",
                PAYMENT_STATUS['CANCELLED']: "Платеж отменен",
                PAYMENT_STATUS['EXPIRED']: "Время ожидания платежа истекло"
            }
            
            # Формируем сообщение в зависимости от статуса
            message = status_messages.get(transaction.status, f"Неизвестный статус: {transaction.status}")
            
            return True, message, transaction_data
            
        except Exception as e:
            logger.error(f"Error checking payment status for transaction {transaction_id}: {str(e)}")
            return False, f"Ошибка при проверке статуса платежа: {str(e)}", {}
    
    def _create_robokassa_payment(self, user_id: int, amount: float,
                                 description: str) -> Tuple[bool, str, Optional[int]]:
        """
        Создание платежа через Robokassa
        
        Args:
            user_id: ID пользователя
            amount: Сумма платежа
            description: Описание платежа
            
        Returns:
            Tuple[bool, str, Optional[int]]: Кортеж (успех, сообщение, ID транзакции)
        """
        try:
            # Проверяем наличие секретов Robokassa
            if not ROBOKASSA_SECRET_KEY or not ROBOKASSA_LOGIN:
                logger.warning("Robokassa credentials are not set")
                return False, "Реквизиты Robokassa не настроены. Пожалуйста, выберите другой способ оплаты.", None
            
            # Создаем уникальный идентификатор заказа
            inv_id = int(time.time() * 1000) % 1_000_000_000
            
            # Создаем подпись для Robokassa
            signature = self._generate_robokassa_signature(amount, inv_id, user_id)
            
            # Создаем метаданные платежа
            metadata = {
                'robokassa_inv_id': str(inv_id),
                'robokassa_signature': signature,
                'user_id': str(user_id)
            }
            
            # Создаем платежную ссылку
            payment_link = f"{ROBOKASSA_URL}?MerchantLogin={ROBOKASSA_LOGIN}&OutSum={amount:.2f}&InvId={inv_id}&SignatureValue={signature}&Desc={description}&IsTest=1&Culture=ru"
            
            # Добавляем payment_link в метаданные
            metadata['payment_link'] = payment_link
            
            # Импортируем сервис верификации платежей для создания транзакции
            from services.payment_verification_service_v2 import payment_verification_service_v2
            
            # Создаем транзакцию
            success, message, transaction_id = payment_verification_service_v2.create_payment_transaction(
                user_id=user_id,
                amount=amount,
                payment_method=PAYMENT_SYSTEMS['ROBOKASSA'],
                description=description,
                metadata=metadata
            )
            
            if not success:
                logger.error(f"Failed to create payment transaction: {message}")
                return False, message, None
            
            # Отправляем пользователю уведомление с платежной ссылкой
            try:
                # Импортируем здесь, чтобы избежать циклических импортов
                from services.notification_service import send_payment_link_notification
                import asyncio
                
                # Получаем информацию о платформе пользователя
                platform_type = "unknown"
                platform_version = None
                
                # Если есть информация о платформе, получаем ее
                from services.platform_detection_service import get_user_platform_info
                platform_info = get_user_platform_info(user_id)
                if platform_info:
                    platform_type = platform_info.get('platform_type', 'unknown')
                    platform_version = platform_info.get('platform_version')
                
                # Создаем и запускаем корутину для отправки уведомления
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                loop.run_until_complete(
                    send_payment_link_notification(
                        user_id=user_id,
                        transaction_id=transaction_id,
                        payment_method=PAYMENT_SYSTEMS['ROBOKASSA'],
                        payment_link=payment_link,
                        platform_type=platform_type,
                        platform_version=platform_version
                    )
                )
                
                loop.close()
                
            except Exception as e:
                logger.error(f"Error sending payment notification: {str(e)}")
                # Продолжаем выполнение, даже если не удалось отправить уведомление
            
            return True, "Платеж успешно создан", transaction_id
            
        except Exception as e:
            logger.error(f"Error creating Robokassa payment: {str(e)}")
            return False, f"Ошибка при создании платежа через Robokassa: {str(e)}", None
    
    def _create_sbp_payment(self, user_id: int, amount: float,
                          description: str, 
                          payment_method: str = PAYMENT_SYSTEMS['SBP_LINK']) -> Tuple[bool, str, Optional[int]]:
        """
        Создание платежа через СБП
        
        Args:
            user_id: ID пользователя
            amount: Сумма платежа
            description: Описание платежа
            payment_method: Метод оплаты СБП
            
        Returns:
            Tuple[bool, str, Optional[int]]: Кортеж (успех, сообщение, ID транзакции)
        """
        try:
            # Создаем уникальный идентификатор заказа
            order_id = f"SBP-{user_id}-{int(time.time())}"
            
            # Определяем тип СБП-платежа в зависимости от payment_method
            if payment_method == PAYMENT_SYSTEMS['SBP_LINK_AUTO']:
                # Платеж через СБП с автоматическим выбором банка
                payment_url = f"{APP_BASE_URL}/payment/sbp/{user_id}/{order_id}?auto_redirect=true"
            elif payment_method == PAYMENT_SYSTEMS['SBP_LINK_DESKTOP']:
                # Платеж через СБП для десктопных устройств (QR код)
                payment_url = f"{APP_BASE_URL}/payment/sbp/{user_id}/{order_id}?qr_only=true"
            else:
                # Обычный платеж через СБП
                payment_url = f"{APP_BASE_URL}/payment/sbp/{user_id}/{order_id}"
            
            # Создаем метаданные платежа
            metadata = {
                'order_id': order_id,
                'payment_link': payment_url,
                'payment_type': payment_method
            }
            
            # Импортируем сервис верификации платежей для создания транзакции
            from services.payment_verification_service_v2 import payment_verification_service_v2
            
            # Создаем транзакцию
            success, message, transaction_id = payment_verification_service_v2.create_payment_transaction(
                user_id=user_id,
                amount=amount,
                payment_method=payment_method,
                description=description,
                metadata=metadata
            )
            
            if not success:
                logger.error(f"Failed to create payment transaction: {message}")
                return False, message, None
            
            # Обновляем платежную ссылку, добавляя ID транзакции
            payment_url = f"{payment_url}&transaction_id={transaction_id}"
            
            # Обновляем метаданные с новой платежной ссылкой
            transaction = Transaction.query.get(transaction_id)
            if transaction:
                metadata = transaction.metadata or {}
                metadata['payment_link'] = payment_url
                transaction.metadata = metadata
                db.session.commit()
            
            # Отправляем пользователю уведомление с платежной ссылкой
            try:
                # Импортируем здесь, чтобы избежать циклических импортов
                from services.notification_service import send_payment_link_notification
                import asyncio
                
                # Получаем информацию о платформе пользователя
                platform_type = "unknown"
                platform_version = None
                
                # Если есть информация о платформе, получаем ее
                from services.platform_detection_service import get_user_platform_info
                platform_info = get_user_platform_info(user_id)
                if platform_info:
                    platform_type = platform_info.get('platform_type', 'unknown')
                    platform_version = platform_info.get('platform_version')
                
                # Создаем и запускаем корутину для отправки уведомления
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                loop.run_until_complete(
                    send_payment_link_notification(
                        user_id=user_id,
                        transaction_id=transaction_id,
                        payment_method=payment_method,
                        payment_link=payment_url,
                        platform_type=platform_type,
                        platform_version=platform_version
                    )
                )
                
                loop.close()
                
            except Exception as e:
                logger.error(f"Error sending payment notification: {str(e)}")
                # Продолжаем выполнение, даже если не удалось отправить уведомление
            
            return True, "Платеж успешно создан", transaction_id
            
        except Exception as e:
            logger.error(f"Error creating SBP payment: {str(e)}")
            return False, f"Ошибка при создании платежа через СБП: {str(e)}", None
    
# Метод _create_manual_payment удален для упрощения системы и устранения
# возможных ошибок пользователей. Ручная активация платежей больше не поддерживается.
    
    def _generate_robokassa_signature(self, amount: float, inv_id: int, 
                                     user_id: Optional[int] = None) -> str:
        """
        Генерация подписи для Robokassa
        
        Args:
            amount: Сумма платежа
            inv_id: Номер счета
            user_id: ID пользователя (опционально)
            
        Returns:
            str: Подпись
        """
        try:
            # Округляем сумму до 2 знаков после запятой
            amount_str = f"{amount:.2f}"
            
            # Формируем строку для подписи
            signature_string = f"{ROBOKASSA_LOGIN}:{amount_str}:{inv_id}:{ROBOKASSA_PASSWORD1}"
            
            # Если указан user_id, добавляем его к строке подписи
            if user_id:
                signature_string += f":{user_id}"
            
            # Вычисляем MD5-хеш
            signature = hashlib.md5(signature_string.encode()).hexdigest().upper()
            
            return signature
            
        except Exception as e:
            logger.error(f"Error generating Robokassa signature: {str(e)}")
            # Возвращаем пустую строку в случае ошибки
            return ""
    
    async def async_check_payment_status(self, transaction_id: int) -> Dict[str, Any]:
        """
        Асинхронная проверка статуса платежа
        Используется для периодических проверок состояния платежа
        
        Args:
            transaction_id: ID транзакции
            
        Returns:
            Dict[str, Any]: Данные о платеже
        """
        try:
            # Проверяем статус платежа
            success, message, transaction_data = self.check_payment_status(transaction_id)
            
            if not success:
                return {
                    'success': False,
                    'message': message
                }
            
            return {
                'success': True,
                'message': message,
                'data': transaction_data
            }
            
        except Exception as e:
            logger.error(f"Error in async_check_payment_status for transaction {transaction_id}: {str(e)}")
            return {
                'success': False,
                'message': f"Ошибка при проверке статуса платежа: {str(e)}"
            }

# Создаем единственный экземпляр фасада
payment_processor_facade = PaymentProcessorFacade()