#!/usr/bin/env python
# coding: utf-8

"""
Обработчик вебхуков от платежных систем (Robokassa) и веб-страниц оплаты
"""

import os
import logging
import asyncio
import datetime
import time
from pathlib import Path
from flask import Flask, request, render_template, abort, send_from_directory
from telegram import Bot
from typing import Dict, Any, Optional, List

import config
from database import get_user, update_user_subscription, save_user, update_transaction_status
from database import add_transaction, process_subscription_referral_rewards, save_transactions, load_transactions
from services.payment_service import verify_robokassa_signature, generate_robokassa_payout_url, generate_robokassa_signature

logger = logging.getLogger(__name__)

# Инициализируем Flask приложение
app = Flask(__name__, template_folder=os.getcwd())

# Создаем статический каталог, если его нет
STATIC_FOLDER = "static"
os.makedirs(STATIC_FOLDER, exist_ok=True)

# Добавляем обработчик статических файлов
@app.route('/static/<path:filename>')
def serve_static(filename):
    """
    Обработчик для статических файлов
    """
    return send_from_directory(STATIC_FOLDER, filename)

@app.route('/payment/<int:user_id>')
def payment_page(user_id):
    """
    Страница оплаты с iFrame Robokassa
    
    Args:
        user_id: Telegram ID пользователя
    """
    # Проверяем, существует ли пользователь
    user_data = get_user(user_id)
    if not user_data:
        return "Пользователь не найден", 404
    
    # Добавляем HTML-шаблон для страницы оплаты
    html_template = f"""
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Оплата подписки бота Катюша</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
            }}
            .payment-container {{
                margin-top: 30px;
            }}
            h1 {{
                color: #4a76a8;
            }}
            .robokassa-iframe {{
                width: 100%;
                height: 600px;
                border: none;
            }}
            .instructions {{
                background-color: #f1f1f1;
                padding: 15px;
                border-radius: 5px;
                margin-bottom: 20px;
                text-align: left;
            }}
        </style>
        <script src="https://auth.robokassa.ru/Merchant/bundle/robokassa_iframe.js"></script>
    </head>
    <body>
        <h1>Оплата подписки бота Катюша</h1>
        
        <div class="instructions">
            <p><strong>Инструкция:</strong></p>
            <ol>
                <li>Выберите удобный способ оплаты в форме ниже.</li>
                <li>Произведите оплату согласно инструкциям.</li>
                <li>После успешной оплаты ваша подписка будет активирована автоматически.</li>
                <li>В случае проблем, отправьте команду /activate_subscription боту.</li>
            </ol>
        </div>
        
        <div class="payment-container">
            <div id="robokassa-payment-form"></div>
        </div>
        
        <script type="text/javascript">
            document.addEventListener('DOMContentLoaded', function() {{
                // Инициализация формы оплаты Robokassa
                var robokassaParams = {{
                    MerchantLogin: "KatiyshaMathBot",
                    OutSum: 199.00,
                    InvId: Date.now(),
                    Description: "Подписка на бота Катюша на 1 месяц",
                    Email: "",
                    Culture: "ru",
                    Encoding: "utf-8",
                    IsTest: 1,
                    SignatureValue: "", // будет сгенерировано на стороне сервера
                    Shp_user: {user_id}
                }};
                
                const robokassaContainer = document.getElementById('robokassa-payment-form');
                if (robokassaContainer) {{
                    Robokassa.StartPayment({{
                        MerchantLogin: robokassaParams.MerchantLogin,
                        OutSum: robokassaParams.OutSum,
                        InvId: robokassaParams.InvId,
                        Description: robokassaParams.Description,
                        Email: robokassaParams.Email,
                        Culture: robokassaParams.Culture,
                        Encoding: robokassaParams.Encoding,
                        IsTest: robokassaParams.IsTest,
                        Shp_user: robokassaParams.Shp_user
                    }});
                }}
            }});
        </script>
    </body>
    </html>
    """
    return html_template

@app.route('/robokassa/webhook', methods=['GET', 'POST'])
def robokassa_webhook():
    """
    Обработчик уведомлений от Robokassa
    
    Документация по Result URL: https://docs.robokassa.ru/ru/knowledge-base/integration/notifications-paymentcompleted
    """
    # Получаем параметры запроса
    inv_id = request.args.get('InvId', '')
    outsum = request.args.get('OutSum', '')
    signature = request.args.get('SignatureValue', '')
    user_id = request.args.get('Shp_user', '')
    
    logger.info(f"Received Robokassa webhook: InvId={inv_id}, OutSum={outsum}, SignatureValue={signature}, Shp_user={user_id}")
    
    # Проверяем подпись
    if not verify_robokassa_signature(inv_id, outsum, signature, user_id):
        logger.warning(f"Invalid Robokassa signature: {signature}")
        return "Incorrect signature", 400
    
    # Если подпись действительна, активируем подписку пользователя
    if user_id:
        try:
            user_id_int = int(user_id)
            
            # Получаем данные пользователя
            user_data = get_user(user_id_int)
            if not user_data:
                logger.warning(f"User with ID {user_id_int} not found for subscription activation")
                return "User not found", 404
            
            # Устанавливаем дату окончания подписки (один месяц от текущей даты)
            now = datetime.datetime.now()
            expiry_date = now + datetime.timedelta(days=config.SUBSCRIPTION_DURATION_DAYS)
            
            # Обновляем данные о подписке
            update_user_subscription(user_id_int, expiry_date.isoformat())
            logger.info(f"Subscription activated for user {user_id_int} until {expiry_date.isoformat()}")
            
            # Отправляем пользователю уведомление о активации подписки
            asyncio.create_task(send_subscription_notification(user_id_int))
            
            return "OK", 200
        except Exception as e:
            logger.error(f"Error processing Robokassa webhook: {e}")
            return "Error", 500
    else:
        logger.warning("User ID not provided in Robokassa webhook")
        return "User ID not provided", 400

async def send_subscription_notification(user_id):
    """
    Отправить уведомление пользователю о успешной активации подписки
    
    Args:
        user_id: Telegram ID пользователя
    """
    try:
        # Получаем токен бота
        bot_token = config.TELEGRAM_TOKEN
        if not bot_token:
            logger.error("Bot token not found")
            return
        
        # Создаем экземпляр бота
        bot = Bot(token=bot_token)
        
        # Формируем сообщение об успешной активации подписки
        now = datetime.datetime.now()
        expiry_date = now + datetime.timedelta(days=config.SUBSCRIPTION_DURATION_DAYS)
        
        message = (
            "✅ *Спасибо за оплату!* Ваша подписка активирована на 1 месяц до "
            f"{expiry_date.strftime('%d.%m.%Y')}.\n\n"
            "Теперь вы можете *неограниченно* пользоваться ботом Катюша!\n\n"
            "Что вы можете делать с подпиской:\n"
            "• Решать неограниченное количество математических задач\n"
            "• Отправлять фотографии задач для распознавания текста\n"
            "• Отправлять голосовые сообщения для решения задач\n\n"
            "Отправьте текст задачи или нажмите кнопку «Решить задачу»"
        )
        
        # Отправляем уведомление пользователю
        await bot.send_message(chat_id=user_id, text=message, parse_mode='Markdown')
        logger.info(f"Subscription notification sent to user {user_id}")
    except Exception as e:
        logger.error(f"Error sending subscription notification: {e}")

async def handle_robokassa_notification(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle Robokassa payment notification
    
    Args:
        data: Notification data from Robokassa
        
    Returns:
        dict: Response to send back to Robokassa
    """
    logger.info(f"Received Robokassa notification: {data}")
    
    # Extract payment data
    try:
        # Required parameters
        inv_id = data.get('InvId')  # Transaction ID in Robokassa
        out_sum = data.get('OutSum')  # Payment amount
        signature = data.get('SignatureValue')  # Signature for verification
        
        # Our custom parameters
        user_id = data.get('Shp_user')  # User ID
        payment_type = data.get('Shp_type', 'subscription')  # Payment type (subscription, payout)
        
        if not all([inv_id, out_sum, signature, user_id]):
            logger.error(f"Missing required parameters in Robokassa notification: {data}")
            return {'success': False, 'error': 'Missing required parameters'}
        
        # Verify the signature
        if not verify_robokassa_signature(inv_id, out_sum, signature, user_id):
            logger.error(f"Invalid signature in Robokassa notification: {data}")
            return {'success': False, 'error': 'Invalid signature'}
        
        # Process payment based on payment type
        if payment_type == 'subscription':
            await process_subscription_payment(user_id, out_sum, inv_id)
        elif payment_type == 'referral_payout':
            await process_referral_payout(user_id, out_sum, inv_id, data.get('Shp_transaction_id'))
        
        # Return success response
        return {
            'success': True,
            'message': 'OK',
            'inv_id': inv_id
        }
    
    except Exception as e:
        logger.error(f"Error processing Robokassa notification: {e}")
        return {'success': False, 'error': str(e)}

async def process_subscription_payment(user_id: str, amount: str, transaction_id: str) -> None:
    """
    Process subscription payment
    
    Args:
        user_id: User ID
        amount: Payment amount
        transaction_id: Robokassa transaction ID
    """
    try:
        user_id_int = int(user_id)
        amount_float = float(amount)
        
        # Check payment amount
        if amount_float < 199.0:
            logger.warning(f"Payment amount too low: {amount_float}₽ for user {user_id_int}")
            return
        
        # Record payment transaction
        transaction_id_int = add_transaction(
            transaction_type="subscription",
            user_id=user_id_int,
            amount=amount_float,
            description=f"Subscription payment via Robokassa",
            status="completed",
            payment_data={
                "robokassa_transaction_id": transaction_id,
                "payment_method": "SBP",  # Assume SBP for now
                "payment_date": datetime.datetime.now().isoformat()
            }
        )
        
        # Calculate subscription duration (1 month per 199₽)
        months = int(amount_float // 199)
        if months < 1:
            months = 1
        
        # Get user data
        user_data = get_user(user_id_int)
        if not user_data:
            logger.error(f"User not found: {user_id_int}")
            return
        
        # Calculate new expiry date
        now = datetime.datetime.now()
        current_expiry = None
        
        if user_data.get('subscription_expiry'):
            try:
                current_expiry = datetime.datetime.fromisoformat(user_data['subscription_expiry'])
                # If subscription expired, start from now
                if current_expiry < now:
                    current_expiry = None
            except (ValueError, TypeError):
                current_expiry = None
        
        if current_expiry:
            # Extend existing subscription
            expiry_date = current_expiry + datetime.timedelta(days=30 * months)
        else:
            # New subscription
            expiry_date = now + datetime.timedelta(days=30 * months)
        
        # Update user subscription
        update_user_subscription(user_id_int, expiry_date.isoformat())
        
        logger.info(f"Subscription activated for user {user_id_int} until {expiry_date.isoformat()}")
        
        # Process referral rewards - this happens automatically in update_user_subscription now
        
    except Exception as e:
        logger.error(f"Error processing subscription payment: {e}")

async def process_referral_payout(user_id: str, amount: str, transaction_id: str, 
                                 internal_transaction_id: Optional[str] = None) -> None:
    """
    Process referral payout confirmation
    
    Args:
        user_id: User ID
        amount: Payment amount
        transaction_id: Robokassa transaction ID
        internal_transaction_id: Our internal transaction ID
    """
    try:
        user_id_int = int(user_id)
        amount_float = float(amount)
        
        # If internal transaction ID provided, update its status
        if internal_transaction_id:
            transaction_id_int = int(internal_transaction_id)
            success = update_transaction_status(
                transaction_id=transaction_id_int,
                status="completed",
                payment_data={
                    "robokassa_transaction_id": transaction_id,
                    "payment_method": "SBP",
                    "payment_date": datetime.datetime.now().isoformat()
                }
            )
            
            if success:
                logger.info(f"Updated transaction {transaction_id_int} status to completed")
            else:
                logger.warning(f"Failed to update transaction {transaction_id_int}")
        else:
            # If no internal transaction ID, create a new transaction record
            add_transaction(
                transaction_type="payout",
                user_id=user_id_int,
                amount=amount_float,
                description=f"Referral reward payout via Robokassa",
                status="completed",
                payment_data={
                    "robokassa_transaction_id": transaction_id,
                    "payment_method": "SBP",
                    "payment_date": datetime.datetime.now().isoformat()
                }
            )
            
            logger.info(f"Created new payout record for user {user_id_int}, amount: {amount_float}₽")
    
    except Exception as e:
        logger.error(f"Error processing referral payout: {e}")

async def update_weekly_payout_status() -> None:
    """
    Update status of weekly payouts and related transactions
    """
    try:
        transactions_db = load_transactions()
        updated = False
        
        # Look for processing payouts
        for weekly_payout in transactions_db.get("weekly_payouts", []):
            if weekly_payout["status"] == "processing":
                # Check if it's been processing for more than 24 hours
                processing_date = datetime.datetime.fromisoformat(weekly_payout.get("processed_at", ""))
                now = datetime.datetime.now()
                
                if (now - processing_date).total_seconds() > 86400:  # 24 hours
                    # Assume payout completed after 24 hours
                    weekly_payout["status"] = "completed"
                    weekly_payout["completed_at"] = now.isoformat()
                    updated = True
                    
                    # Also update all associated transactions
                    for user_payout in weekly_payout.get("user_payouts", []):
                        for transaction_id in user_payout.get("transaction_ids", []):
                            for transaction in transactions_db.get("transactions", []):
                                if transaction["id"] == transaction_id and transaction["status"] == "processed":
                                    transaction["status"] = "completed"
                                    transaction["updated_at"] = now.isoformat()
                    
                    logger.info(f"Updated weekly payout {weekly_payout['id']} status to completed")
        
        if updated:
            save_transactions(transactions_db)
    
    except Exception as e:
        logger.error(f"Error updating weekly payout status: {e}")

async def generate_robokassa_payout_urls(user_payouts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Generate Robokassa payout URLs for a list of user payouts
    
    Args:
        user_payouts: List of user payout records
        
    Returns:
        List[Dict]: List of payout records with URLs
    """
    result = []
    
    for payout in user_payouts:
        try:
            user_id = payout["user_id"]
            amount = payout["amount"]
            transaction_id = payout.get("transaction_id")
            
            # Get user data to check payment method
            user_data = get_user(user_id)
            if not user_data:
                logger.error(f"User not found for payout: {user_id}")
                continue
            
            # Get payment URL from Robokassa - this is a placeholder
            # In a real implementation, you would call Robokassa API to create a payout
            
            payout_url = generate_robokassa_payout_url(
                user_id=user_id,
                amount=amount,
                transaction_id=transaction_id,
                description=f"Referral reward payout"
            )
            
            result.append({
                "user_id": user_id,
                "amount": amount,
                "transaction_id": transaction_id,
                "payout_url": payout_url
            })
            
        except Exception as e:
            logger.error(f"Error generating payout URL: {e}")
    
    return result

def run_webhook_server(port=5000):
    """
    Run a webhook server for payment notifications
    
    Args:
        port: Port to listen on
    """
    @app.route("/")
    def home():
        return "Webhook server is running!"
    
    @app.route("/payment/<int:user_id>", methods=["GET"])
    def payment_page(user_id):
        """
        Страница оплаты с iframe Robokassa
        """
        # Получаем информацию о пользователе
        user_data = get_user(user_id)
        if not user_data:
            abort(404)
        
        # Передаем данные пользователя в шаблон
        username = user_data.get('username', '')
        first_name = user_data.get('first_name', '')
        
        # Формируем имя пользователя для отображения
        display_name = first_name or username or f"User{user_id}"
        
        # Получаем параметры для формирования URL оплаты
        merchant_login = os.getenv("ROBOKASSA_MERCHANT_LOGIN", "")
        secret_key = os.getenv("ROBOKASSA_SECRET_KEY_1", "")
        
        if not merchant_login or not secret_key:
            return render_template("payment_error.html", 
                                  error="Ошибка конфигурации платежного сервиса")
        
        # Формируем подпись для URL оплаты
        
        # Генерируем уникальный ID заказа
        inv_id = int(time.time())
        
        # Сумма платежа (199 руб)
        out_sum = 199.0
        
        # Генерируем подпись
        signature = generate_robokassa_signature(
            merchant_login=merchant_login,
            outsum=out_sum,
            inv_id=inv_id,
            secret_key=secret_key,
            user_id=user_id
        )
        
        # Передаем параметры в шаблон
        return render_template(
            "payment.html",
            user_id=user_id,
            display_name=display_name,
            merchant_login=merchant_login,
            out_sum=out_sum,
            inv_id=inv_id,
            signature=signature
        )
    
    @app.route("/robokassa/result", methods=["POST"])
    def robokassa_result():
        """
        Обработчик уведомлений от Robokassa о результате платежа
        """
        # Get data from request
        data = request.form.to_dict()
        
        # Process notification asyncronously
        asyncio.run(handle_robokassa_notification(data))
        
        # Return success response
        return "OK"
    
    @app.route("/robokassa/success", methods=["GET", "POST"])
    def robokassa_success():
        """
        Страница успешной оплаты
        """
        # Get data from request
        if request.method == "POST":
            data = request.form.to_dict()
        else:
            data = request.args.to_dict()
        
        # Extract user_id from Shp_user parameter
        user_id = data.get("Shp_user")
        
        if not user_id:
            return render_template("payment_error.html", 
                                  error="Не удалось определить пользователя")
        
        # Render success page with instructions
        return render_template(
            "payment_success.html",
            bot_username=config.BOT_USERNAME
        )
    
    @app.route("/robokassa/fail", methods=["GET", "POST"])
    def robokassa_fail():
        """
        Страница неудачной оплаты
        """
        # Get data from request
        if request.method == "POST":
            data = request.form.to_dict()
        else:
            data = request.args.to_dict()
        
        # Extract user_id from Shp_user parameter
        user_id = data.get("Shp_user")
        
        if not user_id:
            return render_template("payment_error.html", 
                                  error="Не удалось определить пользователя")
        
        # Render failure page with instructions
        return render_template(
            "payment_fail.html",
            bot_username=config.BOT_USERNAME
        )
    
    @app.route("/admin/payouts", methods=["GET"])
    def admin_payouts():
        """
        Страница управления выплатами для администратора
        Требует аутентификации
        """
        # Check for admin authentication
        auth_header = request.headers.get("Authorization", "")
        admin_token = os.getenv("ADMIN_TOKEN", "")
        
        if not admin_token or not auth_header.startswith("Bearer ") or auth_header[7:] != admin_token:
            return "Unauthorized", 401
        
        # Load weekly payouts
        transactions_db = load_transactions()
        weekly_payouts = transactions_db.get("weekly_payouts", [])
        
        # Render admin page
        return render_template(
            "admin_payouts.html",
            weekly_payouts=weekly_payouts
        )
    
    @app.route("/admin/payout/<int:payout_id>/process", methods=["POST"])
    def admin_process_payout(payout_id):
        """
        Обработка выплаты администратором
        Требует аутентификации
        """
        # Check for admin authentication
        auth_header = request.headers.get("Authorization", "")
        admin_token = os.getenv("ADMIN_TOKEN", "")
        
        if not admin_token or not auth_header.startswith("Bearer ") or auth_header[7:] != admin_token:
            return "Unauthorized", 401
        
        # Load weekly payouts
        transactions_db = load_transactions()
        
        # Find the payout by ID
        payout_found = False
        for payout in transactions_db.get("weekly_payouts", []):
            if payout.get("id") == payout_id and payout.get("status") == "pending":
                payout["status"] = "processing"
                payout["processed_at"] = datetime.datetime.now().isoformat()
                payout_found = True
                break
        
        if not payout_found:
            return "Payout not found or already processed", 404
        
        # Save changes
        save_transactions(transactions_db)
        
        # Process payouts asynchronously
        # In a real implementation, you would trigger a background task here
        # For now, we'll simulate this by just responding immediately
        
        return "Processing started", 200
    
    @app.route("/static/<path:path>")
    def serve_static(path):
        return send_from_directory("static", path)
    
    # Run the Flask app
    app.run(host="0.0.0.0", port=port)