"""
Service modules for the Katiysha bot
"""