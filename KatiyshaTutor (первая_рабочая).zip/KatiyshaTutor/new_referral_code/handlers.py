﻿#!/usr/bin/env python
# coding: utf-8

"""
Handlers for the Katiysha bot commands and messages
"""

import os
import time
import logging
import datetime
import tempfile
import traceback
import html
from typing import Dict, Any, Optional

from telegram import Update, ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, ConversationHandler

import config
from database import (
    get_user, get_user_by_referral_code, save_user, update_user, update_user_subscription, is_admin,
    add_admin, remove_admin, get_subscription_stats, add_transaction,
    update_transaction_status, get_user_pending_rewards,
    get_user_total_rewards, collect_weekly_payouts,
    process_payout_for_user, update_referral_rates,
    load_database, load_transactions, save_transactions  # Добавляем импорт load_transactions и save_transactions
)
from keyboards import get_main_keyboard, get_problem_keyboard
from models import User
from services.deepseek_service import solve_math_problem
from services.ocr_service import extract_text_from_image
from services.speech_service import convert_voice_to_text
from services.payment_service import create_external_payment_link, create_manual_activation

logger = logging.getLogger(__name__)

# Хранилище состояний пользователей для отслеживания контекста разговора
user_states = {}

# Добавление константы для состояния разговора
WAITING_REFCODE = 1

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /start command - introduce the bot and show main keyboard."""
    user = update.effective_user
    user_id = user.id
    message_text = update.message.text
    
    # Получение или создание данных пользователя
    user_data = get_user(user_id)
    if not user_data:
        user_data = {
            "id": user_id,
            "username": user.username,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "free_request_used": False,
            "subscription_expiry": None,
            "referral_code": None,
            "referrer_id": None,
            "referrals": {
                "level1": [],  # 5% (прямые рефералы)
                "level2": [],  # 2% (рефералы 2-го уровня)
                "level3": [],  # 2% (рефералы 3-го уровня)
                "level4": [],  # 2% (рефералы 4-го уровня)
            }
        }
        save_user(user_data)
        logger.info(f"New user registered: {user_id} ({user.username})")
    
    # Проверяем, не является ли это переходом по реферальной ссылке
    if message_text and message_text.startswith('/start ref_'):
        # Извлекаем реферальный код
        referral_code = message_text.split('ref_')[1]
        await process_referral(update, context, referral_code)
    else:    
        await update.message.reply_text(
            config.WELCOME_MESSAGE,
            reply_markup=get_main_keyboard(),
            parse_mode='Markdown'
        )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /help command - show help text and main keyboard."""
    await update.message.reply_text(
        config.HELP_MESSAGE,
        reply_markup=get_main_keyboard(),
        parse_mode='Markdown'
    )

async def solve_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /solve command - prompt user to send a problem."""
    await update.message.reply_text(
        config.SEND_PROBLEM_MESSAGE,
        reply_markup=get_main_keyboard()
    )
    
    # Устанавливаем состояние пользователя - ожидаем от него задачу
    user_id = update.effective_user.id
    user_states[user_id] = {'waiting_for_problem': True}

async def subscribe_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /subscribe command - send payment link."""
    # Используем функцию для создания ссылки на оплату
    # await create_external_payment_link(update, context)
    # Для упрощения пока используем ручную активацию
    await create_manual_activation(update, context)

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle text messages - process math problems."""
    text = update.message.text
    user_id = update.effective_user.id
    
    # Если текст похож на команду из основной клавиатуры
    if text == "Решить задачу":
        await solve_command(update, context)
        return
    elif text == "Купить подписку (199₽/месяц)":
        await subscribe_command(update, context)
        return
    elif text == "Пригласить друга (реферальная система)":
        await invite_command(update, context)
        return
    
    # Если пользователь отправляет текст задачи после команды /solve
    if user_id in user_states and user_states[user_id].get('waiting_for_problem', False):
        # Сохраняем задачу в состоянии пользователя
        user_states[user_id]['problem'] = text
        user_states[user_id]['waiting_for_problem'] = False
        
        # Отправляем подтверждение
        await update.message.reply_text(
            f"📝 Задача получена:\n\n{text}\n\nРешить эту задачу?",
            reply_markup=get_problem_keyboard()
        )
    else:
        # Если пользователь просто отправил сообщение без предварительной команды,
        # воспринимаем его как задачу
        user_states[user_id] = {'problem': text}
        
        await update.message.reply_text(
            f"📝 Задача получена:\n\n{text}\n\nРешить эту задачу?",
            reply_markup=get_problem_keyboard()
        )

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle photo messages - extract text using OCR and process math problems."""
    user_id = update.effective_user.id
    
    # Проверяем права доступа пользователя перед обработкой изображения
    user_data = get_user(user_id)
    user = User.from_dict(user_data) if user_data else User(user_id)
    
    if not user.can_solve_problem():
        await update.message.reply_text(
            config.SUBSCRIPTION_NEEDED_MESSAGE,
            reply_markup=get_main_keyboard()
        )
        return
    
    # Получаем информацию о фото
    photo = update.message.photo[-1]  # Берем фото с наилучшим качеством
    
    # Отправляем сообщение о начале обработки
    processing_msg = await update.message.reply_text(
        "🔍 Распознаю текст с изображения... Это может занять некоторое время."
    )
    
    try:
        # Скачиваем фото во временный файл
        photo_file = await context.bot.get_file(photo.file_id)
        
        # Создаем временную директорию, если её нет
        temp_dir = "temp_images"
        os.makedirs(temp_dir, exist_ok=True)
        
        # Формируем имя файла и путь
        timestamp = int(time.time())
        photo_path = f"{temp_dir}/photo_{user_id}_{timestamp}.jpg"
        
        # Скачиваем фото
        await photo_file.download_to_drive(photo_path)
        
        # Используем OCR для извлечения текста из изображения
        extracted_text = await extract_text_from_image(photo_path)
        
        # Удаляем сообщение о обработке
        await processing_msg.delete()
        
        if not extracted_text or extracted_text.strip() == "":
            await update.message.reply_text(
                config.OCR_ERROR_MESSAGE,
                reply_markup=get_main_keyboard()
            )
            return
        
        # Сохраняем извлеченный текст в состоянии пользователя
        user_states[user_id] = {
            'problem': extracted_text,
            'image_path': photo_path
        }
        
        # Отправляем подтверждение с извлеченным текстом
        await update.message.reply_text(
            f"📝 Распознанный текст:\n\n{extracted_text}\n\nРешить эту задачу?",
            reply_markup=get_problem_keyboard()
        )
        
    except Exception as e:
        logger.error(f"Error processing photo: {e}")
        
        # Удаляем сообщение о обработке
        await processing_msg.delete()
        
        await update.message.reply_text(
            config.ERROR_MESSAGE,
            reply_markup=get_main_keyboard()
        )

async def handle_voice(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle voice messages - convert speech to text and process math problems."""
    user_id = update.effective_user.id
    
    # Проверяем права доступа пользователя перед обработкой голосового сообщения
    user_data = get_user(user_id)
    user = User.from_dict(user_data) if user_data else User(user_id)
    
    if not user.can_solve_problem():
        await update.message.reply_text(
            config.SUBSCRIPTION_NEEDED_MESSAGE,
            reply_markup=get_main_keyboard()
        )
        return
    
    # Получаем информацию о голосовом сообщении
    voice = update.message.voice
    
    # Отправляем сообщение о начале обработки
    processing_msg = await update.message.reply_text(
        config.VOICE_PROCESSING_MESSAGE
    )
    
    try:
        # Скачиваем голосовое сообщение во временный файл
        voice_file = await context.bot.get_file(voice.file_id)
        
        # Создаем временную директорию, если её нет
        temp_dir = "temp_voices"
        os.makedirs(temp_dir, exist_ok=True)
        
        # Формируем имя файла и путь
        timestamp = int(time.time())
        voice_path = f"{temp_dir}/voice_{user_id}_{timestamp}.oga"
        
        # Скачиваем голосовое сообщение
        await voice_file.download_to_drive(voice_path)
        
        # Конвертируем голосовое сообщение в текст
        extracted_text = await convert_voice_to_text(voice_path)
        
        # Удаляем сообщение о обработке
        await processing_msg.delete()
        
        if not extracted_text or extracted_text.strip() == "":
            await update.message.reply_text(
                config.VOICE_ERROR_MESSAGE,
                reply_markup=get_main_keyboard()
            )
            return
        
        # Сохраняем извлеченный текст в состоянии пользователя
        user_states[user_id] = {'problem': extracted_text}
        
        # Отправляем подтверждение с извлеченным текстом
        await update.message.reply_text(
            f"📝 Распознанный текст:\n\n{extracted_text}\n\nРешить эту задачу?",
            reply_markup=get_problem_keyboard()
        )
        
    except Exception as e:
        logger.error(f"Error processing voice: {e}")
        
        # Удаляем сообщение о обработке
        await processing_msg.delete()
        
        await update.message.reply_text(
            config.ERROR_MESSAGE,
            reply_markup=get_main_keyboard()
        )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle callback queries from inline keyboards."""
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    
    if query.data == "solve_problem":
        # User clicked "Solve Problem" button from main menu
        await query.edit_message_text(config.SEND_PROBLEM_MESSAGE)
        user_states[user_id] = {'waiting_for_problem': True}
    
    elif query.data == "subscribe":
        # User clicked "Subscribe" button from main menu
        await query.delete_message()
        await create_manual_activation(update, context)
    
    elif query.data == "manual_activate":
        # User confirmed manual subscription activation
        await query.delete_message()
        await activate_subscription_command(update, context)
    
    elif query.data == "confirm_solve":
        # User confirmed the extracted text for solving
        if user_id in user_states and 'problem' in user_states[user_id]:
            problem = user_states[user_id]['problem']
            await query.delete_message()
            await process_problem(update, context, problem, is_callback=True)
        else:
            await query.edit_message_text("Извините, я не могу найти вашу задачу. Пожалуйста, попробуйте снова.")
    
    elif query.data == "cancel_solve":
        # User cancelled the problem solving
        await query.edit_message_text("Операция отменена. Вы можете отправить новую задачу в любое время.")
        if user_id in user_states:
            user_states.pop(user_id, None)

async def process_problem(update: Update, context: ContextTypes.DEFAULT_TYPE, problem: str, is_callback: bool = False) -> None:
    """Process and solve a math problem."""
    user_id = update.effective_user.id
    
    # Получаем данные пользователя
    user_data = get_user(user_id)
    if not user_data:
        # Если данных нет, создаем нового пользователя
        user = update.effective_user
        user_data = {
            "id": user_id,
            "username": user.username,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "free_request_used": False,
            "subscription_expiry": None
        }
        save_user(user_data)
    
    user = User.from_dict(user_data)
    
    # Проверяем, может ли пользователь решать задачи
    if not user.can_solve_problem():
        if is_callback:
            await context.bot.send_message(
                chat_id=user_id,
                text=config.SUBSCRIPTION_NEEDED_MESSAGE,
                reply_markup=get_main_keyboard(),
                parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(
                config.SUBSCRIPTION_NEEDED_MESSAGE,
                reply_markup=get_main_keyboard(),
                parse_mode='Markdown'
            )
        return
    
    # Send processing message
    if is_callback:
        processing_msg = await context.bot.send_message(
            chat_id=user_id,
            text=config.PROCESSING_MESSAGE
        )
    else:
        processing_msg = await update.message.reply_text(config.PROCESSING_MESSAGE)
    
    try:
        # Получаем решение через каскадную систему (DeepSeek -> OpenAI -> встроенный решатель)
        logger.info(f"Solving problem: {problem}")
        solution = await solve_math_problem(problem)
        logger.info(f"Got solution: {solution[:100]}..." if solution else "No solution received")
        
        # Проверяем, что решение не пустое
        if not solution or len(solution.strip()) == 0:
            solution = "Извините, не удалось получить решение. Пожалуйста, проверьте формат задачи и попробуйте снова."
        
        # Mark free request as used if this is the user's first request
        if not user_data.get('free_request_used', False) and not is_subscription_active(user_data):
            user_data['free_request_used'] = True
            save_user(user_data)
        
        # Send the solution
        await processing_msg.delete()
        
        # Формируем сообщение с задачей и решением
        # Используем обычный текст без разметки, чтобы избежать проблем с форматированием
        solution_message = f"📝 Задача:\n{problem}\n\n✅ Решение:\n{solution}"
        
        if is_callback:
            await context.bot.send_message(
                chat_id=user_id,
                text=solution_message,
                reply_markup=get_main_keyboard(),
                parse_mode=None
            )
        else:
            await update.message.reply_text(
                solution_message,
                reply_markup=get_main_keyboard(),
                parse_mode=None
            )
    except Exception as e:
        logger.error(f"Error processing problem: {e}")
        await processing_msg.delete()
        
        if is_callback:
            await context.bot.send_message(
                chat_id=user_id,
                text=config.ERROR_MESSAGE,
                reply_markup=get_main_keyboard()
            )
        else:
            await update.message.reply_text(
                config.ERROR_MESSAGE,
                reply_markup=get_main_keyboard()
            )

async def activate_subscription_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /activate_subscription command - manually activate subscription after payment
    This is a fallback for when Robokassa webhook doesn't work
    """
    user_id = update.effective_user.id
    
    # Check if user already has active subscription
    user_data = get_user(user_id)
    if is_subscription_active(user_data):
        expiry_date = datetime.datetime.fromisoformat(user_data['subscription_expiry'])
        await update.message.reply_text(
            f"✅ У вас уже есть *активная подписка* до {expiry_date.strftime('%d.%m.%Y')}.\n\n"
            "Вы можете продолжать пользоваться всеми функциями бота Катюша!",
            reply_markup=get_main_keyboard(),
            parse_mode='Markdown'
        )
        return
    
    # Проверяем, пришел ли запрос от текущего месяца
    # это простая проверка для минимизации случаев активации без оплаты
    current_month = datetime.datetime.now().month
    if getattr(context.user_data, 'get', lambda x, y: y)('last_activation_month', None) == current_month:
        # Если уже была активация в этом месяце, проверяем "баланс активаций"
        if getattr(context.user_data, 'get', lambda x, y: y)('monthly_activations', 0) >= 1:
            await update.message.reply_text(
                "⚠️ *Превышение лимита активаций*\n\n"
                "Система обнаружила, что вы уже активировали подписку в этом месяце.\n"
                "Если вы считаете, что произошла ошибка, напишите в поддержку.\n\n"
                "Если вы хотите активировать подписку для другого пользователя, пожалуйста, "
                "воспользуйтесь его аккаунтом.",
                reply_markup=get_main_keyboard(),
                parse_mode='Markdown'
            )
            return
        
    # Update user's subscription status
    now = datetime.datetime.now()
    expiry_date = now + datetime.timedelta(days=config.SUBSCRIPTION_DURATION_DAYS)
    
    update_user_subscription(user_id, expiry_date.isoformat())
    
    # Обновляем счетчик активаций для этого месяца
    if hasattr(context, 'user_data') and hasattr(context.user_data, 'update'):
        context.user_data.update({
            'last_activation_month': now.month,
            'monthly_activations': context.user_data.get('monthly_activations', 0) + 1
        })
    
    # Проверяем, есть ли у пользователя реферер, и если да, начисляем ему вознаграждение
    # Для этого проверяем, кто пригласил текущего пользователя
    if user_data and user_data.get('referrer_id'):
        logger.info(f"User {user_id} has referrer {user_data['referrer_id']}, processing rewards")
        
        # Здесь можно добавить реальную логику начисления вознаграждения
        # Например, запись в специальную таблицу для статистики или начисление баллов/денег
        
        # В данной реализации просто отправляем сообщение пригласившему пользователю
        referrer_id = user_data['referrer_id']
        try:
            # Отправляем сообщение реферу о полученном вознаграждении
            await context.bot.send_message(
                chat_id=referrer_id,
                text=f"🎉 *Поздравляем!*\n\n"
                     f"Ваш реферал активировал подписку!\n"
                     f"Вы получаете 5% от стоимости подписки (9.95₽).\n\n"
                     f"Продолжайте приглашать друзей, чтобы зарабатывать больше!",
                parse_mode='Markdown'
            )
            logger.info(f"Sent reward notification to referrer {referrer_id}")
        except Exception as e:
            logger.error(f"Failed to send reward notification to referrer {referrer_id}: {e}")
    
    # Notify user about successful subscription
    await update.message.reply_text(
        "✅ *Спасибо за оплату!* Ваша подписка успешно активирована до "
        f"{expiry_date.strftime('%d.%m.%Y')}.\n\n"
        "Теперь вы можете *неограниченно* пользоваться ботом Катюша!\n\n"
        "🔹 *Что вы можете делать с подпиской:*\n"
        "• Решать неограниченное количество математических задач\n"
        "• Отправлять фотографии задач для распознавания текста\n"
        "• Отправлять голосовые сообщения для решения задач\n\n"
        "🔹 *Как использовать бота:*\n"
        "• Просто напишите свою задачу в чат\n"
        "• Или нажмите кнопку \"Решить задачу\" и следуйте инструкциям\n"
        "• Загрузите фото с задачей или отправьте голосовое сообщение\n\n"
        "Приятного использования! 🎓✨\n\n"
        "Отправьте текст задачи или нажмите кнопку «Решить задачу»",
        reply_markup=get_main_keyboard(),
        parse_mode='Markdown'
    )
    logger.info(f"Manual subscription activation for user {user_id} until {expiry_date.isoformat()}")

def is_subscription_active(user_data: Optional[Dict[str, Any]]) -> bool:
    """Check if a user has an active subscription."""
    if not user_data or 'subscription_expiry' not in user_data or not user_data['subscription_expiry']:
        return False
    
    try:
        expiry_date = datetime.datetime.fromisoformat(user_data['subscription_expiry'])
        return datetime.datetime.now() < expiry_date
    except (ValueError, TypeError):
        return False

async def invite_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /invite command - generate and show referral link
    """
    user_id = update.effective_user.id
    
    # Получаем данные пользователя
    user_data = get_user(user_id)
    if not user_data:
        user = update.effective_user
        user_data = {
            "id": user_id,
            "username": user.username,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "free_request_used": False,
            "subscription_expiry": None,
            "referral_code": None,
            "referrer_id": None,
            "referrals": {
                "level1": [],  # 5% (прямые рефералы)
                "level2": [],  # 2% (рефералы 2-го уровня)
                "level3": [],  # 2% (рефералы 3-го уровня)
                "level4": [],  # 2% (рефералы 4-го уровня)
            }
        }
        save_user(user_data)
    
    # Создаем объект пользователя и генерируем реферальную ссылку
    user = User.from_dict(user_data)
    referral_link = user.get_referral_link()
    
    # Если код изменился, сохраняем его в базе данных
    if user.referral_code != user_data.get('referral_code'):
        user_data['referral_code'] = user.referral_code
        save_user(user_data)
    
    # Формируем сообщение с реферальной ссылкой
    await update.message.reply_text(
        config.REFERRAL_MESSAGE.format(referral_link=referral_link),
        reply_markup=get_main_keyboard(),
        parse_mode='Markdown'
    )
    
    # Отправляем отдельным сообщением реферальный код для удобного копирования
    await update.message.reply_text(
        f"📋 *Ваш реферальный код для ручной передачи:*\n\n`{user.referral_code}`\n\n"
        f"Вы можете поделиться этим кодом, и ваши друзья смогут ввести его командой /refcode",
        parse_mode='Markdown'
    )

async def refcode_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Позволяет пользователю ввести реферальный код другого пользователя.
    После ввода кода пользователь становится рефералом указанного пользователя.
    """
    user = update.effective_user
    user_id = user.id
    
    # Проверяем был ли уже указан реферал для этого пользователя
    user_data = get_user(user_id)
    if user_data and user_data.get('referrer_id'):
        await update.message.reply_text("Вы уже привязаны к реферальной программе. Невозможно изменить реферала.")
        return
    
    # Запрашиваем у пользователя ввод реферального кода
    await update.message.reply_text(
        "Пожалуйста, введите реферальный код пригласившего вас пользователя в формате: REF-XXXX\n"
        "Например: REF-1234"
    )
    return WAITING_REFCODE

async def process_refcode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Обрабатывает введенный пользователем реферальный код.
    """
    user = update.effective_user
    user_id = user.id
    text = update.message.text.strip()
    
    # Проверяем формат кода
    if not text.startswith("REF-") or len(text) < 5:
        await update.message.reply_text(
            "Неверный формат реферального кода. Код должен быть в формате REF-XXXX. Попробуйте снова."
        )
        return WAITING_REFCODE
    
    # Извлекаем ID реферера из кода
    referrer_id_str = text[4:]
    
    # Проверяем, существует ли пользователь с таким ID
    referrer_id = get_user_by_referral_code(referrer_id_str)
    if not referrer_id:
        await update.message.reply_text(
            "Пользователь с таким реферальным кодом не найден. Проверьте код и попробуйте снова."
        )
        return WAITING_REFCODE
    
    # Нельзя указать себя как реферера
    if referrer_id == user_id:
        await update.message.reply_text(
            "Вы не можете указать себя в качестве реферера."
        )
        return WAITING_REFCODE
        
    # Обновляем данные пользователя, устанавливая реферера
    user_data = get_user(user_id) or {}
    user_data['referrer_id'] = referrer_id
    update_user(user_id, user_data)
    
    # Получаем данные реферера
    referrer_data = get_user(referrer_id)
    if not referrer_data:
        logging.error(f"Referrer {referrer_id} not found in database despite successful lookup")
        await update.message.reply_text(
            "Произошла ошибка при обработке реферального кода. Пожалуйста, попробуйте позже."
        )
        return ConversationHandler.END
    
    # Добавляем текущего пользователя в список рефералов реферера
    if 'referrals' not in referrer_data:
        referrer_data['referrals'] = {
            "level1": [],
            "level2": [],
            "level3": [],
            "level4": [],
        }
    
    # Добавляем пользователя как реферала первого уровня, если его там еще нет
    if user_id not in referrer_data['referrals'].get('level1', []):
        if not isinstance(referrer_data['referrals'].get('level1'), list):
            referrer_data['referrals']['level1'] = []
        referrer_data['referrals']['level1'].append(user_id)
        update_user(referrer_id, referrer_data)
    
    # Отправляем уведомление реферору о новом реферале
    try:
        user_name = user.full_name or f"User {user_id}"
        referral_msg = f"🎉 Поздравляем! У вас новый реферал: {user_name}. Вы будете получать комиссию с его платежей."
        await context.bot.send_message(chat_id=referrer_id, text=referral_msg)
    except Exception as e:
        logging.error(f"Failed to notify referrer: {e}")
    
    # Сообщаем пользователю об успешной привязке
    await update.message.reply_text(
        f"Вы успешно указали реферальный код. Теперь вы являетесь частью реферальной программы."
    )
    
    return ConversationHandler.END

async def cancel_refcode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Отменяет ввод реферального кода
    """
    await update.message.reply_text("Ввод реферального кода отменен.")
    return ConversationHandler.END

async def process_referral(update: Update, context: ContextTypes.DEFAULT_TYPE, referral_code: str) -> None:
    """
    Process referral when a user comes from a referral link
    
    Args:
        update: Telegram update
        context: Telegram context
        referral_code: Referral code from the link
    """
    user_id = update.effective_user.id
    
    # Получаем данные пользователя
    user_data = get_user(user_id)
    
    # Если у пользователя уже есть реферер, не обрабатываем повторно
    if user_data and user_data.get('referrer_id'):
        await update.message.reply_text(
            config.WELCOME_MESSAGE,
            reply_markup=get_main_keyboard(),
            parse_mode='Markdown'
        )
        return
    
    # Поиск пользователя с таким реферальным кодом
    db = load_database()
    referrer_id = None
    
    for db_user_id, db_user_data in db['users'].items():
        if db_user_data.get('referral_code') == referral_code:
            referrer_id = int(db_user_id)
            break
    
    if referrer_id:
        # Если найден реферер и это не сам пользователь
        if referrer_id != user_id:
            # Обновляем данные пользователя
            if not user_data:
                # Если это новый пользователь, создаем запись
                user = update.effective_user
                user_data = {
                    "id": user_id,
                    "username": user.username,
                    "first_name": user.first_name,
                    "last_name": user.last_name,
                    "free_request_used": False,
                    "subscription_expiry": None,
                    "referral_code": None,
                    "referrer_id": referrer_id,
                    "referrals": {
                        "level1": [],
                        "level2": [],
                        "level3": [],
                        "level4": [],
                    }
                }
            else:
                # Если пользователь уже существует, добавляем реферера
                user_data["referrer_id"] = referrer_id
            
            # Сохраняем данные пользователя
            save_user(user_data)
            
            # Добавляем пользователя как реферала первого уровня
            referrer_data = db['users'].get(str(referrer_id))
            if referrer_data:
                if 'referrals' not in referrer_data:
                    referrer_data['referrals'] = {
                        "level1": [],
                        "level2": [],
                        "level3": [],
                        "level4": [],
                    }
                
                # Добавляем пользователя как реферала первого уровня, если его там еще нет
                if user_id not in referrer_data['referrals'].get('level1', []):
                    if not isinstance(referrer_data['referrals'].get('level1'), list):
                        referrer_data['referrals']['level1'] = []
                    referrer_data['referrals']['level1'].append(user_id)
                    
                    # Сохраняем изменения
                    save_user(referrer_data)
                    
                    # Находим реферера второго уровня
                    referrer2_id = referrer_data.get('referrer_id')
                    if referrer2_id:
                        referrer2_data = db['users'].get(str(referrer2_id))
                        if referrer2_data:
                            if 'referrals' not in referrer2_data:
                                referrer2_data['referrals'] = {
                                    "level1": [],
                                    "level2": [],
                                    "level3": [],
                                    "level4": [],
                                }
                            
                            # Добавляем пользователя как реферала второго уровня
                            if user_id not in referrer2_data['referrals'].get('level2', []):
                                if not isinstance(referrer2_data['referrals'].get('level2'), list):
                                    referrer2_data['referrals']['level2'] = []
                                referrer2_data['referrals']['level2'].append(user_id)
                                save_user(referrer2_data)
                                
                                # Находим реферера третьего уровня
                                referrer3_id = referrer2_data.get('referrer_id')
                                if referrer3_id:
                                    referrer3_data = db['users'].get(str(referrer3_id))
                                    if referrer3_data:
                                        if 'referrals' not in referrer3_data:
                                            referrer3_data['referrals'] = {
                                                "level1": [],
                                                "level2": [],
                                                "level3": [],
                                                "level4": [],
                                            }
                                        
                                        # Добавляем пользователя как реферала третьего уровня
                                        if user_id not in referrer3_data['referrals'].get('level3', []):
                                            if not isinstance(referrer3_data['referrals'].get('level3'), list):
                                                referrer3_data['referrals']['level3'] = []
                                            referrer3_data['referrals']['level3'].append(user_id)
                                            save_user(referrer3_data)
                                            
                                            # Находим реферера четвертого уровня
                                            referrer4_id = referrer3_data.get('referrer_id')
                                            if referrer4_id:
                                                referrer4_data = db['users'].get(str(referrer4_id))
                                                if referrer4_data:
                                                    if 'referrals' not in referrer4_data:
                                                        referrer4_data['referrals'] = {
                                                            "level1": [],
                                                            "level2": [],
                                                            "level3": [],
                                                            "level4": [],
                                                        }
                                                    
                                                    # Добавляем пользователя как реферала четвертого уровня
                                                    if user_id not in referrer4_data['referrals'].get('level4', []):
                                                        if not isinstance(referrer4_data['referrals'].get('level4'), list):
                                                            referrer4_data['referrals']['level4'] = []
                                                        referrer4_data['referrals']['level4'].append(user_id)
                                                        save_user(referrer4_data)
            
            # Отправляем приветственное сообщение с упоминанием реферальной программы
            await update.message.reply_text(
                "👋 *Добро пожаловать к Катюше!*\n\n"
                "Вы перешли по реферальной ссылке. Когда вы активируете подписку, "
                "пригласивший вас пользователь получит вознаграждение!\n\n" + 
                config.WELCOME_MESSAGE,
                reply_markup=get_main_keyboard(),
                parse_mode='Markdown'
            )
            return
    
    # Если не нашли реферера или это сам пользователь, отправляем обычное приветствие
    await update.message.reply_text(
        config.WELCOME_MESSAGE,
        reply_markup=get_main_keyboard(),
        parse_mode='Markdown'
    )

async def error_handler(update, context):
    """Log the error and send a telegram message to notify the developer."""
    # Log the error before we do anything else, so we can see it even if something breaks.
    logger.error(msg="Exception while handling an update:", exc_info=context.error)

    # traceback.format_exception returns the usual python way of printing the exception
    # but as a list of strings instead of a single string.
    tb_list = traceback.format_exception(None, context.error, context.error.__traceback__)
    tb_string = ''.join(tb_list)

    # Build the message with some markup and additional information about what happened.
    message = (
        f'Произошла ошибка при обработке сообщения:\n'
        f'{update}\n\n'
        f'<pre>{html.escape(tb_string)}</pre>'
    )

    # Send the message
    admin_id = config.ADMIN_USER_ID  # Get your user id from config
    if admin_id:
        await context.bot.send_message(
            chat_id=admin_id, 
            text=message, 
            parse_mode='HTML'
        )

# Admin commands for referral system management

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /admin command - show admin panel if the user is an admin
    """
    user_id = update.effective_user.id
    username = update.effective_user.username or "Unknown"
    logger.info(f"Попытка доступа к админ-панели: user_id={user_id}, username={username}")
    
    # Загружаем базу данных и проверяем admins массив
    db = load_database()
    logger.debug(f"Список администраторов в базе: {db.get('admins', [])}")
    
    # Check if user is an admin
    is_user_admin = is_admin(user_id)
    logger.info(f"Проверка прав администратора для user_id={user_id}: {is_user_admin}")
    
    if not is_user_admin:
        logger.warning(f"Отказано в доступе к админ-панели: user_id={user_id}, username={username}")
        await update.message.reply_text(
            "⛔ У вас нет прав администратора для доступа к этой команде.",
            parse_mode='Markdown'
        )
        return
    
    logger.info(f"Доступ к админ-панели разрешен: user_id={user_id}, username={username}")
    
    # Show admin panel
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 Статистика подписок", callback_data="admin_subscription_stats")],
        [InlineKeyboardButton("💰 Управление выплатами", callback_data="admin_payouts")],
        [InlineKeyboardButton("👥 Управление рефералами", callback_data="admin_referrals")],
        [InlineKeyboardButton("📋 Выгрузить отчёт", callback_data="admin_export_report")],
        [InlineKeyboardButton("⚙️ Настройки реф. программы", callback_data="admin_referral_settings")]
    ])
    
    await update.message.reply_text(
        "🔐 *Панель администратора*\n\n"
        "Выберите действие:",
        reply_markup=keyboard,
        parse_mode='Markdown'
    )
    logger.info(f"Админ-панель успешно показана пользователю {user_id}")

async def admin_add_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /admin_add command - add a new admin
    """
    user_id = update.effective_user.id
    username = update.effective_user.username or "Unknown"
    logger.info(f"Попытка добавить администратора: вызвал user_id={user_id}, username={username}")
    
    # Check if the current user is allowed to add admins (super admin)
    super_admin_id = config.ADMIN_USER_ID
    logger.debug(f"Супер-админ из конфига: {super_admin_id}, текущий пользователь: {user_id}")
    
    if user_id != super_admin_id:
        logger.warning(f"Попытка добавить админа без прав супер-админа: user_id={user_id}, требуется {super_admin_id}")
        await update.message.reply_text(
            "⛔ Только главный администратор может добавлять новых администраторов.",
            parse_mode='Markdown'
        )
        return
    
    # Check if a user ID was provided
    if not context.args:
        logger.warning(f"Отсутствуют аргументы в команде admin_add: user_id={user_id}")
        await update.message.reply_text("Использование: /admin_add <user_id>")
        return
    
    try:
        new_admin_id = int(context.args[0])
        logger.info(f"Попытка добавить администратора: new_admin_id={new_admin_id}")
        
        # Проверяем текущий список админов
        db = load_database()
        logger.debug(f"Текущий список администраторов: {db.get('admins', [])}")
        
        # Add the user as an admin
        success = add_admin(new_admin_id)
        logger.info(f"Результат добавления администратора {new_admin_id}: {success}")
        
        if success:
            await update.message.reply_text(f"✅ Пользователь {new_admin_id} добавлен как администратор.")
        else:
            await update.message.reply_text(f"ℹ️ Пользователь {new_admin_id} уже является администратором.")
    except ValueError:
        logger.error(f"Неверный формат ID пользователя: {context.args[0]}")
        await update.message.reply_text("❌ Неверный ID пользователя. Используйте числовой ID.")

async def admin_remove_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /admin_remove command - remove an admin
    """
    user_id = update.effective_user.id
    username = update.effective_user.username or "Unknown"
    logger.info(f"Попытка удалить администратора: вызвал user_id={user_id}, username={username}")
    
    # Check if the current user is allowed to remove admins (super admin)
    super_admin_id = config.ADMIN_USER_ID
    logger.debug(f"Супер-админ из конфига: {super_admin_id}, текущий пользователь: {user_id}")
    
    if user_id != super_admin_id:
        logger.warning(f"Попытка удалить админа без прав супер-админа: user_id={user_id}, требуется {super_admin_id}")
        await update.message.reply_text(
            "⛔ Только главный администратор может удалять администраторов.",
            parse_mode='Markdown'
        )
        return
    
    # Check if a user ID was provided
    if not context.args:
        logger.warning(f"Отсутствуют аргументы в команде admin_remove: user_id={user_id}")
        await update.message.reply_text("Использование: /admin_remove <user_id>")
        return
    
    try:
        admin_id = int(context.args[0])
        logger.info(f"Попытка удалить администратора: admin_id={admin_id}")
        
        # Проверяем текущий список админов
        db = load_database()
        logger.debug(f"Текущий список администраторов: {db.get('admins', [])}")
        
        # Remove the user from admin list
        success = remove_admin(admin_id)
        logger.info(f"Результат удаления администратора {admin_id}: {success}")
        
        if success:
            await update.message.reply_text(f"✅ Пользователь {admin_id} удален из списка администраторов.")
        else:
            await update.message.reply_text(f"ℹ️ Пользователь {admin_id} не является администратором.")
    except ValueError:
        logger.error(f"Неверный формат ID пользователя: {context.args[0]}")
        await update.message.reply_text("❌ Неверный ID пользователя. Используйте числовой ID.")

async def admin_stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /admin_stats command - show subscription and referral statistics
    """
    user_id = update.effective_user.id
    username = update.effective_user.username or "Unknown"
    logger.info(f"Запрос статистики: user_id={user_id}, username={username}")
    
    # Check if user is an admin
    is_user_admin = is_admin(user_id)
    logger.info(f"Проверка прав администратора для user_id={user_id}: {is_user_admin}")
    
    if not is_user_admin:
        logger.warning(f"Отказано в доступе к статистике: user_id={user_id}, username={username}")
        await update.message.reply_text(
            "⛔ У вас нет прав администратора для доступа к этой команде.",
            parse_mode='Markdown'
        )
        return
    
    # Get period from arguments, default to 7 days
    period_days = 7
    if context.args and len(context.args) > 0:
        try:
            period_days = int(context.args[0])
            logger.debug(f"Запрошен период: {period_days} дней")
        except ValueError:
            logger.warning(f"Неверный формат периода: {context.args[0]}, используется по умолчанию: 7 дней")
            pass
    
    # Get subscription stats
    logger.debug(f"Запрос статистики за {period_days} дней")
    stats = get_subscription_stats(period_days)
    logger.debug(f"Получена статистика: {stats}")
    
    # Безопасно форматируем числовые значения, чтобы избежать проблем с Markdown
    # Например, число 2.50% может быть интерпретировано как незакрытый курсив из-за _
    active_subs = stats['active_subscriptions']
    inactive_subs = stats['inactive_subscriptions']
    revenue = "{:.2f}".format(stats['subscription_revenue'])
    payouts = "{:.2f}".format(stats['referral_payouts'])
    percentage = "{:.2f}".format(stats['referral_percentage'])
    
    # Format the message, избегая использования форматирования в динамических данных
    message = (
        f"📊 *Статистика за {stats['period_days']} дней*\n\n"
        f"👤 Пользователей с активной подпиской: {active_subs}\n"
        f"👤 Пользователей без подписки: {inactive_subs}\n\n"
        f"💵 Общий доход от подписок: {revenue}₽\n"
        f"💸 Выплаты по реферальной программе: {payouts}₽\n"
        f"📈 Процент выплат: {percentage}%\n\n"
        f"Используйте /admin\\_stats <дней> для изменения периода."
    )
    
    try:
        await update.message.reply_text(
            message,
            parse_mode='Markdown'
        )
        logger.info(f"Статистика успешно отправлена пользователю {user_id}")
    except Exception as e:
        logger.error(f"Ошибка при отправке статистики: {e}")
        # Резервный вариант без Markdown
        await update.message.reply_text(
            f"📊 Статистика за {stats['period_days']} дней\n\n"
            f"👤 Пользователей с активной подпиской: {active_subs}\n"
            f"👤 Пользователей без подписки: {inactive_subs}\n\n"
            f"💵 Общий доход от подписок: {revenue}₽\n"
            f"💸 Выплаты по реферальной программе: {payouts}₽\n"
            f"📈 Процент выплат: {percentage}%\n\n"
            f"Используйте /admin_stats <дней> для изменения периода."
        )

async def admin_payout_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /admin_payout command - process weekly payouts
    """
    user_id = update.effective_user.id
    
    # Check if user is an admin
    if not is_admin(user_id):
        # If not admin, ignore the command
        return
    
    # Check if confirmation code is provided
    if not context.args or len(context.args) < 1 or context.args[0] != "confirm":
        await update.message.reply_text(
            "⚠️ *Внимание!* Эта команда запустит еженедельные выплаты по реферальной программе.\n\n"
            "Для подтверждения используйте:\n"
            "`/admin_payout confirm`",
            parse_mode='Markdown'
        )
        return
    
    # Process weekly payouts
    num_transactions, total_amount = collect_weekly_payouts()
    
    # Format the message
    if num_transactions > 0:
        message = (
            f"✅ *Еженедельные выплаты подготовлены*\n\n"
            f"📊 Количество транзакций: {num_transactions}\n"
            f"💰 Общая сумма: {total_amount:.2f}₽\n\n"
            f"Используйте /admin_process_payouts для обработки выплат через Robokassa."
        )
    else:
        message = "ℹ️ Нет ожидающих выплат для обработки."
    
    await update.message.reply_text(
        message,
        parse_mode='Markdown'
    )

async def admin_process_payouts_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /admin_process_payouts command - process payouts through Robokassa
    """
    user_id = update.effective_user.id
    
    # Check if user is an admin
    if not is_admin(user_id):
        # If not admin, ignore the command
        return
    
    # TODO: Implement actual payout processing with Robokassa
    # For now, just mark the most recent payout batch as completed
    
    transactions_db = load_transactions()
    for weekly_payout in reversed(transactions_db.get("weekly_payouts", [])):
        if weekly_payout["status"] == "pending":
            weekly_payout["status"] = "processing"
            weekly_payout["processed_at"] = datetime.datetime.now().isoformat()
            save_transactions(transactions_db)
            
            await update.message.reply_text(
                f"✅ *Выплаты запущены в обработку*\n\n"
                f"📊 Количество пользователей: {weekly_payout['total_users']}\n"
                f"💰 Общая сумма: {weekly_payout['total_amount']:.2f}₽\n\n"
                f"Статус выплат будет обновлен автоматически после обработки."
            )
            return
    
    await update.message.reply_text(
        "ℹ️ Нет ожидающих выплат для обработки."
    )

async def admin_export_report_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /admin_export_report command - export user and referral data to Excel
    """
    user_id = update.effective_user.id
    
    # Check if user is an admin
    if not is_admin(user_id):
        # If not admin, ignore the command
        return
    
    # Generate Excel report
    await update.message.reply_text(
        "📊 *Экспорт отчета*\n\n"
        "Отчет будет сгенерирован и отправлен отдельным сообщением.\n\n"
        "Пожалуйста, используйте команду:\n"
        "`/admin_export_report`",
        parse_mode='Markdown'
    )
    
    try:
        import pandas as pd
        from io import BytesIO
        
        # Load database
        db = load_database()
        transactions_db = load_transactions()
        
        # Create a list to store user data
        users_data = []
        
        # Process each user
        for user_id_str, user_data in db["users"].items():
            user_id = int(user_id_str)
            
            # Get referral rewards for this user
            rewards = get_user_total_rewards(user_id)
            
            # Count referrals at each level
            referrals = user_data.get("referrals", {})
            level1_count = len(referrals.get("level1", []))
            level2_count = len(referrals.get("level2", []))
            level3_count = len(referrals.get("level3", []))
            level4_count = len(referrals.get("level4", []))
            
            # Calculate referral rewards for each level
            # This is a simplified calculation - in reality we would need to sum actual transactions
            level1_reward = level1_count * 199 * 0.05
            level2_reward = level2_count * 199 * 0.02
            level3_reward = level3_count * 199 * 0.02
            level4_reward = level4_count * 199 * 0.01
            
            # Check if subscription is active
            has_subscription = False
            if user_data.get("subscription_expiry"):
                try:
                    expiry_date = datetime.datetime.fromisoformat(user_data["subscription_expiry"])
                    has_subscription = datetime.datetime.now() < expiry_date
                except (ValueError, TypeError):
                    pass
            
            # Add user data to the list
            users_data.append({
                "ID": user_id,
                "Username": user_data.get("username", ""),
                "First Name": user_data.get("first_name", ""),
                "Last Name": user_data.get("last_name", ""),
                "Phone Number": user_data.get("phone", ""),
                "Subscription Status": "Активна" if has_subscription else "Неактивна",
                "Referral Code": user_data.get("referral_code", ""),
                "Level 1 Referrals": f"{level1_count} = {level1_reward:.2f}₽",
                "Level 2 Referrals": f"{level2_count} = {level2_reward:.2f}₽",
                "Level 3 Referrals": f"{level3_count} = {level3_reward:.2f}₽",
                "Level 4 Referrals": f"{level4_count} = {level4_reward:.2f}₽",
                "Total Rewards": f"{rewards['total_all_time']:.2f}₽",
                "Pending Rewards": f"{rewards['total_pending']:.2f}₽",
                "Paid Rewards": f"{rewards['total_paid']:.2f}₽"
            })
        
        # Create DataFrame
        df = pd.DataFrame(users_data)
        
        # Save to Excel
        output = BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df.to_excel(writer, sheet_name='Users', index=False)
            
            # Add a Summary sheet
            summary_data = {
                "Metric": [
                    "Total Users",
                    "Active Subscriptions",
                    "Inactive Users",
                    "Total Subscription Revenue",
                    "Total Referral Payouts",
                    "Referral Payout Percentage"
                ],
                "Value": [
                    len(users_data),
                    sum(1 for user in users_data if user["Subscription Status"] == "Активна"),
                    sum(1 for user in users_data if user["Subscription Status"] == "Неактивна"),
                    "Placeholder",  # Will be calculated from transactions
                    "Placeholder",  # Will be calculated from transactions
                    "Placeholder"   # Will be calculated
                ]
            }
            
            # Calculate subscription revenue and referral payouts
            subscription_revenue = sum(
                t["amount"] for t in transactions_db.get("transactions", [])
                if t["type"] == "subscription" and t["status"] == "completed"
            )
            
            referral_payouts = sum(
                t["amount"] for t in transactions_db.get("transactions", [])
                if t["type"] == "payout" and t["status"] == "completed"
            )
            
            # Update placeholder values
            summary_data["Value"][3] = f"{subscription_revenue:.2f}₽"
            summary_data["Value"][4] = f"{referral_payouts:.2f}₽"
            
            # Calculate percentage
            if subscription_revenue > 0:
                percentage = (referral_payouts / subscription_revenue) * 100
                summary_data["Value"][5] = f"{percentage:.2f}%"
            else:
                summary_data["Value"][5] = "0.00%"
            
            # Create summary DataFrame
            summary_df = pd.DataFrame(summary_data)
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
        
        # Reset buffer position
        output.seek(0)
        
        # Get current date for filename
        now = datetime.datetime.now().strftime("%Y-%m-%d")
        
        # Send file to user
        await update.message.reply_document(
            document=output,
            filename=f"katiysha_report_{now}.xlsx",
            caption="📊 Отчет по пользователям и реферальной программе."
        )
        
    except Exception as e:
        logger.error(f"Error generating report: {e}")
        await update.message.reply_text(
            f"❌ Ошибка при генерации отчета: {e}"
        )

async def admin_update_rates_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /admin_update_rates command - update referral rates
    """
    user_id = update.effective_user.id
    
    # Check if user is an admin
    if not is_admin(user_id):
        # If not admin, ignore the command
        return
    
    # Check if rates are provided
    if not context.args or len(context.args) < 4:
        await update.message.reply_text(
            "Использование: /admin_update_rates <level1> <level2> <level3> <level4>\n\n"
            "Пример: `/admin_update_rates 0.05 0.02 0.02 0.01`\n"
            "Это установит ставки: 5% для уровня 1, 2% для уровней 2-3, 1% для уровня 4.",
            parse_mode='Markdown'
        )
        return
    
    try:
        # Parse rates
        rates = {
            "level1": float(context.args[0]),
            "level2": float(context.args[1]),
            "level3": float(context.args[2]),
            "level4": float(context.args[3])
        }
        
        # Validate rates (0-1)
        for level, rate in rates.items():
            if rate < 0 or rate > 1:
                await update.message.reply_text(
                    f"❌ Неверная ставка для {level}: {rate}. Ставки должны быть в диапазоне 0-1 (0-100%)."
                )
                return
        
        # Update rates
        success = update_referral_rates(rates)
        
        if success:
            total_rate = sum(rates.values()) * 100
            await update.message.reply_text(
                f"✅ Ставки реферальной программы обновлены:\n\n"
                f"Уровень 1: {rates['level1']*100:.1f}%\n"
                f"Уровень 2: {rates['level2']*100:.1f}%\n"
                f"Уровень 3: {rates['level3']*100:.1f}%\n"
                f"Уровень 4: {rates['level4']*100:.1f}%\n\n"
                f"Суммарный % выплат: {total_rate:.1f}%"
            )
        else:
            await update.message.reply_text(
                "❌ Ошибка при обновлении ставок реферальной программы."
            )
    except ValueError:
        await update.message.reply_text(
            "❌ Неверный формат ставок. Используйте числа (например, 0.05 для 5%)."
        )

async def admin_user_referrals_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /admin_user_referrals command - show referrals for a specific user
    """
    user_id = update.effective_user.id
    
    # Check if user is an admin
    if not is_admin(user_id):
        # If not admin, ignore the command
        return
    
    # Check if a user ID was provided
    if not context.args:
        await update.message.reply_text("Использование: /admin_user_referrals <user_id>")
        return
    
    try:
        target_user_id = int(context.args[0])
        
        # Get user data
        user_data = get_user(target_user_id)
        if not user_data:
            await update.message.reply_text(f"❌ Пользователь с ID {target_user_id} не найден.")
            return
        
        # Get referral rewards for this user
        rewards = get_user_total_rewards(target_user_id)
        
        # Format referrals and rewards
        referrals = user_data.get("referrals", {})
        
        level1_referrals = referrals.get("level1", [])
        level2_referrals = referrals.get("level2", [])
        level3_referrals = referrals.get("level3", [])
        level4_referrals = referrals.get("level4", [])
        
        message = (
            f"👥 *Рефералы пользователя {target_user_id}*\n\n"
            f"👤 *Уровень 1 (5%)*: {len(level1_referrals)} рефералов\n"
            f"👥 *Уровень 2 (2%)*: {len(level2_referrals)} рефералов\n"
            f"👥 *Уровень 3 (2%)*: {len(level3_referrals)} рефералов\n"
            f"👥 *Уровень 4 (2%)*: {len(level4_referrals)} рефералов\n\n"
            f"💰 *Вознаграждения*:\n"
            f"💵 Ожидает выплаты: {rewards['total_pending']:.2f}₽\n"
            f"💸 Выплачено: {rewards['total_paid']:.2f}₽\n"
            f"📊 Всего заработано: {rewards['total_all_time']:.2f}₽\n\n"
            f"Для выплаты вознаграждения используйте:\n"
            f"`/admin_user_payout {target_user_id}`"
        )
        
        await update.message.reply_text(
            message,
            parse_mode='Markdown'
        )
    except ValueError:
        await update.message.reply_text("❌ Неверный ID пользователя. Используйте числовой ID.")

async def admin_user_payout_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /admin_user_payout command - process payout for a specific user
    """
    user_id = update.effective_user.id
    
    # Check if user is an admin
    if not is_admin(user_id):
        # If not admin, ignore the command
        return
    
    # Check if a user ID was provided
    if not context.args:
        await update.message.reply_text("Использование: /admin_user_payout <user_id>")
        return
    
    try:
        target_user_id = int(context.args[0])
        
        # Process payout for user
        amount, transaction_id = process_payout_for_user(target_user_id)
        
        if amount > 0:
            await update.message.reply_text(
                f"✅ Выплата для пользователя {target_user_id} создана.\n\n"
                f"💰 Сумма: {amount:.2f}₽\n"
                f"🔢 ID транзакции: {transaction_id}\n\n"
                f"Статус выплаты будет обновлен после обработки через Robokassa."
            )
        else:
            await update.message.reply_text(
                f"ℹ️ Нет ожидающих выплат для пользователя {target_user_id}."
            )
    except ValueError:
        await update.message.reply_text("❌ Неверный ID пользователя. Используйте числовой ID.")

# Admin callback handling

async def admin_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle admin panel callbacks
    """
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    
    # Check if user is an admin
    if not is_admin(user_id):
        # If not admin, ignore the callback
        return
    
    callback_data = query.data
    
    if callback_data == "admin_subscription_stats":
        # Show subscription statistics
        stats = get_subscription_stats(7)  # Last 7 days
        
        message = (
            f"📊 *Статистика подписок*\n\n"
            f"👤 Активных подписок: {stats['active_subscriptions']}\n"
            f"👤 Неактивных пользователей: {stats['inactive_subscriptions']}\n\n"
            f"💵 Доход от подписок (7 дней): {stats['subscription_revenue']:.2f}₽\n"
            f"💸 Выплаты рефералам (7 дней): {stats['referral_payouts']:.2f}₽\n"
            f"📈 Процент выплат: {stats['referral_percentage']:.2f}%\n\n"
            f"Для подробной статистики используйте команду:\n"
            f"`/admin_stats <количество_дней>`"
        )
        
        await query.edit_message_text(
            text=message,
            parse_mode='Markdown'
        )
    
    elif callback_data == "admin_payouts":
        # Show payout management options
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("💰 Сформировать еженедельные выплаты", callback_data="admin_create_payouts")],
            [InlineKeyboardButton("💸 Обработать ожидающие выплаты", callback_data="admin_process_pending_payouts")],
            [InlineKeyboardButton("📋 История выплат", callback_data="admin_payout_history")],
            [InlineKeyboardButton("🔙 Назад", callback_data="admin_back_to_main")]
        ])
        
        await query.edit_message_text(
            text="💰 *Управление выплатами*\n\n"
                 "Выберите действие:",
            reply_markup=keyboard,
            parse_mode='Markdown'
        )
    
    elif callback_data == "admin_referrals":
        # Show referral management options
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("👤 Информация о пользователе", callback_data="admin_user_info")],
            [InlineKeyboardButton("💰 Выплата для пользователя", callback_data="admin_user_payout_cb")],
            [InlineKeyboardButton("⚙️ Настройки ставок", callback_data="admin_referral_settings")],
            [InlineKeyboardButton("🔙 Назад", callback_data="admin_back_to_main")]
        ])
        
        await query.edit_message_text(
            text="👥 *Управление рефералами*\n\n"
                 "Выберите действие:",
            reply_markup=keyboard,
            parse_mode='Markdown'
        )
    
    elif callback_data == "admin_export_report":
        # Notify that report will be generated and sent
        await query.edit_message_text(
            text="📊 *Экспорт отчета*\n\n"
                 "Отчет будет сгенерирован и отправлен отдельным сообщением.\n\n"
                 "Пожалуйста, используйте команду:\n"
                 "`/admin_export_report`",
            parse_mode='Markdown'
        )
    
    elif callback_data == "admin_referral_settings":
        # Show referral rate settings
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Обновить ставки", callback_data="admin_update_rates")],
            [InlineKeyboardButton("🔙 Назад", callback_data="admin_back_to_main")]
        ])
        
        # Get current rates
        try:
            import config
            current_rates = {
                "level1": getattr(config, "REFERRAL_RATE_LEVEL1", 0.05),
                "level2": getattr(config, "REFERRAL_RATE_LEVEL2", 0.02),
                "level3": getattr(config, "REFERRAL_RATE_LEVEL3", 0.02),
                "level4": getattr(config, "REFERRAL_RATE_LEVEL4", 0.01),
            }
            
            total_rate = sum(current_rates.values()) * 100
            
            message = (
                f"⚙️ *Настройки реферальной программы*\n\n"
                f"*Текущие ставки:*\n"
                f"Уровень 1: {current_rates['level1']*100:.1f}%\n"
                f"Уровень 2: {current_rates['level2']*100:.1f}%\n"
                f"Уровень 3: {current_rates['level3']*100:.1f}%\n"
                f"Уровень 4: {current_rates['level4']*100:.1f}%\n\n"
                f"Суммарный % выплат: {total_rate:.1f}%\n\n"
                f"Для обновления ставок используйте команду:\n"
                f"`/admin_update_rates <level1> <level2> <level3> <level4>`\n\n"
                f"Пример: `/admin_update_rates 0.05 0.02 0.02 0.01`"
            )
        except:
            message = (
                f"⚙️ *Настройки реферальной программы*\n\n"
                f"*Текущие ставки:*\n"
                f"Уровень 1: 5.0%\n"
                f"Уровень 2: 2.0%\n"
                f"Уровень 3: 2.0%\n"
                f"Уровень 4: 2.0%\n\n"
                f"Суммарный % выплат: 11.0%\n\n"
                f"Для обновления ставок используйте команду:\n"
                f"`/admin_update_rates <level1> <level2> <level3> <level4>`\n\n"
                f"Пример: `/admin_update_rates 0.05 0.02 0.02 0.01`"
            )
        
        await query.edit_message_text(
            text=message,
            reply_markup=keyboard,
            parse_mode='Markdown'
        )
    
    elif callback_data == "admin_back_to_main":
        # Return to main admin panel
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("📊 Статистика подписок", callback_data="admin_subscription_stats")],
            [InlineKeyboardButton("💰 Управление выплатами", callback_data="admin_payouts")],
            [InlineKeyboardButton("👥 Управление рефералами", callback_data="admin_referrals")],
            [InlineKeyboardButton("📋 Выгрузить отчёт", callback_data="admin_export_report")],
            [InlineKeyboardButton("⚙️ Настройки реф. программы", callback_data="admin_referral_settings")]
        ])
        
        await query.edit_message_text(
            text="🔐 *Панель администратора*\n\n"
                 "Выберите действие:",
            reply_markup=keyboard,
            parse_mode='Markdown'
        )
    
    # Additional callback handlers...
    elif callback_data == "admin_create_payouts":
        # Create weekly payouts
        num_transactions, total_amount = collect_weekly_payouts()
        
        if num_transactions > 0:
            message = (
                f"✅ *Еженедельные выплаты подготовлены*\n\n"
                f"📊 Количество транзакций: {num_transactions}\n"
                f"💰 Общая сумма: {total_amount:.2f}₽\n\n"
                f"Используйте 'Обработать ожидающие выплаты' для отправки выплат через Robokassa."
            )
        else:
            message = "ℹ️ Нет ожидающих выплат для обработки."
        
        # Back to payouts menu
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 Назад к управлению выплатами", callback_data="admin_payouts")]
        ])
        
        await query.edit_message_text(
            text=message,
            reply_markup=keyboard,
            parse_mode='Markdown'
        )
    
    elif callback_data == "admin_update_rates":
        # Prompt for new rates
        await query.edit_message_text(
            text="⚙️ *Обновление ставок реферальной программы*\n\n"
                 "Для обновления ставок используйте команду:\n"
                 "`/admin_update_rates <level1> <level2> <level3> <level4>`\n\n"
                 "Пример: `/admin_update_rates 0.05 0.02 0.02 0.01`\n"
                 "Это установит ставки: 5% для уровня 1, 2% для уровней 2-3, 1% для уровня 4.",
            parse_mode='Markdown'
        )
    
    # Add other callback handlers as needed

async def debug_admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Отладочная команда для проверки прав администратора и структуры базы данных
    """
    user_id = update.effective_user.id
    username = update.effective_user.username or "Unknown"
    logger.info(f"Вызвана отладочная команда: user_id={user_id}, username={username}")
    
    # Загружаем базу данных
    db = load_database()
    admins_list = db.get('admins', [])
    
    # Проверяем, является ли пользователь админом
    is_user_admin = is_admin(user_id)
    
    # Проверяем, является ли пользователь супер-админом
    super_admin_id = config.ADMIN_USER_ID
    is_super_admin = (user_id == super_admin_id)
    
    # Форматируем сообщение с отладочной информацией
    debug_message = (
        f"🔍 *Отладка прав администратора*\n\n"
        f"Ваш ID: `{user_id}`\n"
        f"Ваш username: `{username}`\n\n"
        f"✅ Права администратора: {'Есть' if is_user_admin else 'Нет'}\n"
        f"👑 Права супер-администратора: {'Есть' if is_super_admin else 'Нет'}\n\n"
        f"⚙️ Настройки:\n"
        f"- ID супер-администратора: `{super_admin_id}`\n"
        f"- Количество администраторов в базе: {len(admins_list)}\n"
        f"- Текущий список ID администраторов: `{admins_list}`\n\n"
        f"💾 Примечание: если ID хранятся как строки, преобразование типов выполняется автоматически."
    )
    
    await update.message.reply_text(
        debug_message,
        parse_mode='Markdown'
    )
    logger.info(f"Отладочная информация отправлена пользователю {user_id}")

async def debug_database_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Отладочная команда для проверки содержимого базы данных
    """
    user_id = update.effective_user.id
    
    # Проверка прав администратора
    if not is_admin(user_id):
        await update.message.reply_text("У вас нет прав для выполнения этой команды.")
        return
    
    try:
        # Загружаем базу данных
        db = load_database()
        
        # Проверяем количество пользователей
        users_count = len(db.get("users", {}))
        
        # Подробная информация о пользователях
        users_info = []
        for user_id_str, user_data in db.get("users", {}).items():
            subscription_status = "❌ Нет подписки"
            if "subscription_expiry" in user_data and user_data["subscription_expiry"]:
                try:
                    expiry_date = datetime.datetime.fromisoformat(user_data["subscription_expiry"])
                    if datetime.datetime.now() < expiry_date:
                        subscription_status = f"✅ Активна до {expiry_date.strftime('%d.%m.%Y')}"
                    else:
                        subscription_status = f"❌ Истекла {expiry_date.strftime('%d.%m.%Y')}"
                except (ValueError, TypeError):
                    subscription_status = "❌ Ошибка в дате подписки"
            
            user_info = (
                f"ID: {user_id_str}\n"
                f"Имя: {user_data.get('first_name', 'Не указано')}\n"
                f"Username: {user_data.get('username', 'Нет')}\n"
                f"Подписка: {subscription_status}\n"
                f"Реферер: {user_data.get('referrer_id', 'Нет')}\n"
                f"-------------------"
            )
            users_info.append(user_info)
        
        # Формируем подробное сообщение (без Markdown)
        if users_info:
            message = f"📊 База данных пользователей\n\nВсего пользователей: {users_count}\n\n"
            # Объединяем информацию только о первых 5 пользователях (уменьшаем, чтобы избежать проблем с длиной)
            message += "\n".join(users_info[:5])
            
            if len(users_info) > 5:
                message += f"\n\n...и еще {len(users_info) - 5} пользователей."
        else:
            message = "База данных пуста. Нет зарегистрированных пользователей."
        
        # Отправляем сообщение без Markdown
        await update.message.reply_text(message)
        
        # Если больше 5 пользователей, отправим дополнительные сообщения
        if len(users_info) > 5:
            # Разбиваем список на части по 5 пользователям
            for i in range(1, min(3, (len(users_info) + 4) // 5)):  # Максимум 3 дополнительных сообщения
                start_idx = i * 5
                end_idx = min(start_idx + 5, len(users_info))
                additional_message = f"📊 Пользователи {start_idx+1}-{end_idx} из {len(users_info)}:\n\n"
                additional_message += "\n".join(users_info[start_idx:end_idx])
                await update.message.reply_text(additional_message)
        
    except Exception as e:
        logger.error(f"Ошибка при выполнении debug_database: {e}")
        await update.message.reply_text(f"Произошла ошибка при чтении базы данных: {str(e)}")

# Альтернативный вариант команды, показывающий только суммарную информацию
async def debug_database_summary_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Отладочная команда для просмотра сводки базы данных
    """
    user_id = update.effective_user.id
    
    # Проверка прав администратора
    if not is_admin(user_id):
        await update.message.reply_text("У вас нет прав для выполнения этой команды.")
        return
    
    try:
        # Загружаем базу данных
        db = load_database()
        
        # Проверяем количество пользователей
        users_count = len(db.get("users", {}))
        
        # Считаем активные и неактивные подписки
        active_subscriptions = 0
        inactive_subscriptions = 0
        
        for user_data in db.get("users", {}).values():
            if "subscription_expiry" in user_data and user_data["subscription_expiry"]:
                try:
                    expiry_date = datetime.datetime.fromisoformat(user_data["subscription_expiry"])
                    if datetime.datetime.now() < expiry_date:
                        active_subscriptions += 1
                    else:
                        inactive_subscriptions += 1
                except (ValueError, TypeError):
                    inactive_subscriptions += 1
            else:
                inactive_subscriptions += 1
        
        # Подсчет рефералов
        users_with_referrers = 0
        for user_data in db.get("users", {}).values():
            if "referrer_id" in user_data and user_data["referrer_id"]:
                users_with_referrers += 1
        
        # Формируем сообщение
        message = (
            "📊 Сводка базы данных пользователей\n\n"
            f"- Всего пользователей: {users_count}\n"
            f"- Активных подписок: {active_subscriptions}\n"
            f"- Неактивных подписок: {inactive_subscriptions}\n"
            f"- Пользователей с рефералами: {users_with_referrers}\n\n"
            f"Используйте /debug_database для просмотра подробной информации."
        )
        
        await update.message.reply_text(message)
        
    except Exception as e:
        logger.error(f"Ошибка при выполнении debug_database_summary: {e}")
        await update.message.reply_text(f"Произошла ошибка при чтении базы данных: {str(e)}")

async def debug_referral_chain_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Отладочная команда для проверки цепочки рефералов пользователя
    """
    user_id = update.effective_user.id
    
    # Проверка прав администратора
    if not is_admin(user_id):
        await update.message.reply_text("У вас нет прав для выполнения этой команды.")
        return
    
    # Проверяем, указан ли ID пользователя для поиска
    target_user_id = None
    if context.args:
        try:
            target_user_id = int(context.args[0])
        except ValueError:
            await update.message.reply_text("Неверный формат ID. Используйте числовой ID пользователя.")
            return
    else:
        # Если ID не указан, используем ID самого отправителя команды
        target_user_id = user_id
    
    try:
        # Загружаем базу данных
        db = load_database()
        user_data = get_user(target_user_id)
        
        if not user_data:
            await update.message.reply_text(f"Пользователь с ID {target_user_id} не найден в базе данных.")
            return
        
        # Формируем информацию о пользователе
        username = user_data.get('username', 'Нет')
        first_name = user_data.get('first_name', 'Не указано')
        
        # Проверяем наличие реферера у пользователя
        referrer_id = user_data.get('referrer_id')
        
        # Собираем информацию о реферере (если есть)
        referrer_info = "Нет"
        if referrer_id:
            referrer_data = get_user(referrer_id)
            if referrer_data:
                referrer_username = referrer_data.get('username', 'Нет')
                referrer_first_name = referrer_data.get('first_name', 'Не указано')
                referrer_info = f"ID: {referrer_id}, Имя: {referrer_first_name}, Username: {referrer_username}"
        
        # Ищем рефералов пользователя (тех, кто указал его как реферера)
        referrals = []
        for user_id_str, data in db["users"].items():
            if data.get('referrer_id') == target_user_id:
                user_username = data.get('username', 'Нет')
                user_first_name = data.get('first_name', 'Не указано')
                subscription_status = "❌ Нет подписки"
                
                if "subscription_expiry" in data and data["subscription_expiry"]:
                    try:
                        expiry_date = datetime.datetime.fromisoformat(data["subscription_expiry"])
                        if datetime.datetime.now() < expiry_date:
                            subscription_status = f"✅ Активна до {expiry_date.strftime('%d.%m.%Y')}"
                        else:
                            subscription_status = f"❌ Истекла {expiry_date.strftime('%d.%m.%Y')}"
                    except (ValueError, TypeError):
                        subscription_status = "❌ Ошибка в дате подписки"
                
                referrals.append({
                    "id": user_id_str,
                    "username": user_username,
                    "first_name": user_first_name,
                    "subscription_status": subscription_status
                })
        
        # Собираем информацию о вознаграждениях
        rewards_stats = get_user_total_rewards(target_user_id)
        
        # Формируем сообщение
        message = (
            f"🔍 Информация о реферальной цепочке пользователя {target_user_id}\n\n"
            f"👤 Имя: {first_name}\n"
            f"👤 Username: {username}\n\n"
            f"👆 Реферер: {referrer_info}\n\n"
            f"💰 Вознаграждения:\n"
            f"- Ожидает выплаты: {rewards_stats['total_pending']:.2f}₽\n"
            f"- Уже выплачено: {rewards_stats['total_paid']:.2f}₽\n"
            f"- Всего заработано: {rewards_stats['total_all_time']:.2f}₽\n\n"
            f"👥 Рефералы (напрямую приглашенные): {len(referrals)}\n"
        )
        
        # Добавляем информацию о каждом реферале
        if referrals:
            for i, ref in enumerate(referrals, 1):
                ref_info = (
                    f"{i}. ID: {ref['id']}, Имя: {ref['first_name']}, "
                    f"Username: {ref['username']}, Подписка: {ref['subscription_status']}\n"
                )
                message += ref_info
        else:
            message += "У пользователя нет прямых рефералов.\n"
        
        # Отправляем сообщение
        await update.message.reply_text(message)
        
    except Exception as e:
        logger.error(f"Ошибка при выполнении debug_referral_chain: {e}")
        await update.message.reply_text(f"Произошла ошибка: {str(e)}")

async def debug_transactions_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Отладочная команда для просмотра транзакций
    """
    user_id = update.effective_user.id
    
    # Проверка прав администратора
    if not is_admin(user_id):
        await update.message.reply_text("У вас нет прав для выполнения этой команды.")
        return
    
    try:
        # Загружаем транзакции
        transactions_db = load_transactions()
        
        # Проверяем аргументы для фильтрации
        if context.args:
            # Если указан ID пользователя, фильтруем по нему
            try:
                filter_user_id = int(context.args[0])
                transactions = [t for t in transactions_db.get("transactions", []) 
                               if t['user_id'] == filter_user_id]
                
                if not transactions:
                    await update.message.reply_text(f"Транзакций для пользователя {filter_user_id} не найдено.")
                    return
                
                message = f"🧾 Транзакции пользователя {filter_user_id} (всего: {len(transactions)}):\n\n"
                
                # Сортируем по дате создания (последние сначала)
                transactions.sort(key=lambda t: t['created_at'], reverse=True)
                
                # Выводим последние 10 транзакций
                for i, t in enumerate(transactions[:10], 1):
                    created_at = t['created_at'].split('T')[0]  # Только дата
                    message += (
                        f"{i}. ID: {t['id']}, Тип: {t['type']}, Сумма: {t['amount']}₽, "
                        f"Статус: {t['status']}, Дата: {created_at}\n"
                    )
                
                if len(transactions) > 10:
                    message += f"\n...и еще {len(transactions) - 10} транзакций."
                
                await update.message.reply_text(message)
                return
                
            except ValueError:
                await update.message.reply_text("Неверный формат ID. Используйте числовой ID пользователя.")
                return
        
        # Если не указан ID пользователя, показываем общую сводку
        transaction_types = {}
        transaction_statuses = {}
        
        for transaction in transactions_db.get("transactions", []):
            t_type = transaction['type']
            t_status = transaction['status']
            
            if t_type not in transaction_types:
                transaction_types[t_type] = 0
            transaction_types[t_type] += 1
            
            if t_status not in transaction_statuses:
                transaction_statuses[t_status] = 0
            transaction_statuses[t_status] += 1
        
        # Подсчет сумм для разных типов транзакций
        referral_reward_amount = sum(t['amount'] for t in transactions_db.get("transactions", []) 
                                if t['type'] == 'referral_reward')
        subscription_amount = sum(t['amount'] for t in transactions_db.get("transactions", []) 
                                if t['type'] == 'subscription')
        payout_amount = sum(t['amount'] for t in transactions_db.get("transactions", []) 
                           if t['type'] == 'payout')
        
        # Формируем сообщение
        message = (
            "📊 Сводка транзакций\n\n"
            f"Всего транзакций: {len(transactions_db.get('transactions', []))}\n\n"
            "Типы транзакций:\n"
        )
        
        for t_type, count in transaction_types.items():
            message += f"- {t_type}: {count}\n"
        
        message += "\nСтатусы транзакций:\n"
        for t_status, count in transaction_statuses.items():
            message += f"- {t_status}: {count}\n"
        
        message += (
            f"\nСуммы по типам:\n"
            f"- Реферальные вознаграждения: {referral_reward_amount:.2f}₽\n"
            f"- Подписки: {subscription_amount:.2f}₽\n"
            f"- Выплаты: {payout_amount:.2f}₽\n\n"
            f"Для просмотра транзакций конкретного пользователя используйте:\n"
            f"/debug_transactions <ID пользователя>"
        )
        
        await update.message.reply_text(message)
        
    except Exception as e:
        logger.error(f"Ошибка при выполнении debug_transactions: {e}")
        await update.message.reply_text(f"Произошла ошибка: {str(e)}")

async def debug_process_rewards_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Отладочная команда для принудительного запуска расчета реферальных вознаграждений
    """
    user_id = update.effective_user.id
    
    # Проверка прав администратора
    if not is_admin(user_id):
        await update.message.reply_text("У вас нет прав для выполнения этой команды.")
        return
    
    try:
        # Проверяем аргументы
        if not context.args:
            await update.message.reply_text(
                "Использование: /debug_process_rewards <ID пользователя>\n\n"
                "Данная команда принудительно запустит расчет реферальных вознаграждений, "
                "как если бы указанный пользователь только что обновил подписку."
            )
            return
        
        target_user_id = None
        try:
            target_user_id = int(context.args[0])
        except ValueError:
            await update.message.reply_text("Неверный формат ID. Используйте числовой ID пользователя.")
            return
        
        # Проверяем существование пользователя
        user_data = get_user(target_user_id)
        if not user_data:
            await update.message.reply_text(f"Пользователь с ID {target_user_id} не найден в базе данных.")
            return
        
        # Запускаем процесс начисления реферальных вознаграждений
        transaction_ids = process_subscription_referral_rewards(target_user_id)
        
        if transaction_ids:
            message = (
                f"✅ Реферальные вознаграждения успешно обработаны!\n\n"
                f"Создано транзакций: {len(transaction_ids)}\n"
                f"ID транзакций: {', '.join(map(str, transaction_ids))}\n\n"
                f"Используйте /debug_transactions {target_user_id} для просмотра деталей."
            )
        else:
            message = (
                f"ℹ️ Реферальные вознаграждения не начислены.\n\n"
                f"Возможные причины:\n"
                f"- У пользователя нет реферера\n"
                f"- Цепочка рефералов не найдена\n"
                f"- Произошла ошибка при расчете"
            )
        
        await update.message.reply_text(message)
        
    except Exception as e:
        logger.error(f"Ошибка при выполнении debug_process_rewards: {e}")
        await update.message.reply_text(f"Произошла ошибка: {str(e)}")