# Миграция на PostgreSQL

В этом документе описан процесс миграции бота Катюша с JSON-файлов на базу данных PostgreSQL.

## Предварительные требования

1. Установленный PostgreSQL сервер
2. Переменные окружения для подключения к PostgreSQL:
   - `DATABASE_URL`: URL для подключения к PostgreSQL (формат: `postgresql://username:password@host:port/database`)
   - `PGHOST`: Хост PostgreSQL сервера
   - `PGPORT`: Порт PostgreSQL сервера
   - `PGUSER`: Имя пользователя PostgreSQL
   - `PGPASSWORD`: Пароль пользователя PostgreSQL
   - `PGDATABASE`: Имя базы данных PostgreSQL

## Установка зависимостей

Для работы с PostgreSQL необходимо установить дополнительные зависимости:

```bash
python install_dependencies.py
```

## Шаги миграции

### 1. Создание таблиц базы данных

```bash
python manage_db.py init-db
```

Этот скрипт создаст необходимые таблицы в базе данных PostgreSQL на основе моделей SQLAlchemy.

### 2. Миграция данных из JSON в PostgreSQL

```bash
python manage_db.py migrate-data
```

Этот скрипт мигрирует данные из JSON-файлов в базу данных PostgreSQL.

### 3. Создание и применение начальной миграции

```bash
python create_migration.py
```

Этот скрипт создаст и применит начальную миграцию базы данных, используя Flask-Migrate.

## Резервное копирование и восстановление базы данных

### Создание резервной копии в Яндекс.Диск

Для резервного копирования базы данных на Яндекс.Диск необходимы следующие переменные окружения:
- `YANDEX_OAUTH_CLIENT_ID`: ID клиента OAuth Яндекс.Диска
- `YANDEX_OAUTH_CLIENT_SECRET`: Секретный ключ OAuth Яндекс.Диска

Создание резервной копии:

```bash
python manage_db.py backup
```

### Просмотр списка резервных копий

```bash
python manage_db.py list-backups
```

### Восстановление из резервной копии

```bash
python manage_db.py restore /path/to/backup.sql  # Локальный файл
```

или

```bash
python manage_db.py restore /Katiysha_Bot_Backups/katiysha_bot_backup_20250502_120000.sql  # Файл на Яндекс.Диске
```

## Управление миграциями базы данных

### Создание новой миграции

При внесении изменений в модели базы данных необходимо создать новую миграцию:

```bash
python manage_db.py create-migration
```

### Применение миграций

```bash
python manage_db.py apply-migrations
```

## Структура базы данных

### Таблица users

- `id`: ID пользователя в Telegram (primary key)
- `username`: Имя пользователя в Telegram (может быть NULL)
- `first_name`: Имя пользователя
- `last_name`: Фамилия пользователя
- `free_request_used`: Использован ли бесплатный запрос
- `subscription_expiry`: Дата окончания подписки
- `referral_code`: Реферальный код пользователя
- `referrer_id`: ID пользователя, который пригласил текущего
- `referrals_json`: JSON-строка со структурой рефералов
- `created_at`: Дата создания записи
- `updated_at`: Дата обновления записи

### Таблица math_problems

- `id`: ID задачи (primary key)
- `user_id`: ID пользователя, который отправил задачу
- `problem_text`: Текст задачи
- `image_path`: Путь к изображению задачи (если есть)
- `solution`: Решение задачи
- `created_at`: Дата создания записи
- `updated_at`: Дата обновления записи

### Таблица transactions

- `id`: ID транзакции (primary key)
- `type`: Тип транзакции (subscription, referral_reward, payout)
- `user_id`: ID пользователя, связанного с транзакцией
- `amount`: Сумма транзакции в рублях
- `description`: Описание транзакции
- `related_user_id`: ID связанного пользователя (например, реферера для вознаграждений)
- `status`: Статус транзакции (pending, completed, failed, processing, processing_payout)
- `payment_data`: Дополнительные данные о платеже (JSON)
- `created_at`: Дата создания записи
- `updated_at`: Дата обновления записи
- `payout_id`: ID связанной выплаты

### Таблица weekly_payouts

- `id`: ID выплаты (primary key)
- `status`: Статус выплаты (processing, completed, failed)
- `total_amount`: Общая сумма выплаты в рублях
- `total_users`: Количество пользователей для выплаты
- `payout_data`: Данные о выплатах пользователям (JSON)
- `created_at`: Дата создания записи
- `updated_at`: Дата обновления записи

### Таблица yandex_disk_tokens

- `id`: ID токена (primary key)
- `access_token`: Токен доступа Яндекс.Диска
- `refresh_token`: Токен обновления Яндекс.Диска
- `token_type`: Тип токена (обычно "Bearer")
- `expires_at`: Дата истечения токена
- `created_at`: Дата создания записи
- `updated_at`: Дата обновления записи

### Таблица backup_logs

- `id`: ID лога (primary key)
- `backup_file`: Имя файла бэкапа
- `disk_path`: Путь на Яндекс.Диске
- `size_bytes`: Размер файла в байтах
- `status`: Статус бэкапа (success, failed)
- `error_message`: Сообщение об ошибке
- `created_at`: Дата создания записи