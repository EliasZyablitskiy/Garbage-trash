#!/usr/bin/env python
# coding: utf-8

"""
Унифицированный сервис управления реферальной системой бота Катюша
Объединяет функциональность старой и новой систем рефералов
"""

import logging
import os
import json
import random
import string
import base64
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Константы для реферальной системы
REFERRAL_LEVELS = {
    "level1": 0.05,  # 5% комиссии для прямых рефералов
    "level2": 0.02,  # 2% комиссии для рефералов 2-го уровня
    "level3": 0.02,  # 2% комиссии для рефералов 3-го уровня
    "level4": 0.02,  # 2% комиссии для рефералов 4-го уровня
}

# Стоимость подписки в рублях
SUBSCRIPTION_COST = 199.0

class ReferralService:
    """Унифицированный сервис управления реферальной системой"""
    
    def __init__(self, database_path: str = "users_db.json"):
        """
        Инициализация сервиса реферальной системы
        
        Args:
            database_path: Путь к файлу базы данных пользователей
        """
        self.database_path = database_path
        logger.info(f"Initialized ReferralService with database: {database_path}")
    
    def load_database(self) -> Dict[str, Any]:
        """
        Загрузка базы данных пользователей
        
        Returns:
            Dict[str, Any]: База данных пользователей
        """
        try:
            if os.path.exists(self.database_path):
                with open(self.database_path, 'r', encoding='utf-8') as file:
                    return json.load(file)
            else:
                # Создание пустой базы данных
                empty_db = {"users": {}}
                self.save_database(empty_db)
                return empty_db
        except Exception as e:
            logger.error(f"Ошибка загрузки базы данных: {str(e)}")
            return {"users": {}}
    
    def save_database(self, db: Dict[str, Any]) -> None:
        """
        Сохранение базы данных пользователей
        
        Args:
            db: База данных для сохранения
        """
        try:
            with open(self.database_path, 'w', encoding='utf-8') as file:
                json.dump(db, file, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Ошибка сохранения базы данных: {str(e)}")
    
    def generate_referral_code(self, user_id: int) -> str:
        """
        Генерация уникального реферального кода для пользователя
        
        Args:
            user_id: ID пользователя
            
        Returns:
            str: Уникальный реферальный код
        """
        # Создаем основу кода на базе ID пользователя и случайности
        prefix = "ref_"
        
        # Используем комбинацию ID пользователя и случайных символов
        # для обеспечения уникальности кода
        random_suffix = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
        base = f"{user_id}_{random_suffix}"
        
        # Конвертируем в base64 и берем только первые 12 символов
        # Это даст нам короткий, но очень уникальный код
        safe_code = base64.urlsafe_b64encode(base.encode()).decode()[:12]
        
        # Формируем полный код с префиксом
        full_code = f"{prefix}{safe_code}"
        
        # Проверяем, что код уникален в базе данных
        # Используем итеративный подход вместо рекурсивного
        attempt = 0
        max_attempts = 5
        
        while self.is_code_exists(full_code) and attempt < max_attempts:
            # Если код существует, создаем новый с другим случайным суффиксом
            random_suffix = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
            base = f"{user_id}_{random_suffix}_{attempt}"
            safe_code = base64.urlsafe_b64encode(base.encode()).decode()[:12]
            full_code = f"{prefix}{safe_code}"
            attempt += 1
        
        # Если после всех попыток код все еще не уникален,
        # добавляем текущее время для гарантии уникальности
        if self.is_code_exists(full_code):
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            base = f"{user_id}_{timestamp}"
            safe_code = base64.urlsafe_b64encode(base.encode()).decode()[:12]
            full_code = f"{prefix}{safe_code}"
        
        return full_code
    
    def is_code_exists(self, code: str) -> bool:
        """
        Проверка существования реферального кода в базе данных
        
        Args:
            code: Реферальный код для проверки
            
        Returns:
            bool: True, если код существует, False в противном случае
        """
        db = self.load_database()
        
        for user_id, user_data in db["users"].items():
            if user_data.get("referral_code") == code:
                return True
        
        return False
    
    def get_referral_link(self, user_id: int, bot_username: str) -> str:
        """
        Получение полной реферальной ссылки для пользователя
        
        Args:
            user_id: ID пользователя
            bot_username: Имя пользователя бота
            
        Returns:
            str: Полная реферальная ссылка
        """
        db = self.load_database()
        user_data = db["users"].get(str(user_id))
        
        if not user_data:
            logger.warning(f"User {user_id} not found in database")
            return ""
        
        # Если у пользователя нет реферального кода, генерируем его
        if not user_data.get("referral_code"):
            user_data["referral_code"] = self.generate_referral_code(user_id)
            db["users"][str(user_id)] = user_data
            self.save_database(db)
            logger.info(f"Generated referral code for user {user_id}: {user_data['referral_code']}")
        
        referral_code = user_data["referral_code"]
        return f"https://t.me/{bot_username}?start={referral_code}"
    
    def get_user(self, user_id: int) -> Optional[Dict[str, Any]]:
        """
        Получение данных пользователя из базы данных
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Optional[Dict[str, Any]]: Данные пользователя или None, если пользователь не найден
        """
        db = self.load_database()
        return db["users"].get(str(user_id))
    
    def save_user(self, user_data: Dict[str, Any]) -> None:
        """
        Сохранение данных пользователя в базу данных
        
        Args:
            user_data: Данные пользователя для сохранения
        """
        if "id" not in user_data:
            logger.error("Невозможно сохранить пользователя без идентификатора")
            return
        
        db = self.load_database()
        db["users"][str(user_data["id"])] = user_data
        self.save_database(db)
        logger.info(f"Saved user data for user {user_data['id']}")
    
    def process_new_referral(self, user_id: int, referral_code: str) -> bool:
        """
        Обработка нового реферала
        
        Args:
            user_id: ID пользователя, который перешел по реферальной ссылке
            referral_code: Реферальный код из ссылки
            
        Returns:
            bool: True, если реферальный код принят, False в противном случае
        """
        logger.info(f"Processing referral for user {user_id} with code {referral_code}")
        db = self.load_database()
        
        # Проверка, есть ли у пользователя уже реферер
        user_data = db["users"].get(str(user_id))
        if user_data and user_data.get("referrer_id"):
            logger.info(f"User {user_id} already has a referrer: {user_data['referrer_id']}")
            return False
        
        # Поиск пользователя с таким реферальным кодом
        referrer_id = None
        for db_user_id, db_user_data in db["users"].items():
            if db_user_data.get("referral_code") == referral_code:
                referrer_id = int(db_user_id)
                break
        
        if not referrer_id:
            logger.warning(f"Referrer not found for code {referral_code}")
            return False
        
        # Защита от самореферралов
        if referrer_id == user_id:
            logger.warning(f"User {user_id} tried to refer themselves")
            return False
        
        # Обновляем данные пользователя
        if not user_data:
            # Если пользователя нет в базе, создаем запись
            user_data = {
                "id": user_id,
                "username": None,
                "first_name": None,
                "last_name": None,
                "free_request_used": False,
                "subscription_expiry": None,
                "referral_code": None,
                "referrer_id": referrer_id,
                "referrals": {
                    "level1": [],
                    "level2": [],
                    "level3": [],
                    "level4": [],
                }
            }
        else:
            # Если пользователь существует, добавляем реферера
            user_data["referrer_id"] = referrer_id
            # Инициализируем структуру рефералов, если её нет
            if "referrals" not in user_data:
                user_data["referrals"] = {
                    "level1": [],
                    "level2": [],
                    "level3": [],
                    "level4": [],
                }
        
        # Сохраняем данные пользователя
        self.save_user(user_data)
        logger.info(f"User {user_id} set referrer to {referrer_id}")
        
        # Обновляем реферальную структуру на 4 уровня
        self._update_referral_structure(user_id, referrer_id, level=1)
        
        return True
    
    def _update_referral_structure(self, user_id: int, referrer_id: int, level: int) -> None:
        """
        Итеративное обновление структуры рефералов для всех уровней
        
        Args:
            user_id: ID реферала
            referrer_id: ID реферера
            level: Текущий уровень (1-4)
        """
        if level > 4 or not referrer_id:
            return
            
        # Убедимся, что referrer_id является целым числом
        if not isinstance(referrer_id, int):
            if isinstance(referrer_id, str):
                if referrer_id.isdigit():
                    referrer_id = int(referrer_id)
                else:
                    logger.error(f"Неверный формат referrer_id в _update_referral_structure: '{referrer_id}' (тип: {type(referrer_id)})")
                    return
            else:
                logger.warning(f"Invalid referrer_id format: {referrer_id}")
                return
        
        # Безопасная обработка циклов в реферальной цепочке
        if level > 1:
            chain = []
            current_id = referrer_id
            # Проверяем 10 уровней назад максимум для предотвращения бесконечных циклов
            for _ in range(10): 
                if current_id in chain:
                    logger.warning(f"Detected cycle in referral chain for user {user_id}")
                    return
                chain.append(current_id)
                
                ref_data = self.get_user(current_id)
                if not ref_data or not ref_data.get("referrer_id"):
                    break
                    
                next_id = ref_data.get("referrer_id")
                # Убедимся, что next_id является целым числом
                if not isinstance(next_id, int):
                    if isinstance(next_id, str):
                        if next_id.isdigit():
                            next_id = int(next_id)
                        else:
                            logger.error(f"Неверный формат referrer_id в цепочке: '{next_id}' (тип: {type(next_id)})")
                            break
                    else:
                        logger.warning(f"Invalid next_id format in chain: {next_id}")
                        break
                
                current_id = next_id
        
        db = self.load_database()
        referrer_data = db["users"].get(str(referrer_id))
        
        if not referrer_data:
            logger.warning(f"Referrer {referrer_id} not found in database")
            return
        
        # Инициализируем структуру рефералов, если её нет
        if "referrals" not in referrer_data:
            referrer_data["referrals"] = {
                "level1": [],
                "level2": [],
                "level3": [],
                "level4": [],
            }
        
        # Добавляем пользователя как реферала текущего уровня
        level_key = f"level{level}"
        if not isinstance(referrer_data["referrals"].get(level_key), list):
            referrer_data["referrals"][level_key] = []
        
        if user_id not in referrer_data["referrals"][level_key]:
            referrer_data["referrals"][level_key].append(user_id)
            self.save_user(referrer_data)
            logger.info(f"Added user {user_id} as level {level} referral of user {referrer_id}")
        
        # Получаем следующего реферера в цепочке
        next_referrer_id = referrer_data.get("referrer_id")
        if next_referrer_id:
            # Проверка и преобразование next_referrer_id
            if not isinstance(next_referrer_id, int):
                if isinstance(next_referrer_id, str):
                    if next_referrer_id.isdigit():
                        next_referrer_id = int(next_referrer_id)
                    else:
                        logger.error(f"Неверный формат next_referrer_id: '{next_referrer_id}' (тип: {type(next_referrer_id)})")
                        logger.error(f"Данные реферера: {referrer_data}")
                        return
                else:
                    logger.warning(f"Invalid next_referrer_id format: {next_referrer_id}")
                    return
            
            # Используем итеративный подход вместо рекурсивного, чтобы избежать ошибок стека
            # Просто вызываем для следующего уровня без глубокой рекурсии
            if level < 4:  # Только если не достигли максимальной глубины
                # Проверяем, не является ли следующий реферер уже существующим в цепочке
                if next_referrer_id != user_id and next_referrer_id != referrer_id:
                    # Безопасно вызываем для следующего уровня
                    try:
                        self._update_referral_structure_safe(user_id, next_referrer_id, level + 1)
                    except Exception as e:
                        logger.error(f"Error updating referral structure: {e}")
    
    def _update_referral_structure_safe(self, user_id: int, referrer_id: int, level: int) -> None:
        """
        Безопасная версия обновления структуры рефералов без рекурсии
        
        Args:
            user_id: ID реферала
            referrer_id: ID реферера
            level: Текущий уровень (1-4)
        """
        if level > 4 or not referrer_id:
            return
            
        # Убедимся, что referrer_id является целым числом
        if not isinstance(referrer_id, int):
            if isinstance(referrer_id, str):
                if referrer_id.isdigit():
                    referrer_id = int(referrer_id)
                else:
                    logger.error(f"Неверный формат referrer_id в _update_referral_structure_safe: '{referrer_id}' (тип: {type(referrer_id)})")
                    return
            else:
                logger.warning(f"Invalid referrer_id format: {referrer_id}")
                return
        
        db = self.load_database()
        referrer_data = db["users"].get(str(referrer_id))
        
        if not referrer_data:
            return
        
        # Инициализируем структуру рефералов, если её нет
        if "referrals" not in referrer_data:
            referrer_data["referrals"] = {
                "level1": [],
                "level2": [],
                "level3": [],
                "level4": [],
            }
        
        # Добавляем пользователя как реферала текущего уровня
        level_key = f"level{level}"
        if not isinstance(referrer_data["referrals"].get(level_key), list):
            referrer_data["referrals"][level_key] = []
        
        if user_id not in referrer_data["referrals"][level_key]:
            referrer_data["referrals"][level_key].append(user_id)
            self.save_user(referrer_data)
    
    def calculate_rewards(self, user_id: int, amount: float = SUBSCRIPTION_COST) -> Dict[str, Any]:
        """
        Расчет вознаграждений реферерам при оплате подписки
        
        Args:
            user_id: ID пользователя, оплатившего подписку
            amount: Сумма оплаты (по умолчанию стоимость подписки)
            
        Returns:
            Dict[str, Any]: Структура с информацией о вознаграждениях
        """
        result = {
            "user_id": user_id,
            "amount": amount,
            "referrer_id": None,
            "rewards": {}
        }
        
        # Предварительная проверка корректности ID пользователя
        if not isinstance(user_id, int):
            if isinstance(user_id, str) and user_id.isdigit():
                user_id = int(user_id)
            else:
                logger.warning(f"Invalid user_id format: {user_id}")
                return result
                
        db = self.load_database()
        user_data = db["users"].get(str(user_id))
        
        if not user_data:
            logger.info(f"User {user_id} not found in database, no rewards to calculate")
            return result
            
        if not user_data.get("referrer_id"):
            logger.info(f"User {user_id} has no referrer, no rewards to calculate")
            return result
        
        # Получаем и проверяем ID реферера
        referrer_id = user_data.get("referrer_id")
        
        # Убедимся, что referrer_id является целым числом или содержит только цифры
        try:
            # Если это уже целое число, оставляем как есть
            if isinstance(referrer_id, int):
                pass
            # Если это строка, пытаемся преобразовать в int
            elif isinstance(referrer_id, str):
                # Удалим все нецифровые символы, если строка начинается с 'r'
                if referrer_id.startswith('r') and len(referrer_id) > 1:
                    # Пытаемся извлечь числовую часть
                    numeric_part = ''.join(c for c in referrer_id if c.isdigit())
                    if numeric_part:
                        referrer_id = int(numeric_part)
                        # Обновляем значение в базе данных
                        user_data["referrer_id"] = referrer_id
                        db["users"][str(user_id)] = user_data
                        self.save_database(db)
                        logger.info(f"Fixed referrer_id format for user {user_id}: from '{user_data.get('referrer_id')}' to {referrer_id}")
                    else:
                        logger.error(f"Не удалось извлечь числовую часть из referrer_id: '{referrer_id}' для пользователя {user_id}")
                        return result
                # Если строка содержит только цифры, просто преобразуем в int
                elif referrer_id.isdigit():
                    referrer_id = int(referrer_id)
                    # Обновляем значение в базе данных
                    user_data["referrer_id"] = referrer_id
                    db["users"][str(user_id)] = user_data
                    self.save_database(db)
                else:
                    logger.error(f"Неверный формат referrer_id: '{referrer_id}' (тип: {type(referrer_id)}) для пользователя {user_id}")
                    logger.error(f"Данные пользователя: {user_data}")
                    return result
            else:
                logger.warning(f"Invalid referrer_id format: {referrer_id} for user {user_id}")
                return result
        except Exception as e:
            logger.error(f"Ошибка при обработке referrer_id: {e} для пользователя {user_id}")
            return result
                
        # Сохраняем ID реферера пользователя
        result["referrer_id"] = referrer_id
        
        # Обрабатываем каждый уровень рефералов итеративно
        current_referrer_id = referrer_id
        current_level = 1
        
        # Список обработанных ID для предотвращения циклов
        processed_ids = set([user_id])
        
        while current_referrer_id and current_level <= 4:
            # Предотвращение циклических ссылок
            if current_referrer_id in processed_ids:
                logger.warning(f"Detected cyclic referral chain at level {current_level}")
                break
                
            processed_ids.add(current_referrer_id)
            
            referrer_data = db["users"].get(str(current_referrer_id))
            if not referrer_data:
                logger.warning(f"Referrer {current_referrer_id} not found in database")
                break
            
            # Рассчитываем вознаграждение для текущего уровня
            level_key = f"level{current_level}"
            reward_percentage = REFERRAL_LEVELS.get(level_key, 0)
            reward = amount * reward_percentage
            
            # Добавляем вознаграждение в результаты
            if reward > 0:
                result["rewards"][level_key] = {
                    "user_id": current_referrer_id,
                    "percentage": reward_percentage,
                    "amount": round(reward, 2)
                }
                logger.info(f"Calculated {level_key} reward for user {current_referrer_id}: {round(reward, 2)}₽")
            
            # Переходим к следующему уровню
            next_referrer_id = referrer_data.get("referrer_id")
            
            # Проверка и преобразование next_referrer_id
            if next_referrer_id:
                try:
                    # Если это уже целое число, оставляем как есть
                    if isinstance(next_referrer_id, int):
                        pass
                    # Если это строка, пытаемся преобразовать в int
                    elif isinstance(next_referrer_id, str):
                        # Удалим все нецифровые символы, если строка начинается с 'r'
                        if next_referrer_id.startswith('r') and len(next_referrer_id) > 1:
                            # Пытаемся извлечь числовую часть
                            numeric_part = ''.join(c for c in next_referrer_id if c.isdigit())
                            if numeric_part:
                                next_referrer_id = int(numeric_part)
                                # Обновляем значение в базе данных
                                referrer_data["referrer_id"] = next_referrer_id
                                db["users"][str(current_referrer_id)] = referrer_data
                                self.save_database(db)
                                logger.info(f"Fixed next_referrer_id format: from '{referrer_data.get('referrer_id')}' to {next_referrer_id}")
                            else:
                                logger.error(f"Не удалось извлечь числовую часть из next_referrer_id: '{next_referrer_id}'")
                                break
                        # Если строка содержит только цифры, просто преобразуем в int
                        elif next_referrer_id.isdigit():
                            next_referrer_id = int(next_referrer_id)
                            # Обновляем значение в базе данных
                            referrer_data["referrer_id"] = next_referrer_id
                            db["users"][str(current_referrer_id)] = referrer_data
                            self.save_database(db)
                        else:
                            logger.error(f"Неверный формат next_referrer_id: '{next_referrer_id}' (тип: {type(next_referrer_id)})")
                            logger.error(f"Данные реферера: {referrer_data}")
                            break
                    else:
                        logger.warning(f"Invalid next_referrer_id format: {next_referrer_id}, stopping reward chain")
                        break
                except Exception as e:
                    logger.error(f"Ошибка при обработке next_referrer_id: {e}")
                    break
            
            current_referrer_id = next_referrer_id
            current_level += 1
        
        return result
    
    def get_rewards_description(self, user_id: int) -> str:
        """
        Получение описания реферальной статистики пользователя
        
        Args:
            user_id: ID пользователя
            
        Returns:
            str: Текстовое описание статистики рефералов и потенциальных вознаграждений
        """
        db = self.load_database()
        user_data = db["users"].get(str(user_id))
        
        if not user_data or not user_data.get("referrals"):
            return "У вас пока нет рефералов. Пригласите друзей и получайте вознаграждения!"
        
        referrals = user_data["referrals"]
        level1_count = len(referrals.get("level1", []))
        level2_count = len(referrals.get("level2", []))
        level3_count = len(referrals.get("level3", []))
        level4_count = len(referrals.get("level4", []))
        
        total_potential = (
            level1_count * SUBSCRIPTION_COST * REFERRAL_LEVELS["level1"] +
            level2_count * SUBSCRIPTION_COST * REFERRAL_LEVELS["level2"] +
            level3_count * SUBSCRIPTION_COST * REFERRAL_LEVELS["level3"] +
            level4_count * SUBSCRIPTION_COST * REFERRAL_LEVELS["level4"]
        )
        
        description = (
            f"🔗 *Ваша реферальная статистика:*\n\n"
            f"👥 *Рефералы 1-го уровня:* {level1_count} чел. (5% комиссии)\n"
            f"👥 *Рефералы 2-го уровня:* {level2_count} чел. (2% комиссии)\n"
            f"👥 *Рефералы 3-го уровня:* {level3_count} чел. (2% комиссии)\n"
            f"👥 *Рефералы 4-го уровня:* {level4_count} чел. (2% комиссии)\n\n"
            f"💰 *Потенциальный доход в месяц:* {round(total_potential, 2)} ₽\n\n"
            f"✉️ Отправьте свою реферальную ссылку друзьям и получайте вознаграждения, когда они оплачивают подписку!"
        )
        
        return description
    
    def get_referral_stats(self, user_id: int) -> Dict[str, Any]:
        """
        Получение структурированной статистики по рефералам пользователя
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Dict[str, Any]: Статистика по рефералам
        """
        db = self.load_database()
        user_data = db["users"].get(str(user_id))
        
        if not user_data:
            return {
                "total_referrals": 0,
                "level1": 0,
                "level2": 0,
                "level3": 0,
                "level4": 0,
                "potential_income": 0
            }
        
        referrals = user_data.get("referrals", {
            "level1": [],
            "level2": [],
            "level3": [],
            "level4": []
        })
        
        level1_count = len(referrals.get("level1", []))
        level2_count = len(referrals.get("level2", []))
        level3_count = len(referrals.get("level3", []))
        level4_count = len(referrals.get("level4", []))
        
        total_referrals = level1_count + level2_count + level3_count + level4_count
        
        potential_income = (
            level1_count * SUBSCRIPTION_COST * REFERRAL_LEVELS["level1"] +
            level2_count * SUBSCRIPTION_COST * REFERRAL_LEVELS["level2"] +
            level3_count * SUBSCRIPTION_COST * REFERRAL_LEVELS["level3"] +
            level4_count * SUBSCRIPTION_COST * REFERRAL_LEVELS["level4"]
        )
        
        return {
            "total_referrals": total_referrals,
            "level1": level1_count,
            "level2": level2_count,
            "level3": level3_count,
            "level4": level4_count,
            "potential_income": round(potential_income, 2)
        }
    
    def validate_referral_structure(self) -> List[Dict[str, Any]]:
        """
        Проверка и исправление целостности реферальной структуры
        
        Returns:
            List[Dict[str, Any]]: Список проблем, которые были исправлены
        """
        db = self.load_database()
        fixed_issues = []
        
        # Проверяем каждого пользователя
        for user_id, user_data in db["users"].items():
            # Инициализируем структуру рефералов, если её нет
            if "referrals" not in user_data:
                user_data["referrals"] = {
                    "level1": [],
                    "level2": [],
                    "level3": [],
                    "level4": [],
                }
                fixed_issues.append({
                    "user_id": user_id,
                    "issue": "missing_referrals_structure",
                    "action": "initialized_structure"
                })
            
            # Проверяем, что все уровни рефералов существуют
            for level in range(1, 5):
                level_key = f"level{level}"
                if level_key not in user_data["referrals"]:
                    user_data["referrals"][level_key] = []
                    fixed_issues.append({
                        "user_id": user_id,
                        "issue": f"missing_level_{level}",
                        "action": "initialized_level"
                    })
            
            # Проверяем уникальность рефералов в каждом уровне
            for level in range(1, 5):
                level_key = f"level{level}"
                referrals_list = user_data["referrals"][level_key]
                if not isinstance(referrals_list, list):
                    user_data["referrals"][level_key] = []
                    fixed_issues.append({
                        "user_id": user_id,
                        "issue": f"invalid_level_{level}_type",
                        "action": "reset_level"
                    })
                    continue
                
                # Удаляем дубликаты
                unique_referrals = list(set(referrals_list))
                if len(unique_referrals) != len(referrals_list):
                    user_data["referrals"][level_key] = unique_referrals
                    fixed_issues.append({
                        "user_id": user_id,
                        "issue": f"duplicate_referrals_level_{level}",
                        "action": "removed_duplicates"
                    })
        
        # Сохраняем исправленную базу данных
        if fixed_issues:
            self.save_database(db)
            logger.info(f"Fixed {len(fixed_issues)} issues in referral structure")
        
        return fixed_issues
    
    def get_referral_chain(self, user_id: int, max_depth: int = 4) -> List[int]:
        """
        Получение цепочки рефереров для пользователя
        
        Args:
            user_id: ID пользователя
            max_depth: Максимальная глубина цепочки
            
        Returns:
            List[int]: Список ID рефереров в порядке от ближайшего к самому дальнему
        """
        chain = []
        db = self.load_database()
        
        current_user_id = user_id
        depth = 0
        
        # Итеративно поднимаемся по цепочке рефереров
        while depth < max_depth:
            user_data = db["users"].get(str(current_user_id))
            if not user_data or not user_data.get("referrer_id"):
                break
            
            referrer_id = user_data["referrer_id"]
            chain.append(referrer_id)
            
            # Проверка на циклы в цепочке
            if referrer_id in chain[:-1]:
                logger.warning(f"Cycle detected in referral chain for user {user_id}")
                break
            
            current_user_id = referrer_id
            depth += 1
        
        return chain
    
    def migrate_from_old_system(self) -> Tuple[int, List[Dict[str, Any]]]:
        """
        Миграция данных из старой реферальной системы
        
        Returns:
            Tuple[int, List[Dict[str, Any]]]: Количество перенесенных пользователей и список ошибок
        """
        db = self.load_database()
        migrated_count = 0
        errors = []
        
        # Проходим по всем пользователям
        for user_id, user_data in db["users"].items():
            try:
                # Проверяем наличие реферального кода
                if not user_data.get("referral_code"):
                    user_data["referral_code"] = self.generate_referral_code(int(user_id))
                    migrated_count += 1
                
                # Проверяем структуру рефералов
                if "referrals" not in user_data:
                    user_data["referrals"] = {
                        "level1": [],
                        "level2": [],
                        "level3": [],
                        "level4": [],
                    }
                    migrated_count += 1
                
                # Проверяем все уровни рефералов
                for level in range(1, 5):
                    level_key = f"level{level}"
                    if level_key not in user_data["referrals"]:
                        user_data["referrals"][level_key] = []
                        migrated_count += 1
                
                # Сохраняем обновленные данные
                db["users"][user_id] = user_data
            except Exception as e:
                logger.error(f"Error migrating user {user_id}: {e}")
                errors.append({
                    "user_id": user_id,
                    "error": str(e)
                })
        
        # Сохраняем обновленную базу данных
        self.save_database(db)
        logger.info(f"Migrated {migrated_count} users from old referral system")
        
        return migrated_count, errors

# Создаем глобальный экземпляр сервиса
referral_service = ReferralService()