#!/usr/bin/env python
# coding: utf-8

"""
Сервис для работы с транзакциями и выплатами через базу данных PostgreSQL
Заменяет функции из transactions.py, использовавшие JSON-файлы
"""

import logging
import datetime
from typing import Dict, Any, List, Optional, Tuple, Union

from sqlalchemy import func, and_, or_
from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session

from db_models import db, Transaction, WeeklyPayout, BatchPayout, User
from config import SUBSCRIPTION_PRICE, REFERRAL_RATES, MIN_PAYOUT_AMOUNT

# Настройка логгера
logger = logging.getLogger(__name__)

# Стоимость подписки в рублях (конвертируем из копеек)
SUBSCRIPTION_AMOUNT = SUBSCRIPTION_PRICE / 100.0


async def get_transactions_by_status_async(
    session: AsyncSession,
    status: str,
    transaction_type: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Получение списка транзакций по статусу и типу (асинхронная версия)
    
    Args:
        session: Активная сессия базы данных
        status: Статус транзакций для фильтрации
        transaction_type: Тип транзакций для фильтрации (опционально)
        
    Returns:
        list: Список транзакций в виде словарей
    """
    try:
        # Создаем базовый запрос
        query = select(Transaction).where(Transaction.status == status)
        
        # Добавляем условие по типу, если указан
        if transaction_type:
            query = query.where(Transaction.type == transaction_type)
        
        # Выполняем запрос
        result = await session.execute(query)
        transactions = result.scalars().all()
        
        # Преобразуем в словари
        return [transaction.to_dict() for transaction in transactions]
    except Exception as e:
        logger.error(f"Ошибка при получении транзакций по статусу: {e}", exc_info=True)
        return []


def get_transactions_by_status(
    status: str,
    transaction_type: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Получение списка транзакций по статусу и типу (синхронная версия)
    
    Args:
        status: Статус транзакций для фильтрации
        transaction_type: Тип транзакций для фильтрации (опционально)
        
    Returns:
        list: Список транзакций в виде словарей
    """
    try:
        with db.session() as session:
            # Создаем базовый запрос
            query = session.query(Transaction).filter(Transaction.status == status)
            
            # Добавляем условие по типу, если указан
            if transaction_type:
                query = query.filter(Transaction.type == transaction_type)
            
            # Выполняем запрос
            transactions = query.all()
            
            # Преобразуем в словари
            return [transaction.to_dict() for transaction in transactions]
    except Exception as e:
        logger.error(f"Ошибка при получении транзакций по статусу: {e}", exc_info=True)
        return []


async def create_weekly_payout_async(session: AsyncSession) -> int:
    """
    Создание еженедельной выплаты для ожидающих вознаграждений (асинхронная версия)
    
    Args:
        session: Активная сессия базы данных
        
    Returns:
        int: ID выплаты или -1 в случае ошибки
    """
    try:
        # Получаем ожидающие транзакции
        query = select(Transaction).where(
            and_(
                Transaction.status == "pending",
                Transaction.type == "referral_reward"
            )
        )
        result = await session.execute(query)
        pending_rewards = result.scalars().all()
        
        if not pending_rewards:
            logger.warning("Нет ожидающих реферальных вознаграждений для выплаты")
            return -1
        
        # Группируем транзакции по пользователям
        user_payouts = {}
        total_amount = 0.0
        
        for transaction in pending_rewards:
            user_id = transaction.user_id
            if user_id not in user_payouts:
                user_payouts[user_id] = []
            
            user_payouts[user_id].append(transaction.id)
            total_amount += transaction.amount
        
        # Создаем новую выплату
        new_payout = WeeklyPayout(
            status="processing",
            total_amount=total_amount,
            total_users=len(user_payouts),
            payout_data={
                "user_payouts": user_payouts
            }
        )
        
        # Добавляем в сессию
        session.add(new_payout)
        await session.flush()
        
        # Получаем ID новой выплаты
        payout_id = new_payout.id
        
        # Обновляем статус всех транзакций, включенных в выплату
        for transaction in pending_rewards:
            transaction.status = "processing_payout"
            transaction.payout_id = payout_id
            if not transaction.payment_data:
                transaction.payment_data = {}
            transaction.payment_data["payout_id"] = payout_id
        
        # Фиксируем транзакцию
        await session.commit()
        
        logger.info(f"Создана еженедельная выплата #{payout_id}: {total_amount}₽ для {len(user_payouts)} пользователей")
        return payout_id
    
    except Exception as e:
        # Откатываем транзакцию в случае ошибки
        await session.rollback()
        logger.error(f"Ошибка при создании еженедельной выплаты: {e}", exc_info=True)
        return -1


def create_weekly_payout() -> int:
    """
    Создание еженедельной выплаты для ожидающих вознаграждений (синхронная версия)
    
    Returns:
        int: ID выплаты или -1 в случае ошибки
    """
    try:
        with db.session() as session:
            # Получаем ожидающие транзакции
            pending_rewards = session.query(Transaction).filter(
                Transaction.status == "pending",
                Transaction.type == "referral_reward"
            ).all()
            
            if not pending_rewards:
                logger.warning("Нет ожидающих реферальных вознаграждений для выплаты")
                return -1
            
            # Группируем транзакции по пользователям
            user_payouts = {}
            total_amount = 0.0
            
            for transaction in pending_rewards:
                user_id = transaction.user_id
                if user_id not in user_payouts:
                    user_payouts[user_id] = []
                
                user_payouts[user_id].append(transaction.id)
                total_amount += transaction.amount
            
            # Создаем новую выплату
            new_payout = WeeklyPayout(
                status="processing",
                total_amount=total_amount,
                total_users=len(user_payouts),
                payout_data={
                    "user_payouts": user_payouts
                }
            )
            
            # Добавляем в сессию
            session.add(new_payout)
            session.flush()
            
            # Получаем ID новой выплаты
            payout_id = new_payout.id
            
            # Обновляем статус всех транзакций, включенных в выплату
            for transaction in pending_rewards:
                transaction.status = "processing_payout"
                transaction.payout_id = payout_id
                if not transaction.payment_data:
                    transaction.payment_data = {}
                transaction.payment_data["payout_id"] = payout_id
            
            # Фиксируем транзакцию
            session.commit()
            
            logger.info(f"Создана еженедельная выплата #{payout_id}: {total_amount}₽ для {len(user_payouts)} пользователей")
            return payout_id
    
    except Exception as e:
        logger.error(f"Ошибка при создании еженедельной выплаты: {e}", exc_info=True)
        return -1


async def get_weekly_payouts_async(
    session: AsyncSession, 
    status: Optional[str] = None,
    payout_id: Optional[int] = None
) -> List[Dict[str, Any]]:
    """
    Получение списка еженедельных выплат (асинхронная версия)
    
    Args:
        session: Активная сессия базы данных
        status: Статус выплат для фильтрации (опционально)
        payout_id: ID конкретной выплаты (опционально)
        
    Returns:
        list: Список еженедельных выплат в виде словарей
    """
    try:
        # Создаем базовый запрос
        query = select(WeeklyPayout)
        
        # Добавляем фильтрацию по статусу, если указан
        if status:
            query = query.where(WeeklyPayout.status == status)
        
        # Добавляем фильтрацию по ID, если указан
        if payout_id:
            query = query.where(WeeklyPayout.id == payout_id)
        
        # Выполняем запрос
        result = await session.execute(query)
        payouts = result.scalars().all()
        
        # Преобразуем в словари
        return [payout.to_dict() for payout in payouts]
    
    except Exception as e:
        logger.error(f"Ошибка при получении еженедельных выплат: {e}", exc_info=True)
        return []


def get_weekly_payouts(
    status: Optional[str] = None,
    payout_id: Optional[int] = None
) -> List[Dict[str, Any]]:
    """
    Получение списка еженедельных выплат (синхронная версия)
    
    Args:
        status: Статус выплат для фильтрации (опционально)
        payout_id: ID конкретной выплаты (опционально)
        
    Returns:
        list: Список еженедельных выплат в виде словарей
    """
    try:
        with db.session() as session:
            # Создаем базовый запрос
            query = session.query(WeeklyPayout)
            
            # Добавляем фильтрацию по статусу, если указан
            if status:
                query = query.filter(WeeklyPayout.status == status)
            
            # Добавляем фильтрацию по ID, если указан
            if payout_id:
                query = query.filter(WeeklyPayout.id == payout_id)
            
            # Выполняем запрос
            payouts = query.all()
            
            # Преобразуем в словари
            return [payout.to_dict() for payout in payouts]
    
    except Exception as e:
        logger.error(f"Ошибка при получении еженедельных выплат: {e}", exc_info=True)
        return []


async def update_payout_status_async(
    session: AsyncSession,
    payout_id: int,
    status: str
) -> bool:
    """
    Обновление статуса еженедельной выплаты (асинхронная версия)
    
    Args:
        session: Активная сессия базы данных
        payout_id: ID выплаты
        status: Новый статус
        
    Returns:
        bool: True, если выплата была обновлена, False в противном случае
    """
    try:
        # Ищем выплату по ID
        query = select(WeeklyPayout).where(WeeklyPayout.id == payout_id)
        result = await session.execute(query)
        payout = result.scalars().first()
        
        if not payout:
            logger.warning(f"Выплата #{payout_id} не найдена")
            return False
        
        # Обновляем статус выплаты
        payout.status = status
        payout.updated_at = datetime.datetime.now()
        
        # Определяем новый статус для транзакций
        new_transaction_status = "completed" if status == "completed" else "pending"
        
        # Находим все транзакции, связанные с выплатой
        transaction_query = select(Transaction).where(Transaction.payout_id == payout_id)
        result = await session.execute(transaction_query)
        transactions = result.scalars().all()
        
        # Обновляем статус всех транзакций
        for transaction in transactions:
            transaction.status = new_transaction_status
            transaction.updated_at = datetime.datetime.now()
        
        # Фиксируем изменения
        await session.commit()
        
        logger.info(f"Обновлен статус выплаты #{payout_id} на {status}")
        return True
    
    except Exception as e:
        # Откатываем транзакцию в случае ошибки
        await session.rollback()
        logger.error(f"Ошибка при обновлении статуса выплаты: {e}", exc_info=True)
        return False


def update_payout_status(payout_id: int, status: str) -> bool:
    """
    Обновление статуса еженедельной выплаты (синхронная версия)
    
    Args:
        payout_id: ID выплаты
        status: Новый статус
        
    Returns:
        bool: True, если выплата была обновлена, False в противном случае
    """
    try:
        with db.session() as session:
            # Ищем выплату по ID
            payout = session.query(WeeklyPayout).filter(WeeklyPayout.id == payout_id).first()
            
            if not payout:
                logger.warning(f"Выплата #{payout_id} не найдена")
                return False
            
            # Обновляем статус выплаты
            payout.status = status
            payout.updated_at = datetime.datetime.now()
            
            # Определяем новый статус для транзакций
            new_transaction_status = "completed" if status == "completed" else "pending"
            
            # Находим все транзакции, связанные с выплатой
            transactions = session.query(Transaction).filter(Transaction.payout_id == payout_id).all()
            
            # Обновляем статус всех транзакций
            for transaction in transactions:
                transaction.status = new_transaction_status
                transaction.updated_at = datetime.datetime.now()
            
            # Фиксируем изменения
            session.commit()
            
            logger.info(f"Обновлен статус выплаты #{payout_id} на {status}")
            return True
    
    except Exception as e:
        logger.error(f"Ошибка при обновлении статуса выплаты: {e}", exc_info=True)
        return False


async def get_user_total_rewards_async(session: AsyncSession, user_id: int) -> Dict[str, float]:
    """
    Получение статистики о реферальных вознаграждениях пользователя (асинхронная версия)
    
    Args:
        session: Активная сессия базы данных
        user_id: ID пользователя
        
    Returns:
        dict: Статистика вознаграждений
    """
    stats = {
        "total_earned": 0.0,       # Всего заработано
        "total_pending": 0.0,       # Всего ожидает выплаты
        "total_paid": 0.0,          # Всего выплачено
        "total_processing": 0.0     # Всего в обработке
    }
    
    try:
        # Получаем общую сумму заработанных вознаграждений
        query = select(func.sum(Transaction.amount)).where(
            and_(
                Transaction.user_id == user_id,
                Transaction.type == "referral_reward"
            )
        )
        result = await session.execute(query)
        total_earned = result.scalar()
        stats["total_earned"] = total_earned or 0.0
        
        # Получаем сумму ожидающих вознаграждений
        query = select(func.sum(Transaction.amount)).where(
            and_(
                Transaction.user_id == user_id,
                Transaction.type == "referral_reward",
                Transaction.status == "pending"
            )
        )
        result = await session.execute(query)
        total_pending = result.scalar()
        stats["total_pending"] = total_pending or 0.0
        
        # Получаем сумму выплаченных вознаграждений
        query = select(func.sum(Transaction.amount)).where(
            and_(
                Transaction.user_id == user_id,
                Transaction.type == "referral_reward",
                Transaction.status == "completed"
            )
        )
        result = await session.execute(query)
        total_paid = result.scalar()
        stats["total_paid"] = total_paid or 0.0
        
        # Получаем сумму вознаграждений в обработке
        query = select(func.sum(Transaction.amount)).where(
            and_(
                Transaction.user_id == user_id,
                Transaction.type == "referral_reward",
                or_(
                    Transaction.status == "processing",
                    Transaction.status == "processing_payout"
                )
            )
        )
        result = await session.execute(query)
        total_processing = result.scalar()
        stats["total_processing"] = total_processing or 0.0
        
        return stats
    
    except Exception as e:
        logger.error(f"Ошибка при получении статистики вознаграждений: {e}", exc_info=True)
        return stats


def get_user_total_rewards(user_id: int) -> Dict[str, float]:
    """
    Получение статистики о реферальных вознаграждениях пользователя (синхронная версия)
    
    Args:
        user_id: ID пользователя
        
    Returns:
        dict: Статистика вознаграждений
    """
    stats = {
        "total_earned": 0.0,       # Всего заработано
        "total_pending": 0.0,       # Всего ожидает выплаты
        "total_paid": 0.0,          # Всего выплачено
        "total_processing": 0.0     # Всего в обработке
    }
    
    try:
        with db.session() as session:
            # Получаем общую сумму заработанных вознаграждений
            total_earned = session.query(func.sum(Transaction.amount)).filter(
                Transaction.user_id == user_id,
                Transaction.type == "referral_reward"
            ).scalar()
            stats["total_earned"] = total_earned or 0.0
            
            # Получаем сумму ожидающих вознаграждений
            total_pending = session.query(func.sum(Transaction.amount)).filter(
                Transaction.user_id == user_id,
                Transaction.type == "referral_reward",
                Transaction.status == "pending"
            ).scalar()
            stats["total_pending"] = total_pending or 0.0
            
            # Получаем сумму выплаченных вознаграждений
            total_paid = session.query(func.sum(Transaction.amount)).filter(
                Transaction.user_id == user_id,
                Transaction.type == "referral_reward",
                Transaction.status == "completed"
            ).scalar()
            stats["total_paid"] = total_paid or 0.0
            
            # Получаем сумму вознаграждений в обработке
            total_processing = session.query(func.sum(Transaction.amount)).filter(
                Transaction.user_id == user_id,
                Transaction.type == "referral_reward",
                or_(
                    Transaction.status == "processing",
                    Transaction.status == "processing_payout"
                )
            ).scalar()
            stats["total_processing"] = total_processing or 0.0
            
            return stats
    
    except Exception as e:
        logger.error(f"Ошибка при получении статистики вознаграждений: {e}", exc_info=True)
        return stats


async def get_referral_statistics_async(session: AsyncSession) -> Dict[str, float]:
    """
    Получение общей статистики по реферальной программе (асинхронная версия)
    
    Args:
        session: Активная сессия базы данных
        
    Returns:
        dict: Статистика реферальной программы
    """
    stats = {
        "total_subscription_revenue": 0.0,   # Общий доход от подписок
        "total_subscriptions": 0,           # Общее количество подписок
        "total_rewards": 0.0,               # Общая сумма начисленных вознаграждений
        "total_paid_rewards": 0.0,          # Общая сумма выплаченных вознаграждений
        "total_pending_rewards": 0.0,       # Общая сумма ожидающих выплаты вознаграждений
        "monthly_subscription_revenue": 0.0, # Доход от подписок за последние 30 дней
        "monthly_rewards": 0.0,             # Начисленные вознаграждения за последние 30 дней
        "reward_percentage": 0.0            # Процент выплат от дохода
    }
    
    try:
        # Получаем общий доход от подписок
        query = select(func.sum(Transaction.amount)).where(
            Transaction.type == "subscription"
        )
        result = await session.execute(query)
        total_subscription_revenue = result.scalar()
        stats["total_subscription_revenue"] = total_subscription_revenue or 0.0
        
        # Получаем количество подписок
        query = select(func.count(Transaction.id)).where(
            Transaction.type == "subscription"
        )
        result = await session.execute(query)
        total_subscriptions = result.scalar()
        stats["total_subscriptions"] = total_subscriptions or 0
        
        # Получаем общую сумму начисленных вознаграждений
        query = select(func.sum(Transaction.amount)).where(
            Transaction.type == "referral_reward"
        )
        result = await session.execute(query)
        total_rewards = result.scalar()
        stats["total_rewards"] = total_rewards or 0.0
        
        # Получаем общую сумму выплаченных вознаграждений
        query = select(func.sum(Transaction.amount)).where(
            and_(
                Transaction.type == "referral_reward",
                Transaction.status == "completed"
            )
        )
        result = await session.execute(query)
        total_paid_rewards = result.scalar()
        stats["total_paid_rewards"] = total_paid_rewards or 0.0
        
        # Получаем общую сумму ожидающих выплаты вознаграждений
        query = select(func.sum(Transaction.amount)).where(
            and_(
                Transaction.type == "referral_reward",
                Transaction.status == "pending"
            )
        )
        result = await session.execute(query)
        total_pending_rewards = result.scalar()
        stats["total_pending_rewards"] = total_pending_rewards or 0.0
        
        # Вычисляем дату 30 дней назад
        thirty_days_ago = datetime.datetime.now() - datetime.timedelta(days=30)
        
        # Получаем доход от подписок за последние 30 дней
        query = select(func.sum(Transaction.amount)).where(
            and_(
                Transaction.type == "subscription",
                Transaction.created_at >= thirty_days_ago
            )
        )
        result = await session.execute(query)
        monthly_subscription_revenue = result.scalar()
        stats["monthly_subscription_revenue"] = monthly_subscription_revenue or 0.0
        
        # Получаем начисленные вознаграждения за последние 30 дней
        query = select(func.sum(Transaction.amount)).where(
            and_(
                Transaction.type == "referral_reward",
                Transaction.created_at >= thirty_days_ago
            )
        )
        result = await session.execute(query)
        monthly_rewards = result.scalar()
        stats["monthly_rewards"] = monthly_rewards or 0.0
        
        # Вычисляем процент выплат от дохода
        if stats["total_subscription_revenue"] > 0:
            stats["reward_percentage"] = (stats["total_rewards"] / stats["total_subscription_revenue"]) * 100
        
        return stats
    
    except Exception as e:
        logger.error(f"Ошибка при получении статистики реферальной программы: {e}", exc_info=True)
        return stats


def get_referral_statistics() -> Dict[str, float]:
    """
    Получение общей статистики по реферальной программе (синхронная версия)
    
    Returns:
        dict: Статистика реферальной программы
    """
    stats = {
        "total_subscription_revenue": 0.0,   # Общий доход от подписок
        "total_subscriptions": 0,           # Общее количество подписок
        "total_rewards": 0.0,               # Общая сумма начисленных вознаграждений
        "total_paid_rewards": 0.0,          # Общая сумма выплаченных вознаграждений
        "total_pending_rewards": 0.0,       # Общая сумма ожидающих выплаты вознаграждений
        "monthly_subscription_revenue": 0.0, # Доход от подписок за последние 30 дней
        "monthly_rewards": 0.0,             # Начисленные вознаграждения за последние 30 дней
        "reward_percentage": 0.0            # Процент выплат от дохода
    }
    
    try:
        with db.session() as session:
            # Получаем общий доход от подписок
            total_subscription_revenue = session.query(func.sum(Transaction.amount)).filter(
                Transaction.type == "subscription"
            ).scalar()
            stats["total_subscription_revenue"] = total_subscription_revenue or 0.0
            
            # Получаем количество подписок
            total_subscriptions = session.query(func.count(Transaction.id)).filter(
                Transaction.type == "subscription"
            ).scalar()
            stats["total_subscriptions"] = total_subscriptions or 0
            
            # Получаем общую сумму начисленных вознаграждений
            total_rewards = session.query(func.sum(Transaction.amount)).filter(
                Transaction.type == "referral_reward"
            ).scalar()
            stats["total_rewards"] = total_rewards or 0.0
            
            # Получаем общую сумму выплаченных вознаграждений
            total_paid_rewards = session.query(func.sum(Transaction.amount)).filter(
                Transaction.type == "referral_reward",
                Transaction.status == "completed"
            ).scalar()
            stats["total_paid_rewards"] = total_paid_rewards or 0.0
            
            # Получаем общую сумму ожидающих выплаты вознаграждений
            total_pending_rewards = session.query(func.sum(Transaction.amount)).filter(
                Transaction.type == "referral_reward",
                Transaction.status == "pending"
            ).scalar()
            stats["total_pending_rewards"] = total_pending_rewards or 0.0
            
            # Вычисляем дату 30 дней назад
            thirty_days_ago = datetime.datetime.now() - datetime.timedelta(days=30)
            
            # Получаем доход от подписок за последние 30 дней
            monthly_subscription_revenue = session.query(func.sum(Transaction.amount)).filter(
                Transaction.type == "subscription",
                Transaction.created_at >= thirty_days_ago
            ).scalar()
            stats["monthly_subscription_revenue"] = monthly_subscription_revenue or 0.0
            
            # Получаем начисленные вознаграждения за последние 30 дней
            monthly_rewards = session.query(func.sum(Transaction.amount)).filter(
                Transaction.type == "referral_reward",
                Transaction.created_at >= thirty_days_ago
            ).scalar()
            stats["monthly_rewards"] = monthly_rewards or 0.0
            
            # Вычисляем процент выплат от дохода
            if stats["total_subscription_revenue"] > 0:
                stats["reward_percentage"] = (stats["total_rewards"] / stats["total_subscription_revenue"]) * 100
            
            return stats
    
    except Exception as e:
        logger.error(f"Ошибка при получении статистики реферальной программы: {e}", exc_info=True)
        return stats


# Функция для проверки механизма восстановления после сбоев
async def detect_and_recover_interrupted_payouts_async(session: AsyncSession) -> List[int]:
    """
    Обнаружение и восстановление прерванных выплат (асинхронная версия)
    
    Args:
        session: Активная сессия базы данных
        
    Returns:
        list: Список ID восстановленных выплат
    """
    try:
        # Ищем выплаты в статусе 'processing' старше 1 часа
        one_hour_ago = datetime.datetime.now() - datetime.timedelta(hours=1)
        
        query = select(WeeklyPayout).where(
            and_(
                WeeklyPayout.status == "processing",
                WeeklyPayout.updated_at <= one_hour_ago
            )
        )
        result = await session.execute(query)
        stalled_payouts = result.scalars().all()
        
        recovered_ids = []
        
        for payout in stalled_payouts:
            logger.info(f"Обнаружена прерванная выплата #{payout.id}, восстанавливаем")
            
            # Помечаем выплату как частично обработанную
            payout.status = "partial"
            payout.error_message = "Выплата была прервана и автоматически восстановлена"
            payout.updated_at = datetime.datetime.now()
            
            # Получаем обработанные транзакции
            processed_transactions = payout.processed_transactions or []
            
            # Получаем все транзакции, связанные с выплатой
            query = select(Transaction).where(Transaction.payout_id == payout.id)
            result = await session.execute(query)
            all_transactions = result.scalars().all()
            
            # Восстанавливаем транзакции, которые не были обработаны
            for transaction in all_transactions:
                if transaction.id not in processed_transactions:
                    # Возвращаем транзакции в статус "pending" для повторной обработки
                    transaction.status = "pending"
                    transaction.updated_at = datetime.datetime.now()
            
            recovered_ids.append(payout.id)
        
        # Фиксируем изменения
        if recovered_ids:
            await session.commit()
            logger.info(f"Восстановлено {len(recovered_ids)} прерванных выплат: {recovered_ids}")
        
        return recovered_ids
    
    except Exception as e:
        await session.rollback()
        logger.error(f"Ошибка при восстановлении прерванных выплат: {e}", exc_info=True)
        return []


def detect_and_recover_interrupted_payouts() -> List[int]:
    """
    Обнаружение и восстановление прерванных выплат (синхронная версия)
    
    Returns:
        list: Список ID восстановленных выплат
    """
    try:
        with db.session() as session:
            # Ищем выплаты в статусе 'processing' старше 1 часа
            one_hour_ago = datetime.datetime.now() - datetime.timedelta(hours=1)
            
            stalled_payouts = session.query(WeeklyPayout).filter(
                WeeklyPayout.status == "processing",
                WeeklyPayout.updated_at <= one_hour_ago
            ).all()
            
            recovered_ids = []
            
            for payout in stalled_payouts:
                logger.info(f"Обнаружена прерванная выплата #{payout.id}, восстанавливаем")
                
                # Помечаем выплату как частично обработанную
                payout.status = "partial"
                payout.error_message = "Выплата была прервана и автоматически восстановлена"
                payout.updated_at = datetime.datetime.now()
                
                # Получаем обработанные транзакции
                processed_transactions = payout.processed_transactions or []
                
                # Получаем все транзакции, связанные с выплатой
                all_transactions = session.query(Transaction).filter(Transaction.payout_id == payout.id).all()
                
                # Восстанавливаем транзакции, которые не были обработаны
                for transaction in all_transactions:
                    if transaction.id not in processed_transactions:
                        # Возвращаем транзакции в статус "pending" для повторной обработки
                        transaction.status = "pending"
                        transaction.updated_at = datetime.datetime.now()
                
                recovered_ids.append(payout.id)
            
            # Фиксируем изменения
            if recovered_ids:
                session.commit()
                logger.info(f"Восстановлено {len(recovered_ids)} прерванных выплат: {recovered_ids}")
            
            return recovered_ids
    
    except Exception as e:
        logger.error(f"Ошибка при восстановлении прерванных выплат: {e}", exc_info=True)
        return []


class DBSessionManager:
    """
    Менеджер сессий базы данных для безопасной работы с транзакциями
    """
    
    @staticmethod
    def get_session() -> Session:
        """
        Получение сессии базы данных
        
        Returns:
            Session: Активная сессия базы данных
        """
        return db.session()
    
    @staticmethod
    async def get_async_session() -> AsyncSession:
        """
        Получение асинхронной сессии базы данных с контекстом приложения
        
        Returns:
            AsyncSession: Активная асинхронная сессия базы данных
        """
        from db_config import get_flask_app
        from sqlalchemy.ext.asyncio import create_async_engine
        import os
        
        app = get_flask_app()
        
        # Используем контекст приложения для получения engine
        with app.app_context():
            # Создаем асинхронный движок из строки подключения
            db_url = os.environ.get("DATABASE_URL")
            if db_url and not db_url.startswith("postgresql+asyncpg://"):
                # Преобразуем URL для работы с asyncpg
                db_url = db_url.replace("postgresql://", "postgresql+asyncpg://")
                
            # Удаляем параметр sslmode из URL, если он есть
            import re
            db_url = re.sub(r"\?sslmode=\w+", "", db_url)
                
            async_engine = create_async_engine(db_url, echo=False)
            return AsyncSession(async_engine)
    
    @staticmethod
    def session_context():
        """
        Контекстный менеджер для работы с сессией (context manager)
        
        Yields:
            Session: Активная сессия базы данных
        """
        session = DBSessionManager.get_session()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
    
    @staticmethod
    async def async_session_context():
        """
        Асинхронный контекстный менеджер для работы с сессией
        
        Yields:
            AsyncSession: Активная асинхронная сессия базы данных
        """
        try:
            async_session = await DBSessionManager.get_async_session()
            
            try:
                yield async_session
                try:
                    await async_session.commit()
                except Exception as e:
                    logger.error(f"Error committing async session: {e}")
                    await async_session.rollback()
                    raise
            except Exception as e:
                logger.error(f"Error in async session context: {e}")
                try:
                    await async_session.rollback()
                except Exception as rollback_error:
                    logger.error(f"Error rolling back async session: {rollback_error}")
                raise
            finally:
                try:
                    await async_session.close()
                except Exception as close_error:
                    logger.error(f"Error closing async session: {close_error}")
        except Exception as e:
            logger.error(f"Failed to create async session: {e}")
            raise