#!/usr/bin/env python
# coding: utf-8

"""
Bot initialization and configuration
"""

import logging
from telegram.ext import (
    Application,
    CommandHandler, 
    MessageHandler, 
    CallbackQueryHandler,
    PreCheckoutQueryHandler,
    filters
)
from telegram.ext import PicklePersistence

import config
from handlers import (
    start_command, 
    help_command, 
    solve_command,
    subscribe_command,
    activate_subscription_command,
    handle_text, 
    handle_photo, 
    handle_voice,
    handle_callback, 
    handle_pre_checkout, 
    handle_successful_payment,
    error_handler
)

logger = logging.getLogger(__name__)

async def create_bot():
    """Create and configure the bot with all necessary handlers"""
    
    # Check if telegram token is available
    if not config.TELEGRAM_TOKEN:
        raise ValueError("Telegram token not found. Please set the TELEGRAM_TOKEN environment variable.")
    
    # Set up persistence to store user data
    persistence = PicklePersistence(filepath="bot_data")
    
    # Create application instance with higher timeout for API requests
    # and request_kwargs with a higher read_timeout and write_timeout
    application = Application.builder() \
        .token(config.TELEGRAM_TOKEN) \
        .persistence(persistence) \
        .connect_timeout(30.0) \
        .read_timeout(30.0) \
        .pool_timeout(30.0) \
        .write_timeout(30.0) \
        .build()
        
    # Set up bot commands in Telegram menu
    from telegram import BotCommand
    commands = [
        BotCommand("start", "Запустить бота"),
        BotCommand("help", "Показать справочную информацию"),
        BotCommand("solve", "Решить математическую задачу"),
        BotCommand("subscribe", "Купить подписку"),
        BotCommand("activate_subscription", "Активировать подписку после оплаты")
    ]
    
    await application.bot.set_my_commands(commands)
    
    # Add command handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("solve", solve_command))
    application.add_handler(CommandHandler("subscribe", subscribe_command))
    application.add_handler(CommandHandler("activate_subscription", activate_subscription_command))
    
    # Add message handlers
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    application.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    application.add_handler(MessageHandler(filters.VOICE, handle_voice))
    
    # Add callback query handler
    application.add_handler(CallbackQueryHandler(handle_callback))
    
    # Add payment handlers
    application.add_handler(PreCheckoutQueryHandler(handle_pre_checkout))
    application.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, handle_successful_payment))
    
    # Log all errors
    application.add_error_handler(error_handler)
    
    return application
