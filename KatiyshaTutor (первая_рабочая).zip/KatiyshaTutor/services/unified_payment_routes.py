#!/usr/bin/env python
# coding: utf-8

"""
Маршруты для централизованной обработки платежных уведомлений через Blueprint
"""

import os
import logging
import json
from flask import Blueprint, request, jsonify, redirect, render_template_string
from functools import wraps
import ipaddress
from typing import Dict, Any, List, Callable

from services.unified_payment_handler import unified_payment_handler
from services.instance_lock_service import instance_lock_service

# Настройка логирования
logger = logging.getLogger(__name__)

# Создаем Blueprint для платежных маршрутов
payment_routes_bp = Blueprint('payment_routes', __name__)

# Список доверенных IP-адресов для платежных систем
TRUSTED_IPS = {
    'robokassa': [
        '127.0.0.1',  # Для локального тестирования
        '185.59.216.0/24',  # Диапазон IP Robokassa
        '91.200.28.0/24'  # Альтернативный диапазон Robokassa
    ],
    'sbp': [
        '127.0.0.1',  # Для локального тестирования
        '185.71.76.0/24',  # Примерный диапазон IP СБП
        '91.198.174.0/24'  # Альтернативный диапазон СБП
    ],
    'yoomoney': [
        '127.0.0.1',  # Для локального тестирования
        '91.232.230.0/24',  # Диапазон IP ЮMoney (примерный)
    ]
}

def validate_ip(payment_system: str = None):
    """
    Декоратор для проверки IP-адреса источника webhook
    
    Args:
        payment_system: Платежная система (опционально, если None - определяется по URL)
        
    Returns:
        Декоратор для проверки IP
    """
    def decorator(f: Callable):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Получаем IP-адрес клиента
            client_ip = request.remote_addr
            
            # Определяем тип платежной системы по URL, если не указан
            ps = payment_system
            if not ps:
                if '/robokassa/' in request.path:
                    ps = 'robokassa'
                elif '/sbp/' in request.path:
                    ps = 'sbp'
                elif '/yoomoney/' in request.path:
                    ps = 'yoomoney'
            
            if not ps:
                logger.warning(f"Unknown payment system webhook: {request.path}")
                return jsonify({'success': False, 'message': 'Unknown payment system'}), 400
            
            # Проверяем, что IP-адрес клиента в списке доверенных
            trusted = False
            
            for ip_range in TRUSTED_IPS.get(ps, []):
                if '/' in ip_range:  # CIDR-нотация
                    try:
                        network = ipaddress.ip_network(ip_range)
                        if ipaddress.ip_address(client_ip) in network:
                            trusted = True
                            break
                    except Exception as e:
                        logger.error(f"Error checking IP in network: {str(e)}")
                else:  # Прямое сравнение IP
                    if client_ip == ip_range:
                        trusted = True
                        break
            
            # Локальные тесты всегда проходят проверку
            if client_ip == '127.0.0.1' or client_ip == 'localhost':
                trusted = True
            
            if not trusted:
                logger.warning(f"Unauthorized IP for {ps} webhook: {client_ip}")
                return jsonify({'success': False, 'message': 'Unauthorized IP'}), 403
            
            # IP-адрес проверен, вызываем исходную функцию
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator

# Регистрируем обработчики для разных платежных систем

@payment_routes_bp.route('/payment/robokassa/notification', methods=['POST', 'GET'])
@validate_ip('robokassa')
def robokassa_notification():
    """
    Обработчик уведомлений от Robokassa
    
    Документация: https://docs.robokassa.ru/ru/knowledge-base/integration/notifications-paymentcompleted
    """
    try:
        # Собираем все данные из запроса
        notification_data = {}
        
        # Robokassa может отправлять данные как в form-data, так и в query string
        if request.form:
            notification_data = request.form.to_dict()
        elif request.args:
            notification_data = request.args.to_dict()
        elif request.json:
            notification_data = request.json
        
        logger.info(f"Received Robokassa notification: {notification_data}")
        
        # Передаем обработку в унифицированный обработчик
        response, status_code = unified_payment_handler.handle_payment_notification(
            notification_data, 
            request.path
        )
        
        # Для Robokassa ответ может быть строкой или словарем
        if isinstance(response, dict):
            return jsonify(response), status_code
        return response, status_code
    
    except Exception as e:
        logger.error(f"Error processing Robokassa notification: {str(e)}", exc_info=True)
        return f"ERROR: {str(e)}", 500

@payment_routes_bp.route('/payment/sbp/notification', methods=['POST'])
@validate_ip('sbp')
def sbp_notification():
    """
    Обработчик уведомлений от СБП
    """
    try:
        # Получаем данные из запроса
        notification_data = request.json or {}
        
        logger.info(f"Received SBP notification: {notification_data}")
        
        # Передаем обработку в унифицированный обработчик
        response, status_code = unified_payment_handler.handle_payment_notification(
            notification_data, 
            request.path
        )
        
        return jsonify(response), status_code
    
    except Exception as e:
        logger.error(f"Error processing SBP notification: {str(e)}", exc_info=True)
        return jsonify({
            'success': False, 
            'message': str(e)
        }), 500

@payment_routes_bp.route('/payment/yoomoney/notification', methods=['POST'])
@validate_ip('yoomoney')
def yoomoney_notification():
    """
    Обработчик уведомлений от ЮMoney
    """
    try:
        # Получаем данные из запроса
        notification_data = request.form.to_dict() or request.json or {}
        
        logger.info(f"Received YooMoney notification: {notification_data}")
        
        # Передаем обработку в унифицированный обработчик
        response, status_code = unified_payment_handler.handle_payment_notification(
            notification_data, 
            request.path
        )
        
        return jsonify(response), status_code
    
    except Exception as e:
        logger.error(f"Error processing YooMoney notification: {str(e)}", exc_info=True)
        return jsonify({
            'success': False, 
            'message': str(e)
        }), 500

# Общие маршруты для обработки завершения платежей
@payment_routes_bp.route('/payment/success', methods=['GET'])
def payment_success():
    """
    Страница успешного завершения платежа
    """
    transaction_id = request.args.get('transaction_id')
    if transaction_id:
        return redirect(f"/payment/status/{transaction_id}")
    
    # HTML-шаблон для страницы успешной оплаты
    success_html = """
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Оплата успешно завершена</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
            }
            .success-container {
                margin-top: 30px;
                background-color: #e8f5e9;
                padding: 20px;
                border-radius: 10px;
            }
            h1 {
                color: #2e7d32;
            }
            .icon {
                font-size: 48px;
                margin-bottom: 20px;
            }
            .instructions {
                background-color: #f5f5f5;
                padding: 15px;
                border-radius: 5px;
                margin: 20px 0;
                text-align: left;
            }
            .button {
                display: inline-block;
                background-color: #4a76a8;
                color: white;
                padding: 10px 20px;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                margin-top: 20px;
            }
        </style>
    </head>
    <body>
        <div class="success-container">
            <div class="icon">✅</div>
            <h1>Оплата успешно завершена</h1>
            <p>Спасибо за оплату подписки!</p>
            
            <div class="instructions">
                <p><strong>Что делать дальше:</strong></p>
                <ol>
                    <li>Вернитесь в бота Катюша.</li>
                    <li>Ваша подписка должна быть уже активирована.</li>
                    <li>Если подписка не активировалась автоматически, отправьте команду /activate_subscription.</li>
                    <li>При возникновении проблем обратитесь в поддержку.</li>
                </ol>
            </div>
            
            <a href="https://t.me/Katiysha_bot" class="button">Вернуться к боту</a>
        </div>
    </body>
    </html>
    """
    return render_template_string(success_html)

@payment_routes_bp.route('/payment/fail', methods=['GET'])
def payment_fail():
    """
    Страница неудачного завершения платежа
    """
    transaction_id = request.args.get('transaction_id')
    if transaction_id:
        return redirect(f"/payment/status/{transaction_id}")
    
    # HTML-шаблон для страницы неудачной оплаты
    fail_html = """
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Ошибка оплаты</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
            }
            .fail-container {
                margin-top: 30px;
                background-color: #ffebee;
                padding: 20px;
                border-radius: 10px;
            }
            h1 {
                color: #c62828;
            }
            .icon {
                font-size: 48px;
                margin-bottom: 20px;
            }
            .instructions {
                background-color: #f5f5f5;
                padding: 15px;
                border-radius: 5px;
                margin: 20px 0;
                text-align: left;
            }
            .button {
                display: inline-block;
                background-color: #4a76a8;
                color: white;
                padding: 10px 20px;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                margin-top: 20px;
            }
        </style>
    </head>
    <body>
        <div class="fail-container">
            <div class="icon">❌</div>
            <h1>Ошибка при оплате</h1>
            <p>К сожалению, при оплате возникла ошибка.</p>
            
            <div class="instructions">
                <p><strong>Что можно сделать:</strong></p>
                <ol>
                    <li>Вернитесь в бота и попробуйте оплатить подписку снова.</li>
                    <li>Убедитесь, что на вашей карте достаточно средств.</li>
                    <li>Проверьте, не заблокированы ли онлайн-платежи на вашей карте.</li>
                    <li>Попробуйте использовать другой метод оплаты.</li>
                    <li>Если проблема повторяется, обратитесь в поддержку.</li>
                </ol>
            </div>
            
            <a href="https://t.me/Katiysha_bot" class="button">Вернуться к боту</a>
        </div>
    </body>
    </html>
    """
    return render_template_string(fail_html)

@payment_routes_bp.route('/payment/status/<int:transaction_id>', methods=['GET'])
def payment_status(transaction_id):
    """
    Страница статуса платежа по ID транзакции
    
    Args:
        transaction_id: ID транзакции
    """
    from db_models import Transaction
    
    try:
        # Получаем информацию о транзакции
        transaction = Transaction.query.get(transaction_id)
        
        if not transaction:
            return render_template_string("""
                <h1>Транзакция не найдена</h1>
                <p>Информация о платеже не найдена в системе.</p>
                <a href="https://t.me/Katiysha_bot">Вернуться к боту</a>
            """)
        
        # Проверяем статус транзакции
        status = transaction.status.lower() if transaction.status else "unknown"
        
        if status in ["completed", "success"]:
            # Перенаправляем на страницу успешной оплаты
            return redirect("/payment/success")
        elif status in ["failed", "error", "cancelled"]:
            # Перенаправляем на страницу ошибки
            return redirect("/payment/fail")
        else:
            # Страница ожидания обработки платежа
            return render_template_string("""
                <!DOCTYPE html>
                <html lang="ru">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Платеж в обработке</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            max-width: 800px;
                            margin: 0 auto;
                            padding: 20px;
                            text-align: center;
                        }
                        .pending-container {
                            margin-top: 30px;
                            background-color: #e3f2fd;
                            padding: 20px;
                            border-radius: 10px;
                        }
                        h1 {
                            color: #1976d2;
                        }
                        .icon {
                            font-size: 48px;
                            margin-bottom: 20px;
                        }
                        .button {
                            display: inline-block;
                            background-color: #4a76a8;
                            color: white;
                            padding: 10px 20px;
                            text-decoration: none;
                            border-radius: 5px;
                            font-weight: bold;
                            margin-top: 20px;
                        }
                    </style>
                </head>
                <body>
                    <div class="pending-container">
                        <div class="icon">⏳</div>
                        <h1>Платеж в обработке</h1>
                        <p>Ваш платеж обрабатывается. Это может занять некоторое время.</p>
                        <p>ID транзакции: {{ transaction_id }}</p>
                        <p>Статус: {{ status }}</p>
                        <p>Дата создания: {{ created_at }}</p>
                        
                        <a href="https://t.me/Katiysha_bot" class="button">Вернуться к боту</a>
                    </div>
                </body>
                </html>
            """, transaction_id=transaction_id, status=status, created_at=transaction.created_at)
    
    except Exception as e:
        logger.error(f"Error checking payment status for transaction {transaction_id}: {str(e)}")
        return render_template_string("""
            <h1>Ошибка проверки статуса</h1>
            <p>При проверке статуса платежа произошла ошибка.</p>
            <a href="https://t.me/Katiysha_bot">Вернуться к боту</a>
        """)

def register_payment_routes(app):
    """
    Регистрация всех маршрутов для обработки платежей
    
    Args:
        app: Flask приложение
    """
    # Регистрируем Blueprint
    app.register_blueprint(payment_routes_bp)
    
    # Инициализируем унифицированный обработчик
    unified_payment_handler.init_app(app)
    
    # Устанавливаем сервис уведомлений, если он доступен
    if hasattr(app, 'notification_service'):
        unified_payment_handler.set_notification_service(app.notification_service)
    
    logger.info("Registered unified payment routes")
    
    return app