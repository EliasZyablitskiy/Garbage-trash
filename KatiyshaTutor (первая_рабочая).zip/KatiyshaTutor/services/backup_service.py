#!/usr/bin/env python
# coding: utf-8

"""
Service for database backup and restore operations
"""

import os
import sys
import logging
import datetime
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple, Union

# Импортируем сервис для работы с Яндекс.Диском
from services.yandex_disk_service import yandex_disk_service

logger = logging.getLogger(__name__)

# PostgreSQL переменные окружения
PGHOST = os.environ.get("PGHOST")
PGPORT = os.environ.get("PGPORT")
PGUSER = os.environ.get("PGUSER")
PGPASSWORD = os.environ.get("PGPASSWORD")
PGDATABASE = os.environ.get("PGDATABASE")
DATABASE_URL = os.environ.get("DATABASE_URL")

class BackupService:
    """Service for database backup and restore operations"""
    
    def __init__(self):
        """Initialize backup service"""
        # Проверяем, указаны ли необходимые переменные окружения
        if not all([PGHOST, PGPORT, PGUSER, PGPASSWORD, PGDATABASE]):
            logger.warning("PostgreSQL connection parameters not set")
    
    def _create_backup_dir(self) -> str:
        """
        Create local directory for backups
        
        Returns:
            str: Path to backup directory
        """
        try:
            # Создаем директорию для бэкапов, если она не существует
            backup_dir = Path("backups")
            backup_dir.mkdir(exist_ok=True)
            
            return str(backup_dir)
        except Exception as e:
            logger.error(f"Error creating backup directory: {e}")
            raise
    
    def create_backup(self) -> Optional[str]:
        """
        Create a backup of the PostgreSQL database
        
        Returns:
            str: Path to backup file or None if error
        """
        try:
            # Проверяем, указаны ли необходимые переменные окружения
            if not all([PGHOST, PGPORT, PGUSER, PGPASSWORD, PGDATABASE]):
                logger.error("PostgreSQL connection parameters not set")
                return None
            
            # Создаем директорию для бэкапов
            backup_dir = self._create_backup_dir()
            
            # Формируем имя файла для бэкапа
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = f"katiysha_bot_backup_{timestamp}.sql"
            backup_path = os.path.join(backup_dir, backup_file)
            
            # Используем pg_dump для создания бэкапа
            env = os.environ.copy()
            env["PGPASSWORD"] = PGPASSWORD
            
            cmd = [
                "pg_dump",
                f"--host={PGHOST}",
                f"--port={PGPORT}",
                f"--username={PGUSER}",
                f"--dbname={PGDATABASE}",
                "--format=plain",
                f"--file={backup_path}"
            ]
            
            logger.info(f"Creating backup of database {PGDATABASE} to {backup_path}")
            
            # Выполняем команду pg_dump
            process = subprocess.run(cmd, env=env, check=True, capture_output=True, text=True)
            
            if process.returncode == 0:
                logger.info(f"Backup created successfully: {backup_path}")
                return backup_path
            else:
                logger.error(f"Error creating backup: {process.stderr}")
                return None
        except subprocess.CalledProcessError as e:
            logger.error(f"Error creating backup with pg_dump: {e.stderr}")
            return None
        except Exception as e:
            logger.error(f"Error creating backup: {e}")
            return None
    
    def restore_backup(self, backup_path: str) -> bool:
        """
        Restore a backup of the PostgreSQL database
        
        Args:
            backup_path: Path to backup file
            
        Returns:
            bool: True if backup restored successfully, False otherwise
        """
        try:
            # Проверяем, указаны ли необходимые переменные окружения
            if not all([PGHOST, PGPORT, PGUSER, PGPASSWORD, PGDATABASE]):
                logger.error("PostgreSQL connection parameters not set")
                return False
            
            # Проверяем, существует ли файл бэкапа
            if not backup_path.startswith("/") and not os.path.exists(backup_path):
                # Возможно, это файл на Яндекс.Диске
                logger.info(f"Backup file {backup_path} not found locally, trying to download from Yandex.Disk")
                
                # Скачиваем файл с Яндекс.Диска
                local_path = yandex_disk_service.download_file(backup_path)
                if local_path:
                    backup_path = local_path
                else:
                    logger.error(f"Failed to download backup file {backup_path} from Yandex.Disk")
                    return False
            
            # Создаем PSQL команду для восстановления
            env = os.environ.copy()
            env["PGPASSWORD"] = PGPASSWORD
            
            cmd = [
                "psql",
                f"--host={PGHOST}",
                f"--port={PGPORT}",
                f"--username={PGUSER}",
                f"--dbname={PGDATABASE}",
                f"--file={backup_path}"
            ]
            
            logger.info(f"Restoring backup from {backup_path} to database {PGDATABASE}")
            
            # Выполняем команду psql
            process = subprocess.run(cmd, env=env, check=True, capture_output=True, text=True)
            
            if process.returncode == 0:
                logger.info(f"Backup restored successfully from {backup_path}")
                return True
            else:
                logger.error(f"Error restoring backup: {process.stderr}")
                return False
        except subprocess.CalledProcessError as e:
            logger.error(f"Error restoring backup with psql: {e.stderr}")
            return False
        except Exception as e:
            logger.error(f"Error restoring backup: {e}")
            return False
    
    def backup_to_yandex_disk(self) -> Optional[Dict[str, Any]]:
        """
        Create a backup of the PostgreSQL database and upload it to Yandex.Disk
        
        Returns:
            dict: Information about uploaded file or None if error
        """
        try:
            # Создаем локальный бэкап
            backup_path = self.create_backup()
            if not backup_path:
                logger.error("Failed to create local backup")
                return None
            
            # Инициализируем клиент Яндекс.Диска
            if not yandex_disk_service.initialize_client():
                logger.error("Failed to initialize Yandex.Disk client")
                return None
            
            # Загружаем бэкап на Яндекс.Диск
            upload_result = yandex_disk_service.upload_file(backup_path)
            
            if upload_result:
                logger.info(f"Backup uploaded to Yandex.Disk: {upload_result.get('path')}")
                return upload_result
            else:
                logger.error("Failed to upload backup to Yandex.Disk")
                return None
        except Exception as e:
            logger.error(f"Error backing up to Yandex.Disk: {e}")
            return None
    
    def list_yandex_disk_backups(self, limit: int = 10) -> Optional[List[Dict[str, Any]]]:
        """
        List backups on Yandex.Disk
        
        Args:
            limit: Maximum number of backups to return
            
        Returns:
            list: List of backup information or None if error
        """
        return yandex_disk_service.list_backups(limit)
    
    def restore_from_yandex_disk(self, remote_path: str) -> bool:
        """
        Restore a backup from Yandex.Disk
        
        Args:
            remote_path: Path on Yandex.Disk
            
        Returns:
            bool: True if backup restored successfully, False otherwise
        """
        try:
            # Инициализируем клиент Яндекс.Диска
            if not yandex_disk_service.initialize_client():
                logger.error("Failed to initialize Yandex.Disk client")
                return False
            
            # Скачиваем бэкап с Яндекс.Диска
            local_path = yandex_disk_service.download_file(remote_path)
            
            if not local_path:
                logger.error(f"Failed to download backup from Yandex.Disk: {remote_path}")
                return False
            
            # Восстанавливаем из бэкапа
            restore_result = self.restore_backup(local_path)
            
            # Удаляем временный файл
            try:
                os.remove(local_path)
            except:
                pass
            
            return restore_result
        except Exception as e:
            logger.error(f"Error restoring from Yandex.Disk: {e}")
            return False

# Создаем глобальный экземпляр сервиса для использования в других модулях
backup_service = BackupService()