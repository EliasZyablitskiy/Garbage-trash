# Документация по системе уведомлений

## Обзор

Система уведомлений бота Катюша состоит из нескольких компонентов, обеспечивающих отправку различных типов уведомлений пользователям. В настоящее время в системе реализованы два основных сервиса уведомлений:

1. **Стандартный сервис уведомлений** (notification_service.py)
   - Базовые функции для отправки уведомлений
   - Управление шаблонами уведомлений
   - Поддержка ключевых типов уведомлений

2. **Расширенный сервис уведомлений** (enhanced_notification_service.py)
   - Улучшенная версия стандартного сервиса
   - Дополнительные возможности для массовой отправки уведомлений
   - Функционал для автоматических напоминаний и оповещений

3. **Адаптер уведомлений** (notification_adapter.py)
   - Обеспечивает плавный переход со стандартного сервиса на расширенный
   - Поддерживает обратную совместимость
   - Предоставляет единый интерфейс для отправки уведомлений

## Стандартный сервис уведомлений

Файл: `services/notification_service.py`

Основные компоненты:

### NotificationTemplates

Перечисление шаблонов уведомлений:

```python
class NotificationTemplates(Enum):
    PAYMENT_SUCCESS = "payment_success"
    PAYMENT_ERROR = "payment_error"
    REFERRAL_REWARD = "referral_reward"
    PAYOUT_INITIATED = "payout_initiated"
    PAYOUT_COMPLETED = "payout_completed"
    PAYOUT_FAILED = "payout_failed"
    SYSTEM_NOTIFICATION = "system_notification"
    RECOVERY_ATTEMPT = "recovery_attempt"
    SUBSCRIPTION_EXPIRY = "subscription_expiry"
```

### NotificationType

Типы уведомлений:

```python
class NotificationType:
    PAYMENT_PENDING = "payment_pending"
    PAYMENT_SUCCESSFUL = "payment_successful"
    PAYMENT_FAILED = "payment_failed"
    SUBSCRIPTION_EXPIRING = "subscription_expiring"
    SUBSCRIPTION_EXPIRED = "subscription_expired"
    REFERRAL_REWARD = "referral_reward"
    PAYOUT_AVAILABLE = "payout_available"
    PAYOUT_PROCESSING = "payout_processing"
    PAYOUT_COMPLETED = "payout_completed"
    PAYOUT_FAILED = "payout_failed"
    SYSTEM = "system"
```

### NotificationManager

Базовый класс для управления уведомлениями через шаблоны:

```python
manager = get_notification_manager(bot)
await manager.send_template(user_id, NotificationTemplates.PAYMENT_SUCCESS, context)
```

### NotificationService

Сервис для отправки уведомлений на основе типов:

```python
service = NotificationService(bot)
await service.send_notification(user_id, NotificationType.PAYMENT_SUCCESSFUL, context)
```

## Расширенный сервис уведомлений

Файл: `services/enhanced_notification_service.py`

Основные компоненты:

### EnhancedNotificationService

Расширенный класс для отправки уведомлений с дополнительными возможностями:

```python
service = get_enhanced_notification_service(bot)
await service.send_notification(user_id, NotificationType.PAYMENT_SUCCESSFUL, context)
```

### Дополнительные методы

- `notify_users_about_available_payouts` - массовая отправка уведомлений о доступных выплатах
- `notify_users_about_expiring_subscriptions` - массовая отправка уведомлений об истекающих подписках

## Адаптер уведомлений

Файл: `services/notification_adapter.py`

Адаптер обеспечивает единый интерфейс для отправки уведомлений, автоматически выбирая между стандартным и расширенным сервисами.

### Настройки адаптера

```python
# Использовать расширенный сервис по умолчанию
USE_ENHANCED_SERVICE = True

# Если расширенный сервис не сработал, использовать стандартный
FALLBACK_TO_LEGACY = True
```

### Использование адаптера

```python
from services.notification_adapter import send_notification

# Автоматический выбор сервиса на основе настроек
await send_notification(
    user_id=user_id,
    notification_type=NotificationType.PAYMENT_SUCCESSFUL,
    context={"amount": 199},
    bot=bot
)

# Принудительное использование расширенного сервиса
await send_notification(
    user_id=user_id,
    notification_type=NotificationType.PAYMENT_SUCCESSFUL,
    context={"amount": 199},
    bot=bot,
    use_enhanced=True
)
```

### Дополнительные методы адаптера

```python
from services.notification_adapter import notify_users_about_expiring_subscriptions

# Отправка уведомлений пользователям с истекающими подписками
notification_count = await notify_users_about_expiring_subscriptions(
    session=db_session,
    bot=bot,
    days_threshold=3
)
```

## Интеграция с существующим кодом

При разработке новых функций или обновлении существующих рекомендуется использовать адаптер уведомлений, который обеспечивает плавный переход на расширенный сервис.

### Пример миграции со старого сервиса на адаптер

```python
# Было:
from services.notification_service import NotificationService, NotificationType

notification_service = NotificationService(bot)
await notification_service.send_notification(
    user_id=user_id,
    notification_type=NotificationType.PAYMENT_SUCCESSFUL,
    context={"amount": 199}
)

# Стало:
from services.notification_adapter import send_notification
from services.notification_service import NotificationType

await send_notification(
    user_id=user_id,
    notification_type=NotificationType.PAYMENT_SUCCESSFUL,
    context={"amount": 199},
    bot=bot
)
```

## Планы развития

1. Постепенный переход всех компонентов системы на использование адаптера уведомлений
2. Расширение функциональности EnhancedNotificationService
3. Добавление механизма отложенных уведомлений
4. Реализация приоритетов уведомлений
5. Интеграция с веб-интерфейсом администратора для управления шаблонами уведомлений