#!/usr/bin/env python
# coding: utf-8

"""
SQLAlchemy models for PostgreSQL database
"""

import uuid
import json
import os
import hashlib
import hmac
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Union
from sqlalchemy import Column, Integer, BigInteger, String, Float, Boolean, DateTime, Text, ForeignKey, JSON, Table, Enum
from sqlalchemy.orm import relationship
from flask_sqlalchemy import SQLAlchemy
import enum
from werkzeug.security import generate_password_hash, check_password_hash

# Инициализируем SQLAlchemy
db = SQLAlchemy()

# Таблица для связи между BatchPayout и Transaction
batch_payout_transactions = Table(
    'batch_payout_transactions',
    db.metadata,
    Column('batch_payout_id', Integer, ForeignKey('batch_payouts.id'), primary_key=True),
    Column('transaction_id', Integer, ForeignKey('transactions.id'), primary_key=True)
)

class User(db.Model):
    """User model for storing user information and subscription status"""
    __tablename__ = 'users'
    
    id = Column(BigInteger, primary_key=True)  # Telegram user ID (переключено на BigInteger для поддержки больших Telegram ID)
    username = Column(String(255), nullable=True)
    first_name = Column(String(255), nullable=True)
    last_name = Column(String(255), nullable=True)
    free_request_used = Column(Boolean, default=False)
    subscription_expiry = Column(DateTime, nullable=True)
    subscription_end = Column(DateTime, nullable=True)  # Алиас для subscription_expiry для обратной совместимости
    referral_code = Column(String(32), nullable=True, unique=True)
    referrer_id = Column(BigInteger, ForeignKey('users.id'), nullable=True)
    referrals_json = Column(Text, nullable=True)  # JSON строка для хранения структуры рефералов
    accumulated_amount = Column(Float, default=0.0, nullable=True)  # Накопленные малые вознаграждения
    wallet_address = Column(String(255), nullable=True)  # Адрес кошелька для выплат
    email = Column(String(255), nullable=True)  # Email для выплат
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Отношения
    referrals = relationship("User", backref="referrer", remote_side=[id])
    transactions = relationship("Transaction", back_populates="user", foreign_keys="Transaction.user_id")
    related_transactions = relationship("Transaction", foreign_keys="Transaction.related_user_id")
    math_problems = relationship("MathProblem", back_populates="user")
    
    @property
    def referrals_dict(self) -> Dict[str, List[int]]:
        """Получить структуру рефералов в виде словаря"""
        if not self.referrals_json:
            return {
                "level1": [],  # 5% (прямые рефералы)
                "level2": [],  # 2% (рефералы 2-го уровня)
                "level3": [],  # 2% (рефералы 3-го уровня)
                "level4": [],  # 2% (рефералы 4-го уровня)
            }
        return json.loads(self.referrals_json)
    
    @referrals_dict.setter
    def referrals_dict(self, value: Dict[str, List[int]]) -> None:
        """Установить структуру рефералов из словаря"""
        self.referrals_json = json.dumps(value)
    
    def has_active_subscription(self) -> bool:
        """Check if user has an active subscription"""
        if not self.subscription_expiry:
            return False
        
        # Синхронизируем subscription_end и subscription_expiry для совместимости
        if self.subscription_expiry and self.subscription_end != self.subscription_expiry:
            self.subscription_end = self.subscription_expiry
        
        return datetime.now() < self.subscription_expiry
    
    def generate_referral_code(self) -> str:
        """Generate a unique referral code for the user"""
        if not self.referral_code:
            import base64
            # Создаем уникальный код на основе ID пользователя и случайного UUID
            code_base = f"{self.id}_{uuid.uuid4().hex[:8]}"
            # Кодируем в base64 и берем первые 10 символов
            self.referral_code = base64.b64encode(code_base.encode()).decode()[:10]
        return self.referral_code
    
    def get_referral_link(self) -> str:
        """Get full referral link for the user"""
        # We are importing here to avoid circular imports
        import config
        code = self.generate_referral_code()
        return f"https://t.me/{config.BOT_USERNAME}?start=ref_{code}"
    
    def can_solve_problem(self) -> bool:
        """Check if user can solve a problem (has free request or active subscription)"""
        return not self.free_request_used or self.has_active_subscription()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert User instance to dictionary for storage"""
        data = {
            'id': self.id,
            'username': self.username,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'free_request_used': self.free_request_used
        }
        
        if self.subscription_expiry:
            data['subscription_expiry'] = self.subscription_expiry.isoformat()
        else:
            data['subscription_expiry'] = None
        
        # Добавляем сохранение данных о рефералах
        data['referral_code'] = self.referral_code
        data['referrer_id'] = self.referrer_id
        data['referrals'] = self.referrals_dict
            
        return data
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'User':
        """Create a User instance from dictionary data"""
        user = cls(
            id=data['id'],
            username=data.get('username'),
            first_name=data.get('first_name'),
            last_name=data.get('last_name'),
            free_request_used=data.get('free_request_used', False),
            referral_code=data.get('referral_code'),
            referrer_id=data.get('referrer_id')
        )
        
        if 'subscription_expiry' in data and data['subscription_expiry']:
            try:
                user.subscription_expiry = datetime.fromisoformat(data['subscription_expiry'])
            except (ValueError, TypeError):
                user.subscription_expiry = None
        
        # Добавляем загрузку данных о рефералах
        referrals = data.get('referrals', {
            "level1": [],  # 5% (прямые рефералы)
            "level2": [],  # 2% (рефералы 2-го уровня)
            "level3": [],  # 2% (рефералы 3-го уровня)
            "level4": [],  # 2% (рефералы 4-го уровня)
        })
        user.referrals_dict = referrals
        
        return user


class MathProblem(db.Model):
    """Math problem model for tracking user problems"""
    __tablename__ = 'math_problems'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, ForeignKey('users.id'), nullable=False)
    problem_text = Column(Text, nullable=False)
    image_path = Column(String(255), nullable=True)
    solution = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Отношения
    user = relationship("User", back_populates="math_problems")


class Transaction(db.Model):
    """Transaction model for tracking payments and referral rewards"""
    __tablename__ = 'transactions'
    
    id = Column(Integer, primary_key=True)
    type = Column(String(50), nullable=False)  # subscription, referral_reward, payout
    user_id = Column(BigInteger, ForeignKey('users.id'), nullable=False)
    amount = Column(Float, nullable=False)
    description = Column(Text, nullable=True)
    related_user_id = Column(BigInteger, ForeignKey('users.id'), nullable=True)
    status = Column(String(50), default='pending')  # pending, completed, failed, processing, processing_payout
    payment_data = Column(JSON, nullable=True)
    external_id = Column(String(255), nullable=True, unique=True, index=True)  # Внешний ID платежа для идемпотентности
    idempotency_key = Column(String(255), nullable=True, unique=True, index=True)  # Ключ идемпотентности
    payment_method = Column(String(50), nullable=True)  # robokassa, qr, sbp, manual
    payment_expires_at = Column(DateTime, nullable=True)  # Время истечения платежа
    retry_count = Column(Integer, default=0)  # Счетчик повторных попыток обработки
    last_error = Column(Text, nullable=True)  # Последняя ошибка при обработке
    notes = Column(JSON, nullable=True)  # Дополнительные заметки о транзакции
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    payout_id = Column(Integer, ForeignKey('weekly_payouts.id'), nullable=True)
    
    # Отношения
    user = relationship("User", back_populates="transactions", foreign_keys=[user_id])
    related_user = relationship("User", foreign_keys=[related_user_id], overlaps="related_transactions")
    payout = relationship("WeeklyPayout", back_populates="transactions")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert Transaction to dictionary"""
        return {
            'id': self.id,
            'type': self.type,
            'user_id': self.user_id,
            'amount': self.amount,
            'description': self.description,
            'related_user_id': self.related_user_id,
            'status': self.status,
            'payment_data': self.payment_data,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'payout_id': self.payout_id
        }


class WeeklyPayout(db.Model):
    """Weekly payout model for referral rewards"""
    __tablename__ = 'weekly_payouts'
    
    id = Column(Integer, primary_key=True)
    admin_id = Column(BigInteger, ForeignKey('users.id'), nullable=True)
    status = Column(String(50), default='pending')  # pending, processing, partial, completed, failed
    total_amount = Column(Float, nullable=False)
    amount = Column(Float, nullable=False)  # Дублирует total_amount для совместимости
    total_users = Column(Integer, nullable=False)
    processed_users = Column(Integer, default=0)  # Количество обработанных пользователей
    payout_data = Column(JSON, nullable=True)  # Данные о выплатах пользователям
    processed_transactions = Column(JSON, default=lambda: [])  # Список обработанных транзакций
    error_message = Column(Text, nullable=True)  # Сообщение об ошибке
    processed_at = Column(DateTime, nullable=True)  # Дата начала обработки
    completed_at = Column(DateTime, nullable=True)  # Дата завершения обработки
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Отношения
    transactions = relationship("Transaction", back_populates="payout")
    batch_payouts = relationship("BatchPayout", back_populates="weekly_payout", cascade="all, delete-orphan")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert WeeklyPayout to dictionary"""
        return {
            'id': self.id,
            'status': self.status,
            'total_amount': self.total_amount,
            'total_users': self.total_users,
            'processed_users': self.processed_users,
            'payout_data': self.payout_data,
            'processed_transactions': self.processed_transactions,
            'error_message': self.error_message,
            'processed_at': self.processed_at.isoformat() if self.processed_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        
    def is_complete(self) -> bool:
        """Check if payout is fully processed"""
        return self.processed_users >= self.total_users
        
    def mark_as_processing(self) -> None:
        """Mark payout as processing"""
        self.status = 'processing'
        self.processed_at = datetime.now()
        
    def mark_as_completed(self) -> None:
        """Mark payout as completed"""
        self.status = 'completed'
        self.completed_at = datetime.now()
        
    def mark_as_failed(self, error_message: str) -> None:
        """Mark payout as failed"""
        self.status = 'failed'
        self.error_message = error_message
        
    def update_progress(self, processed_count: int, transaction_ids: List[int]) -> None:
        """Update progress of processing"""
        self.processed_users += processed_count
        
        # Добавляем обработанные транзакции
        if not self.processed_transactions:
            self.processed_transactions = []
            
        self.processed_transactions.extend(transaction_ids)
        
        # Обновляем статус
        if self.is_complete():
            self.mark_as_completed()
        elif self.processed_users > 0:
            self.status = 'partial'


class BatchPayout(db.Model):
    """Batch payout model for processing groups of transactions"""
    __tablename__ = 'batch_payouts'
    
    id = Column(Integer, primary_key=True)
    weekly_payout_id = Column(Integer, ForeignKey('weekly_payouts.id'), nullable=False)
    tier_name = Column(String(50), nullable=False)  # Название группы выплат (1000-3000₽, etc.)
    status = Column(String(50), default='pending')  # pending, processing, completed, failed
    total_amount = Column(Float, nullable=False)
    total_transactions = Column(Integer, nullable=False)
    robokassa_batch_id = Column(String(255), nullable=True)  # ID пакета выплат в Robokassa
    request_data = Column(JSON, nullable=True)  # Данные запроса
    response_data = Column(JSON, nullable=True)  # Данные ответа от API
    error_message = Column(Text, nullable=True)  # Сообщение об ошибке
    processed_at = Column(DateTime, nullable=True)  # Дата начала обработки
    completed_at = Column(DateTime, nullable=True)  # Дата завершения обработки
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Отношения
    weekly_payout = relationship("WeeklyPayout", back_populates="batch_payouts")
    transactions = relationship("Transaction", secondary="batch_payout_transactions")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert BatchPayout to dictionary"""
        return {
            'id': self.id,
            'weekly_payout_id': self.weekly_payout_id,
            'tier_name': self.tier_name,
            'status': self.status,
            'total_amount': self.total_amount,
            'total_transactions': self.total_transactions,
            'robokassa_batch_id': self.robokassa_batch_id,
            'request_data': self.request_data,
            'response_data': self.response_data,
            'error_message': self.error_message,
            'processed_at': self.processed_at.isoformat() if self.processed_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        
    def mark_as_processing(self) -> None:
        """Mark batch as processing"""
        self.status = 'processing'
        self.processed_at = datetime.now()
        
    def mark_as_completed(self) -> None:
        """Mark batch as completed"""
        self.status = 'completed'
        self.completed_at = datetime.now()
        
    def mark_as_failed(self, error_message: str) -> None:
        """Mark batch as failed"""
        self.status = 'failed'
        self.error_message = error_message


class YandexDiskToken(db.Model):
    """Model for storing Yandex.Disk OAuth tokens"""
    __tablename__ = 'yandex_disk_tokens'
    
    id = Column(Integer, primary_key=True)
    access_token = Column(String(255), nullable=False)
    refresh_token = Column(String(255), nullable=False)
    token_type = Column(String(50), default='Bearer')
    expires_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    def is_valid(self) -> bool:
        """Check if token is still valid"""
        if not self.expires_at:
            return False
        return datetime.now() < self.expires_at
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert token to dictionary"""
        return {
            'id': self.id,
            'access_token': self.access_token,
            'refresh_token': self.refresh_token,
            'token_type': self.token_type,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None
        }


class PayoutOperationLog(db.Model):
    """Model for detailed logging of payout operations"""
    __tablename__ = 'payout_operation_logs'
    
    id = Column(Integer, primary_key=True)
    operation_type = Column(String(50), nullable=False)  # create_payout, process_payout, update_status, process_payment_rewards
    payout_id = Column(Integer, ForeignKey('weekly_payouts.id'), nullable=True)
    batch_id = Column(Integer, ForeignKey('batch_payouts.id'), nullable=True)
    transaction_id = Column(Integer, ForeignKey('transactions.id'), nullable=True)
    entity_id = Column(BigInteger, nullable=True)  # Универсальный ID сущности
    entity_type = Column(String(50), nullable=True)  # Тип сущности (transaction, payout, batch, etc)
    source_user_id = Column(BigInteger, nullable=True)  # ID пользователя-источника операции
    amount = Column(Float, nullable=True)  # Сумма операции
    request_data = Column(JSON, nullable=True)  # Данные запроса
    response_data = Column(JSON, nullable=True)  # Данные ответа
    operation_metadata = Column(JSON, nullable=True)  # Дополнительные метаданные операции
    status = Column(String(50), nullable=False)  # started, completed, error, failed, retry
    error_message = Column(Text, nullable=True)  # Сообщение об ошибке
    retry_count = Column(Integer, default=0)  # Счетчик повторных попыток
    execution_time_ms = Column(Integer, nullable=True)  # Время выполнения в мс
    ip_address = Column(String(50), nullable=True)  # IP-адрес запроса
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Отношения
    weekly_payout = relationship("WeeklyPayout", backref="operation_logs")
    batch_payout = relationship("BatchPayout", backref="operation_logs")
    transaction = relationship("Transaction", backref="operation_logs")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert operation log to dictionary"""
        return {
            'id': self.id,
            'operation_type': self.operation_type,
            'payout_id': self.payout_id,
            'batch_id': self.batch_id,
            'transaction_id': self.transaction_id,
            'entity_id': self.entity_id,
            'entity_type': self.entity_type,
            'source_user_id': self.source_user_id,
            'amount': self.amount,
            'request_data': self.request_data,
            'response_data': self.response_data,
            'operation_metadata': self.operation_metadata,
            'status': self.status,
            'error_message': self.error_message,
            'retry_count': self.retry_count,
            'execution_time_ms': self.execution_time_ms,
            'ip_address': self.ip_address,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }





class BackupLog(db.Model):
    """Model for tracking database backups to Yandex.Disk"""
    __tablename__ = 'backup_logs'
    
    id = Column(Integer, primary_key=True)
    backup_file = Column(String(255), nullable=False)  # Имя файла бэкапа
    disk_path = Column(String(255), nullable=False)  # Путь на Яндекс.Диске
    size_bytes = Column(Integer, nullable=True)  # Размер файла в байтах
    status = Column(String(50), default='success')  # success, failed
    error_message = Column(Text, nullable=True)  # Сообщение об ошибке
    created_at = Column(DateTime, default=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert backup log to dictionary"""
        return {
            'id': self.id,
            'backup_file': self.backup_file,
            'disk_path': self.disk_path,
            'size_bytes': self.size_bytes,
            'status': self.status,
            'error_message': self.error_message,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class AdminUser(db.Model):
    """Модель для администраторов с расширенной аутентификацией и ограничением попыток входа"""
    __tablename__ = 'admin_users'
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, ForeignKey('users.id'), nullable=False, unique=True)
    username = Column(String(64), nullable=False, unique=True)  # Добавляем имя пользователя
    password_hash = Column(String(256), nullable=False)
    role = Column(String(50), default='support_admin')  # super_admin, finance_admin, monitoring_admin, support_admin
    login_attempts = Column(Integer, default=0)
    last_login_attempt = Column(DateTime, nullable=True)
    is_locked = Column(Boolean, default=False)
    lock_until = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)
    last_login = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    two_factor_enabled = Column(Boolean, default=False)
    two_factor_secret = Column(String(32), nullable=True)
    temporary_access_token = Column(String(64), nullable=True)
    temporary_access_expires = Column(DateTime, nullable=True)
    
    # Отношения
    user = relationship("User", foreign_keys=[telegram_id])
    action_logs = relationship("AdminActionLog", back_populates="admin_user")
    
    def set_password(self, password):
        """Установить хешированный пароль"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Проверить пароль"""
        return check_password_hash(self.password_hash, password)
    
    def increment_login_attempts(self):
        """Увеличить счетчик попыток входа"""
        self.login_attempts += 1
        self.last_login_attempt = datetime.now()
        
        # Блокировка аккаунта после 5 неудачных попыток на 15 минут
        if self.login_attempts >= 5:
            self.is_locked = True
            self.lock_until = datetime.now() + timedelta(minutes=15)
    
    def reset_login_attempts(self):
        """Сбросить счетчик попыток входа после успешной аутентификации"""
        self.login_attempts = 0
        self.last_login_attempt = None
        self.is_locked = False
        self.lock_until = None
        self.last_login = datetime.now()
    
    def is_account_locked(self):
        """Проверить, заблокирован ли аккаунт"""
        if not self.is_locked:
            return False
        
        # Разблокировать аккаунт, если время блокировки истекло
        if self.lock_until and datetime.now() > self.lock_until:
            self.is_locked = False
            self.lock_until = None
            return False
            
        return True
    
    def generate_temporary_access_token(self, expires_in_minutes=30):
        """Генерировать временный токен доступа (для 2FA)"""
        token = hashlib.sha256(os.urandom(32)).hexdigest()
        self.temporary_access_token = token
        self.temporary_access_expires = datetime.now() + timedelta(minutes=expires_in_minutes)
        return token
    
    def verify_temporary_access_token(self, token):
        """Проверить временный токен доступа"""
        if not self.temporary_access_token or not self.temporary_access_expires:
            return False
        
        if datetime.now() > self.temporary_access_expires:
            self.temporary_access_token = None
            self.temporary_access_expires = None
            return False
            
        is_valid = self.temporary_access_token == token
        
        # Токен одноразового использования - удаляем после проверки
        if is_valid:
            self.temporary_access_token = None
            self.temporary_access_expires = None
            
        return is_valid

class AdminActionLog(db.Model):
    """Модель для логирования действий администраторов"""
    __tablename__ = 'admin_action_logs'
    
    id = Column(Integer, primary_key=True)
    admin_id = Column(BigInteger, ForeignKey('users.id'), nullable=False)
    admin_user_id = Column(Integer, ForeignKey('admin_users.id'), nullable=True)
    action_type = Column(String(100), nullable=False)  # Тип действия (create_payout, process_payout, etc.)
    details = Column(Text, nullable=True)  # Детали действия в формате JSON
    ip_address = Column(String(45), nullable=True)  # IP-адрес (включая поддержку IPv6)
    user_agent = Column(String(255), nullable=True)  # User-Agent браузера/клиента
    timestamp = Column(DateTime, default=datetime.now)
    is_verified = Column(Boolean, default=False)  # Проверка целостности лога
    verification_hash = Column(String(64), nullable=True)  # Хеш для проверки целостности
    
    # Отношения
    admin = relationship("User", foreign_keys=[admin_id])
    admin_user = relationship("AdminUser", back_populates="action_logs", foreign_keys=[admin_user_id])
    
    def set_verification_hash(self):
        """Установить хеш для проверки целостности логов"""
        # Создаем строку из важных полей лога
        content = f"{self.admin_id}|{self.action_type}|{self.details}|{self.timestamp.isoformat()}|{self.ip_address}"
        # Добавляем секрет для предотвращения подделки
        secret = os.environ.get("LOG_VERIFICATION_SECRET", "default_log_verification_secret")
        # Вычисляем HMAC-хеш
        self.verification_hash = hmac.new(
            secret.encode(),
            content.encode(),
            hashlib.sha256
        ).hexdigest()
        self.is_verified = True
    
    def verify_integrity(self):
        """Проверить целостность лога"""
        if not self.verification_hash:
            return False
            
        # Создаем строку из важных полей лога
        content = f"{self.admin_id}|{self.action_type}|{self.details}|{self.timestamp.isoformat()}|{self.ip_address}"
        # Добавляем секрет для предотвращения подделки
        secret = os.environ.get("LOG_VERIFICATION_SECRET", "default_log_verification_secret")
        # Вычисляем HMAC-хеш для сравнения
        expected_hash = hmac.new(
            secret.encode(),
            content.encode(),
            hashlib.sha256
        ).hexdigest()
        
        return hmac.compare_digest(self.verification_hash, expected_hash)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert admin action log to dictionary"""
        return {
            'id': self.id,
            'admin_id': self.admin_id,
            'action_type': self.action_type,
            'details': self.details,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }
        
    @classmethod
    def log_action(cls, admin_id: int, action_type: str, details: Dict[str, Any]) -> 'AdminActionLog':
        """Create and save admin action log"""
        details_json = json.dumps(details) if isinstance(details, dict) else details
        log = cls(
            admin_id=admin_id,
            action_type=action_type,
            details=details_json
        )
        db.session.add(log)
        return log


class FraudRiskEnum(enum.Enum):
    """Уровни риска мошенничества"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class FraudRuleTypeEnum(enum.Enum):
    """Типы правил обнаружения мошенничества"""
    REGISTRATION = "registration"
    REFERRAL = "referral"
    PAYMENT = "payment"
    PATTERN = "pattern"
    NETWORK = "network"


class ReferralNetwork(db.Model):
    """Сетевая модель реферальной программы для анализа связей между пользователями"""
    __tablename__ = 'referral_networks'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, ForeignKey('users.id'), nullable=False)
    network_data = Column(JSON, nullable=True)  # Данные о сети рефералов
    risk_score = Column(Float, default=0.0)  # Оценка риска от 0.0 до 1.0
    risk_level = Column(Enum(FraudRiskEnum), default=FraudRiskEnum.LOW)
    analyzed_at = Column(DateTime, default=datetime.now)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Отношения
    user = relationship("User", foreign_keys=[user_id])
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert ReferralNetwork to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'network_data': self.network_data,
            'risk_score': self.risk_score,
            'risk_level': self.risk_level.value if self.risk_level else None,
            'analyzed_at': self.analyzed_at.isoformat() if self.analyzed_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class FraudDetectionLog(db.Model):
    """Журнал обнаружения потенциально мошеннических действий"""
    __tablename__ = 'fraud_detection_logs'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, ForeignKey('users.id'), nullable=False)
    rule_name = Column(String(255), nullable=False)  # Название правила, которое сработало
    rule_type = Column(Enum(FraudRuleTypeEnum), nullable=False)
    risk_level = Column(Enum(FraudRiskEnum), nullable=False)
    risk_score = Column(Float, nullable=False)  # Оценка риска от 0.0 до 1.0
    details = Column(JSON, nullable=True)  # Детали срабатывания правила
    action_taken = Column(String(50), nullable=True)  # Какое действие было предпринято
    transaction_id = Column(Integer, ForeignKey('transactions.id'), nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    
    # Отношения
    user = relationship("User", foreign_keys=[user_id])
    transaction = relationship("Transaction", foreign_keys=[transaction_id])
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert FraudDetectionLog to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'rule_name': self.rule_name,
            'rule_type': self.rule_type.value if self.rule_type else None,
            'risk_level': self.risk_level.value if self.risk_level else None,
            'risk_score': self.risk_score,
            'details': self.details,
            'action_taken': self.action_taken,
            'transaction_id': self.transaction_id,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
        
class SubscriptionAuditLog(db.Model):
    """Model for tracking subscription changes"""
    __tablename__ = 'subscription_audit_logs'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, ForeignKey('users.id'), nullable=False)
    action = Column(String(50), nullable=False)  # activate, deactivate, extend, update, etc.
    old_value = Column(String(255), nullable=True)  # Старое значение (например, дата окончания)
    new_value = Column(String(255), nullable=True)  # Новое значение
    reason = Column(String(255), nullable=False)  # Причина изменения (payment, admin_action, expiry, etc.)
    details = Column(JSON, nullable=True)  # Дополнительные детали изменения
    created_at = Column(DateTime, default=datetime.now)
    transaction_id = Column(Integer, ForeignKey('transactions.id'), nullable=True)
    
    # Отношения
    user = relationship("User", foreign_keys=[user_id])
    transaction = relationship("Transaction", foreign_keys=[transaction_id])
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert SubscriptionAuditLog to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'action': self.action,
            'old_value': self.old_value,
            'new_value': self.new_value,
            'reason': self.reason,
            'details': self.details,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'transaction_id': self.transaction_id
        }
        

class AccumulatedReward(db.Model):
    """Модель для отслеживания накопленных малых вознаграждений до порога выплаты"""
    __tablename__ = 'accumulated_rewards'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, ForeignKey('users.id'), nullable=False)
    amount = Column(Float, default=0.0, nullable=False)
    last_updated = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Отношения
    user = relationship("User", backref="accumulated_rewards")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "amount": self.amount,
            "last_updated": self.last_updated.isoformat() if self.last_updated else None
        }


class UserPlatform(db.Model):
    """Модель для хранения информации о платформе пользователя"""
    __tablename__ = 'user_platforms'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, ForeignKey('users.id'), nullable=False, index=True)
    platform_type = Column(String(20), nullable=False, default='unknown')
    platform_version = Column(String(50), nullable=True)
    device_model = Column(String(100), nullable=True)  # Изменено с device_type на device_model для соответствия схеме БД
    user_agent = Column(Text, nullable=True)
    last_seen = Column(DateTime, default=datetime.now)
    
    # Отношения
    user = relationship("User", backref="platforms")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "platform_type": self.platform_type,
            "platform_version": self.platform_version,
            "device_model": self.device_model,  # Обновлено в соответствии с изменением имени колонки
            "user_agent": self.user_agent,
            "last_seen": self.last_seen.isoformat() if self.last_seen else None
        }
    
    def __repr__(self):
        return f"<UserPlatform(user_id={self.user_id}, platform={self.platform_type})>"


class InstanceLock(db.Model):
    """Модель для хранения информации о блокировках экземпляров"""
    __tablename__ = 'instance_locks'
    
    id = Column(Integer, primary_key=True)
    lock_name = Column(String(100), nullable=False, unique=True, index=True)
    instance_id = Column(String(36), nullable=False)
    created_at = Column(DateTime, default=datetime.now)
    expires_at = Column(DateTime, nullable=False)
    lock_metadata = Column(JSON, nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "lock_name": self.lock_name,
            "instance_id": self.instance_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "metadata": self.metadata
        }
    
    def __repr__(self):
        return f"<InstanceLock(lock_name={self.lock_name}, instance_id={self.instance_id})>"


class PlatformTestResult(db.Model):
    """Модель для хранения результатов тестирования платформы"""
    __tablename__ = 'platform_test_results'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, ForeignKey('users.id'), nullable=False, index=True)
    platform_type = Column(String(20), nullable=False, default='unknown')
    platform_version = Column(String(50), nullable=True)
    tests_run = Column(Integer, default=0)
    tests_passed = Column(Integer, default=0)
    tests_failed = Column(Integer, default=0)
    results_json = Column(Text, nullable=True)  # JSON с детальными результатами тестов
    timestamp = Column(DateTime, default=datetime.now)
    
    # Отношения
    user = relationship("User", backref="platform_tests")
    
    
class PlatformFeedback(db.Model):
    """Модель для хранения обратной связи пользователей о платформенной совместимости"""
    __tablename__ = 'platform_feedback'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, ForeignKey('users.id'), nullable=False, index=True)
    platform_type = Column(String(20), nullable=False, default='unknown')
    platform_version = Column(String(50), nullable=True)
    device_info = Column(String(255), nullable=True)
    feature_type = Column(String(50), nullable=False)  # Тип функции (AI, QR, UI, etc)
    rating = Column(Integer, nullable=False)  # Оценка 1-5
    feedback_text = Column(Text, nullable=True)  # Текстовый отзыв
    screenshot_path = Column(String(255), nullable=True)  # Путь к скриншоту
    is_resolved = Column(Boolean, default=False)  # Флаг разрешения проблемы
    admin_notes = Column(Text, nullable=True)  # Заметки администратора
    timestamp = Column(DateTime, default=datetime.now)
    
    # Отношения
    user = relationship("User", backref="platform_feedback")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'platform_type': self.platform_type,
            'platform_version': self.platform_version,
            'device_info': self.device_info,
            'feature_type': self.feature_type,
            'rating': self.rating,
            'feedback_text': self.feedback_text,
            'screenshot_path': self.screenshot_path,
            'is_resolved': self.is_resolved,
            'admin_notes': self.admin_notes,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }
    
    def __repr__(self):
        return f"<PlatformFeedback(user_id={self.user_id}, platform={self.platform_type}, feature={self.feature_type}, rating={self.rating})>"
