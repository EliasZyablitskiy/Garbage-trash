#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для добавления полей wallet_address и email в таблицу users
"""

import os
import logging
import sqlalchemy as sa
from sqlalchemy import create_engine
from sqlalchemy.sql import text

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def run_migration():
    """Выполнение миграции - добавление полей wallet_address и email в таблицу users"""
    try:
        # Получаем URL базы данных из переменной окружения
        database_url = os.environ.get('DATABASE_URL')
        if not database_url:
            logger.error("DATABASE_URL не найден в переменных окружения")
            return False
        
        # Создаем движок SQLAlchemy
        engine = create_engine(database_url)
        
        # Проверяем существование колонок перед добавлением
        with engine.connect() as connection:
            inspector = sa.inspect(engine)
            columns = [col['name'] for col in inspector.get_columns('users')]
            
            # Добавляем wallet_address, если его нет
            if 'wallet_address' not in columns:
                logger.info("Добавление колонки wallet_address в таблицу users")
                connection.execute(text(
                    "ALTER TABLE users ADD COLUMN wallet_address VARCHAR(255)"
                ))
                logger.info("Колонка wallet_address успешно добавлена")
            else:
                logger.info("Колонка wallet_address уже существует")
                
            # Добавляем email, если его нет
            if 'email' not in columns:
                logger.info("Добавление колонки email в таблицу users")
                connection.execute(text(
                    "ALTER TABLE users ADD COLUMN email VARCHAR(255)"
                ))
                logger.info("Колонка email успешно добавлена")
            else:
                logger.info("Колонка email уже существует")

        logger.info("Миграция успешно завершена")
        return True
    except Exception as e:
        logger.error(f"Ошибка при выполнении миграции: {e}")
        return False

def main():
    """Основная функция"""
    logger.info("Запуск миграции для добавления полей wallet_address и email")
    success = run_migration()
    if success:
        logger.info("Миграция успешно выполнена")
    else:
        logger.error("Миграция не выполнена из-за ошибок")

if __name__ == '__main__':
    main()