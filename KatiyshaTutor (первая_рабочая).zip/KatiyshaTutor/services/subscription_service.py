"""
Сервис для управления подписками пользователей и отправки уведомлений
"""
import os
import logging
import datetime
import json
import asyncio
from typing import Optional, Dict, Any, List, Tuple

import telegram
from telegram import Bot

from database import (
    get_user, update_user_subscription, add_transaction, 
    get_users_with_expiring_subscriptions, get_transaction_by_id,
    get_all_users, update_user_data
)
from db_models import db, SubscriptionAuditLog
import config

# Настраиваем логирование
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Создаем логгер для аудита операций с подписками
subscription_audit_logger = logging.getLogger("subscription_audit")
subscription_audit_logger.setLevel(logging.INFO)

# Добавляем обработчик для сохранения аудита в отдельный файл
audit_handler = logging.FileHandler("logs/subscription_audit.log")
audit_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
subscription_audit_logger.addHandler(audit_handler)

def safe_parse_date(date_string: Optional[str]) -> Optional[datetime.datetime]:
    """
    Безопасный парсинг даты с обработкой всех возможных ошибок
    
    Args:
        date_string: Строка с датой для парсинга
        
    Returns:
        Optional[datetime.datetime]: Объект даты или None в случае ошибки
    """
    if not date_string:
        return None
    
    try:
        return datetime.datetime.fromisoformat(date_string)
    except (ValueError, TypeError) as e:
        logger.error(f"Ошибка разбора даты '{date_string}': {e}")
        return None

async def send_subscription_activation_notification(user_id: int, expiry_date: datetime.datetime, transaction_id: Optional[str] = None, payment_data: Optional[Dict[str, Any]] = None) -> bool:
    """
    Отправляет пользователю уведомление о успешной активации подписки
    
    Args:
        user_id: ID пользователя в Telegram
        expiry_date: Дата окончания подписки
        transaction_id: ID транзакции (опционально)
        payment_data: Данные о платеже (опционально)
        
    Returns:
        bool: True, если уведомление успешно отправлено, False в противном случае
    """
    try:
        # Получаем экземпляр бота из config и telegram
        from telegram.ext import ApplicationBuilder
        from config import TELEGRAM_TOKEN
        
        # Создаем временный экземпляр бота для отправки сообщения
        application = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
        bot = application.bot
        
        # Формируем инфо о платеже с расширенными деталями
        payment_info = ""
        if payment_data:
            # Извлекаем больше информации из payment_data
            payment_method = payment_data.get('payment_method', 'неизвестно')
            invoice_id = payment_data.get('invoice_id', 'не указан')
            amount = payment_data.get('amount', payment_data.get('price', 'неизвестно'))
            currency = payment_data.get('currency', 'RUB')
            payment_date = payment_data.get('payment_date', datetime.datetime.now().isoformat())
            plan = payment_data.get('plan', 'monthly')
            source = payment_data.get('source', 'неизвестно')
            
            # Пытаемся форматировать дату платежа, если она есть
            payment_date_formatted = payment_date
            try:
                if isinstance(payment_date, str):
                    payment_date_obj = datetime.datetime.fromisoformat(payment_date)
                    payment_date_formatted = payment_date_obj.strftime('%d.%m.%Y %H:%M')
            except:
                pass
                
            # Форматируем сумму
            amount_str = f"{amount}₽" if amount != 'неизвестно' else 'неизвестно'
            
            # Добавляем русское описание метода оплаты
            method_names = {
                'manual_activation': 'Ручная активация',
                'robokassa': 'Робокасса',
                'sbp': 'Система быстрых платежей',
                'sbp_link': 'СБП (по ссылке)',
                'sbp_manual': 'СБП (ручной ввод)',
                'sbp_link_auto': 'СБП (автоматический)',
                'sbp_link_desktop': 'СБП (для ПК)',
                'bank_card': 'Банковская карта',
                'telegram': 'Telegram'
            }
            
            payment_method_name = method_names.get(payment_method, payment_method)
            
            # Создаем расширенную информацию о платеже
            payment_info = (
                f"🧾 *Детали платежа*\n"
                f"• Способ оплаты: {payment_method_name}\n"
                f"• Сумма: {amount_str}\n"
                f"• Дата: {payment_date_formatted}\n"
            )
            
            # Добавляем номер счета только если он известен
            if invoice_id != 'не указан':
                payment_info += f"• Номер счета: {invoice_id}\n"
                
            payment_info += f"• Номер транзакции: {transaction_id or 'не указан'}\n\n"
        
        # Формируем сообщение об успешной активации подписки
        message = (
            "✅ *Спасибо за оплату!* Ваша подписка успешно активирована!\n\n"
            f"📆 Срок действия: до *{expiry_date.strftime('%d.%m.%Y')}*\n\n"
            f"{payment_info}"
            "🎯 *Что вы можете делать с подпиской:*\n"
            "• Решать неограниченное количество математических задач\n"
            "• Отправлять фотографии задач для распознавания текста\n"
            "• Отправлять голосовые сообщения для решения задач\n\n"
            "⚠️ *Важно:* За 3 дня до окончания подписки вы получите напоминание с возможностью её продления.\n\n"
            "📝 Отправьте текст задачи или нажмите кнопку «Решить задачу»"
        )
        
        # Отправляем уведомление пользователю
        await bot.send_message(chat_id=user_id, text=message, parse_mode='Markdown')
        logger.info(f"Subscription activation notification sent to user {user_id}")
        return True
    except Exception as e:
        logger.error(f"Error sending subscription activation notification: {e}")
        return False

async def send_subscription_expiry_notification(user_id: int, expiry_date: datetime.datetime) -> bool:
    """
    Отправляет пользователю уведомление о скором окончании подписки
    
    Args:
        user_id: ID пользователя в Telegram
        expiry_date: Дата окончания подписки
        
    Returns:
        bool: True, если уведомление успешно отправлено, False в противном случае
    """
    try:
        # Получаем экземпляр бота из config и telegram
        from telegram.ext import ApplicationBuilder
        from config import TELEGRAM_TOKEN
        
        # Создаем временный экземпляр бота для отправки сообщения
        application = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
        bot = application.bot
        
        days_left = (expiry_date - datetime.datetime.now()).days
        
        # Подбираем текст в зависимости от оставшегося времени
        if days_left <= 0:
            time_text = "уже закончилась сегодня"
        elif days_left == 1:
            time_text = "заканчивается завтра"
        elif days_left <= 3:
            time_text = f"заканчивается через {days_left} дня"
        else:
            time_text = f"заканчивается через {days_left} дней"
        
        # Формируем сообщение о скором окончании подписки
        message = (
            f"⚠️ *Напоминание о подписке*\n\n"
            f"Ваша подписка на бота Катюша {time_text} "
            f"(*{expiry_date.strftime('%d.%m.%Y')}*).\n\n"
            f"Чтобы продолжить пользоваться всеми функциями бота без ограничений, "
            f"пожалуйста, продлите подписку.\n\n"
            f"💰 Стоимость продления: *{config.SUBSCRIPTION_PRICE / 100}₽* за месяц\n\n"
            f"Для продления нажмите команду /subscribe или используйте кнопку «Купить подписку»"
        )
        
        # Отправляем уведомление пользователю
        from keyboards import get_main_keyboard
        await bot.send_message(
            chat_id=user_id, 
            text=message, 
            parse_mode='Markdown',
            reply_markup=get_main_keyboard()
        )
        logger.info(f"Subscription expiry notification sent to user {user_id}")
        return True
    except Exception as e:
        logger.error(f"Error sending subscription expiry notification: {e}")
        return False

async def send_subscription_expired_notification(user_id: int) -> bool:
    """
    Отправляет пользователю уведомление о том, что его подписка истекла
    
    Args:
        user_id: ID пользователя в Telegram
        
    Returns:
        bool: True, если уведомление успешно отправлено, False в противном случае
    """
    try:
        # Получаем экземпляр бота из config и telegram
        from telegram.ext import ApplicationBuilder
        from config import TELEGRAM_TOKEN
        
        # Создаем временный экземпляр бота для отправки сообщения
        application = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
        bot = application.bot
        
        # Формируем сообщение об истечении подписки
        message = (
            "⚠️ *Ваша подписка истекла*\n\n"
            "К сожалению, срок действия вашей подписки на бота Катюша закончился.\n\n"
            "🔒 Теперь вы можете использовать только ограниченную версию бота.\n\n"
            "Чтобы продолжить пользоваться всеми функциями бота без ограничений, "
            "пожалуйста, продлите подписку.\n\n"
            f"💰 Стоимость продления: *{config.SUBSCRIPTION_PRICE / 100}₽* за месяц\n\n"
            "Для продления используйте команду /subscribe или кнопку «Купить подписку»"
        )
        
        # Отправляем уведомление пользователю
        from keyboards import get_main_keyboard
        await bot.send_message(
            chat_id=user_id, 
            text=message, 
            parse_mode='Markdown',
            reply_markup=get_main_keyboard()
        )
        logger.info(f"Subscription expired notification sent to user {user_id}")
        return True
    except Exception as e:
        logger.error(f"Error sending subscription expired notification: {e}")
        return False

def synchronize_subscription_fields(user_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Синхронизирует поля subscription_expiry и subscription_end в данных пользователя
    
    Args:
        user_data: Данные пользователя
        
    Returns:
        Dict[str, Any]: Обновленные данные пользователя
    """
    if not user_data:
        return user_data
        
    # Проверяем наличие полей подписки
    has_subscription_expiry = "subscription_expiry" in user_data
    has_subscription_end = "subscription_end" in user_data
    
    # Если оба поля отсутствуют - ничего не меняем
    if not has_subscription_expiry and not has_subscription_end:
        return user_data
        
    # Если есть только subscription_expiry, копируем его в subscription_end
    if has_subscription_expiry and not has_subscription_end:
        user_data["subscription_end"] = user_data["subscription_expiry"]
        logger.info(f"Copied subscription_expiry to subscription_end for user {user_data.get('id', 'unknown')}")
        
    # Если есть только subscription_end, копируем его в subscription_expiry
    elif not has_subscription_expiry and has_subscription_end:
        user_data["subscription_expiry"] = user_data["subscription_end"]
        logger.info(f"Copied subscription_end to subscription_expiry for user {user_data.get('id', 'unknown')}")
        
    # Если оба поля есть, но разные - устанавливаем более позднюю дату в оба поля
    elif has_subscription_expiry and has_subscription_end and user_data["subscription_expiry"] != user_data["subscription_end"]:
        expiry_date = safe_parse_date(user_data["subscription_expiry"])
        end_date = safe_parse_date(user_data["subscription_end"])
        
        # Если одна из дат не может быть распознана, используем другую
        if expiry_date is None and end_date is not None:
            user_data["subscription_expiry"] = user_data["subscription_end"]
            logger.info(f"Fixed invalid subscription_expiry with subscription_end for user {user_data.get('id', 'unknown')}")
        elif end_date is None and expiry_date is not None:
            user_data["subscription_end"] = user_data["subscription_expiry"]
            logger.info(f"Fixed invalid subscription_end with subscription_expiry for user {user_data.get('id', 'unknown')}")
        # Если обе даты корректны, но разные - выбираем более позднюю
        elif expiry_date is not None and end_date is not None:
            if expiry_date > end_date:
                user_data["subscription_end"] = user_data["subscription_expiry"]
                logger.info(f"Synchronized subscription fields using later date (expiry) for user {user_data.get('id', 'unknown')}")
            else:
                user_data["subscription_expiry"] = user_data["subscription_end"]
                logger.info(f"Synchronized subscription fields using later date (end) for user {user_data.get('id', 'unknown')}")
    
    return user_data

def log_subscription_audit(user_id: int, action: str, old_value: Optional[str], new_value: Optional[str], reason: str, details: Optional[Dict[str, Any]] = None) -> None:
    """
    Записывает информацию об изменении подписки в журнал аудита
    
    Args:
        user_id: ID пользователя
        action: Действие (активация, деактивация, продление и т.д.)
        old_value: Старое значение даты окончания
        new_value: Новое значение даты окончания
        reason: Причина изменения
        details: Дополнительные детали
    """
    # Запись в файл журнала
    log_message = f"User: {user_id}, Action: {action}, Old: {old_value}, New: {new_value}, Reason: {reason}, Details: {json.dumps(details) if details else '{}'}"
    subscription_audit_logger.info(log_message)
    
    # Запись в базу данных с проверкой контекста приложения
    try:
        from flask import current_app
        
        # Проверяем, находимся ли мы внутри контекста приложения
        if current_app:
            # Создаем новую запись аудита
            audit_log = SubscriptionAuditLog()
            audit_log.user_id = user_id
            audit_log.action = action
            audit_log.old_value = old_value
            audit_log.new_value = new_value
            audit_log.reason = reason
            audit_log.details = details
            
            # Сохраняем в базу
            db.session.add(audit_log)
            db.session.commit()
            
            logger.info(f"Subscription audit log saved to database for user {user_id}, action {action}")
    except Exception as e:
        logger.error(f"Error saving subscription audit log to database: {e}")
        # Если у нас есть активная сессия, откатываем транзакцию
        try:
            db.session.rollback()
        except Exception:
            # Если нет активной сессии или контекста, просто логируем ошибку
            pass

def update_subscription_with_audit(user_id: int, expiry_date: datetime.datetime, reason: str, details: Optional[Dict[str, Any]] = None) -> bool:
    """
    Обновляет подписку пользователя с аудитом изменений
    
    Args:
        user_id: ID пользователя
        expiry_date: Новая дата окончания подписки
        reason: Причина изменения подписки
        details: Дополнительные детали
        
    Returns:
        bool: True, если обновление прошло успешно, False в противном случае
    """
    # Получаем текущие данные пользователя
    user_data = get_user(user_id)
    if not user_data:
        logger.error(f"Can't update subscription, user {user_id} not found")
        return False
    
    # Получаем текущую дату окончания подписки
    old_expiry = None
    if "subscription_expiry" in user_data:
        old_expiry = user_data["subscription_expiry"]
    elif "subscription_end" in user_data:
        old_expiry = user_data["subscription_end"]
    
    # Форматируем новую дату для сохранения
    new_expiry_str = expiry_date.isoformat()
    
    # Обновляем оба поля подписки
    user_data["subscription_expiry"] = new_expiry_str
    user_data["subscription_end"] = new_expiry_str
    
    # Проверяем, изменилась ли подписка
    if old_expiry == new_expiry_str:
        logger.info(f"Subscription for user {user_id} not changed (same date)")
        return True
    
    # Записываем в аудит
    log_subscription_audit(
        user_id=user_id,
        action="update",
        old_value=old_expiry,
        new_value=new_expiry_str,
        reason=reason,
        details=details
    )
    
    # Сохраняем обновленные данные пользователя
    success = update_user_data(user_id, user_data)
    if success:
        logger.info(f"Subscription updated for user {user_id}, new expiry: {new_expiry_str}, reason: {reason}")
    else:
        logger.error(f"Failed to update subscription for user {user_id}")
    
    return success

async def synchronize_all_subscriptions() -> Tuple[int, int, int]:
    """
    Синхронизирует поля subscription_expiry и subscription_end для всех пользователей
    
    Returns:
        Tuple[int, int, int]: (количество обработанных пользователей, количество обновленных пользователей, количество ошибок)
    """
    # Счетчики для статистики
    processed_count = 0
    updated_count = 0
    error_count = 0
    
    # Получаем всех пользователей
    users = get_all_users()
    logger.info(f"Starting subscription fields synchronization for {len(users)} users")
    
    # Обрабатываем каждого пользователя
    for user_data in users:
        processed_count += 1
        user_id = user_data.get('id')
        
        if user_id is None:
            error_count += 1
            logger.error(f"Missing user ID in user data: {user_data}")
            continue
            
        try:
            # Синхронизируем поля подписки
            original_data = json.dumps(user_data)
            updated_data = synchronize_subscription_fields(user_data)
            
            # Проверяем, были ли изменения
            if json.dumps(updated_data) != original_data:
                # Обновляем данные пользователя в базе
                if update_user_data(user_id, updated_data):
                    updated_count += 1
                    logger.info(f"Successfully synchronized subscription fields for user {user_id}")
                else:
                    error_count += 1
                    logger.error(f"Failed to update user data after synchronization for user {user_id}")
        except Exception as e:
            error_count += 1
            logger.error(f"Error during subscription synchronization for user {user_id}: {e}")
    
    logger.info(f"Subscription synchronization completed. Processed: {processed_count}, Updated: {updated_count}, Errors: {error_count}")
    return processed_count, updated_count, error_count

async def process_expiring_subscriptions(force_update: bool = False) -> Tuple[int, int, int]:
    """
    Находит пользователей с истекающими подписками, отправляет им уведомления
    и при необходимости деактивирует истекшие подписки
    
    Args:
        force_update: Если True, принудительно деактивирует истекшие подписки
    
    Returns:
        Tuple[int, int, int]: (количество уведомлений об истечении, количество уведомлений о скором истечении, 
                              количество деактивированных подписок)
    """
    logger.info(f"Starting to process expiring subscriptions (force_update={force_update})")
    now = datetime.datetime.now()
    today = now.date()
    
    # Получаем пользователей, у которых подписка истекает в ближайшие 3 дня или уже истекла сегодня
    # Если force_update=True, также получаем всех пользователей с истекшими подписками
    days_range = 3
    if force_update:
        # При force_update мы хотим проверить все истекшие подписки, а не только сегодняшние
        days_range = 1000  # Используем большое число для получения всех истекших подписок
    
    expiring_users = get_users_with_expiring_subscriptions(days=days_range)
    expired_today_users = []  # Истекшие сегодня (для уведомлений)
    expired_users = []        # Все истекшие (для деактивации при force_update)
    expiring_soon_users = []  # Скоро истекающие (для уведомлений)
    
    for user in expiring_users:
        user_id = user.get('id')
        subscription_expiry = user.get('subscription_expiry')
        
        if not subscription_expiry:
            continue
        
        # Используем безопасный парсинг даты
        expiry_date = safe_parse_date(subscription_expiry)
        if not expiry_date:
            logger.error(f"Невозможно разобрать дату окончания подписки для пользователя {user_id}: {subscription_expiry}")
            continue
            
        # Проверяем, истекла ли подписка
        if expiry_date <= now:
            # Если force_update=True, добавляем в список для деактивации
            if force_update:
                expired_users.append((user_id, expiry_date))
            
            # Если истекла сегодня, добавляем в список для уведомления
            if expiry_date.date() == today:
                expired_today_users.append((user_id, expiry_date))
        # Если подписка истекает в ближайшие дни
        else:
            expiring_soon_users.append((user_id, expiry_date))
    
    expired_count = 0
    expiring_count = 0
    deactivated_count = 0
    
    # Отправляем уведомления пользователям, у которых подписка истекла сегодня
    for user_id, expiry_date in expired_today_users:
        try:
            success = await send_subscription_expired_notification(user_id)
            if success:
                expired_count += 1
        except Exception as e:
            logger.error(f"Error sending expired notification to user {user_id}: {e}")
    
    # Отправляем уведомления пользователям, у которых подписка скоро истечет
    for user_id, expiry_date in expiring_soon_users:
        try:
            # Отправляем уведомление, если до истечения осталось 3, 2 или 1 день
            days_left = (expiry_date - now).days
            if days_left in [1, 2, 3]:
                success = await send_subscription_expiry_notification(user_id, expiry_date)
                if success:
                    expiring_count += 1
        except Exception as e:
            logger.error(f"Error sending expiring notification to user {user_id}: {e}")
    
    # Если force_update=True, принудительно деактивируем истекшие подписки
    if force_update and expired_users:
        logger.info(f"Force updating {len(expired_users)} expired subscriptions")
        
        for user_id, expiry_date in expired_users:
            try:
                # Чтобы деактивировать подписку, устанавливаем дату истечения в прошлом
                # Но сохраняем её для возможного восстановления или анализа
                user_data = get_user(user_id)
                if user_data:
                    # Если запись о подписке всё ещё показывает, что она активна
                    if is_subscription_active(user_data):
                        logger.warning(f"Inconsistency detected: User {user_id} has expired subscription but is_subscription_active returned True")
                    
                    # Добавляем транзакцию о деактивации подписки
                    add_transaction(
                        transaction_type="subscription_deactivation",
                        user_id=user_id,
                        amount=0,
                        description=f"Автоматическая деактивация истекшей подписки (истекла: {expiry_date.isoformat()})",
                        status="completed",
                        payment_data={
                            "action": "deactivation",
                            "reason": "expired",
                            "expiry_date": expiry_date.isoformat(),
                            "deactivation_date": now.isoformat()
                        }
                    )
                    
                    # Логически подписка уже неактивна (истекла), но мы можем явно отметить её как деактивированную
                    # Оставляем оригинальную дату истечения, так как она используется для анализа
                    deactivated_count += 1
                    logger.info(f"Deactivated expired subscription for user {user_id} (expired: {expiry_date.isoformat()})")
                    
                    # Записываем в журнал аудита
                    log_subscription_audit(
                        user_id=user_id,
                        action="deactivate",
                        old_value=expiry_date.isoformat(),
                        new_value=None,
                        reason="expired",
                        details={
                            "expired_date": expiry_date.isoformat(),
                            "deactivation_date": now.isoformat()
                        }
                    )
            except Exception as e:
                logger.error(f"Error deactivating expired subscription for user {user_id}: {e}")
    
    logger.info(f"Processed expiring subscriptions: {expired_count} expired notifications, {expiring_count} expiring notifications, {deactivated_count} deactivated")
    return expired_count, expiring_count, deactivated_count

def is_subscription_active(user_data: Optional[Dict[str, Any]]) -> bool:
    """
    Проверяет, активна ли подписка у пользователя
    
    Args:
        user_data: Данные пользователя
        
    Returns:
        bool: True, если подписка активна, False в противном случае
    """
    if not user_data:
        return False
    
    # Проверяем наличие поля с датой окончания подписки
    expiry_field = None
    if "subscription_expiry" in user_data:
        expiry_field = "subscription_expiry"
    elif "subscription_end" in user_data:
        expiry_field = "subscription_end"
    
    if not expiry_field:
        return False
    
    # Получаем дату окончания подписки
    expiry_date_str = user_data[expiry_field]
    if not expiry_date_str:
        return False
    
    # Преобразуем строку с датой в объект datetime
    try:
        expiry_date = safe_parse_date(expiry_date_str)
        if not expiry_date:
            return False
            
        # Если дата окончания подписки больше текущей даты, значит подписка активна
        now = datetime.datetime.now()
        return expiry_date > now
    except Exception as e:
        logger.error(f"Error checking subscription status: {e}")
        return False

def get_subscription_expiry_date(user_id: int) -> Optional[datetime.datetime]:
    """
    Получает дату окончания подписки пользователя
    
    Args:
        user_id: ID пользователя
        
    Returns:
        Optional[datetime.datetime]: Дата окончания подписки или None, если подписка не активна
    """
    user_data = get_user(user_id)
    if not user_data:
        return None
    
    # Проверяем наличие поля с датой окончания подписки
    expiry_date_str = None
    if "subscription_expiry" in user_data:
        expiry_date_str = user_data["subscription_expiry"]
    elif "subscription_end" in user_data:
        expiry_date_str = user_data["subscription_end"]
    
    if not expiry_date_str:
        return None
    
    # Преобразуем строку с датой в объект datetime
    return safe_parse_date(expiry_date_str)

def get_subscription_status(user_id: int) -> Dict[str, Any]:
    """
    Получает информацию о статусе подписки пользователя
    
    Args:
        user_id: ID пользователя
        
    Returns:
        Dict[str, Any]: Словарь с информацией о подписке
    """
    from db_models import User as DbUser

    result = {
        "active": False,
        "expiry_date": None,
        "expiry_date_str": None,
        "days_left": 0,
        "has_free_request": False,
        "reason": "unknown"
    }
    
    # Сначала проверяем JSON базу данных (для обратной совместимости)
    user_data = get_user(user_id)
    
    # Если пользователь не найден в JSON, проверяем SQL базу данных
    if not user_data:
        try:
            # Импортируем Flask-приложение напрямую из main
            from main import app
            
            # Используем контекст приложения для доступа к базе данных
            with app.app_context():
                db_user = DbUser.query.filter_by(id=user_id).first()
                if db_user:
                    # Создаем эквивалент user_data из объекта базы данных
                    user_data = {
                        "id": db_user.id,
                        "username": db_user.username,
                        "first_name": db_user.first_name,
                        "last_name": db_user.last_name,
                        "free_request_used": db_user.free_request_used,
                        "subscription_expiry": db_user.subscription_expiry.isoformat() if db_user.subscription_expiry else None,
                        "subscription_end": db_user.subscription_end.isoformat() if db_user.subscription_end else None,
                        "referral_code": db_user.referral_code,
                        "referrer_id": db_user.referrer_id,
                        "referrals_json": db_user.referrals_json
                    }
                    logger.info(f"User {user_id} found in SQL database but not in JSON")
        except Exception as e:
            logger.error(f"Error accessing SQL database: {e}")
    
    # Если пользователь всё равно не найден
    if not user_data:
        result["reason"] = "user_not_found"
        result["has_free_request"] = True  # Новый пользователь имеет право на бесплатный запрос
        return result
        
    # Проверяем, есть ли бесплатный запрос (напрямую из данных пользователя)
    result["has_free_request"] = not user_data.get("free_request_used", False)
    
    # Проверяем статус подписки
    if is_subscription_active(user_data):
        result["active"] = True
        result["reason"] = "subscription_active"
        
        # Получаем дату окончания
        expiry_date = None
        if "subscription_expiry" in user_data:
            expiry_date = safe_parse_date(user_data["subscription_expiry"])
        elif "subscription_end" in user_data:
            expiry_date = safe_parse_date(user_data["subscription_end"])
            
        if expiry_date:
            result["expiry_date"] = expiry_date
            result["expiry_date_str"] = expiry_date.strftime("%d.%m.%Y")
            
            # Рассчитываем количество оставшихся дней
            days_left = (expiry_date - datetime.datetime.now()).days
            result["days_left"] = max(0, days_left)
    else:
        result["reason"] = "no_subscription"
            
    return result

def has_free_request(user_id: int) -> bool:
    """
    Проверяет, имеет ли пользователь право на бесплатный запрос
    
    Args:
        user_id: ID пользователя
        
    Returns:
        bool: True, если пользователь имеет право на бесплатный запрос
    """
    # Импортируем в функции, чтобы избежать циклических импортов
    from db_models import User as DbUser
    
    # Проверяем JSON базу данных
    user_data = get_user(user_id)
    
    # Проверяем SQL базу данных если не найден в JSON
    if not user_data:
        try:
            from main import app
            with app.app_context():
                db_user = DbUser.query.filter_by(id=user_id).first()
                if db_user:
                    # Проверяем использовал ли пользователь бесплатный запрос в SQL
                    return not db_user.free_request_used
        except Exception as e:
            logger.error(f"Error checking free request in SQL database: {e}")
            # В случае ошибки считаем, что пользователь использовал бесплатный запрос
            return False
    elif user_data:
        # Проверяем использовал ли пользователь бесплатный запрос в JSON
        return not user_data.get("free_request_used", False)
    
    # Если пользователь не найден ни в одной базе, считаем его новым
    return True

def use_free_request(user_id: int) -> bool:
    """
    Отмечает бесплатный запрос как использованный
    
    Args:
        user_id: ID пользователя
        
    Returns:
        bool: True, если операция выполнена успешно
    """
    # Импортируем в функции, чтобы избежать циклических импортов
    from db_models import User as DbUser
    
    # Проверяем наличие и статус пользователя в обеих базах
    user_data = get_user(user_id)
    sql_user_exists = False
    
    # Проверяем SQL базу данных
    try:
        from main import app
        
        with app.app_context():
            db_user = DbUser.query.filter_by(id=user_id).first()
            if db_user:
                sql_user_exists = True
                
                # Проверяем, использовал ли пользователь бесплатный запрос в SQL
                if db_user.free_request_used:
                    logger.warning(f"User {user_id} already used free request (SQL)")
                    return False
                
                # Отмечаем запрос как использованный в SQL
                db_user.free_request_used = True
                db.session.commit()
                logger.info(f"Free request marked as used for user {user_id} in SQL database")
    except Exception as e:
        logger.error(f"Error updating SQL database: {e}")
    
    # Обновляем также JSON базу для обратной совместимости
    if not user_data:
        if not sql_user_exists:
            # Если пользователя нет ни в SQL, ни в JSON, создаем его в JSON
            logger.warning(f"Marking free request as used for non-existent user {user_id}")
            user_data = {
                "id": user_id,
                "username": "",
                "first_name": "",
                "last_name": "",
                "free_request_used": True,
                "registration_date": datetime.datetime.now().isoformat()
            }
            update_user_data(user_id, user_data)
    else:
        # Если пользователь уже использовал бесплатный запрос в JSON
        if user_data.get("free_request_used", False):
            if not sql_user_exists:  # Логируем только если не сделали это для SQL выше
                logger.warning(f"User {user_id} already used free request (JSON)")
                return False
        
        # Отмечаем бесплатный запрос как использованный в JSON
        user_data["free_request_used"] = True
        update_user_data(user_id, user_data)
    
    # Логируем использование бесплатного запроса
    log_subscription_audit(
        user_id=user_id,
        action="free_request_use",
        old_value="False",
        new_value="True",
        reason="user_action",
        details={
            "action": "free_request",
            "timestamp": datetime.datetime.now().isoformat()
        }
    )
    
    logger.info(f"Free request used by user {user_id}")
    return True

def can_use_problem_solving(user_id: int) -> Tuple[bool, str]:
    """
    Проверяет, может ли пользователь использовать решение задач с учётом его платформы
    
    Args:
        user_id: ID пользователя
        
    Returns:
        Tuple[bool, str]: (может ли использовать, причина)
    """
    status = get_subscription_status(user_id)
    
    # Проверяем платформу пользователя для адаптивной проверки подписки
    try:
        from db_models import UserPlatform, db
        from services.payment_service import is_subscription_active, PLATFORM_UNKNOWN
        from db_config import flask_app
        
        # Используем контекст приложения Flask
        with flask_app.app_context():
            # Получаем информацию о платформе пользователя
            platform_info = UserPlatform.query.filter_by(user_id=user_id).order_by(
                UserPlatform.last_seen.desc()
            ).first()
            
            platform_type = PLATFORM_UNKNOWN
            if platform_info:
                platform_type = platform_info.platform_type
                logger.debug(f"Platform detected for user {user_id}: {platform_type}")
            
            user_data = get_user(user_id)
            
            # Если есть активная подписка с учетом платформы
            if user_data and is_subscription_active(user_data, platform_type):
                return True, "subscription"
    except Exception as e:
        logger.error(f"Error checking platform-aware subscription: {e}")
        # Если произошла ошибка при проверке платформо-зависимой подписки,
        # используем обычную проверку
        if status["active"]:
            return True, "subscription"
        
    # Если есть неиспользованный бесплатный запрос
    if status["has_free_request"]:
        return True, "free_request"
        
    # Нет ни подписки, ни бесплатного запроса
    return False, "no_access"