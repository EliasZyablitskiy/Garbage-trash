#!/usr/bin/env python
# coding: utf-8

"""
Service for extracting text from images using Free Online OCR API
"""

import os
import base64
import logging
import aiohttp
import config
import pytesseract
from PIL import Image

logger = logging.getLogger(__name__)

# API конфигурация для Free Online OCR API
OCR_API_URL = config.OCR_API_URL
OCR_API_KEY = config.OCR_API_KEY

async def extract_text_from_image(image_path: str) -> str:
    """
    Extract text from an image using Free Online OCR API
    
    Args:
        image_path: Path to the image file
        
    Returns:
        str: The extracted text from the image
    """
    logger.info(f"Extracting text from image: {image_path}")
    
    try:
        # Кодируем изображение в base64
        with open(image_path, "rb") as img_file:
            base64_image = base64.b64encode(img_file.read()).decode('utf-8')
        
        # Параметры запроса к OCR API
        headers = {
            "Content-Type": "application/json",
            "apikey": OCR_API_KEY
        }
        
        payload = {
            "base64Image": base64_image,
            "language": "rus"  # Указываем русский язык для распознавания
        }
        
        # Отправляем запрос к API
        async with aiohttp.ClientSession() as session:
            async with session.post(OCR_API_URL, headers=headers, json=payload) as response:
                if response.status != 200:
                    logger.error(f"OCR API error: {response.status} - {await response.text()}")
                    return await fallback_ocr(image_path)
                
                response_data = await response.json()
                extracted_text = response_data.get("text", "")
                
                if not extracted_text:
                    logger.warning("Empty text extracted by OCR API")
                    return await fallback_ocr(image_path)
                
                return extracted_text
                
    except Exception as e:
        logger.error(f"Error extracting text from image: {e}")
        return await fallback_ocr(image_path)

async def fallback_ocr(image_path: str) -> str:
    """
    Fallback OCR method using pytesseract if available
    
    Args:
        image_path: Path to the image file
        
    Returns:
        str: The extracted text or empty string if fails
    """
    logger.info("Using fallback OCR (pytesseract)")
    
    try:
        # Используем pytesseract как резервный метод OCR
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img, lang='rus')
        return text if text else "Не удалось распознать текст на изображении."
    except Exception as e:
        logger.error(f"Fallback OCR error: {e}")
        return "Не удалось распознать текст на изображении."