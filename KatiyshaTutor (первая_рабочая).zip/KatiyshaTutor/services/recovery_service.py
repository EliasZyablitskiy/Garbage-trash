#!/usr/bin/env python
# coding: utf-8

"""
Сервис для восстановления прерванных выплат и транзакций
"""

import logging
import datetime
import asyncio
from typing import Dict, Any, List, Optional, Tuple, Set

from sqlalchemy import and_, or_, func
from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession

from db_models import Transaction, WeeklyPayout, BatchPayout, User, db
from services.db_transaction_service import DBSessionManager
from services.notification_service import NotificationService, NotificationType
from flask import current_app
from config import ADMIN_IDS
from services.payment_error_handler import analyze_robokassa_error, get_admin_error_message
from services.payment_verification_service_v2 import payment_verification_service_v2, PAYMENT_SYSTEMS, PaymentResultCode
from services.unified_payment_handler import unified_payment_handler, PaymentSystem

# Настраиваем логирование
logger = logging.getLogger(__name__)


class RecoveryService:
    """
    Сервис для восстановления прерванных выплат
    """
    
    @staticmethod
    def _get_notification_service() -> Optional[NotificationService]:
        """
        Получает экземпляр сервиса уведомлений из app context
        
        Returns:
            NotificationService: Экземпляр сервиса уведомлений или None
        """
        try:
            # Пробуем получить сервис из контекста приложения
            try:
                app = current_app._get_current_object() if hasattr(current_app, '_get_current_object') else None
                if app and hasattr(app, 'notification_service'):
                    return app.notification_service
            except Exception as e:
                logger.warning(f"Не удалось получить notification_service из app context: {e}")
            
            # Если сервис не найден в контексте приложения, возвращаем глобальный экземпляр
            return NotificationService.get_instance()
            
        except Exception as e:
            logger.error(f"Ошибка при получении сервиса уведомлений: {e}")
            return None
    
    @staticmethod
    def _safe_int_convert(value) -> int:
        """
        Безопасно преобразует значение в целое число
        
        Args:
            value: Значение для преобразования (может быть Column[int], int или другим типом)
            
        Returns:
            int: Преобразованное целое число или 0 в случае ошибки
        """
        try:
            if hasattr(value, '__int__'):
                return int(value)
            return int(str(value))
        except (ValueError, TypeError, AttributeError):
            logger.warning(f"Не удалось преобразовать значение {value} к целому числу")
            return 0
    
    @staticmethod
    async def _send_recovery_notification(user_id: int, payout_id: int, transaction_ids: List[int], is_batch: bool = False) -> bool:
        """
        Отправляет уведомление о восстановлении платежа пользователю
        
        Args:
            user_id: ID пользователя для отправки уведомления
            payout_id: ID выплаты (или пакетной выплаты)
            transaction_ids: Список ID транзакций, которые были восстановлены
            is_batch: Является ли выплата пакетной
            
        Returns:
            bool: True если уведомление успешно отправлено, False в противном случае
        """
        try:
            # Получаем экземпляр сервиса уведомлений
            notification_service = RecoveryService._get_notification_service()
            
            if not notification_service:
                logger.error(f"Не удалось получить сервис уведомлений для отправки уведомления о восстановлении пользователю {user_id}")
                return False
            
            # Определяем тип восстановления в зависимости от параметров
            recovery_type = "batch_recovered" if is_batch else "transaction_recovered"
            
            # Подготавливаем контекст для уведомления
            context = {
                "transaction_id": transaction_ids[0] if len(transaction_ids) == 1 else f"{len(transaction_ids)} транзакций",
                "payout_id": payout_id,
                "count": len(transaction_ids)
            }
            
            # Отправляем уведомление пользователю
            await notification_service.send_payment_recovery_notification(
                user_id=user_id,
                recovery_type=recovery_type,
                context=context
            )
            
            # Отправляем уведомление администраторам
            for admin_id in ADMIN_IDS:
                # Для администраторов используем специальный тип уведомления
                admin_context = {
                    "payout_id": payout_id,
                    "count": len(transaction_ids),
                    "user_id": user_id
                }
                
                await notification_service.send_payment_recovery_notification(
                    user_id=admin_id,
                    recovery_type="admin_recovery_notification",
                    context=admin_context
                )
            
            logger.info(f"Отправлено уведомление о восстановлении платежа пользователю {user_id} (выплата #{payout_id}, {len(transaction_ids)} транзакций)")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка при отправке уведомления о восстановлении платежа: {e}", exc_info=True)
            return False
    
    @staticmethod
    async def detect_stalled_payouts(session: AsyncSession, hours_threshold: int = 1) -> List[WeeklyPayout]:
        """
        Обнаружение зависших выплат
        
        Args:
            session: Активная сессия базы данных
            hours_threshold: Пороговое значение в часах для определения зависших выплат
            
        Returns:
            list: Список зависших выплат
        """
        try:
            # Вычисляем пороговую дату
            threshold_date = datetime.datetime.now() - datetime.timedelta(hours=hours_threshold)
            
            # Формируем запрос
            query = select(WeeklyPayout).where(
                and_(
                    WeeklyPayout.status.in_(["processing", "partial"]),
                    WeeklyPayout.updated_at <= threshold_date
                )
            )
            
            # Выполняем запрос
            try:
                result = await session.execute(query)
                stalled_payouts = result.scalars().all()
                return stalled_payouts
            except Exception as inner_e:
                if "sslmode" in str(inner_e):
                    # Получаем новую сессию БД без проблемного параметра sslmode
                    logger.warning("Обнаружена проблема с sslmode, создаем новую сессию")
                    session = await DBSessionManager.get_async_session()
                    result = await session.execute(query)
                    stalled_payouts = result.scalars().all()
                    return stalled_payouts
                else:
                    # Если проблема не в sslmode, пробрасываем исключение дальше
                    raise
        
        except Exception as e:
            logger.error(f"Ошибка при обнаружении зависших выплат: {e}", exc_info=True)
            return []
    
    @staticmethod
    async def detect_stalled_batch_payouts(session: AsyncSession, hours_threshold: int = 1) -> List[BatchPayout]:
        """
        Обнаружение зависших пакетных выплат
        
        Args:
            session: Активная сессия базы данных
            hours_threshold: Пороговое значение в часах для определения зависших выплат
            
        Returns:
            list: Список зависших пакетных выплат
        """
        try:
            # Вычисляем пороговую дату
            threshold_date = datetime.datetime.now() - datetime.timedelta(hours=hours_threshold)
            
            # Формируем запрос
            query = select(BatchPayout).where(
                and_(
                    BatchPayout.status == "processing",
                    BatchPayout.updated_at <= threshold_date
                )
            )
            
            # Выполняем запрос
            try:
                result = await session.execute(query)
                stalled_batches = result.scalars().all()
                return stalled_batches
            except Exception as inner_e:
                if "sslmode" in str(inner_e):
                    # Получаем новую сессию БД без проблемного параметра sslmode
                    logger.warning("Обнаружена проблема с sslmode, создаем новую сессию")
                    session = await DBSessionManager.get_async_session()
                    result = await session.execute(query)
                    stalled_batches = result.scalars().all()
                    return stalled_batches
                else:
                    # Если проблема не в sslmode, пробрасываем исключение дальше
                    raise
        
        except Exception as e:
            logger.error(f"Ошибка при обнаружении зависших пакетных выплат: {e}", exc_info=True)
            return []
    
    @staticmethod
    async def _send_recovery_notification(user_id: int, payout_id: int, transaction_ids: List[int], 
                                        is_batch: bool = False, notify_admin: bool = True) -> bool:
        """
        Отправляет уведомление о восстановлении платежа
        
        Args:
            user_id: ID пользователя для уведомления
            payout_id: ID восстановленной выплаты
            transaction_ids: Список восстановленных транзакций
            is_batch: Указывает, является ли выплата пакетной
            notify_admin: Отправлять ли уведомление администраторам
            
        Returns:
            bool: Успешность отправки
        """
        try:
            notification_service = RecoveryService._get_notification_service()
            if not notification_service:
                logger.warning("NotificationService не найден, уведомления о восстановлении не отправлены")
                return False
                
            # Формируем сообщение для пользователя
            payout_type = "пакетной выплаты" if is_batch else "выплаты"
            message = f"🔄 Автоматическое восстановление {payout_type} #{payout_id}\n\n"
            message += f"Система обнаружила и восстановила зависшую выплату. "
            message += f"Восстановлено транзакций: {len(transaction_ids)}."
            
            # Отправляем уведомление пользователю
            await notification_service.send_notification(
                user_id=user_id,
                message=message,
                notification_type=NotificationType.PAYMENT_RECOVERY,
                metadata={
                    "payout_id": payout_id,
                    "transaction_count": len(transaction_ids),
                    "is_batch": is_batch,
                    "recovered_at": datetime.datetime.now().isoformat()
                }
            )
            
            # Отправляем уведомление админам, если нужно
            if notify_admin:
                admin_message = f"🔄 Автоматическое восстановление {payout_type} #{payout_id}\n\n"
                admin_message += f"Пользователь ID: {user_id}\n"
                admin_message += f"Восстановленных транзакций: {len(transaction_ids)}\n\n"
                admin_message += f"Дата восстановления: {datetime.datetime.now().strftime('%d.%m.%Y %H:%M:%S')}"
                
                # Отправляем всем администраторам
                for admin_id in ADMIN_IDS:
                    if admin_id and admin_id != user_id:  # Не отправляем админу, если он же является получателем выплаты
                        await notification_service.send_notification(
                            user_id=admin_id,
                            message=admin_message,
                            notification_type=NotificationType.ADMIN_ALERT,
                            metadata={
                                "payout_id": payout_id,
                                "user_id": user_id,
                                "transaction_count": len(transaction_ids),
                                "is_batch": is_batch,
                                "recovered_at": datetime.datetime.now().isoformat()
                            }
                        )
            
            return True
        except Exception as e:
            logger.error(f"Ошибка при отправке уведомления о восстановлении: {str(e)}")
            return False
            
    @staticmethod
    async def recover_stalled_payout(session: AsyncSession, payout: WeeklyPayout, bot=None) -> Dict[str, Any]:
        """
        Восстановление зависшей выплаты
        
        Args:
            session: Активная сессия базы данных
            payout: Объект выплаты для восстановления
            bot: Объект бота для отправки уведомлений (опционально)
            
        Returns:
            dict: Результат восстановления
        """
        result = {
            "payout_id": payout.id,
            "status": "failed",
            "recovered_transactions": 0,
            "error": None
        }
        
        try:
            # Получаем все транзакции, связанные с выплатой
            query = select(Transaction).where(Transaction.payout_id == payout.id)
            result_transactions = await session.execute(query)
            transactions = result_transactions.scalars().all()
            
            # Получаем список обработанных транзакций
            processed_transactions = set(payout.processed_transactions or [])
            
            # Изменяем статус транзакций, которые не были обработаны
            recovered_count = 0
            
            for transaction in transactions:
                if transaction.id not in processed_transactions:
                    # Возвращаем транзакцию в статус "pending" для повторной обработки
                    transaction.status = "pending"
                    transaction.updated_at = datetime.datetime.now()
                    recovered_count += 1
            
            # Обновляем данные о выплате
            payout.status = "failed"
            payout.error_message = f"Выплата прервана и восстановлена. {recovered_count} транзакций возвращены в очередь."
            payout.updated_at = datetime.datetime.now()
            
            # Фиксируем изменения
            await session.commit()
            
            # Отправляем уведомление администраторам, если передан объект бота
            if bot:
                notification_service = NotificationService.get_instance(bot)
                # Отправляем уведомление всем администраторам
                for admin_id in ADMIN_IDS:
                    await notification_service.send_notification(
                        user_id=admin_id,
                        notification_type=NotificationType.RECOVERY_ATTEMPT,
                        context={
                            'transaction_id': str(payout.id),
                            'status': 'Восстановлено',
                            'reason': f"Восстановлено {recovered_count} из {len(transactions)} транзакций"
                        }
                    )
            
            # Обновляем результат
            result["status"] = "success"
            result["recovered_transactions"] = recovered_count
            
            logger.info(f"Восстановлена выплата #{payout.id}, {recovered_count} транзакций возвращены в очередь")
            
            # Отправляем уведомление через новый механизм уведомлений
            if payout.user_id:
                transaction_ids = [RecoveryService._safe_int_convert(t.id) for t in transactions if hasattr(t, 'id') and t.id not in processed_transactions]
                await RecoveryService._send_recovery_notification(
                    user_id=RecoveryService._safe_int_convert(payout.user_id), 
                    payout_id=RecoveryService._safe_int_convert(payout.id), 
                    transaction_ids=transaction_ids, 
                    is_batch=True
                )
            
            return result
        
        except Exception as e:
            await session.rollback()
            error_message = f"Ошибка при восстановлении выплаты #{payout.id}: {e}"
            logger.error(error_message, exc_info=True)
            
            result["error"] = error_message
            return result
    
    @staticmethod
    async def recover_stalled_batch_payout(session: AsyncSession, batch: BatchPayout, bot=None) -> Dict[str, Any]:
        """
        Восстановление зависшей пакетной выплаты
        
        Args:
            session: Активная сессия базы данных
            batch: Объект пакетной выплаты для восстановления
            bot: Объект бота для отправки уведомлений (опционально)
            
        Returns:
            dict: Результат восстановления
        """
        result = {
            "batch_id": batch.id,
            "payout_id": batch.weekly_payout_id,
            "status": "failed",
            "recovered_transactions": 0,
            "error": None
        }
        
        try:
            # Получаем все транзакции, связанные с пакетной выплатой
            transactions = batch.transactions
            
            # Изменяем статус всех транзакций на "pending"
            for transaction in transactions:
                transaction.status = "pending"
                transaction.updated_at = datetime.datetime.now()
            
            # Обновляем данные о пакетной выплате
            batch.status = "failed"
            batch.error_message = f"Пакетная выплата прервана и восстановлена. {len(transactions)} транзакций возвращены в очередь."
            batch.updated_at = datetime.datetime.now()
            
            # Фиксируем изменения
            await session.commit()
            
            # Отправляем уведомление администраторам, если передан объект бота
            if bot:
                notification_service = NotificationService.get_instance(bot)
                # Отправляем уведомление всем администраторам
                for admin_id in ADMIN_IDS:
                    await notification_service.send_notification(
                        user_id=admin_id,
                        notification_type=NotificationType.RECOVERY_ATTEMPT,
                        context={
                            'transaction_id': f"Batch-{batch.id}",
                            'status': 'Восстановлено',
                            'reason': f"Восстановлено {len(transactions)} транзакций в пакете уровня {batch.tier_name}"
                        }
                    )
            
            # Обновляем результат
            result["status"] = "success"
            result["recovered_transactions"] = len(transactions)
            
            logger.info(f"Восстановлена пакетная выплата #{batch.id} (выплата #{batch.weekly_payout_id}), "
                       f"{len(transactions)} транзакций возвращены в очередь")
            
            # Отправляем уведомления пользователям через новый механизм уведомлений
            # Группируем транзакции по пользователям
            user_transactions = {}
            for transaction in transactions:
                if hasattr(transaction, 'user_id') and transaction.user_id:
                    if transaction.user_id not in user_transactions:
                        user_transactions[transaction.user_id] = []
                    user_transactions[transaction.user_id].append(transaction.id)
            
            # Отправляем уведомление каждому пользователю
            for user_id, transaction_ids in user_transactions.items():
                try:
                    await RecoveryService._send_recovery_notification(
                        user_id=RecoveryService._safe_int_convert(user_id),
                        payout_id=RecoveryService._safe_int_convert(batch.id),
                        transaction_ids=[RecoveryService._safe_int_convert(tx_id) for tx_id in transaction_ids],
                        is_batch=True
                    )
                    logger.info(f"Отправлено уведомление пользователю {user_id} о восстановлении {len(transaction_ids)} транзакций в пакетной выплате #{batch.id}")
                except Exception as e:
                    logger.error(f"Ошибка при отправке уведомления пользователю {user_id}: {e}")
            
            return result
        
        except Exception as e:
            await session.rollback()
            error_message = f"Ошибка при восстановлении пакетной выплаты #{batch.id}: {e}"
            logger.error(error_message, exc_info=True)
            
            result["error"] = error_message
            return result
    
    @staticmethod
    async def recover_pending_payments(session: AsyncSession = None, bot=None) -> Dict[str, Any]:
        """
        Восстанавливает незавершенные платежи, используя унифицированную платежную систему
        
        Args:
            session: Существующая сессия SQLAlchemy (опционально)
            bot: Объект бота для отправки уведомлений (опционально)
            
        Returns:
            Dict: Результаты восстановления платежей
        """
        # Инициализируем результаты восстановления
        results = {
            "total_transactions": 0,
            "recovered": 0,
            "failed": 0,
            "skipped": 0,
            "details": []
        }
        
        # Получаем сервис уведомлений
        notification_service = RecoveryService._get_notification_service()
        
        # Используем контекстный менеджер сессии, если она не была предоставлена
        session_mgr = None
        if session is None:
            session_mgr = DBSessionManager()
            session = await session_mgr.get_session()
        
        try:
            # Находим все транзакции в статусе "pending" или "processing", которые были созданы более часа назад
            time_threshold = datetime.datetime.now() - datetime.timedelta(hours=1)
            
            stalled_transactions_stmt = select(Transaction).where(
                and_(
                    or_(
                        Transaction.status == "pending",
                        Transaction.status == "processing",
                    ),
                    Transaction.created_at < time_threshold,
                    Transaction.transaction_type.in_(["payment", "subscription"])
                )
            )
            
            stalled_transactions = await session.execute(stalled_transactions_stmt)
            stalled_transactions = stalled_transactions.scalars().all()
            
            results["total_transactions"] = len(stalled_transactions)
            logger.info(f"Найдено {len(stalled_transactions)} незавершенных платежей для восстановления")
            
            # Обрабатываем каждую транзакцию
            for transaction in stalled_transactions:
                transaction_detail = {
                    "transaction_id": transaction.id,
                    "user_id": transaction.user_id,
                    "amount": transaction.amount,
                    "created_at": transaction.created_at.isoformat() if transaction.created_at else None,
                    "status": transaction.status,
                    "result": "skipped"
                }
                
                try:
                    # Проверяем, есть ли данные платежа
                    payment_data = transaction.payment_data
                    if not payment_data:
                        transaction_detail["result"] = "skipped"
                        transaction_detail["reason"] = "no_payment_data"
                        results["skipped"] += 1
                        results["details"].append(transaction_detail)
                        continue
                    
                    # Определяем платежную систему на основе данных транзакции
                    payment_system = None
                    if "robokassa" in str(payment_data).lower():
                        payment_system = PaymentSystem.ROBOKASSA
                        system_id = PAYMENT_SYSTEMS['ROBOKASSA']
                    elif "sbp" in str(payment_data).lower():
                        payment_system = PaymentSystem.SBP
                        system_id = PAYMENT_SYSTEMS['SBP_LINK']
                    elif "yoomoney" in str(payment_data).lower():
                        payment_system = PaymentSystem.YOOMONEY
                        system_id = PAYMENT_SYSTEMS['YOOMONEY']
                    else:
                        transaction_detail["result"] = "skipped"
                        transaction_detail["reason"] = "unknown_payment_system"
                        results["skipped"] += 1
                        results["details"].append(transaction_detail)
                        continue
                    
                    # Пытаемся верифицировать платеж с использованием унифицированного сервиса
                    verification_result = payment_verification_service_v2.verify_payment_by_transaction(
                        transaction_id=transaction.id,
                        payment_system=system_id
                    )
                    
                    # Если верификация успешна, обрабатываем платеж
                    if verification_result.success:
                        processing_result = payment_verification_service_v2.process_payment(verification_result)
                        
                        if processing_result.success:
                            transaction_detail["result"] = "recovered"
                            transaction_detail["message"] = f"Платеж успешно восстановлен: {processing_result.message}"
                            results["recovered"] += 1
                            
                            # Отправляем уведомление пользователю
                            if notification_service:
                                try:
                                    await notification_service.send_payment_recovery_notification(
                                        user_id=transaction.user_id,
                                        transaction_id=transaction.id,
                                        successful=True,
                                        details=transaction_detail
                                    )
                                except Exception as notify_err:
                                    logger.error(f"Ошибка при отправке уведомления о восстановлении платежа: {notify_err}")
                        else:
                            transaction_detail["result"] = "failed"
                            transaction_detail["message"] = f"Ошибка обработки платежа: {processing_result.message}"
                            results["failed"] += 1
                    else:
                        # Если верификация не удалась, возвращаем транзакцию в статус "pending" для повторной обработки
                        transaction.status = "pending"
                        transaction.updated_at = datetime.datetime.now()
                        await session.commit()
                        
                        transaction_detail["result"] = "retried"
                        transaction_detail["message"] = f"Ошибка верификации, платеж помечен для повторной обработки: {verification_result.message}"
                        results["failed"] += 1
                        
                        # Отправляем уведомление администратору
                        if notification_service:
                            try:
                                await notification_service.send_payment_recovery_notification(
                                    user_id=transaction.user_id,
                                    transaction_id=transaction.id,
                                    successful=False,
                                    details=transaction_detail,
                                    admin_ids=ADMIN_IDS
                                )
                            except Exception as notify_err:
                                logger.error(f"Ошибка при отправке уведомления администратору: {notify_err}")
                
                except Exception as e:
                    logger.error(f"Ошибка при восстановлении платежа {transaction.id}: {str(e)}", exc_info=True)
                    transaction_detail["result"] = "error"
                    transaction_detail["message"] = str(e)
                    results["failed"] += 1
                
                # Добавляем результат обработки в детали
                results["details"].append(transaction_detail)
            
            # Фиксируем изменения в базе данных
            await session.commit()
            
            # Логируем итоговый результат
            logger.info(f"Результаты восстановления платежей: всего={results['total_transactions']}, "
                       f"восстановлено={results['recovered']}, неудачно={results['failed']}, пропущено={results['skipped']}")
            
            # Возвращаем результаты
            return results
            
        except Exception as e:
            logger.error(f"Ошибка при восстановлении незавершенных платежей: {str(e)}", exc_info=True)
            if session_mgr:
                await session.rollback()
            raise
        
        finally:
            # Закрываем сессию, если она была создана в этом методе
            if session_mgr:
                await session_mgr.close()
    
    @staticmethod
    async def recover_all_stalled_payouts(bot=None) -> Dict[str, Any]:
        """
        Восстановление всех зависших выплат
        
        Args:
            bot: Объект бота для отправки уведомлений (опционально)
            
        Returns:
            dict: Результат восстановления
        """
        result = {
            "payouts": {
                "total": 0,
                "recovered": 0,
                "failed": 0,
                "recovered_transactions": 0
            },
            "batches": {
                "total": 0,
                "recovered": 0,
                "failed": 0,
                "recovered_transactions": 0
            }
        }
        
        try:
            # Создаем асинхронную сессию напрямую вместо использования контекстного менеджера
            async_session = None
            try:
                logger.info("Создание асинхронной сессии для восстановления выплат")
                async_session = await DBSessionManager.get_async_session()
                logger.info("Сессия успешно создана")
                
                # Восстанавливаем зависшие выплаты
                stalled_payouts = await RecoveryService.detect_stalled_payouts(async_session)
                result["payouts"]["total"] = len(stalled_payouts)
                logger.info(f"Обнаружено {len(stalled_payouts)} зависших выплат")
                
                for payout in stalled_payouts:
                    recovery_result = await RecoveryService.recover_stalled_payout(async_session, payout, bot)
                    
                    if recovery_result["status"] == "success":
                        result["payouts"]["recovered"] += 1
                        result["payouts"]["recovered_transactions"] += recovery_result["recovered_transactions"]
                    else:
                        result["payouts"]["failed"] += 1
                
                # Восстанавливаем зависшие пакетные выплаты
                stalled_batches = await RecoveryService.detect_stalled_batch_payouts(async_session)
                result["batches"]["total"] = len(stalled_batches)
                logger.info(f"Обнаружено {len(stalled_batches)} зависших пакетных выплат")
                
                for batch in stalled_batches:
                    recovery_result = await RecoveryService.recover_stalled_batch_payout(async_session, batch, bot)
                    
                    if recovery_result["status"] == "success":
                        result["batches"]["recovered"] += 1
                        result["batches"]["recovered_transactions"] += recovery_result["recovered_transactions"]
                    else:
                        result["batches"]["failed"] += 1
                
                # Фиксируем изменения
                await async_session.commit()
                logger.info("Изменения зафиксированы в базе данных")
                
            except Exception as session_error:
                logger.error(f"Ошибка в процессе восстановления выплат: {session_error}", exc_info=True)
                if async_session:
                    try:
                        await async_session.rollback()
                        logger.info("Выполнен откат транзакции")
                    except Exception as rollback_error:
                        logger.error(f"Ошибка при откате транзакции: {rollback_error}", exc_info=True)
                raise
            finally:
                if async_session:
                    try:
                        await async_session.close()
                        logger.info("Сессия закрыта")
                    except Exception as close_error:
                        logger.error(f"Ошибка при закрытии сессии: {close_error}", exc_info=True)
            
            # Отправляем сводное уведомление администраторам, если восстановлены какие-либо выплаты
            if bot and (result["payouts"]["recovered"] > 0 or result["batches"]["recovered"] > 0):
                try:
                    notification_service = NotificationService.get_instance(bot)
                    # Создаем текст уведомления
                    summary_message = (
                        f"🔄 *Восстановление выплат: итоги*\n\n"
                        f"📊 *Выплаты*:\n"
                        f"- Всего: {result['payouts']['total']}\n"
                        f"- Восстановлено: {result['payouts']['recovered']}\n"
                        f"- Ошибок: {result['payouts']['failed']}\n"
                        f"- Транзакций восстановлено: {result['payouts']['recovered_transactions']}\n\n"
                        f"📦 *Пакетные выплаты*:\n"
                        f"- Всего: {result['batches']['total']}\n"
                        f"- Восстановлено: {result['batches']['recovered']}\n"
                        f"- Ошибок: {result['batches']['failed']}\n"
                        f"- Транзакций восстановлено: {result['batches']['recovered_transactions']}"
                    )
                    
                    # Отправляем уведомление всем администраторам
                    for admin_id in ADMIN_IDS:
                        try:
                            await notification_service.send_notification(
                                user_id=admin_id,
                                notification_type=NotificationType.SYSTEM,
                                context={'message': summary_message}
                            )
                            logger.info(f"Отправлено уведомление администратору {admin_id} об итогах восстановления")
                        except Exception as admin_notify_error:
                            logger.error(f"Ошибка при отправке уведомления администратору {admin_id}: {admin_notify_error}")
                except Exception as notification_error:
                    logger.error(f"Ошибка при инициализации сервиса уведомлений: {notification_error}")
            
            return result
        
        except Exception as e:
            error_message = f"Ошибка при восстановлении зависших выплат: {e}"
            logger.error(error_message, exc_info=True)
            
            if bot:
                try:
                    notification_service = NotificationService.get_instance(bot)
                    error_text = f"❌ *Ошибка при восстановлении выплат*\n\n{error_message}"
                    
                    # Отправляем уведомление всем администраторам
                    for admin_id in ADMIN_IDS:
                        try:
                            await notification_service.send_notification(
                                user_id=admin_id,
                                notification_type=NotificationType.SYSTEM,
                                context={'message': error_text}
                            )
                        except Exception as admin_notify_error:
                            logger.error(f"Ошибка при отправке уведомления об ошибке администратору {admin_id}: {admin_notify_error}")
                except Exception as notify_error:
                    logger.error(f"Ошибка при отправке уведомления об ошибке: {notify_error}")
            
            return result
    
    @staticmethod
    async def add_recovery_check_to_scheduler(scheduler, bot):
        """
        Добавление задачи проверки и восстановления выплат и платежей в планировщик
        
        Args:
            scheduler: Объект планировщика задач
            bot: Объект бота для отправки уведомлений
        """
        async def scheduled_recovery_check():
            """Задача для планировщика"""
            start_time = datetime.datetime.now()
            task_id = f"recovery-{start_time.strftime('%Y%m%d%H%M%S')}"
            
            try:
                logger.info(f"[{task_id}] Запущена плановая проверка и восстановление платежей и выплат")
                
                # Восстановление незавершенных платежей
                payment_recovery_start = datetime.datetime.now()
                logger.info(f"[{task_id}] Начинаем восстановление незавершенных платежей")
                
                try:
                    payment_result = await RecoveryService.recover_pending_payments(bot=bot)
                    
                    payment_recovery_end = datetime.datetime.now()
                    payment_duration = (payment_recovery_end - payment_recovery_start).total_seconds()
                    
                    payments_total = payment_result.get("total_transactions", 0)
                    payments_recovered = payment_result.get("recovered", 0)
                    payments_failed = payment_result.get("failed", 0)
                    payments_skipped = payment_result.get("skipped", 0)
                    
                    logger.info(f"[{task_id}] Результаты восстановления платежей (за {payment_duration:.2f}с): "
                              f"всего={payments_total}, "
                              f"восстановлено={payments_recovered}, "
                              f"неудачно={payments_failed}, "
                              f"пропущено={payments_skipped}")
                except Exception as e:
                    logger.error(f"[{task_id}] Ошибка при восстановлении платежей: {str(e)}", exc_info=True)
                
                # Восстановление зависших выплат
                logger.info(f"[{task_id}] Начинаем восстановление зависших выплат")
                result = await RecoveryService.recover_all_stalled_payouts(bot)
                
                # Логируем результаты восстановления выплат
                end_time = datetime.datetime.now()
                duration = (end_time - start_time).total_seconds()
                
                payouts_total = result.get("payouts", {}).get("total", 0)
                payouts_recovered = result.get("payouts", {}).get("recovered", 0)
                batches_recovered = result.get("batches", {}).get("recovered", 0)
                
                logger.info(f"[{task_id}] Плановое восстановление завершено за {duration:.2f} сек. "
                           f"Проверено выплат: {payouts_total}, восстановлено: {payouts_recovered}+{batches_recovered}")
                
                # Отправляем уведомление только если были восстановлены выплаты
                if payouts_recovered > 0 or batches_recovered > 0:
                    # В случае успешного восстановления отправляем уведомление администраторам
                    try:
                        notification_service = NotificationService.get_instance(bot)
                        msg = (
                            f"🔄 *Плановое восстановление выплат*\n\n"
                            f"Время выполнения: {duration:.2f} сек.\n"
                            f"Проверено выплат: {payouts_total}\n"
                            f"Восстановлено выплат: {payouts_recovered}\n"
                            f"Восстановлено пакетных выплат: {batches_recovered}\n\n"
                            f"ID задачи: {task_id}"
                        )
                        
                        # Отправляем уведомление всем администраторам через групповую отправку
                        await notification_service.notify_admin_group(
                            message=msg,
                            notification_type=NotificationType.SYSTEM,
                            parse_mode="Markdown"
                        )
                    except Exception as e:
                        logger.error(f"[{task_id}] Ошибка отправки уведомлений администраторам: {e}")
            
            except Exception as e:
                # В случае ошибки логируем её и отправляем уведомление администраторам
                error_time = datetime.datetime.now()
                duration = (error_time - start_time).total_seconds()
                
                logger.error(f"[{task_id}] Ошибка при плановом восстановлении выплат через {duration:.2f} сек: {e}", 
                             exc_info=True)
                
                try:
                    if bot:
                        notification_service = NotificationService.get_instance(bot)
                        error_msg = (
                            f"❌ *Ошибка планового восстановления выплат*\n\n"
                            f"Время: {error_time}\n"
                            f"ID задачи: {task_id}\n"
                            f"Тип ошибки: {type(e).__name__}\n"
                            f"Сообщение: {str(e)}"
                        )
                        
                        for admin_id in ADMIN_IDS:
                            try:
                                await notification_service.send_notification(
                                    user_id=admin_id,
                                    notification_type=NotificationType.ERROR,
                                    context={'message': error_msg}
                                )
                            except Exception as notify_error:
                                logger.error(f"[{task_id}] Ошибка отправки уведомления об ошибке администратору {admin_id}: {notify_error}")
                except Exception as notify_error:
                    logger.error(f"[{task_id}] Критическая ошибка при отправке уведомления об ошибке: {notify_error}")
        
        # Добавляем задачу в планировщик
        scheduler.add_job(
            scheduled_recovery_check,
            'interval',
            hours=3,
            id='recovery_check',
            replace_existing=True,
            misfire_grace_time=300  # 5 минут допуска для запуска пропущенных задач
        )
        
        logger.info("Добавлена задача восстановления выплат в планировщик (каждые 3 часа, grace_time=5 мин.)")


# Функция для ручного запуска восстановления
async def manual_recovery(bot=None):
    """
    Ручной запуск процесса восстановления выплат и незавершенных платежей
    
    Args:
        bot: Объект бота для отправки уведомлений (опционально)
        
    Returns:
        dict: Результат восстановления
    """
    start_time = datetime.datetime.now()
    logger.info(f"[{start_time}] Запущен процесс ручного восстановления выплат и платежей")
    
    if bot:
        logger.info("Объект bot передан для отправки уведомлений")
    else:
        logger.warning("Объект bot не передан, уведомления не будут отправляться")
    
    try:
        # Запускаем восстановление незавершенных платежей
        logger.info("Начинаем восстановление незавершенных платежей")
        payment_recovery_result = await RecoveryService.recover_pending_payments(bot=bot)
        logger.info(f"Результаты восстановления платежей: всего={payment_recovery_result['total_transactions']}, "
                  f"восстановлено={payment_recovery_result['recovered']}, "
                  f"неудачно={payment_recovery_result['failed']}, "
                  f"пропущено={payment_recovery_result['skipped']}")
                  
        # Продолжаем с восстановлением выплат
        # Вызываем метод восстановления выплат
        logger.info("Вызов метода RecoveryService.recover_all_stalled_payouts")
        result = await RecoveryService.recover_all_stalled_payouts(bot)
        
        # Логируем результат
        end_time = datetime.datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        logger.info(f"Процесс ручного восстановления выплат успешно завершен за {duration:.2f} секунд")
        logger.info(f"Результаты восстановления: "
                   f"обработано выплат - {result['payouts']['total']}, "
                   f"восстановлено выплат - {result['payouts']['recovered']}, "
                   f"восстановлено пакетов - {result['batches']['recovered']}")
        
        return result
        
    except Exception as recovery_error:
        # Детальное логирование ошибки
        error_time = datetime.datetime.now()
        duration = (error_time - start_time).total_seconds()
        error_message = f"Ошибка при ручном восстановлении выплат через {duration:.2f} секунд: {recovery_error}"
        
        logger.error(error_message, exc_info=True)
        logger.error(f"Тип ошибки: {type(recovery_error).__name__}")
        
        # В случае ошибки возвращаем базовый результат с информацией об ошибке
        error_result = {
            "payouts": {"total": 0, "recovered": 0, "failed": 0, "recovered_transactions": 0},
            "batches": {"total": 0, "recovered": 0, "failed": 0, "recovered_transactions": 0},
            "error": error_message,
            "status": "failed",
            "error_type": type(recovery_error).__name__,
            "timestamp": str(error_time)
        }
        
        # Если это объект бота, пробуем отправить уведомление об ошибке администратору
        if bot:
            try:
                # Создаем сервис уведомлений
                notification_service = NotificationService.get_instance(bot)
                error_details = f"❌ *Критическая ошибка при восстановлении выплат*\n\n" \
                              f"Тип ошибки: {type(recovery_error).__name__}\n" \
                              f"Сообщение: {str(recovery_error)}\n\n" \
                              f"Время: {error_time}"
                
                # Отправляем уведомление администраторам
                for admin_id in ADMIN_IDS:
                    try:
                        await notification_service.send_notification(
                            user_id=admin_id,
                            notification_type=NotificationType.ERROR,
                            context={'message': error_details}
                        )
                        logger.info(f"Отправлено уведомление об ошибке администратору {admin_id}")
                    except Exception as notify_error:
                        logger.error(f"Ошибка при отправке уведомления об ошибке администратору {admin_id}: {notify_error}")
            except Exception as notification_error:
                logger.error(f"Не удалось отправить уведомление об ошибке: {notification_error}")
        
        return error_result