#!/usr/bin/env python
# coding: utf-8

"""
Сервис для хранения метаданных и настроек для различных платформ
"""

import logging
from typing import Dict, Any, List, Optional, Tuple, Union

# Получаем константы из модуля platform_detection_service
from services.platform_detection_service import (
    PLATFORM_IOS, PLATFORM_ANDROID, PLATFORM_DESKTOP, 
    PLATFORM_UNKNOWN, PLATFORM_WEB
)

# Настройка логгера
logger = logging.getLogger(__name__)

# Карта оптимальных настроек для каждой платформы
PLATFORM_SETTINGS = {
    # iOS настройки
    PLATFORM_IOS: {
        # AI модели
        "ai_models": {
            "primary": "gpt-4o",  # Используем более стабильную модель для iOS
            "fallback": "gpt-4o",
            "temperature": 0.5,  # Более консервативное значение
            "max_tokens": 2000,  # Уменьшенный лимит для экономии трафика
            "supports_streaming": False,  # Отключаем стриминг на iOS
        },
        # Настройки QR-кодов
        "qr_code": {
            "size": 300,  # Размер в пикселях
            "border": 4,  # Размер рамки
            "box_size": 10,  # Размер элемента QR-кода
            "error_correction": "H",  # Высокая коррекция ошибок для iOS
            "image_format": "PNG",  # Формат PNG лучше поддерживается
        },
        # Форматирование сообщений
        "message_format": {
            "preferred": "HTML",  # HTML лучше поддерживается на iOS
            "emoji_set": "compatible",  # Ограниченный набор эмодзи
            "max_length": 4000,  # Ограничение длины сообщения
        },
        # Настройки клавиатуры
        "keyboard": {
            "max_buttons_per_row": 2,  # Ограничиваем количество кнопок в ряду
            "button_width": "wide",  # Широкие кнопки для лучшего нажатия
        },
        # Настройки платежей
        "payment": {
            "preferred_method": "redirect",  # Способ оплаты
            "robokassa_mobile_param": "true",  # Параметр для Робокассы
        },
        # Версии iOS с особыми настройками
        "version_specific": {
            "13": {
                "ai_models": {"primary": "gpt-4o", "fallback": "gpt-4o"},
                "message_format": {"max_length": 3000},
            },
            "14": {
                "ai_models": {"primary": "gpt-4o", "fallback": "gpt-4o"},
            },
            "15": {
                "qr_code": {"size": 350},
            },
        }
    },
    
    # Android настройки
    PLATFORM_ANDROID: {
        # AI модели
        "ai_models": {
            "primary": "deepseek-chat",  # Основная модель
            "fallback": "gpt-4o",  # Запасная модель
            "temperature": 0.7,
            "max_tokens": 2500,
            "supports_streaming": True,  # Android лучше поддерживает стриминг
        },
        # Настройки QR-кодов
        "qr_code": {
            "size": 400,  # Больший размер для Android
            "border": 3,
            "box_size": 12,
            "error_correction": "M",  # Средняя коррекция ошибок
            "image_format": "PNG",
        },
        # Форматирование сообщений
        "message_format": {
            "preferred": "MarkdownV2",  # Android лучше поддерживает Markdown
            "emoji_set": "full",  # Полная поддержка эмодзи
            "max_length": 4096,
        },
        # Настройки клавиатуры
        "keyboard": {
            "max_buttons_per_row": 3,
            "button_width": "normal",
        },
        # Настройки платежей
        "payment": {
            "preferred_method": "all",  # Поддерживаются все методы
            "robokassa_mobile_param": "true",
        },
        # Настройки для конкретных версий
        "version_specific": {
            "8": {
                "message_format": {"preferred": "HTML"},
            },
            "10": {
                "qr_code": {"size": 450},
            }
        }
    },
    
    # Desktop настройки
    PLATFORM_DESKTOP: {
        # AI модели
        "ai_models": {
            "primary": "deepseek-chat",
            "fallback": "gpt-4o",
            "temperature": 0.7,
            "max_tokens": 3000,  # Больше токенов для десктопа
            "supports_streaming": True,
        },
        # Настройки QR-кодов
        "qr_code": {
            "size": 450,  # Большие QR-коды для десктопа
            "border": 2,
            "box_size": 15,
            "error_correction": "M",
            "image_format": "PNG",
        },
        # Форматирование сообщений
        "message_format": {
            "preferred": "HTML",  # HTML для лучшей совместимости
            "emoji_set": "full",
            "max_length": 4096,
        },
        # Настройки клавиатуры
        "keyboard": {
            "max_buttons_per_row": 4,  # Больше кнопок в ряду
            "button_width": "auto",  # Автоматическая ширина
        },
        # Настройки платежей
        "payment": {
            "preferred_method": "all",
            "robokassa_mobile_param": "false",  # Не мобильное устройство
        }
    },
    
    # Web-клиент
    PLATFORM_WEB: {
        # AI модели
        "ai_models": {
            "primary": "deepseek-chat",
            "fallback": "gpt-4o",
            "temperature": 0.7,
            "max_tokens": 2500,
            "supports_streaming": True,
        },
        # Настройки платежей удалены
        # Форматирование сообщений
        "message_format": {
            "preferred": "HTML",
            "emoji_set": "full",
            "max_length": 4096,
        },
        # Настройки клавиатуры
        "keyboard": {
            "max_buttons_per_row": 3,
            "button_width": "normal",
        },
        # Настройки платежей
        "payment": {
            "preferred_method": "all",
            "robokassa_mobile_param": "false",
        }
    },
    
    # Неизвестная платформа (значения по умолчанию)
    PLATFORM_UNKNOWN: {
        # AI модели
        "ai_models": {
            "primary": "gpt-4o",  # Самая стабильная модель для неизвестных платформ
            "fallback": "gpt-4o",
            "temperature": 0.5,
            "max_tokens": 2000,
            "supports_streaming": False,
        },
        # Настройки QR-кодов удалены
        # Форматирование сообщений
        "message_format": {
            "preferred": "HTML",  # HTML для лучшей совместимости
            "emoji_set": "compatible",
            "max_length": 3000,
        },
        # Настройки клавиатуры
        "keyboard": {
            "max_buttons_per_row": 2,
            "button_width": "wide",  # Широкие кнопки для лучшей совместимости
        },
        # Настройки платежей
        "payment": {
            "preferred_method": "redirect",
            "robokassa_mobile_param": "true",  # Предполагаем мобильное устройство
        }
    }
}

# Карта совместимости эмодзи для различных платформ
EMOJI_COMPATIBILITY = {
    # Базовый набор эмодзи, который гарантированно работает на всех платформах
    "basic": {
        # Основные эмодзи с высокой совместимостью
        "success": "✓",
        "warning": "!",
        "error": "×",
        "info": "i",
        "money": "$",
        "calendar": "[календарь]",
        "person": "[профиль]",
        "lock": "[закрыто]",
        "unlock": "[открыто]",
        "star": "*",
        "smile": ":)",
        "thinking": "?",
        "math": "[задача]",
        "subscription": "[подписка]",
        "referral": "[друг]",
        "payment": "[оплата]",
        "time": "[время]",
        "pencil": "[задача]",
        "check": "[проверить]",
        "bank": "[банк]",
        "card": "[карта]",
        "help": "[помощь]",
    },
    # Совместимый набор для большинства платформ, включая старые устройства
    "compatible": {
        # Эмодзи, которые хорошо работают на всех платформах
        "success": "✅",
        "warning": "⚠️",
        "error": "❌",
        "info": "ℹ️",
        "money": "💰",
        "calendar": "📆",
        "person": "👤",
        "lock": "🔒",
        "unlock": "🔓",
        "star": "⭐",
        "smile": "😊",
        "thinking": "🤔",
        "math": "🧮",
        "subscription": "📱",
        "referral": "👥",
        "payment": "💳",
        "time": "⏱️",
        "pencil": "📝",
        "check": "✓",
        # Платежные эмодзи
        "bank": "🏦",
        "card": "💳",
        "help": "❓",
        # Дополнительные совместимые эмодзи
        "question": "❓",
        "envelope": "✉️",
        "key": "🔑",
        "bell": "🔔",
        "search": "🔍",
        "list": "📋",
        "number": "#️⃣",
        "check_mark": "✔️",
        "cross_mark": "✖️",
    },
    # Расширенный набор для современных платформ
    "full": {
        # Расширенный набор эмодзи для современных платформ
        "success": "✅",
        "warning": "⚠️",
        "error": "❌",
        "info": "ℹ️",
        "money": "💰",
        "calendar": "📆",
        "person": "👤",
        "lock": "🔒",
        "unlock": "🔓",
        "star": "⭐",
        "smile": "😊",
        "thinking": "🤔",
        "math": "🧮",
        "subscription": "📱",
        "referral": "👥",
        "payment": "💳",
        "time": "⏱️",
        "pencil": "📝",
        "check": "✓",
        # Платежные эмодзи
        "bank": "🏦",
        "card": "💳", 
        "help": "❔",
        # Дополнительные эмодзи
        "party": "🎉",
        "rocket": "🚀",
        "gift": "🎁",
        "chart": "📊",
        "fire": "🔥",
        "medal": "🏅",
        "heart": "❤️",
        "thumbs_up": "👍",
        "thumbs_down": "👎",
        "magnifier": "🔍",
        "bulb": "💡",
        "book": "📚",
        "faq": "❓",
        "coin": "🪙",
        "robot": "🤖",
        "crown": "👑",
        "bell": "🔔",
        "graph": "📈",
        "notes": "📋",
        "calculator": "🧮",
        "brain": "🧠",
        "university": "🏫",
        "graduation": "🎓",
        "professor": "👨‍🏫",
        "magic": "✨",
        "crystal_ball": "🔮",
        "tools": "🛠️",
        "gear": "⚙️",
        "light_bulb": "💡",
        "maths": "➗",
        "plus": "➕",
        "minus": "➖",
        "multiply": "✖️",
        "divide": "➗",
        "infinity": "♾️",
        "check_mark": "✔️",
        "cross_mark": "✖️",
    },
    # Специальные настройки для iOS
    "ios": {
        # iOS-совместимые эмодзи (консервативный набор)
        "success": "✅",
        "warning": "⚠️",
        "error": "❌",
        "info": "ℹ️",
        "money": "💰",
        "calendar": "📆",
        "person": "👤",
        "lock": "🔒",
        "unlock": "🔓",
        "star": "⭐",
        "smile": "😊",
        "thinking": "🤔",
        "math": "📝",  # Более простой символ для iOS
        "subscription": "📱",
        "referral": "👤",  # Более простой символ для iOS
        "payment": "💳",
        "time": "⏱️",
        "pencil": "📝",
        "check": "✓",
    },
    # Специальные настройки для Android
    "android": {
        # Эмодзи, оптимизированные для Android
        "success": "✅",
        "warning": "⚠️",
        "error": "❌",
        "info": "ℹ️",
        "money": "💰",
        "calendar": "📆",
        "person": "👤",
        "lock": "🔒",
        "unlock": "🔓",
        "star": "⭐",
        "smile": "😊",
        "thinking": "🤔",
        "math": "🧮",
        "subscription": "📱",
        "referral": "👥",
        "payment": "💳",
        "time": "⏱️",
        "pencil": "📝",
        "check": "✓",
    }
}


def get_platform_settings(platform_type: str, platform_version: Optional[str] = None) -> Dict[str, Any]:
    """
    Получает настройки для конкретной платформы с учетом версии
    
    Args:
        platform_type: Тип платформы (ios, android, desktop, web, unknown)
        platform_version: Версия платформы (например, "14.2" для iOS)
        
    Returns:
        Dict[str, Any]: Словарь с настройками для платформы
    """
    # Если платформа неизвестна или не поддерживается, возвращаем настройки по умолчанию
    if platform_type not in PLATFORM_SETTINGS:
        platform_type = PLATFORM_UNKNOWN
    
    # Получаем базовые настройки для платформы
    settings = PLATFORM_SETTINGS[platform_type].copy()
    
    # Если указана версия и у платформы есть особые настройки для этой версии
    if platform_version and "version_specific" in settings:
        # Определяем основной номер версии (например, "14" из "14.2")
        major_version = platform_version.split('.')[0] if '.' in platform_version else platform_version
        
        # Если есть особые настройки для этой версии
        if major_version in settings["version_specific"]:
            version_settings = settings["version_specific"][major_version]
            
            # Объединяем настройки версии с базовыми настройками
            for category, category_settings in version_settings.items():
                if category in settings:
                    # Обновляем только указанные параметры категории
                    settings[category].update(category_settings)
    
    # Удаляем служебную информацию о версиях из возвращаемых настроек
    if "version_specific" in settings:
        del settings["version_specific"]
    
    return settings


def get_ai_model_settings(platform_type: str, platform_version: Optional[str] = None) -> Dict[str, Any]:
    """
    Получает настройки AI моделей для конкретной платформы
    
    Args:
        platform_type: Тип платформы
        platform_version: Версия платформы
        
    Returns:
        Dict[str, Any]: Настройки AI моделей
    """
    settings = get_platform_settings(platform_type, platform_version)
    return settings.get("ai_models", PLATFORM_SETTINGS[PLATFORM_UNKNOWN]["ai_models"])


# Функция get_qr_code_settings удалена, так как функциональность QR-кодов больше не используется


def get_message_format_settings(platform_type: str, platform_version: Optional[str] = None) -> Dict[str, Any]:
    """
    Получает настройки форматирования сообщений для конкретной платформы
    
    Args:
        platform_type: Тип платформы
        platform_version: Версия платформы
        
    Returns:
        Dict[str, Any]: Настройки форматирования сообщений
    """
    settings = get_platform_settings(platform_type, platform_version)
    return settings.get("message_format", PLATFORM_SETTINGS[PLATFORM_UNKNOWN]["message_format"])


def get_keyboard_settings(platform_type: str, platform_version: Optional[str] = None) -> Dict[str, Any]:
    """
    Получает настройки клавиатуры для конкретной платформы
    
    Args:
        platform_type: Тип платформы
        platform_version: Версия платформы
        
    Returns:
        Dict[str, Any]: Настройки клавиатуры
    """
    settings = get_platform_settings(platform_type, platform_version)
    return settings.get("keyboard", PLATFORM_SETTINGS[PLATFORM_UNKNOWN]["keyboard"])


def get_payment_settings(platform_type: str, platform_version: Optional[str] = None) -> Dict[str, Any]:
    """
    Получает настройки платежей для конкретной платформы
    
    Args:
        platform_type: Тип платформы
        platform_version: Версия платформы
        
    Returns:
        Dict[str, Any]: Настройки платежей
    """
    settings = get_platform_settings(platform_type, platform_version)
    return settings.get("payment", PLATFORM_SETTINGS[PLATFORM_UNKNOWN]["payment"])


def get_emoji(emoji_key: str, platform_type: str = PLATFORM_UNKNOWN, platform_version: Optional[str] = None) -> str:
    """
    Возвращает эмодзи, оптимизированный для конкретной платформы с учетом версии
    
    Args:
        emoji_key: Ключ эмодзи
        platform_type: Тип платформы
        platform_version: Версия платформы
        
    Returns:
        str: Эмодзи символ, совместимый с платформой
    """
    # Получаем настройки форматирования для платформы
    format_settings = get_message_format_settings(platform_type, platform_version)
    emoji_set = format_settings.get("emoji_set", "compatible")
    
    # Проверка наличия специфического набора для платформы
    platform_specific_set = None
    if platform_type == PLATFORM_IOS:
        platform_specific_set = "ios"
    elif platform_type == PLATFORM_ANDROID:
        platform_specific_set = "android"
    
    # Пробуем получить эмодзи из специфического набора для платформы, если он есть
    if platform_specific_set and platform_specific_set in EMOJI_COMPATIBILITY and emoji_key in EMOJI_COMPATIBILITY[platform_specific_set]:
        return EMOJI_COMPATIBILITY[platform_specific_set][emoji_key]
        
    # Проверка на проблемные версии iOS (старые версии имеют проблемы с некоторыми эмодзи)
    is_old_ios = platform_type == PLATFORM_IOS and platform_version and int(platform_version.split('.')[0]) < 13
    
    # Для старых версий iOS используем только базовый набор
    if is_old_ios:
        if emoji_key in EMOJI_COMPATIBILITY["basic"]:
            return EMOJI_COMPATIBILITY["basic"][emoji_key]
    
    # Пробуем получить эмодзи из выбранного набора
    if emoji_set in EMOJI_COMPATIBILITY and emoji_key in EMOJI_COMPATIBILITY[emoji_set]:
        return EMOJI_COMPATIBILITY[emoji_set][emoji_key]
    
    # Если эмодзи не найден в выбранном наборе, пробуем совместимый набор
    if emoji_key in EMOJI_COMPATIBILITY["compatible"]:
        return EMOJI_COMPATIBILITY["compatible"][emoji_key]
    
    # Если эмодзи не найден в совместимом наборе, пробуем базовый набор
    if emoji_key in EMOJI_COMPATIBILITY["basic"]:
        return EMOJI_COMPATIBILITY["basic"][emoji_key]
    
    # По умолчанию возвращаем пустую строку
    logger.warning(f"Эмодзи с ключом '{emoji_key}' не найден ни в одном наборе")
    return ""


# Карта проблемных символов и их замен для различных платформ
PROBLEMATIC_SYMBOLS = {
    PLATFORM_IOS: {
        # Символы, которые могут некорректно отображаться на iOS
        "—": "-",        # Длинное тире -> обычное тире
        "–": "-",        # Среднее тире -> обычное тире
        "…": "...",      # Многоточие -> три точки
        "≈": "~",        # Приблизительно -> тильда
        "≠": "!=",       # Не равно -> !=
        "≤": "<=",       # Меньше или равно -> <=
        "≥": ">=",       # Больше или равно -> >=
        "∞": "бесконечность", # Бесконечность -> слово "бесконечность"
        "√": "корень",    # Квадратный корень -> слово "корень"
        "∑": "сумма",     # Сумма -> слово "сумма"
        "∫": "интеграл",  # Интеграл -> слово "интеграл"
        "∏": "произведение", # Произведение -> слово "произведение"
        "∂": "d",        # Частная производная -> d
        "∆": "дельта",    # Дельта -> слово "дельта"
        "∇": "набла",     # Набла -> слово "набла"
        "∈": "принадлежит", # Принадлежит -> слово "принадлежит"
        "∉": "не принадлежит", # Не принадлежит -> слово "не принадлежит"
        "∩": "пересечение", # Пересечение -> слово "пересечение"
        "∪": "объединение", # Объединение -> слово "объединение"
        "∅": "пустое множество", # Пустое множество -> слово "пустое множество"
        "∀": "для всех",   # Для всех -> слово "для всех"
        "∃": "существует", # Существует -> слово "существует"
        "∄": "не существует", # Не существует -> слово "не существует"
        "⊂": "подмножество", # Подмножество -> слово "подмножество"
        "⊆": "подмножество или равно", # Подмножество или равно -> слово "подмножество или равно"
        "⊃": "надмножество", # Надмножество -> слово "надмножество"
        "⊇": "надмножество или равно", # Надмножество или равно -> слово "надмножество или равно"
        "⊕": "(+)",       # Исключающее или -> (+)
        "⊗": "(*)",       # Тензорное произведение -> (*)
        "⊥": "_|_",       # Перпендикулярно -> _|_
        "⌈": "ceiling",   # Потолок -> ceiling
        "⌉": "ceiling",   # Потолок -> ceiling
        "⌊": "floor",     # Пол -> floor
        "⌋": "floor",     # Пол -> floor
    },
    PLATFORM_ANDROID: {
        # Символы, которые могут некорректно отображаться на старых версиях Android
        "∞": "бесконечность", # Бесконечность -> слово "бесконечность"
        "√": "корень",    # Квадратный корень -> слово "корень"
        "∑": "сумма",     # Сумма -> слово "сумма"
        "∫": "интеграл",  # Интеграл -> слово "интеграл"
    },
    PLATFORM_UNKNOWN: {
        # Символы, которые могут некорректно отображаться на неизвестных платформах
        "—": "-",        # Длинное тире -> обычное тире
        "–": "-",        # Среднее тире -> обычное тире
        "…": "...",      # Многоточие -> три точки
        "≈": "~",        # Приблизительно -> тильда
        "≠": "!=",       # Не равно -> !=
        "≤": "<=",       # Меньше или равно -> <=
        "≥": ">=",       # Больше или равно -> >=
        "∞": "бесконечность", # Бесконечность -> слово "бесконечность"
        "√": "корень",    # Квадратный корень -> слово "корень"
        "∑": "сумма",     # Сумма -> слово "сумма"
        "∫": "интеграл",  # Интеграл -> слово "интеграл"
    }
}


def replace_problematic_symbols(text: str, platform_type: str, platform_version: Optional[str] = None) -> str:
    """
    Заменяет проблемные символы на совместимые с указанной платформой
    
    Args:
        text: Исходный текст
        platform_type: Тип платформы
        platform_version: Версия платформы
        
    Returns:
        str: Текст с замененными символами
    """
    if not text:
        return ""
    
    # Проверяем наличие платформы в словаре проблемных символов
    if platform_type not in PROBLEMATIC_SYMBOLS:
        platform_type = PLATFORM_UNKNOWN
    
    # Определяем старые платформы для более агрессивной замены символов
    is_old_platform = False
    if platform_type == PLATFORM_IOS and platform_version:
        major_version = platform_version.split('.')[0] if '.' in platform_version else platform_version
        is_old_platform = int(major_version) < 13
    elif platform_type == PLATFORM_ANDROID and platform_version:
        major_version = platform_version.split('.')[0] if '.' in platform_version else platform_version
        is_old_platform = int(major_version) < 8
    
    # Для старых платформ используем расширенную замену символов
    if is_old_platform:
        # Заменяем также символы из неизвестной платформы
        combined_symbols = {**PROBLEMATIC_SYMBOLS[platform_type], **PROBLEMATIC_SYMBOLS[PLATFORM_UNKNOWN]}
        for symbol, replacement in combined_symbols.items():
            text = text.replace(symbol, replacement)
    else:
        # Для новых платформ заменяем только проблемные символы для данной платформы
        for symbol, replacement in PROBLEMATIC_SYMBOLS[platform_type].items():
            text = text.replace(symbol, replacement)
    
    return text


def adapt_message_for_platform(message: str, platform_type: str, platform_version: Optional[str] = None) -> str:
    """
    Адаптирует сообщение для конкретной платформы
    
    Args:
        message: Исходное сообщение
        platform_type: Тип платформы
        platform_version: Версия платформы
        
    Returns:
        str: Адаптированное сообщение
    """
    if not message:
        return ""
    
    # Получаем настройки форматирования
    format_settings = get_message_format_settings(platform_type, platform_version)
    max_length = format_settings.get("max_length", 4000)
    
    # Заменяем проблемные символы
    message = replace_problematic_symbols(message, platform_type, platform_version)
    
    # Обрезаем сообщение до максимальной длины
    if len(message) > max_length:
        # Обрезаем с запасом для добавления "..."
        message = message[:max_length-3] + "..."
    
    return message


def get_platform_compatibility_flags(platform_type_or_user_id: Union[str, int], platform_version: Optional[str] = None) -> Dict[str, bool]:
    """
    Возвращает флаги совместимости для конкретной платформы или пользователя
    
    Args:
        platform_type_or_user_id: Тип платформы или ID пользователя
        platform_version: Версия платформы (только если первый аргумент - тип платформы)
        
    Returns:
        Dict[str, bool]: Словарь с флагами совместимости
    """
    # Если передан ID пользователя, получаем информацию о платформе из БД
    if isinstance(platform_type_or_user_id, int):
        from services.platform_detection_service import get_user_platform
        
        user_id = platform_type_or_user_id
        platform_info = get_user_platform(user_id)
        
        if platform_info:
            return get_platform_compatibility_flags(platform_info.platform_type, platform_info.platform_version)
        else:
            return get_platform_compatibility_flags(PLATFORM_UNKNOWN)
            
    # Если передан тип платформы, используем его напрямую
    platform_type = platform_type_or_user_id
    # Базовые настройки совместимости по умолчанию
    compatibility_flags = {
        "qr_compatible": True,         # Совместимость с QR-кодами
        "inline_buttons_compatible": True,  # Совместимость с встроенными кнопками
        "markdown_compatible": True,    # Совместимость с Markdown форматированием
        "html_compatible": True,        # Совместимость с HTML форматированием
        "animation_compatible": True,   # Совместимость с анимированными GIF
        "sticker_compatible": True,     # Совместимость со стикерами
        "emoji_compatible": True,       # Полная совместимость с эмодзи
        "long_message_compatible": True,  # Совместимость с длинными сообщениями
    }
    
    # Настройки для конкретных платформ
    if platform_type == PLATFORM_IOS:
        ios_version = int(platform_version.split('.')[0]) if platform_version and platform_version.split('.')[0].isdigit() else 0
        
        # iOS < 11 имеет проблемы с QR-кодами
        if ios_version < 11:
            compatibility_flags["qr_compatible"] = False
            
        # iOS < 10 имеет проблемы с некоторыми типами эмодзи
        if ios_version < 10:
            compatibility_flags["emoji_compatible"] = False
            
    elif platform_type == PLATFORM_ANDROID:
        android_version = int(platform_version.split('.')[0]) if platform_version and platform_version.split('.')[0].isdigit() else 0
        
        # Android < 6 имеет проблемы с некоторыми форматированиями
        if android_version < 6:
            compatibility_flags["html_compatible"] = False
            
    elif platform_type == PLATFORM_UNKNOWN:
        # Для неизвестной платформы используем консервативные настройки
        compatibility_flags["qr_compatible"] = False
        compatibility_flags["html_compatible"] = False
        compatibility_flags["markdown_compatible"] = True  # Markdown обычно работает везде
        compatibility_flags["emoji_compatible"] = False
    
    return compatibility_flags