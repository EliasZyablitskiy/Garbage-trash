#!/usr/bin/env python
# coding: utf-8

"""
Database configuration for PostgreSQL with SQLAlchemy
"""

import os
import logging
from flask import Flask
from flask_migrate import Migrate
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import sessionmaker
from db_models import db

logger = logging.getLogger(__name__)

def create_flask_app() -> Flask:
    """
    Create and configure Flask application with database
    
    Returns:
        Flask: Configured Flask application
    """
    app = Flask(__name__, template_folder='templates')
    
    # Получаем DATABASE_URL из переменных окружения
    database_url = os.environ.get("DATABASE_URL")
    if not database_url:
        logger.error("DATABASE_URL environment variable not set")
        raise ValueError("DATABASE_URL environment variable not set")
    
    # Настраиваем SQLAlchemy
    app.config["SQLALCHEMY_DATABASE_URI"] = database_url
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    
    # Инициализируем расширения
    db.init_app(app)
    migrate = Migrate(app, db)
    
    return app

def init_db(app: Flask) -> None:
    """
    Initialize database with all models
    
    Args:
        app: Flask application with configured SQLAlchemy
    """
    with app.app_context():
        import db_models  # Импортируем модели, чтобы они были зарегистрированы
        db.create_all()
        logger.info("Database tables created")

# Создаем приложение Flask для использования в других модулях
flask_app = create_flask_app()

def get_flask_app() -> Flask:
    """
    Get configured Flask application
    
    Returns:
        Flask: Configured Flask application
    """
    return flask_app

# Создаем асинхронный движок для SQLAlchemy
database_url = os.environ.get("DATABASE_URL")
if database_url and not database_url.startswith("postgresql+asyncpg"):
    # Преобразуем обычный URL в асинхронный URL
    if database_url.startswith("postgresql://"):
        async_database_url = database_url.replace("postgresql://", "postgresql+asyncpg://")
    else:
        async_database_url = f"postgresql+asyncpg://{database_url.split('://', 1)[1]}"
else:
    async_database_url = database_url

# Создаем асинхронный движок и сессию
async_engine = create_async_engine(
    async_database_url,
    pool_pre_ping=True,
    pool_recycle=300,
    future=True,
    echo=False
)

# Создаем фабрику асинхронных сессий
async_session_maker = async_sessionmaker(
    async_engine,
    expire_on_commit=False,
    class_=AsyncSession
)