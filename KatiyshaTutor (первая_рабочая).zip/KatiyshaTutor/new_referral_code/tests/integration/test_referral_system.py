import unittest
from unittest.mock import patch, AsyncMock, MagicMock
import pytest
import sys
import os
import json
from datetime import datetime, timedelta

# Add the project root directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Import database functions
from database import (
    load_users_db, save_users_db, get_user_data, save_user_data,
    load_transactions_db, save_transactions_db, create_transaction, update_transaction
)

# Import handlers
from handlers import (
    invite_command, process_refcode, subscription_callback, 
    process_subscription_payment
)

# Import payment service
from services.payment_service import generate_payment_url, process_payout

# Test data
MOCK_USERS_DB = {
    "12345": {
        "id": 12345,
        "username": "user1",
        "first_name": "Test User 1",
        "subscription_end": None,
        "subscription_type": None,
        "referral_code": "TESTREF1",
        "referrer_id": None,
        "referrals": [],
        "level_1_referrals": [],
        "level_2_referrals": [],
        "level_3_referrals": [],
        "level_4_referrals": [],
        "total_earned": 0
    },
    "67890": {
        "id": 67890,
        "username": "user2",
        "first_name": "Test User 2",
        "subscription_end": None,
        "subscription_type": None,
        "referral_code": "TESTREF2",
        "referrer_id": None,
        "referrals": [],
        "level_1_referrals": [],
        "level_2_referrals": [],
        "level_3_referrals": [],
        "level_4_referrals": [],
        "total_earned": 0
    }
}

MOCK_TRANSACTIONS_DB = {
    "trans1": {
        "id": "trans1",
        "user_id": 12345,
        "type": "subscription",
        "amount": 100.0,
        "status": "pending",
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat()
    }
}

class MockUpdate:
    def __init__(self, user_id, username=None, first_name=None, text=None):
        self.effective_user = MagicMock()
        self.effective_user.id = user_id
        self.effective_user.username = username
        self.effective_user.first_name = first_name
        
        self.message = MagicMock()
        self.message.text = text
        
        self.callback_query = None
    
    def set_callback_query(self, data):
        self.callback_query = MagicMock()
        self.callback_query.data = data
        return self

class TestReferralIntegration(unittest.TestCase):
    
    def setUp(self):
        """Set up test environment before each test"""
        # Create a backup of the real database files if they exist
        if os.path.exists("users_db.json"):
            with open("users_db.json", "r") as f:
                self.original_users_db = f.read()
        else:
            self.original_users_db = None
            
        if os.path.exists("transactions_db.json"):
            with open("transactions_db.json", "r") as f:
                self.original_transactions_db = f.read()
        else:
            self.original_transactions_db = None
        
        # Create test database files
        with open("users_db.json", "w") as f:
            json.dump(MOCK_USERS_DB, f)
            
        with open("transactions_db.json", "w") as f:
            json.dump(MOCK_TRANSACTIONS_DB, f)
    
    def tearDown(self):
        """Clean up after each test"""
        # Restore the original database files
        if self.original_users_db is not None:
            with open("users_db.json", "w") as f:
                f.write(self.original_users_db)
        else:
            if os.path.exists("users_db.json"):
                os.remove("users_db.json")
                
        if self.original_transactions_db is not None:
            with open("transactions_db.json", "w") as f:
                f.write(self.original_transactions_db)
        else:
            if os.path.exists("transactions_db.json"):
                os.remove("transactions_db.json")
    
    @pytest.mark.asyncio
    async def test_full_referral_flow(self):
        """Test the complete referral flow from invitation to payment rewards"""
        
        # Step 1: User 1 generates a referral link
        update = MockUpdate(12345, "user1", "Test User 1")
        context = AsyncMock()
        context.bot.get_me.return_value = MagicMock(username="katiysha_bot")
        
        await invite_command(update, context)
        context.bot.send_message.assert_called_once()
        message = context.bot.send_message.call_args[0][1]
        assert "https://t.me/katiysha_bot?start=TESTREF1" in message
        
        # Step 2: User 2 uses User 1's referral code
        update = MockUpdate(67890, "user2", "Test User 2", "TESTREF1")
        context = AsyncMock()
        
        await process_refcode(update, context)
        
        # Verify User 2 is now referred by User 1
        user2 = get_user_data(67890)
        assert user2["referrer_id"] == 12345
        
        # Verify User 1 has User 2 as a referral
        user1 = get_user_data(12345)
        assert 67890 in user1["referrals"]
        assert 67890 in user1["level_1_referrals"]
        
        # Step 3: User 2 purchases a subscription
        # Mock the callback with subscription type
        update = MockUpdate(67890).set_callback_query("sub_monthly")
        context = AsyncMock()
        
        with patch("handlers.generate_payment_url", return_value="https://test-payment-url.com"):
            await subscription_callback(update, context)
            
            # Verify a payment URL was generated and sent
            context.bot.send_message.assert_called()
            payment_message = context.bot.send_message.call_args[0][1]
            assert "payment" in payment_message.lower()
        
        # Step 4: Simulate successful payment
        # Create a test transaction for User 2's subscription
        transaction_id = create_transaction(67890, "subscription", 100.0)
        
        # Mock the payment notification process
        robokassa_params = {
            "OutSum": "100.0",
            "InvId": transaction_id,
            "SignatureValue": "test_signature",
            "Email": "user2@test.com"
        }
        
        with patch("webhook_handler.verify_robokassa_signature", return_value=True):
            with patch("webhook_handler.process_subscription_payment") as mock_process:
                mock_process.return_value = True
                
                # In a real application, this would be called by the webhook handler
                # Here we directly call the function that webhook would call
                await process_subscription_payment(transaction_id, "completed")
                
                # Verify the transaction was updated
                transaction = next((t for t in load_transactions_db().values() if t["id"] == transaction_id), None)
                assert transaction["status"] == "completed"
                
                # Verify User 2 now has an active subscription
                user2 = get_user_data(67890)
                assert user2["subscription_type"] == "monthly"
                assert user2["subscription_end"] is not None
                
                # Verify referral commission was recorded
                user1 = get_user_data(12345)
                # Check if there's a transaction for the referral reward
                referral_transactions = [
                    t for t in load_transactions_db().values() 
                    if t["user_id"] == 12345 and t["type"] == "referral_reward"
                ]
                assert len(referral_transactions) > 0
                # The referral reward should be 5% of the subscription cost
                assert referral_transactions[0]["amount"] == 5.0  # 5% of 100
                assert user1["total_earned"] == 5.0
    
    @pytest.mark.asyncio
    async def test_multi_level_referral_rewards(self):
        """Test rewards distribution across multiple referral levels"""
        
        # Create a chain of referrals (4 levels)
        # User A refers B, B refers C, C refers D, D refers E
        users_db = {
            "111": {
                "id": 111,
                "username": "userA",
                "referral_code": "REFA",
                "referrer_id": None,
                "referrals": [222],
                "level_1_referrals": [222],
                "level_2_referrals": [333],
                "level_3_referrals": [444],
                "level_4_referrals": [555],
                "total_earned": 0
            },
            "222": {
                "id": 222,
                "username": "userB",
                "referral_code": "REFB",
                "referrer_id": 111,
                "referrals": [333],
                "level_1_referrals": [333],
                "level_2_referrals": [444],
                "level_3_referrals": [555],
                "total_earned": 0
            },
            "333": {
                "id": 333,
                "username": "userC",
                "referral_code": "REFC",
                "referrer_id": 222,
                "referrals": [444],
                "level_1_referrals": [444],
                "level_2_referrals": [555],
                "total_earned": 0
            },
            "444": {
                "id": 444,
                "username": "userD",
                "referral_code": "REFD",
                "referrer_id": 333,
                "referrals": [555],
                "level_1_referrals": [555],
                "total_earned": 0
            },
            "555": {
                "id": 555,
                "username": "userE",
                "referral_code": "REFE",
                "referrer_id": 444,
                "referrals": [],
                "level_1_referrals": [],
                "total_earned": 0
            }
        }
        
        # Override the mock database
        save_users_db(users_db)
        
        # Simulate UserE making a payment of $100 for a subscription
        transaction_id = create_transaction(555, "subscription", 100.0)
        
        # Process the subscription payment
        with patch("config.REFERRAL_RATE_LEVEL_1", 0.05), \
             patch("config.REFERRAL_RATE_LEVEL_2", 0.02), \
             patch("config.REFERRAL_RATE_LEVEL_3", 0.02), \
             patch("config.REFERRAL_RATE_LEVEL_4", 0.02):
            
            await process_subscription_payment(transaction_id, "completed")
            
            # Verify UserE's subscription is active
            userE = get_user_data(555)
            assert userE["subscription_type"] is not None
            
            # Check that all users in the chain received appropriate rewards
            userA = get_user_data(111)
            userB = get_user_data(222)
            userC = get_user_data(333)
            userD = get_user_data(444)
            
            # UserD (1st level referrer) should get 5%
            assert userD["total_earned"] == 5.0
            
            # UserC (2nd level referrer) should get 2%
            assert userC["total_earned"] == 2.0
            
            # UserB (3rd level referrer) should get 2%
            assert userB["total_earned"] == 2.0
            
            # UserA (4th level referrer) should get 2%
            assert userA["total_earned"] == 2.0
            
            # Verify transactions were created for all rewards
            transactions = load_transactions_db()
            reward_transactions = [t for t in transactions.values() if t["type"] == "referral_reward"]
            assert len(reward_transactions) == 4  # One for each referrer
            
            # Verify the right amounts were recorded
            reward_amounts = {t["user_id"]: t["amount"] for t in reward_transactions}
            assert reward_amounts[111] == 2.0  # Level 4 = 2%
            assert reward_amounts[222] == 2.0  # Level 3 = 2%
            assert reward_amounts[333] == 2.0  # Level 2 = 2%
            assert reward_amounts[444] == 5.0  # Level 1 = 5%


if __name__ == "__main__":
    pytest.main() 