#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для миграции реферальных данных из JSON в PostgreSQL
"""

import logging
import json
import sys
from typing import Dict, List, Any, Optional
from sqlalchemy import text

from db_config import get_flask_app
from db_models import db, User, Transaction, WeeklyPayout
from new_referral_models import ReferralCode, ReferralRelation, ReferralReward

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def load_json_database(filename: str = "users_db.json") -> Dict[str, Any]:
    """
    Загрузка базы данных из JSON-файла
    
    Args:
        filename: Имя файла базы данных
        
    Returns:
        Dict: Содержимое базы данных
    """
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        logger.error(f"File {filename} not found")
        return {"users": {}}
    except json.JSONDecodeError:
        logger.error(f"Error decoding JSON from {filename}")
        return {"users": {}}

def migrate_referral_data():
    """
    Миграция реферальных данных из JSON в PostgreSQL
    """
    app = get_flask_app()
    with app.app_context():
        # Загружаем данные из JSON
        json_db = load_json_database()
        
        if not json_db or "users" not in json_db:
            logger.error("Invalid JSON database format")
            return
        
        # Счетчики для статистики
        stats = {
            "total_users": len(json_db["users"]),
            "processed_users": 0,
            "created_referral_codes": 0,
            "created_relations": 0,
            "errors": 0
        }
        
        # Обрабатываем каждого пользователя
        for user_id_str, user_data in json_db["users"].items():
            try:
                user_id = int(user_id_str)
                
                # Проверяем существует ли пользователь в PostgreSQL
                user = User.query.filter_by(id=user_id).first()
                if not user:
                    logger.warning(f"User with telegram_id={user_id} not found in PostgreSQL, skipping")
                    continue
                
                # Обрабатываем реферальный код
                referral_code = user_data.get("referral_code")
                if referral_code:
                    # Проверяем существует ли уже такой код
                    existing_code = ReferralCode.query.filter_by(code=referral_code).first()
                    if existing_code:
                        logger.info(f"Referral code {referral_code} already exists for user {existing_code.user_id}")
                    else:
                        # Создаем новый реферальный код
                        new_code = ReferralCode(
                            user_id=user.id,
                            code=referral_code,
                            active=True
                        )
                        db.session.add(new_code)
                        stats["created_referral_codes"] += 1
                
                # Обрабатываем реферальные отношения
                referrer_id = user_data.get("referrer_id")
                if referrer_id:
                    # Преобразуем referrer_id в int, если он в строковом формате
                    if isinstance(referrer_id, str):
                        # Убираем префикс 'r', если он есть
                        if referrer_id.startswith('r') and len(referrer_id) > 1:
                            numeric_part = ''.join(c for c in referrer_id if c.isdigit())
                            if numeric_part:
                                referrer_id = int(numeric_part)
                            else:
                                logger.error(f"Invalid referrer_id format: {referrer_id} for user {user_id}")
                                stats["errors"] += 1
                                continue
                        elif referrer_id.isdigit():
                            referrer_id = int(referrer_id)
                        else:
                            logger.error(f"Invalid referrer_id format: {referrer_id} for user {user_id}")
                            stats["errors"] += 1
                            continue
                    
                    # Находим пользователя-реферера
                    referrer = User.query.filter_by(id=referrer_id).first()
                    if not referrer:
                        logger.warning(f"Referrer with telegram_id={referrer_id} not found for user {user_id}, skipping relation")
                        continue
                    
                    # Проверяем существует ли уже такое отношение
                    existing_relation = ReferralRelation.query.filter_by(
                        user_id=user.id,
                        referrer_id=referrer.id
                    ).first()
                    
                    if existing_relation:
                        logger.info(f"Referral relation already exists between user {user.id} and referrer {referrer.id}")
                    else:
                        # Создаем новое реферальное отношение
                        new_relation = ReferralRelation(
                            user_id=user.id,
                            referrer_id=referrer.id
                        )
                        db.session.add(new_relation)
                        stats["created_relations"] += 1
                
                # Обновляем счетчик обработанных пользователей
                stats["processed_users"] += 1
                
                # Сохраняем изменения каждые 100 пользователей для экономии памяти
                if stats["processed_users"] % 100 == 0:
                    db.session.commit()
                    logger.info(f"Processed {stats['processed_users']} users so far")
            
            except Exception as e:
                logger.error(f"Error processing user {user_id_str}: {e}")
                stats["errors"] += 1
        
        # Сохраняем все оставшиеся изменения
        db.session.commit()
        
        # Выводим статистику
        logger.info("Migration completed!")
        logger.info(f"Total users: {stats['total_users']}")
        logger.info(f"Processed users: {stats['processed_users']}")
        logger.info(f"Created referral codes: {stats['created_referral_codes']}")
        logger.info(f"Created referral relations: {stats['created_relations']}")
        logger.info(f"Errors: {stats['errors']}")

def rebuild_referral_hierarchy():
    """
    Пересчет иерархии реферальных отношений для обеспечения целостности данных
    """
    app = get_flask_app()
    with app.app_context():
        try:
            # Строим иерархию реферальных отношений
            # Этот SQL-запрос обновляет level поле в реферальных отношениях
            sql = text("""
            WITH RECURSIVE referral_tree AS (
                SELECT rr.id, rr.user_id, rr.referrer_id, 1 as level
                FROM referral_relation rr
                WHERE NOT EXISTS (
                    SELECT 1 FROM referral_relation r WHERE r.user_id = rr.referrer_id
                )
                
                UNION ALL
                
                SELECT rr.id, rr.user_id, rr.referrer_id, rt.level + 1
                FROM referral_relation rr
                JOIN referral_tree rt ON rr.referrer_id = rt.user_id
                WHERE rr.id != rt.id
            )
            UPDATE referral_relation
            SET level = (
                SELECT level FROM referral_tree WHERE referral_tree.id = referral_relation.id
            )
            WHERE id IN (SELECT id FROM referral_tree);
            """)
            
            result = db.session.execute(sql)
            db.session.commit()
            
            logger.info(f"Referral hierarchy rebuilt successfully!")
            
            # Подсчет статистики
            referral_stats = {}
            for level in range(1, 5):  # Уровни от 1 до 4
                count = ReferralRelation.query.filter_by(level=level).count()
                referral_stats[f"level_{level}"] = count
            
            logger.info(f"Referral statistics:")
            for level, count in referral_stats.items():
                logger.info(f"{level}: {count} relations")
            
            return True
        except Exception as e:
            logger.error(f"Error rebuilding referral hierarchy: {e}")
            db.session.rollback()
            return False

def main():
    """
    Основная функция
    """
    try:
        logger.info("Starting referral data migration from JSON to PostgreSQL")
        migrate_referral_data()
        
        logger.info("Rebuilding referral hierarchy")
        rebuild_referral_hierarchy()
        
        logger.info("Migration completed successfully!")
        return 0
    except Exception as e:
        logger.error(f"Error during migration: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())