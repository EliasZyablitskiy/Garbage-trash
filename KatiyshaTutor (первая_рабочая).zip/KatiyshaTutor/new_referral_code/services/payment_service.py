#!/usr/bin/env python
# coding: utf-8

"""
Service for handling payment processing
"""

import os
import logging
import datetime
import hashlib
from typing import Dict, Any, Optional, List
import aiohttp
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
import time
import asyncio

import config
from database import get_user, update_user_subscription
from keyboards import get_main_keyboard

logger = logging.getLogger(__name__)

async def create_external_payment_link(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Create and send an external payment link for subscription using Robokassa iFrame
    
    Args:
        update: Telegram update object
        context: Telegram context object
    """
    # Получаем ID пользователя
    user_id = update.effective_user.id
    
    # Получаем BASE_URL из окружения (URL веб-сервера)
    base_url = config.get_base_url()
    
    # Формируем URL нашей страницы оплаты с iframe Robokassa
    payment_url = f"{base_url}/payment/{user_id}"
    
    # Создаем инлайн-клавиатуру с кнопкой для перехода на страницу оплаты
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("Оплатить 199₽", url=payment_url)]
    ])
    
    await update.effective_message.reply_text(
        "Для оплаты подписки нажмите на кнопку ниже. "
        "После успешной оплаты подписка должна активироваться автоматически.\n\n"
        "Если этого не произошло, отправьте команду /activate_subscription, "
        "чтобы активировать подписку вручную.",
        reply_markup=keyboard
    )
    
    logger.debug(f"Отправлена ссылка на оплату через iFrame пользователю {user_id} с URL: {payment_url}")

async def create_manual_activation(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Создание кнопки для ручной активации подписки
    
    Args:
        update: Telegram update object
        context: Telegram context object
    """
    user_id = update.effective_user.id
    
    # Проверяем, есть ли уже подписка
    user_data = get_user(user_id)
    if user_data and 'subscription_expiry' in user_data and user_data['subscription_expiry']:
        try:
            expiry_date = datetime.datetime.fromisoformat(user_data['subscription_expiry'])
            if datetime.datetime.now() < expiry_date:
                await update.message.reply_text(
                    f"✅ У вас уже есть *активная подписка* до {expiry_date.strftime('%d.%m.%Y')}.\n\n"
                    "Вы можете продолжать пользоваться всеми функциями бота Катюша!",
                    reply_markup=get_main_keyboard(),
                    parse_mode='Markdown'
                )
                return
        except Exception as e:
            logger.error(f"Error checking subscription: {e}")
    
    # Отправляем сообщение о ручной активации
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("💳 Оплатить через СБП", url="https://telegrampay.robokassa.ru/Pay/19296?culture=ru")],
        [InlineKeyboardButton("✅ Активировать подписку после оплаты", callback_data="manual_activate")]
    ])
    
    await update.effective_message.reply_text(
        "🔐 *Покупка подписки на бот Катюша* 🔐\n\n"
        "Стоимость подписки: *199₽ за 1 месяц*\n\n"
        "1️⃣ Нажмите кнопку *Оплатить через СБП* и оплатите подписку\n\n"
        "2️⃣ После оплаты вернитесь в бот и нажмите *Активировать подписку после оплаты*\n\n"
        "✨ Подписка дает неограниченный доступ ко всем функциям бота:\n"
        "• Решение математических задач с подробным объяснением\n"
        "• Распознавание и обработка фотографий с заданиями\n"
        "• Обработка голосовых сообщений с задачами\n\n"
        "_Активируя подписку, вы подтверждаете, что произвели оплату. Активация без оплаты является нарушением правил._",
        reply_markup=keyboard,
        parse_mode='Markdown'
    )
    
    logger.debug(f"Отправлено предложение по оплате подписки пользователю {user_id}")

def generate_robokassa_signature(merchant_login: str, outsum: float, inv_id: int, 
                                secret_key: str, user_id: int) -> str:
    """
    Generate a signature for Robokassa payment request
    
    Args:
        merchant_login: Robokassa merchant login
        outsum: Payment amount
        inv_id: Invoice ID
        secret_key: Secret key for Robokassa
        user_id: User ID to include in signature
        
    Returns:
        str: Generated signature
    """
    signature_str = f"{merchant_login}:{outsum}:{inv_id}:{secret_key}:Shp_user={user_id}"
    return hashlib.md5(signature_str.encode()).hexdigest()

def verify_robokassa_signature(inv_id: str, outsum: str, signature: str, 
                              user_id: str) -> bool:
    """
    Verify the signature from Robokassa payment notification
    
    Args:
        inv_id: Invoice ID from notification
        outsum: Payment amount from notification
        signature: Signature from notification
        user_id: User ID from notification
        
    Returns:
        bool: True if signature is valid, False otherwise
    """
    # Получаем секретный ключ №2 (для уведомлений о платежах)
    secret_key = config.ROBOKASSA_SECRET_KEY
    
    # Формируем строку для проверки подписи
    check_str = f"{outsum}:{inv_id}:{secret_key}:Shp_user={user_id}"
    
    # Формируем контрольную подпись
    check_signature = hashlib.md5(check_str.encode()).hexdigest().lower()
    
    # Сравниваем подписи (не учитывая регистр)
    return check_signature == signature.lower()

def generate_robokassa_payout_url(user_id: int, amount: float, transaction_id: Optional[int] = None, description: str = "Referral reward") -> str:
    """
    Generate a URL for Robokassa payout
    
    Args:
        user_id: User ID
        amount: Payment amount
        transaction_id: Internal transaction ID (optional)
        description: Payment description
        
    Returns:
        str: Robokassa payment URL
    """
    # Get Robokassa merchant login and secret key
    merchant_login = config.ROBOKASSA_MERCHANT_LOGIN
    secret_key = config.ROBOKASSA_SECRET_KEY_1
    
    # Format amount to 2 decimal places
    outsum = "{:.2f}".format(amount)
    
    # Generate a unique invoice ID if not provided
    inv_id = transaction_id or int(time.time())
    
    # Prepare custom parameters
    custom_params = {
        "Shp_user": user_id,
        "Shp_type": "referral_payout"
    }
    
    if transaction_id:
        custom_params["Shp_transaction_id"] = transaction_id
    
    # Generate signature
    signature_str = f"{merchant_login}:{outsum}:{inv_id}:{secret_key}"
    
    # Add custom parameters to signature in alphabetical order
    for key in sorted(custom_params.keys()):
        signature_str += f":{key}={custom_params[key]}"
    
    signature = hashlib.md5(signature_str.encode()).hexdigest()
    
    # Build URL with parameters
    base_url = "https://auth.robokassa.ru/Merchant/Index.aspx"
    params = {
        "MerchantLogin": merchant_login,
        "OutSum": outsum,
        "InvId": inv_id,
        "Description": description,
        "SignatureValue": signature,
        **custom_params
    }
    
    # Convert params to URL query string
    query_string = "&".join([f"{k}={v}" for k, v in params.items()])
    
    return f"{base_url}?{query_string}"

async def process_robokassa_payout(user_id: int, amount: float, transaction_id: Optional[int] = None) -> Dict[str, Any]:
    """
    Process a payout through Robokassa API
    
    Args:
        user_id: User ID
        amount: Payment amount
        transaction_id: Internal transaction ID (optional)
        
    Returns:
        dict: Payout result
    """
    # In a real implementation, this would use Robokassa's API to initiate a payout
    # For now, we'll just generate a URL to simulate the process
    
    # Get user data to check payment method
    from database import get_user
    user_data = get_user(user_id)
    
    if not user_data:
        logger.error(f"User not found for payout: {user_id}")
        return {
            "success": False,
            "error": "User not found",
            "user_id": user_id
        }
    
    # Generate payout URL
    payout_url = generate_robokassa_payout_url(
        user_id=user_id,
        amount=amount,
        transaction_id=transaction_id,
        description=f"Реферальное вознаграждение от Катюша бот"
    )
    
    # In a real implementation, you would call Robokassa API here
    # and handle the response
    
    # For now, we'll simulate a successful payout
    result = {
        "success": True,
        "user_id": user_id,
        "amount": amount,
        "transaction_id": transaction_id,
        "payout_url": payout_url,
        "status": "pending"
    }
    
    # If this is a real API integration, you would update the transaction status
    # based on the API response
    
    logger.info(f"Processed payout for user {user_id}, amount: {amount}₽")
    
    return result

async def process_batch_payouts(user_payouts: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Process a batch of payouts through Robokassa
    
    Args:
        user_payouts: List of user payout records with user_id, amount, and transaction_id
        
    Returns:
        dict: Results with success and failure counts
    """
    results = {
        "total": len(user_payouts),
        "success": 0,
        "failures": 0,
        "details": []
    }
    
    for payout in user_payouts:
        try:
            result = await process_robokassa_payout(
                user_id=payout["user_id"],
                amount=payout["amount"],
                transaction_id=payout.get("transaction_id")
            )
            
            if result.get("success", False):
                results["success"] += 1
            else:
                results["failures"] += 1
            
            results["details"].append(result)
            
            # Don't overload the API
            await asyncio.sleep(0.5)
            
        except Exception as e:
            logger.error(f"Error processing payout: {e}")
            results["failures"] += 1
            results["details"].append({
                "success": False,
                "user_id": payout["user_id"],
                "amount": payout["amount"],
                "error": str(e)
            })
    
    logger.info(f"Batch payout completed: {results['success']} successful, {results['failures']} failed out of {results['total']}")
    
    return results