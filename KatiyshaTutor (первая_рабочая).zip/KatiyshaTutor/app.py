#!/usr/bin/env python
# coding: utf-8

"""
Flask application entry point for Gunicorn
"""

from webhook_handler import app

# Для доступа к приложению через gunicorn main:app