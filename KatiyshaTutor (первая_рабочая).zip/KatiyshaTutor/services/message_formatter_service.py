#!/usr/bin/env python
# coding: utf-8

"""
Сервис для адаптации форматирования сообщений под разные платформы
"""

import re
import logging
import html
from typing import Dict, Any, Optional, List, Tuple

from services.platform_detection_service import (
    PLATFORM_IOS, PLATFORM_ANDROID, PLATFORM_DESKTOP, 
    PLATFORM_WEB, PLATFORM_UNKNOWN
)
from services.platform_data_service import (
    get_message_format_settings, get_emoji, replace_problematic_symbols
)

logger = logging.getLogger(__name__)

# Таблица соответствия форматирования HTML и MarkdownV2
FORMAT_MAP = {
    "HTML": {
        "bold": ("<b>", "</b>"),
        "italic": ("<i>", "</i>"),
        "code": ("<code>", "</code>"),
        "pre": ("<pre>", "</pre>"),
        "underline": ("<u>", "</u>"),
        "strikethrough": ("<s>", "</s>"),
        "link": lambda url, text: f'<a href="{url}">{text}</a>',
    },
    "MarkdownV2": {
        "bold": ("*", "*"),
        "italic": ("_", "_"),
        "code": ("`", "`"),
        "pre": ("```", "```"),
        "underline": ("__", "__"),
        "strikethrough": ("~", "~"),
        "link": lambda url, text: f"[{text}]({url})",
    }
}

# Экранирование специальных символов для разных форматов
ESCAPE_CHARS = {
    "HTML": {
        "<": "&lt;",
        ">": "&gt;",
        "&": "&amp;"
    },
    "MarkdownV2": {
        "_": "\\_",
        "*": "\\*",
        "[": "\\[",
        "]": "\\]",
        "(": "\\(",
        ")": "\\)",
        "~": "\\~",
        "`": "\\`",
        ">": "\\>",
        "#": "\\#",
        "+": "\\+",
        "-": "\\-",
        "=": "\\=",
        "|": "\\|",
        "{": "\\{",
        "}": "\\}",
        ".": "\\.",
        "!": "\\!"
    }
}

def format_text(
    text: str, 
    format_type: str = "HTML", 
    max_length: int = 4096,
    safe_mode: bool = True
) -> str:
    """
    Форматирует текст в указанном формате с учетом ограничений длины
    и безопасности (экранирование специальных символов).
    
    Args:
        text: Исходный текст
        format_type: Тип форматирования ("HTML" или "MarkdownV2")
        max_length: Максимальная длина сообщения
        safe_mode: Флаг безопасного режима (экранирование спецсимволов)
        
    Returns:
        str: Отформатированный текст
    """
    if not text:
        return ""
    
    # Экранируем специальные символы, если включен безопасный режим
    if safe_mode and format_type in ESCAPE_CHARS:
        for char, escape in ESCAPE_CHARS[format_type].items():
            # В HTML экранируем только спецсимволы, которые не являются 
            # частью тегов форматирования
            if format_type == "HTML" and re.search(r'<[a-z/]+>', text):
                # Не экранируем символы, которые являются частью HTML-тегов
                text_parts = re.split(r'(<[^>]*>)', text)
                for i in range(len(text_parts)):
                    if not text_parts[i].startswith("<") or not text_parts[i].endswith(">"):
                        for c, esc in ESCAPE_CHARS[format_type].items():
                            text_parts[i] = text_parts[i].replace(c, esc)
                text = ''.join(text_parts)
            else:
                # Для других форматов или текста без тегов просто заменяем символы
                text = text.replace(char, escape)
    
    # Обрезаем текст до максимальной длины
    if len(text) > max_length:
        # Сохраняем целостность форматирования
        if format_type == "HTML":
            # Добавляем закрывающие теги, если они были открыты
            open_tags = []
            for match in re.finditer(r'<([a-zA-Z]+)[^>]*>', text[:max_length-3]):
                tag = match.group(1)
                close_tag_pattern = f'</({tag})>'
                # Проверяем, есть ли закрывающий тег после открывающего
                if not re.search(close_tag_pattern, text[match.end():max_length-3]):
                    open_tags.append(tag)
            
            # Формируем закрывающие теги в обратном порядке
            closing_tags = ''.join([f'</{tag}>' for tag in reversed(open_tags)])
            return text[:max_length-3-len(closing_tags)] + '...' + closing_tags
        else:
            # Для Markdown просто обрезаем и добавляем ...
            return text[:max_length-3] + '...'
    
    return text

def format_adaptive_message(
    text: str, 
    platform_type: str = PLATFORM_UNKNOWN, 
    platform_version: Optional[str] = None,
    formatting_elements: Optional[Dict[str, Any]] = None
) -> Tuple[str, str]:
    """
    Форматирует сообщение с учетом платформы пользователя
    
    Args:
        text: Исходный текст сообщения
        platform_type: Тип платформы пользователя
        platform_version: Версия платформы пользователя
        formatting_elements: Словарь с элементами форматирования
            (bold, italic, links, etc.)
        
    Returns:
        Tuple[str, str]: Отформатированный текст и использованный формат
    """
    if not text:
        return "", "HTML"
    
    # Получаем настройки форматирования для платформы
    format_settings = get_message_format_settings(platform_type, platform_version)
    preferred_format = format_settings.get("preferred", "HTML")
    max_length = format_settings.get("max_length", 4096)
    
    # Заменяем проблемные символы на совместимые с платформой
    text = replace_problematic_symbols(text, platform_type, platform_version)
    
    # Применяем элементы форматирования, если они указаны
    if formatting_elements:
        format_map = FORMAT_MAP.get(preferred_format, FORMAT_MAP["HTML"])
        
        # Применяем форматирование к тексту
        for format_type, content in formatting_elements.items():
            if format_type in format_map:
                if format_type == "link" and isinstance(content, list):
                    # Обрабатываем ссылки - каждая ссылка это [url, text]
                    for url, link_text in content:
                        if callable(format_map[format_type]):
                            # Для ссылок используем функцию форматирования
                            formatter = format_map[format_type]
                            text = text.replace(f"[{link_text}]", formatter(url, link_text))
                elif isinstance(content, list):
                    # Обрабатываем другие элементы форматирования (списки фрагментов)
                    for item in content:
                        if isinstance(format_map[format_type], tuple):
                            start, end = format_map[format_type]
                            text = text.replace(f"[{format_type}:{item}]", f"{start}{item}{end}")
                elif isinstance(content, str):
                    # Форматируем весь текст
                    if isinstance(format_map[format_type], tuple):
                        start, end = format_map[format_type]
                        text = f"{start}{text}{end}"
    
    # Форматируем текст с учетом ограничений платформы
    formatted_text = format_text(text, preferred_format, max_length)
    
    # Выполняем дополнительные оптимизации для конкретных платформ
    if platform_type == PLATFORM_IOS:
        # iOS может иметь проблемы с длинными сообщениями и некоторыми форматами
        if len(formatted_text) > 2000:
            # Заменяем множественные переносы строк на одинарные
            formatted_text = re.sub(r'\n{3,}', '\n\n', formatted_text)
            # Убираем лишние пробелы
            formatted_text = re.sub(r' {2,}', ' ', formatted_text)
    
    # Логируем информацию о форматировании
    logger.debug(f"Message formatted for {platform_type} v{platform_version} using {preferred_format}")
    
    return formatted_text, preferred_format

def adapt_solution_message(
    problem_text: str, 
    solution_text: str, 
    platform_type: str = PLATFORM_UNKNOWN,
    platform_version: Optional[str] = None
) -> str:
    """
    Адаптирует сообщение с решением математической задачи под платформу пользователя
    
    Args:
        problem_text: Текст задачи
        solution_text: Текст решения
        platform_type: Тип платформы пользователя
        platform_version: Версия платформы пользователя
        
    Returns:
        str: Адаптированное сообщение с решением
    """
    if not problem_text or not solution_text:
        return "Ошибка: пустое сообщение"
    
    # Получаем настройки форматирования
    format_settings = get_message_format_settings(platform_type, platform_version)
    preferred_format = format_settings.get("preferred", "HTML")
    max_length = format_settings.get("max_length", 4096)
    
    # Получаем эмодзи для платформы с учетом версии
    math_emoji = get_emoji("math", platform_type, platform_version)
    
    # Заменяем проблемные символы на совместимые с платформой
    problem_text = replace_problematic_symbols(problem_text, platform_type, platform_version)
    solution_text = replace_problematic_symbols(solution_text, platform_type, platform_version)
    
    # Форматируем текст задачи и решения
    if preferred_format == "HTML":
        header = f"{math_emoji} <b>Задача:</b>\n"
        problem = html.escape(problem_text)
        separator = "\n\n<b>Решение:</b>\n"
        
        # Для iOS делаем более компактное форматирование
        if platform_type == PLATFORM_IOS:
            # Заменяем множественные переносы строк на одинарные
            solution = re.sub(r'\n{3,}', '\n\n', solution_text)
            # Уменьшаем отступы формул
            solution = re.sub(r'\n\s{4,}', '\n  ', solution)
        else:
            solution = solution_text
    else:  # MarkdownV2
        header = f"{math_emoji} *Задача:*\n"
        # Экранируем спецсимволы Markdown
        problem = problem_text
        for char, escape in ESCAPE_CHARS["MarkdownV2"].items():
            problem = problem.replace(char, escape)
        separator = "\n\n*Решение:*\n"
        
        # Адаптируем решение для Markdown
        solution = solution_text
        for char, escape in ESCAPE_CHARS["MarkdownV2"].items():
            solution = solution.replace(char, escape)
    
    # Собираем полное сообщение
    message = header + problem + separator + solution
    
    # Адаптируем длину сообщения под ограничения платформы
    if len(message) > max_length:
        # Для iOS более агрессивное сокращение
        if platform_type == PLATFORM_IOS:
            # Сокращаем вспомогательные шаги в решении
            solution_max_length = max_length - len(header) - len(problem) - len(separator) - 3
            if len(solution) > solution_max_length:
                # Находим последние шаги решения (обычно ответ)
                last_steps = re.split(r'\n(?:Ответ|Итог|Вывод|Результат):', solution)
                if len(last_steps) > 1:
                    # Оставляем только последний шаг с ответом
                    short_solution = "...\n\nОтвет:" + last_steps[-1]
                    if len(short_solution) < solution_max_length:
                        return header + problem + separator + short_solution
                # Если не удалось сократить по шагам, просто обрезаем
                return header + problem + separator + solution[:solution_max_length-3] + "..."
        
        # Для старых Android устройств также делаем более компактное форматирование
        elif platform_type == PLATFORM_ANDROID and platform_version and int(platform_version.split('.')[0]) < 8:
            # Для старых версий Android сокращаем сообщение аналогично iOS
            solution_max_length = max_length - len(header) - len(problem) - len(separator) - 3
            if len(solution) > solution_max_length:
                # Сокращаем вспомогательные шаги
                return header + problem + separator + solution[:solution_max_length-3] + "..."
        
        # Стандартная обработка для других платформ
        total_length = max_length - 3  # Оставляем место для "..."
        
        # Приоритет сохранения решения над задачей
        # Оставляем не менее 1/3 длины для задачи
        min_problem_length = min(len(problem), total_length // 3)
        solution_length = total_length - len(header) - min_problem_length - len(separator)
        
        short_problem = problem[:min_problem_length]
        short_solution = solution[:solution_length]
        
        message = header + short_problem + "..." + separator + short_solution + "..."
    
    return message

def adapt_text_for_platform(
    text: str, 
    platform_type: str = PLATFORM_UNKNOWN,
    platform_version: Optional[str] = None
) -> str:
    """
    Адаптирует обычный текст сообщения для определенной платформы.
    
    Args:
        text: Исходный текст
        platform_type: Тип платформы
        platform_version: Версия платформы
        
    Returns:
        str: Адаптированный текст
    """
    if not text:
        return ""
    
    # Получаем настройки форматирования
    format_settings = get_message_format_settings(platform_type, platform_version)
    max_length = format_settings.get("max_length", 4096)
    
    # Заменяем проблемные символы на совместимые с платформой
    text = replace_problematic_symbols(text, platform_type, platform_version)
    
    # Адаптация длины текста
    if len(text) > max_length:
        text = text[:max_length-3] + "..."
    
    # Платформенно-специфичные оптимизации
    if platform_type == PLATFORM_IOS:
        # Сокращаем множественные переносы строк
        text = re.sub(r'\n{3,}', '\n\n', text)
        # Убираем лишние пробелы в начале строк для iOS
        text = re.sub(r'\n\s{4,}', '\n  ', text)
    elif platform_type == PLATFORM_ANDROID:
        # Для старых версий Android могут быть проблемы с форматированием
        if platform_version and int(platform_version.split('.')[0]) < 8:
            # Упрощаем форматирование для старых версий Android
            text = re.sub(r'\n{2,}', '\n\n', text)
    
    return text