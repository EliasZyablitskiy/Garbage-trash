#!/usr/bin/env python
# coding: utf-8

"""
Интеграционные тесты для сервиса платежей бота Катюша
"""

import unittest
import datetime
import os
import json
from unittest.mock import patch, MagicMock, AsyncMock

import config
from database import get_user, save_user
from services.payment_service import (
    create_external_payment_link,
    create_manual_activation,
    process_payment_notification,
    create_payout_url
)

class TestPaymentService(unittest.TestCase):
    """Тесты сервиса платежей"""
    
    def setUp(self):
        """Настраиваем окружение перед каждым тестом"""
        # Создаем тестовую БД
        self.test_db_path = "test_users_db.json"
        self.test_transactions_path = "test_transactions_db.json"
        
        # Патчим пути к файлам БД
        self.db_patcher = patch('database.DATABASE_PATH', self.test_db_path)
        self.transactions_patcher = patch('database.TRANSACTIONS_PATH', self.test_transactions_path)
        
        self.db_patcher.start()
        self.transactions_patcher.start()
        
        # Создаем пустые тестовые файлы БД
        with open(self.test_db_path, 'w') as f:
            json.dump({"users": {}, "admins": []}, f)
        
        with open(self.test_transactions_path, 'w') as f:
            json.dump({"transactions": [], "weekly_payouts": []}, f)
            
        # Сохраняем оригинальные параметры конфигурации
        self.original_merchant_login = config.ROBOKASSA_MERCHANT_LOGIN
        self.original_secret_key_1 = config.ROBOKASSA_SECRET_KEY_1
        self.original_subscription_price = config.SUBSCRIPTION_PRICE
        
        # Устанавливаем тестовые значения
        config.ROBOKASSA_MERCHANT_LOGIN = "test_merchant"
        config.ROBOKASSA_SECRET_KEY_1 = "test_secret"
        config.SUBSCRIPTION_PRICE = 19900  # 199 RUB в копейках
    
    def tearDown(self):
        """Очищаем окружение после каждого теста"""
        # Останавливаем патчи
        self.db_patcher.stop()
        self.transactions_patcher.stop()
        
        # Удаляем тестовые файлы БД
        if os.path.exists(self.test_db_path):
            os.remove(self.test_db_path)
        
        if os.path.exists(self.test_transactions_path):
            os.remove(self.test_transactions_path)
            
        # Восстанавливаем параметры конфигурации
        config.ROBOKASSA_MERCHANT_LOGIN = self.original_merchant_login
        config.ROBOKASSA_SECRET_KEY_1 = self.original_secret_key_1
        config.SUBSCRIPTION_PRICE = self.original_subscription_price
    
    async def test_create_external_payment_link(self):
        """Тест создания внешней ссылки для оплаты"""
        # Создаем тестового пользователя
        user_data = {
            "id": 1001,
            "username": "payment_test",
            "first_name": "Payment",
            "last_name": "Test",
            "free_request_used": True,
            "subscription_expiry": None
        }
        save_user(user_data)
        
        # Создаем мок-объекты
        update = MagicMock()
        update.effective_user.id = 1001
        update.message.reply_text = AsyncMock()
        
        context = MagicMock()
        
        # Патчим функцию get_base_url
        with patch('config.get_base_url', return_value="https://test.example.com"):
            # Вызываем функцию
            await create_external_payment_link(update, context)
            
            # Проверяем, что сообщение с ссылкой было отправлено
            update.message.reply_text.assert_called_once()
            
            # Проверяем содержимое сообщения (должна быть ссылка на Robokassa)
            call_args = update.message.reply_text.call_args[0][0]
            self.assertIn("https://auth.robokassa.ru/Merchant/Index.aspx", call_args)
            self.assertIn("MerchantLogin=test_merchant", call_args)
    
    async def test_create_manual_activation(self):
        """Тест создания ссылки для ручной активации"""
        # Создаем тестового пользователя
        user_data = {
            "id": 2001,
            "username": "manual_test",
            "first_name": "Manual",
            "last_name": "Test",
            "free_request_used": True,
            "subscription_expiry": None
        }
        save_user(user_data)
        
        # Создаем мок-объекты
        update = MagicMock()
        update.effective_user.id = 2001
        update.message.reply_text = AsyncMock()
        
        context = MagicMock()
        
        # Патчим функцию get_base_url
        with patch('config.get_base_url', return_value="https://test.example.com"):
            # Вызываем функцию
            await create_manual_activation(update, context)
            
            # Проверяем, что сообщение с инструкциями было отправлено
            update.message.reply_text.assert_called_once()
            
            # Проверяем содержимое сообщения (должна быть ссылка на ручную активацию)
            call_args = update.message.reply_text.call_args[0][0]
            self.assertIn("https://test.example.com/payment", call_args)
            self.assertIn("user_id=2001", call_args)
    
    def test_process_payment_notification(self):
        """Тест обработки уведомления об оплате"""
        # Создаем тестового пользователя
        user_data = {
            "id": 3001,
            "username": "notification_test",
            "first_name": "Notification",
            "last_name": "Test",
            "free_request_used": True,
            "subscription_expiry": None
        }
        save_user(user_data)
        
        # Создаем параметры уведомления
        notification_params = {
            "OutSum": "199.00",
            "InvId": "1001",  # ID заказа
            "SignatureValue": "test_signature",  # Подпись
            "UserId": "3001"  # ID пользователя
        }
        
        # Патчим функцию verify_signature
        with patch('services.payment_service.verify_robokassa_signature', return_value=True):
            # Патчим add_transaction
            with patch('services.payment_service.add_transaction', return_value=1001):
                # Патчим update_user_subscription
                with patch('services.payment_service.update_user_subscription') as mock_update:
                    # Вызываем функцию
                    result = process_payment_notification(notification_params)
                    
                    # Проверяем результат
                    self.assertTrue(result)
                    
                    # Проверяем, что подписка обновлена
                    mock_update.assert_called_once()
                    
                    # Проверяем, что правильный пользователь получил обновление
                    self.assertEqual(mock_update.call_args[0][0], 3001)
    
    def test_create_payout_url(self):
        """Тест создания URL для выплаты вознаграждения"""
        # Создаем тестового пользователя
        user_data = {
            "id": 4001,
            "username": "payout_test",
            "first_name": "Payout",
            "last_name": "Test",
            "free_request_used": True,
            "subscription_expiry": None
        }
        save_user(user_data)
        
        # Патчим функцию get_base_url
        with patch('config.get_base_url', return_value="https://test.example.com"):
            # Вызываем функцию
            url = create_payout_url(4001, 100.0, 1001)
            
            # Проверяем URL
            self.assertIn("https://test.example.com/payout", url)
            self.assertIn("user_id=4001", url)
            self.assertIn("amount=100.0", url)
            self.assertIn("transaction_id=1001", url)


if __name__ == '__main__':
    unittest.main() 