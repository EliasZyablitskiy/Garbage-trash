import os
import json
import unittest
from unittest.mock import patch, mock_open
import pytest
import sys
import tempfile
import shutil
from datetime import datetime, timedelta

# Import database functions to test
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from database import (
    load_users_db, save_users_db, get_user_data, save_user_data,
    get_transaction_data, save_transaction_data, get_all_users_data,
    get_all_transactions, create_transaction, update_transaction,
    update_user_data, get_transactions_db, save_transactions_db,
    get_transaction, get_user_transactions, get_pending_payouts,
    record_referral_reward, process_pending_payouts, calculate_referral_reward
)

# Test data
MOCK_USERS_DB = {
    "123456": {
        "id": 123456,
        "username": "test_user",
        "first_name": "Test",
        "last_name": "User",
        "subscription_end": None,
        "subscription_type": None,
        "referral_code": "ABC123",
        "referrer_id": None,
        "referrals": [],
        "level_1_referrals": [],
        "level_2_referrals": [],
        "level_3_referrals": [],
        "level_4_referrals": [],
        "total_earned": 0
    },
    "789012": {
        "id": 789012,
        "username": "referrer",
        "first_name": "Ref",
        "last_name": "User",
        "subscription_end": "2023-12-31",
        "subscription_type": "premium",
        "referral_code": "XYZ789",
        "referrer_id": None,
        "referrals": [123456],
        "level_1_referrals": [123456],
        "level_2_referrals": [],
        "level_3_referrals": [],
        "level_4_referrals": [],
        "total_earned": 100
    }
}

MOCK_TRANSACTIONS_DB = {
    "tx_1": {
        "id": "tx_1",
        "user_id": 123456,
        "amount": 100,
        "type": "subscription",
        "status": "completed",
        "created_at": "2023-10-15",
        "updated_at": "2023-10-15",
        "description": "Monthly subscription"
    },
    "tx_2": {
        "id": "tx_2",
        "user_id": 789012,
        "amount": 50,
        "type": "referral_reward",
        "status": "pending",
        "created_at": "2023-10-16",
        "updated_at": "2023-10-16",
        "description": "Referral reward for user 123456"
    }
}


class TestDatabaseFunctions(unittest.TestCase):
    
    def setUp(self):
        """Set up test environment before each test"""
        # Create a temporary directory for test files
        self.test_dir = tempfile.mkdtemp()
        
        # Create mock data
        self.mock_users = {
            "12345": {
                "id": 12345,
                "username": "testuser",
                "first_name": "Test User",
                "subscription_end": None,
                "subscription_type": None,
                "referrals": [],
                "referred_by": None,
                "referral_levels": {},
                "total_earned": 0
            },
            "67890": {
                "id": 67890,
                "username": "referrer",
                "first_name": "Referrer User",
                "subscription_end": (datetime.now() + timedelta(days=30)).isoformat(),
                "subscription_type": "monthly",
                "referrals": ["12345"],
                "referred_by": None,
                "referral_levels": {"1": ["12345"]},
                "total_earned": 50
            }
        }
        
        self.mock_transactions = {
            "trans1": {
                "id": "trans1",
                "user_id": 12345,
                "amount": 100.0,
                "type": "subscription",
                "status": "completed",
                "details": "Monthly subscription",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            },
            "trans2": {
                "id": "trans2",
                "user_id": 67890,
                "amount": 50.0,
                "type": "referral_reward",
                "status": "pending_payout",
                "details": "Referral reward for user 12345",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "referral_data": {
                    "referred_user_id": 12345,
                    "level": 1
                }
            }
        }
        
        # Create paths for mock files
        self.users_db_path = os.path.join(self.test_dir, "users_db.json")
        self.transactions_db_path = os.path.join(self.test_dir, "transactions_db.json")
        
        # Write mock data to files
        with open(self.users_db_path, 'w') as f:
            json.dump(self.mock_users, f)
        
        with open(self.transactions_db_path, 'w') as f:
            json.dump(self.mock_transactions, f)
    
    def tearDown(self):
        """Clean up test environment after each test"""
        # Remove the temporary directory and its contents
        shutil.rmtree(self.test_dir)
    
    @patch("database.USERS_DB_FILE")
    def test_load_users_db(self, mock_db_file):
        """Test loading the users database"""
        mock_db_file.return_value = self.users_db_path
        
        # Call the function
        users = load_users_db()
        
        # Assertions
        self.assertEqual(users, self.mock_users)
        self.assertEqual(len(users), 2)
        self.assertEqual(users["12345"]["username"], "testuser")
    
    @patch("database.USERS_DB_FILE")
    @patch("database.load_users_db")
    def test_get_user_data(self, mock_load_users_db, mock_db_file):
        """Test retrieving user data"""
        mock_db_file.return_value = self.users_db_path
        mock_load_users_db.return_value = self.mock_users
        
        # Call the function
        user = get_user_data(12345)
        
        # Assertions
        self.assertEqual(user["id"], 12345)
        self.assertEqual(user["username"], "testuser")
        
        # Test with non-existent user
        user = get_user_data(99999)
        self.assertIsNone(user)
    
    @patch("database.USERS_DB_FILE")
    @patch("database.load_users_db")
    @patch("database.save_users_db")
    def test_update_user_data(self, mock_save_users_db, mock_load_users_db, mock_db_file):
        """Test updating user data"""
        mock_db_file.return_value = self.users_db_path
        mock_load_users_db.return_value = self.mock_users.copy()
        
        # Prepare update data
        update_data = {
            "subscription_type": "annual",
            "subscription_end": (datetime.now() + timedelta(days=365)).isoformat()
        }
        
        # Call the function
        result = update_user_data(12345, update_data)
        
        # Assertions
        self.assertTrue(result)
        mock_save_users_db.assert_called_once()
        
        # Verify the call args to save_users_db
        updated_users = mock_save_users_db.call_args[0][0]
        self.assertEqual(updated_users["12345"]["subscription_type"], "annual")
    
    @patch("database.TRANSACTIONS_DB_FILE")
    def test_get_transactions_db(self, mock_db_file):
        """Test loading the transactions database"""
        mock_db_file.return_value = self.transactions_db_path
        
        # Call the function
        transactions = get_transactions_db()
        
        # Assertions
        self.assertEqual(transactions, self.mock_transactions)
        self.assertEqual(len(transactions), 2)
        self.assertEqual(transactions["trans1"]["user_id"], 12345)
    
    @patch("database.TRANSACTIONS_DB_FILE")
    @patch("database.get_transactions_db")
    @patch("database.save_transactions_db")
    @patch("database.uuid.uuid4")
    def test_create_transaction(self, mock_uuid, mock_save_transactions_db, 
                               mock_get_transactions_db, mock_db_file):
        """Test creating a new transaction"""
        mock_db_file.return_value = self.transactions_db_path
        mock_get_transactions_db.return_value = self.mock_transactions.copy()
        mock_uuid.return_value = MagicMock(hex="newtrans")
        
        # Call the function
        transaction_id = create_transaction(
            user_id=12345,
            amount=200.0,
            transaction_type="subscription",
            status="pending",
            details="Annual subscription"
        )
        
        # Assertions
        self.assertEqual(transaction_id, "newtrans")
        mock_save_transactions_db.assert_called_once()
        
        # Verify the new transaction was added correctly
        updated_transactions = mock_save_transactions_db.call_args[0][0]
        self.assertIn("newtrans", updated_transactions)
        self.assertEqual(updated_transactions["newtrans"]["user_id"], 12345)
        self.assertEqual(updated_transactions["newtrans"]["amount"], 200.0)
    
    @patch("database.TRANSACTIONS_DB_FILE")
    @patch("database.get_transactions_db")
    @patch("database.save_transactions_db")
    def test_update_transaction(self, mock_save_transactions_db, 
                               mock_get_transactions_db, mock_db_file):
        """Test updating a transaction"""
        mock_db_file.return_value = self.transactions_db_path
        mock_get_transactions_db.return_value = self.mock_transactions.copy()
        
        # Call the function
        result = update_transaction(
            transaction_id="trans1",
            update_data={"status": "refunded", "details": "Refund processed"}
        )
        
        # Assertions
        self.assertTrue(result)
        mock_save_transactions_db.assert_called_once()
        
        # Verify the transaction was updated correctly
        updated_transactions = mock_save_transactions_db.call_args[0][0]
        self.assertEqual(updated_transactions["trans1"]["status"], "refunded")
        self.assertEqual(updated_transactions["trans1"]["details"], "Refund processed")
    
    @patch("database.TRANSACTIONS_DB_FILE")
    @patch("database.get_transactions_db")
    def test_get_transaction(self, mock_get_transactions_db, mock_db_file):
        """Test retrieving a specific transaction"""
        mock_db_file.return_value = self.transactions_db_path
        mock_get_transactions_db.return_value = self.mock_transactions
        
        # Call the function
        transaction = get_transaction("trans1")
        
        # Assertions
        self.assertEqual(transaction["id"], "trans1")
        self.assertEqual(transaction["user_id"], 12345)
        
        # Test with non-existent transaction
        transaction = get_transaction("nonexistent")
        self.assertIsNone(transaction)
    
    @patch("database.TRANSACTIONS_DB_FILE")
    @patch("database.get_transactions_db")
    def test_get_user_transactions(self, mock_get_transactions_db, mock_db_file):
        """Test retrieving all transactions for a user"""
        mock_db_file.return_value = self.transactions_db_path
        mock_get_transactions_db.return_value = self.mock_transactions
        
        # Call the function
        transactions = get_user_transactions(12345)
        
        # Assertions
        self.assertEqual(len(transactions), 1)
        self.assertEqual(transactions[0]["id"], "trans1")
        
        # Test filtering by type
        transactions = get_user_transactions(67890, transaction_type="referral_reward")
        self.assertEqual(len(transactions), 1)
        self.assertEqual(transactions[0]["id"], "trans2")
        
        # Test filtering by status
        transactions = get_user_transactions(67890, status="pending_payout")
        self.assertEqual(len(transactions), 1)
        self.assertEqual(transactions[0]["id"], "trans2")
    
    @patch("database.TRANSACTIONS_DB_FILE")
    @patch("database.get_transactions_db")
    def test_get_pending_payouts(self, mock_get_transactions_db, mock_db_file):
        """Test retrieving pending payout transactions"""
        mock_db_file.return_value = self.transactions_db_path
        mock_get_transactions_db.return_value = self.mock_transactions
        
        # Call the function
        payouts = get_pending_payouts()
        
        # Assertions
        self.assertEqual(len(payouts), 1)
        self.assertEqual(payouts[0]["id"], "trans2")
        self.assertEqual(payouts[0]["status"], "pending_payout")
    
    @patch("database.config")
    def test_calculate_referral_reward(self, mock_config):
        """Test calculating referral rewards based on level"""
        # Set up mock config
        mock_config.REFERRAL_RATES = {
            "1": 0.05,  # 5% for level 1
            "2": 0.02,  # 2% for level 2
            "3": 0.02,  # 2% for level 3
            "4": 0.02   # 2% for level 4
        }
        
        # Test first level reward (5%)
        reward = calculate_referral_reward(100.0, 1)
        self.assertEqual(reward, 5.0)
        
        # Test second level reward (2%)
        reward = calculate_referral_reward(100.0, 2)
        self.assertEqual(reward, 2.0)
        
        # Test invalid level (should return 0)
        reward = calculate_referral_reward(100.0, 5)
        self.assertEqual(reward, 0.0)
    
    @patch("database.USERS_DB_FILE")
    @patch("database.TRANSACTIONS_DB_FILE")
    @patch("database.load_users_db")
    @patch("database.get_transactions_db")
    @patch("database.save_users_db")
    @patch("database.save_transactions_db")
    @patch("database.uuid.uuid4")
    @patch("database.calculate_referral_reward")
    def test_record_referral_reward(
        self, mock_calculate_reward, mock_uuid, mock_save_transactions_db, 
        mock_save_users_db, mock_get_transactions_db, mock_load_users_db, 
        mock_transactions_file, mock_users_file
    ):
        """Test recording a referral reward"""
        # Setup mocks
        mock_users_file.return_value = self.users_db_path
        mock_transactions_file.return_value = self.transactions_db_path
        mock_load_users_db.return_value = self.mock_users.copy()
        mock_get_transactions_db.return_value = self.mock_transactions.copy()
        mock_uuid.return_value = MagicMock(hex="reward_trans")
        mock_calculate_reward.return_value = 5.0
        
        # Call the function
        transaction_id = record_referral_reward(
            referrer_id=67890,
            referred_user_id=12345,
            subscription_amount=100.0,
            level=1
        )
        
        # Assertions
        self.assertEqual(transaction_id, "reward_trans")
        mock_calculate_reward.assert_called_once_with(100.0, 1)
        
        # Verify the user's total_earned was updated
        updated_users = mock_save_users_db.call_args[0][0]
        self.assertEqual(updated_users["67890"]["total_earned"], 55.0)  # 50 + 5
        
        # Verify the transaction was created correctly
        updated_transactions = mock_save_transactions_db.call_args[0][0]
        self.assertIn("reward_trans", updated_transactions)
        self.assertEqual(updated_transactions["reward_trans"]["user_id"], 67890)
        self.assertEqual(updated_transactions["reward_trans"]["amount"], 5.0)
        self.assertEqual(updated_transactions["reward_trans"]["type"], "referral_reward")
        self.assertEqual(updated_transactions["reward_trans"]["status"], "pending_payout")
    
    @patch("database.TRANSACTIONS_DB_FILE")
    @patch("database.get_transactions_db")
    @patch("database.save_transactions_db")
    @patch("database.get_pending_payouts")
    @patch("database.process_payout")
    def test_process_pending_payouts(
        self, mock_process_payout, mock_get_pending_payouts, 
        mock_save_transactions_db, mock_get_transactions_db, mock_transactions_file
    ):
        """Test processing all pending payouts"""
        # Setup mocks
        mock_transactions_file.return_value = self.transactions_db_path
        
        # Create a copy of transactions that we can modify
        transactions_copy = self.mock_transactions.copy()
        mock_get_transactions_db.return_value = transactions_copy
        
        # Mock pending payouts
        pending_payout = self.mock_transactions["trans2"].copy()
        mock_get_pending_payouts.return_value = [pending_payout]
        
        # Mock successful payout
        mock_process_payout.return_value = True
        
        # Call the function
        results = process_pending_payouts("test_method", "test_details")
        
        # Assertions
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["transaction_id"], "trans2")
        self.assertEqual(results[0]["success"], True)
        
        # Verify payout was processed
        mock_process_payout.assert_called_once_with(
            67890, 50.0, "test_method", "test_details", "trans2"
        )
        
        # Mock failed payout
        mock_process_payout.reset_mock()
        mock_process_payout.return_value = False
        
        # Call the function again
        results = process_pending_payouts("test_method", "test_details")
        
        # Assertions for failed payout
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["transaction_id"], "trans2")
        self.assertEqual(results[0]["success"], False)


if __name__ == "__main__":
    pytest.main() 