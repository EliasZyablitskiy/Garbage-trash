#!/usr/bin/env python
# coding: utf-8

"""
Адаптер для плавного перехода со старого сервиса уведомлений на новый расширенный сервис
"""

import logging
import functools
from typing import Dict, Any, Optional, Callable, Awaitable
import datetime

from sqlalchemy.ext.asyncio import AsyncSession
from telegram import Bot

# Импортируем оба сервиса
from services.notification_service import (
    NotificationManager, 
    NotificationType, 
    get_notification_manager,
    NotificationTemplates
)
try:
    from services.enhanced_notification_service import (
        EnhancedNotificationService,
        get_enhanced_notification_service
    )
    ENHANCED_SERVICE_AVAILABLE = True
except ImportError:
    ENHANCED_SERVICE_AVAILABLE = False

logger = logging.getLogger(__name__)

# Настройка переключения между сервисами
USE_ENHANCED_SERVICE = True
FALLBACK_TO_LEGACY = True  # Если улучшенный сервис не сработал, использовать старый


async def send_notification(
    user_id: int,
    notification_type: str,
    context: Dict[str, Any] = None,
    bot: Optional[Bot] = None,
    use_enhanced: Optional[bool] = None
) -> bool:
    """
    Универсальный адаптер для отправки уведомлений
    
    Args:
        user_id: ID пользователя
        notification_type: Тип уведомления
        context: Контекст уведомления
        bot: Экземпляр бота Telegram
        use_enhanced: Принудительно использовать улучшенный сервис
        
    Returns:
        bool: Успешность отправки
    """
    if context is None:
        context = {}
    
    # Определяем, какой сервис использовать
    should_use_enhanced = USE_ENHANCED_SERVICE if use_enhanced is None else use_enhanced
    
    # Проверяем доступность улучшенного сервиса
    if should_use_enhanced and ENHANCED_SERVICE_AVAILABLE:
        try:
            # Получаем улучшенный сервис
            enhanced_service = get_enhanced_notification_service(bot)
            if enhanced_service:
                # Отправляем через улучшенный сервис
                success = await enhanced_service.send_notification(
                    user_id=user_id,
                    notification_type=notification_type,
                    context=context
                )
                if success:
                    return True
                elif not FALLBACK_TO_LEGACY:
                    return False
                # Если не удалось, и FALLBACK_TO_LEGACY=True, продолжаем на старом сервисе
            else:
                logger.warning("Enhanced notification service not initialized")
        except Exception as e:
            logger.error(f"Error using enhanced notification service: {e}")
            if not FALLBACK_TO_LEGACY:
                return False
    
    # Отправляем через старый сервис (по умолчанию или если улучшенный не сработал)
    try:
        notification_manager = get_notification_manager(bot)
        
        # В старом сервисе используется другая логика, преобразуем типы
        if notification_type == NotificationType.PAYMENT_SUCCESSFUL:
            template = NotificationTemplates.PAYMENT_SUCCESS
        elif notification_type == NotificationType.PAYMENT_FAILED:
            template = NotificationTemplates.PAYMENT_ERROR
        elif notification_type == NotificationType.REFERRAL_REWARD:
            template = NotificationTemplates.REFERRAL_REWARD
        elif notification_type == NotificationType.PAYOUT_PROCESSING:
            template = NotificationTemplates.PAYOUT_INITIATED
        elif notification_type == NotificationType.PAYOUT_COMPLETED:
            template = NotificationTemplates.PAYOUT_COMPLETED
        elif notification_type == NotificationType.PAYOUT_FAILED:
            template = NotificationTemplates.PAYOUT_FAILED
        elif notification_type == NotificationType.SUBSCRIPTION_EXPIRING:
            template = NotificationTemplates.SUBSCRIPTION_EXPIRY
        elif notification_type == NotificationType.SYSTEM:
            template = NotificationTemplates.SYSTEM_NOTIFICATION
        else:
            # Для других типов используем системное уведомление с текстом
            template = NotificationTemplates.SYSTEM_NOTIFICATION
            context['message'] = f"Уведомление типа: {notification_type}"
        
        return await notification_manager.send_template(user_id, template, context)
    except Exception as e:
        logger.error(f"Error using legacy notification service: {e}")
        return False


async def notify_users_about_available_payouts(
    session: AsyncSession, 
    bot: Bot
) -> int:
    """
    Уведомление пользователей о доступных выплатах
    
    Args:
        session: Сессия базы данных
        bot: Экземпляр бота Telegram
        
    Returns:
        int: Количество отправленных уведомлений
    """
    if ENHANCED_SERVICE_AVAILABLE and USE_ENHANCED_SERVICE:
        try:
            enhanced_service = get_enhanced_notification_service(bot)
            if enhanced_service:
                return await enhanced_service.notify_users_about_available_payouts(session)
        except Exception as e:
            logger.error(f"Error using enhanced notification service for payouts: {e}")
    
    # Если улучшенный сервис недоступен или не сработал, используем базовую реализацию
    logger.warning("Using basic implementation for notifying about available payouts")
    return 0  # Базовая реализация не поддерживает эту функцию


async def notify_users_about_expiring_subscriptions(
    session: AsyncSession, 
    bot: Bot, 
    days_threshold: int = 3
) -> int:
    """
    Уведомление пользователей об истекающих подписках
    
    Args:
        session: Сессия базы данных
        bot: Экземпляр бота Telegram
        days_threshold: За сколько дней до истечения подписки отправлять уведомление
        
    Returns:
        int: Количество отправленных уведомлений
    """
    if ENHANCED_SERVICE_AVAILABLE and USE_ENHANCED_SERVICE:
        try:
            enhanced_service = get_enhanced_notification_service(bot)
            if enhanced_service:
                return await enhanced_service.notify_users_about_expiring_subscriptions(
                    session, days_threshold
                )
        except Exception as e:
            logger.error(f"Error using enhanced notification service for expiring subscriptions: {e}")
    
    # Если улучшенный сервис недоступен или не сработал, используем базовую реализацию
    logger.warning("Using basic implementation for notifying about expiring subscriptions")
    return 0  # Базовая реализация не поддерживает эту функцию