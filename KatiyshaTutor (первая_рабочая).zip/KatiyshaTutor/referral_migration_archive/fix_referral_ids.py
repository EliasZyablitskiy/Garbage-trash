#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для поиска и исправления проблемных referrer_id в базе данных
"""

import json
import logging
import os
import sys
from datetime import datetime
from typing import Dict, List, Any, Tuple, Optional

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def load_database(path: str = "users_db.json") -> Dict[str, Any]:
    """
    Загружает базу данных пользователей из JSON файла
    
    Args:
        path: Путь к файлу базы данных
        
    Returns:
        Dict[str, Any]: Загруженная база данных
    """
    try:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as file:
                return json.load(file)
        else:
            logger.error(f"База данных по пути {path} не найдена")
            return {"users": {}}
    except Exception as e:
        logger.error(f"Ошибка загрузки базы данных: {e}")
        return {"users": {}}

def save_database(db: Dict[str, Any], path: str = "users_db.json") -> None:
    """
    Сохраняет базу данных пользователей в JSON файл
    
    Args:
        db: База данных для сохранения
        path: Путь к файлу базы данных
    """
    try:
        # Создаем резервную копию перед сохранением
        if os.path.exists(path):
            backup_path = f"{path}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            with open(backup_path, 'w', encoding='utf-8') as file:
                with open(path, 'r', encoding='utf-8') as original:
                    file.write(original.read())
            logger.info(f"Создана резервная копия базы данных: {backup_path}")
            
        # Сохраняем обновленную базу данных
        with open(path, 'w', encoding='utf-8') as file:
            json.dump(db, file, ensure_ascii=False, indent=2)
        logger.info(f"База данных успешно сохранена в {path}")
    except Exception as e:
        logger.error(f"Ошибка сохранения базы данных: {e}")

def find_and_fix_referrer_ids(db: Dict[str, Any]) -> Tuple[int, int, List[str]]:
    """
    Находит и исправляет проблемные referrer_id в базе данных
    
    Args:
        db: База данных для проверки и исправления
        
    Returns:
        Tuple[int, int, List[str]]: Количество проверенных пользователей, 
                                    количество исправленных записей,
                                    список исправленных user_ids
    """
    checked_count = 0
    fixed_count = 0
    fixed_user_ids = []
    
    for user_id, user_data in db.get("users", {}).items():
        checked_count += 1
        referrer_id = user_data.get("referrer_id")
        
        # Пропускаем, если referrer_id отсутствует или уже является числом
        if referrer_id is None or isinstance(referrer_id, int):
            continue
        
        # Если referrer_id - строка, проверяем что это за строка
        if isinstance(referrer_id, str):
            # Если строка начинается с 'r', извлекаем числовую часть
            if referrer_id.startswith('r') and len(referrer_id) > 1:
                numeric_part = ''.join(c for c in referrer_id if c.isdigit())
                if numeric_part:
                    # Преобразуем в число и сохраняем
                    new_referrer_id = int(numeric_part)
                    user_data["referrer_id"] = new_referrer_id
                    fixed_count += 1
                    fixed_user_ids.append(user_id)
                    logger.info(f"Исправлен referrer_id: {referrer_id} -> {new_referrer_id} для пользователя {user_id}")
                else:
                    logger.warning(f"Невозможно извлечь числовую часть из referrer_id '{referrer_id}' для пользователя {user_id}")
            
            # Если строка содержит только цифры, преобразуем в число
            elif referrer_id.isdigit():
                new_referrer_id = int(referrer_id)
                user_data["referrer_id"] = new_referrer_id
                fixed_count += 1
                fixed_user_ids.append(user_id)
                logger.info(f"Исправлен referrer_id: {referrer_id} -> {new_referrer_id} для пользователя {user_id}")
            
            # Если это некорректная строка, логируем проблему
            else:
                logger.error(f"Некорректный формат referrer_id: '{referrer_id}' для пользователя {user_id}")
    
    return checked_count, fixed_count, fixed_user_ids

def analyze_database(db: Dict[str, Any]) -> Dict[str, Any]:
    """
    Анализирует базу данных на наличие проблем с referrer_id
    
    Args:
        db: База данных для анализа
        
    Returns:
        Dict[str, Any]: Результаты анализа
    """
    results = {
        "total_users": 0,
        "users_with_referrer_id": 0,
        "problematic_referrer_ids": 0,
        "referrer_id_types": {},
        "problematic_examples": []
    }
    
    for user_id, user_data in db.get("users", {}).items():
        results["total_users"] += 1
        referrer_id = user_data.get("referrer_id")
        
        if referrer_id is not None:
            results["users_with_referrer_id"] += 1
            
            # Подсчитываем типы referrer_id
            referrer_id_type = type(referrer_id).__name__
            results["referrer_id_types"][referrer_id_type] = results["referrer_id_types"].get(referrer_id_type, 0) + 1
            
            # Проверяем на проблемные значения
            if isinstance(referrer_id, str):
                if referrer_id.startswith('r') or not referrer_id.isdigit():
                    results["problematic_referrer_ids"] += 1
                    
                    # Добавляем пример проблемного значения, если их мало
                    if len(results["problematic_examples"]) < 10:
                        results["problematic_examples"].append({
                            "user_id": user_id,
                            "referrer_id": referrer_id,
                            "referrer_id_type": referrer_id_type
                        })
    
    return results

def main() -> None:
    """
    Основная функция
    """
    # Подключаем необходимые модули
    from datetime import datetime
    
    logger.info("Запуск скрипта исправления referrer_id")
    
    # Получаем путь к базе данных из аргументов или используем значение по умолчанию
    db_path = sys.argv[1] if len(sys.argv) > 1 else "users_db.json"
    
    # Загружаем базу данных
    db = load_database(db_path)
    
    # Анализируем базу данных
    analysis_results = analyze_database(db)
    logger.info("Результаты анализа базы данных:")
    logger.info(f"Всего пользователей: {analysis_results['total_users']}")
    logger.info(f"Пользователей с referrer_id: {analysis_results['users_with_referrer_id']}")
    logger.info(f"Проблемных referrer_id: {analysis_results['problematic_referrer_ids']}")
    logger.info(f"Типы referrer_id: {analysis_results['referrer_id_types']}")
    
    if analysis_results["problematic_examples"]:
        logger.info("Примеры проблемных значений:")
        for example in analysis_results["problematic_examples"]:
            logger.info(f"  User ID: {example['user_id']}, Referrer ID: {example['referrer_id']} (тип: {example['referrer_id_type']})")
    
    # Если проблемных значений нет, выходим
    if analysis_results["problematic_referrer_ids"] == 0:
        logger.info("Проблемных значений не обнаружено, исправление не требуется")
        return
    
    # Спрашиваем подтверждение перед исправлением
    confirm = input(f"Обнаружено {analysis_results['problematic_referrer_ids']} проблемных значений. Исправить? (y/n): ")
    if confirm.lower() != 'y':
        logger.info("Операция отменена пользователем")
        return
    
    # Исправляем проблемные значения
    checked_count, fixed_count, fixed_user_ids = find_and_fix_referrer_ids(db)
    
    # Если были исправления, сохраняем базу данных
    if fixed_count > 0:
        save_database(db, db_path)
        logger.info(f"Проверено {checked_count} пользователей, исправлено {fixed_count} записей")
        logger.info(f"Исправленные user_ids: {fixed_user_ids[:10]}{'...' if len(fixed_user_ids) > 10 else ''}")
    else:
        logger.info("Не было произведено исправлений")

if __name__ == "__main__":
    main()