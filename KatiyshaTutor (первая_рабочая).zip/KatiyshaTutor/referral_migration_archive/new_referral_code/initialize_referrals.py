#!/usr/bin/env python
# coding: utf-8

"""
A script to initialize referral fields for existing users
"""

import json
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def initialize_referrals():
    """
    Initialize referral fields for all existing users
    """
    # Load the database
    try:
        with open('users_db.json', 'r', encoding='utf-8') as f:
            db = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.error(f"Failed to load database: {e}")
        return
    
    logger.info(f"Loaded database with {len(db.get('users', {}))} users")
    
    # Update each user's data
    users_updated = 0
    for user_id, user_data in db.get('users', {}).items():
        updated = False
        
        # Add referral_code if missing
        if 'referral_code' not in user_data:
            user_data['referral_code'] = None
            updated = True
        
        # Add referrer_id if missing
        if 'referrer_id' not in user_data:
            user_data['referrer_id'] = None
            updated = True
        
        # Add referrals if missing
        if 'referrals' not in user_data:
            user_data['referrals'] = {
                "level1": [],  # 5% (прямые рефералы)
                "level2": [],  # 2% (рефералы 2-го уровня)
                "level3": [],  # 2% (рефералы 3-го уровня)
                "level4": [],  # 2% (рефералы 4-го уровня)
            }
            updated = True
        
        # Make sure referrals is the correct structure
        if 'referrals' in user_data and isinstance(user_data['referrals'], dict):
            for level in ['level1', 'level2', 'level3', 'level4']:
                if level not in user_data['referrals']:
                    user_data['referrals'][level] = []
                    updated = True
                elif not isinstance(user_data['referrals'][level], list):
                    user_data['referrals'][level] = []
                    updated = True
        
        if updated:
            users_updated += 1
    
    logger.info(f"Updated {users_updated} users with referral fields")
    
    # Save the database
    try:
        with open('users_db.json', 'w', encoding='utf-8') as f:
            json.dump(db, f, ensure_ascii=False, indent=2)
        logger.info("Database saved successfully")
    except Exception as e:
        logger.error(f"Failed to save database: {e}")

if __name__ == '__main__':
    initialize_referrals()