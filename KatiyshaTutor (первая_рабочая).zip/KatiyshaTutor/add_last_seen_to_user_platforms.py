#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для добавления колонки last_seen в таблицу user_platforms
"""

import os
import logging
from datetime import datetime
from sqlalchemy import create_engine, Column, DateTime
from sqlalchemy.sql import text

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def add_last_seen_column():
    """
    Добавляет колонку last_seen в таблицу user_platforms
    """
    try:
        # Получаем URL для подключения к базе данных из переменной окружения
        db_url = os.environ.get('DATABASE_URL')
        if not db_url:
            logger.error('Переменная окружения DATABASE_URL не найдена')
            return False
        
        # Создаем подключение к базе данных
        engine = create_engine(db_url)
        
        # Проверяем существование колонки перед добавлением
        with engine.connect() as connection:
            result = connection.execute(text("SELECT column_name FROM information_schema.columns WHERE table_name = 'user_platforms' AND column_name = 'last_seen'"))
            column_exists = result.fetchone() is not None
            
            if column_exists:
                logger.info('Колонка last_seen уже существует в таблице user_platforms')
                return True
            
            # Добавляем колонку last_seen
            logger.info('Добавление колонки last_seen в таблицу user_platforms...')
            connection.execute(text("ALTER TABLE user_platforms ADD COLUMN last_seen TIMESTAMP WITHOUT TIME ZONE DEFAULT now()"))
            connection.commit()
            
            logger.info('Колонка last_seen успешно добавлена')
            return True
            
    except Exception as e:
        logger.error(f'Ошибка при добавлении колонки last_seen: {e}')
        return False

def main():
    """
    Основная функция
    """
    logger.info('Запуск миграции для добавления колонки last_seen в таблицу user_platforms')
    success = add_last_seen_column()
    if success:
        logger.info('Миграция успешно завершена')
    else:
        logger.error('Миграция завершилась с ошибкой')

if __name__ == '__main__':
    main()