#!/usr/bin/env python
# coding: utf-8

"""
Тестовый скрипт для проверки новой реферальной системы
"""

import logging
import os
import sys
import json
from typing import Dict, Any, Optional

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

from referral_manager import ReferralManager

def test_referral_generation():
    """
    Тестирует генерацию реферального кода и ссылки
    """
    manager = ReferralManager()
    user_id = 999999  # Тестовый ID пользователя
    
    # Создаем тестового пользователя
    test_user_data = {
        "id": user_id,
        "username": "test_user",
        "first_name": "Test",
        "last_name": "User",
        "free_request_used": False,
        "subscription_expiry": None,
        "referral_code": None,
        "referrer_id": None,
        "referrals": {
            "level1": [],
            "level2": [],
            "level3": [],
            "level4": []
        }
    }
    
    # Сохраняем пользователя
    manager.save_user(test_user_data)
    
    # Генерируем реферальный код и ссылку
    bot_username = "Katiysha_bot"  # Имя бота
    referral_link = manager.get_referral_link(user_id, bot_username)
    
    # Получаем обновленные данные пользователя
    updated_user = manager.get_user(user_id)
    
    logger.info(f"Создан тестовый пользователь с ID {user_id}")
    logger.info(f"Сгенерирована реферальная ссылка: {referral_link}")
    logger.info(f"Реферальный код: {updated_user.get('referral_code')}")
    
    return updated_user.get('referral_code')

def test_referral_tracking():
    """
    Тестирует отслеживание рефералов
    """
    manager = ReferralManager()
    referrer_id = 888888  # ID реферера
    referred_id = 777777  # ID реферала
    
    # Создаем реферера
    referrer_data = {
        "id": referrer_id,
        "username": "referrer_user",
        "first_name": "Referrer",
        "last_name": "User",
        "free_request_used": False,
        "subscription_expiry": None,
        "referral_code": "ref_test123_" + str(referrer_id),
        "referrer_id": None,
        "referrals": {
            "level1": [],
            "level2": [],
            "level3": [],
            "level4": []
        }
    }
    
    # Создаем реферала
    referred_data = {
        "id": referred_id,
        "username": "referred_user",
        "first_name": "Referred",
        "last_name": "User",
        "free_request_used": False,
        "subscription_expiry": None,
        "referral_code": None,
        "referrer_id": None,
        "referrals": {
            "level1": [],
            "level2": [],
            "level3": [],
            "level4": []
        }
    }
    
    # Сохраняем пользователей
    manager.save_user(referrer_data)
    manager.save_user(referred_data)
    
    logger.info(f"Создан тестовый реферер с ID {referrer_id}")
    logger.info(f"Создан тестовый реферал с ID {referred_id}")
    
    # Обрабатываем реферальный код
    success = manager.process_new_referral(referred_id, referrer_data["referral_code"])
    
    # Проверяем результаты
    updated_referrer = manager.get_user(referrer_id)
    updated_referred = manager.get_user(referred_id)
    
    logger.info(f"Результат обработки реферального кода: {'Успешно' if success else 'Ошибка'}")
    
    if success:
        logger.info(f"Реферал {referred_id} добавлен к рефереру {referrer_id}")
        logger.info(f"Рефералы 1-го уровня реферера: {updated_referrer['referrals']['level1']}")
        logger.info(f"Реферер пользователя {referred_id}: {updated_referred['referrer_id']}")
    
    return success

def test_reward_calculation():
    """
    Тестирует расчет вознаграждений при активации подписки
    """
    manager = ReferralManager()
    
    # Создаем цепочку рефералов: main_referrer -> level1 -> level2 -> level3 -> subscriber
    main_referrer_id = 100001
    level1_id = 100002
    level2_id = 100003
    level3_id = 100004
    subscriber_id = 100005
    
    # Создаем пользователей
    users = [
        {
            "id": main_referrer_id,
            "username": "main_referrer",
            "referral_code": "ref_main_" + str(main_referrer_id),
            "referrer_id": None,
            "referrals": {"level1": [], "level2": [], "level3": [], "level4": []}
        },
        {
            "id": level1_id,
            "username": "level1",
            "referral_code": "ref_level1_" + str(level1_id),
            "referrer_id": main_referrer_id,
            "referrals": {"level1": [], "level2": [], "level3": [], "level4": []}
        },
        {
            "id": level2_id,
            "username": "level2",
            "referral_code": "ref_level2_" + str(level2_id),
            "referrer_id": level1_id,
            "referrals": {"level1": [], "level2": [], "level3": [], "level4": []}
        },
        {
            "id": level3_id,
            "username": "level3",
            "referral_code": "ref_level3_" + str(level3_id),
            "referrer_id": level2_id,
            "referrals": {"level1": [], "level2": [], "level3": [], "level4": []}
        },
        {
            "id": subscriber_id,
            "username": "subscriber",
            "referral_code": None,
            "referrer_id": level3_id,
            "referrals": {"level1": [], "level2": [], "level3": [], "level4": []}
        }
    ]
    
    # Сохраняем пользователей и настраиваем реферальные связи
    for user in users:
        manager.save_user(user)
    
    # Обновляем реферальную структуру для всех уровней
    manager._update_referral_structure(level1_id, main_referrer_id, level=1)
    manager._update_referral_structure(level2_id, level1_id, level=1)
    manager._update_referral_structure(level3_id, level2_id, level=1)
    manager._update_referral_structure(subscriber_id, level3_id, level=1)
    
    # Расчет вознаграждений
    rewards = manager.calculate_rewards(subscriber_id)
    
    logger.info("Результаты расчета вознаграждений:")
    for user_id, amount in rewards.items():
        user_level = {
            level3_id: "Уровень 1 (5%)",
            level2_id: "Уровень 2 (2%)",
            level1_id: "Уровень 3 (2%)",
            main_referrer_id: "Уровень 4 (1%)"
        }.get(user_id, "Неизвестный уровень")
        
        logger.info(f"Пользователь {user_id} ({user_level}): {amount} руб.")
    
    return rewards

def run_all_tests():
    """
    Запуск всех тестов
    """
    logger.info("=== Тестирование новой реферальной системы ===")
    
    logger.info("\n1. Тест генерации реферального кода и ссылки:")
    referral_code = test_referral_generation()
    
    logger.info("\n2. Тест отслеживания рефералов:")
    tracking_success = test_referral_tracking()
    
    logger.info("\n3. Тест расчета вознаграждений:")
    rewards = test_reward_calculation()
    
    logger.info("\n=== Тестирование завершено ===")
    return {
        "referral_code": referral_code,
        "tracking_success": tracking_success,
        "rewards": rewards
    }

if __name__ == "__main__":
    run_all_tests()