#!/usr/bin/env python
# coding: utf-8

"""
Simple database management for user data persistence
"""

import os
import json
import logging
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)

DATABASE_PATH = "users_db.json"

def load_database() -> Dict[str, Any]:
    """
    Load the database from file or create a new one if it doesn't exist
    
    Returns:
        dict: Database with users
    """
    if os.path.exists(DATABASE_PATH):
        try:
            with open(DATABASE_PATH, 'r', encoding='utf-8') as file:
                return json.load(file)
        except json.JSONDecodeError:
            logger.error(f"Failed to decode JSON in {DATABASE_PATH}")
            return {"users": {}}
        except Exception as e:
            logger.error(f"Error loading database: {e}")
            return {"users": {}}
    else:
        return {"users": {}}

def save_database(db: Dict[str, Any]) -> None:
    """
    Save the database to file
    
    Args:
        db: Database to save
    """
    try:
        with open(DATABASE_PATH, 'w', encoding='utf-8') as file:
            json.dump(db, file, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Error saving database: {e}")

def get_user(user_id: int) -> Optional[Dict[str, Any]]:
    """
    Get user data from the database
    
    Args:
        user_id: Telegram user ID
        
    Returns:
        dict: User data or None if not found
    """
    db = load_database()
    user_id_str = str(user_id)  # Convert to string for JSON keys
    
    if user_id_str in db["users"]:
        return db["users"][user_id_str]
    else:
        return None

def save_user(user_data: Dict[str, Any]) -> None:
    """
    Save user data to the database
    
    Args:
        user_data: User data to save (must contain 'id' key)
    """
    if "id" not in user_data:
        logger.error("Cannot save user without 'id' field")
        return
    
    user_id = str(user_data["id"])  # Convert to string for JSON keys
    db = load_database()
    
    db["users"][user_id] = user_data
    save_database(db)
    logger.debug(f"User {user_id} saved to database")

def update_user_subscription(user_id: int, expiry_date: str) -> bool:
    """
    Update a user's subscription expiry date
    
    Args:
        user_id: Telegram user ID
        expiry_date: ISO format date string for subscription expiry
        
    Returns:
        bool: True if update was successful, False otherwise
    """
    user_data = get_user(user_id)
    
    if user_data:
        user_data['subscription_expiry'] = expiry_date
        save_user(user_data)
        logger.info(f"Updated subscription for user {user_id} to {expiry_date}")
        return True
    else:
        logger.warning(f"Attempted to update subscription for non-existent user {user_id}")
        return False

def get_users_with_expiring_subscriptions(days: int = 3) -> List[Dict[str, Any]]:
    """
    Get users whose subscriptions will expire within the specified number of days
    
    Args:
        days: Number of days ahead to check for expiry (default 3)
        
    Returns:
        List[Dict[str, Any]]: List of user data dictionaries with expiring subscriptions
    """
    import datetime
    
    # Получаем текущую дату
    now = datetime.datetime.now()
    
    # Вычисляем дату окончания диапазона поиска (например, через 3 дня)
    end_date = now + datetime.timedelta(days=days)
    
    # Загружаем базу данных
    db = load_database()
    
    # Список пользователей с истекающими подписками
    expiring_users = []
    
    # Проверяем всех пользователей
    for user_id, user_data in db.get("users", {}).items():
        # Пропускаем пользователей без подписки
        if not user_data.get('subscription_expiry'):
            continue
        
        try:
            # Парсим дату окончания подписки
            expiry_date = datetime.datetime.fromisoformat(user_data['subscription_expiry'])
            
            # Если подписка истекает в заданном диапазоне, добавляем пользователя в список
            if now <= expiry_date <= end_date:
                # Добавляем ID в словарь пользователя для удобства
                user_data['id'] = int(user_id)
                expiring_users.append(user_data)
        except (ValueError, TypeError):
            logger.warning(f"Invalid subscription_expiry format for user {user_id}: {user_data.get('subscription_expiry')}")
    
    logger.info(f"Found {len(expiring_users)} users with subscriptions expiring within {days} days")
    return expiring_users

def add_transaction(transaction_type: str, user_id: int, amount: float, description: str = "", 
                  status: str = "pending", payment_data: Dict[str, Any] = None) -> Optional[str]:
    """
    Add a transaction to the database
    
    Args:
        transaction_type: Type of transaction (subscription_payment, referral_reward, etc.)
        user_id: Telegram user ID
        amount: Transaction amount in rubles
        description: Description of the transaction
        status: Transaction status (pending, completed, failed)
        payment_data: Additional payment data
        
    Returns:
        str: Transaction ID or None if the operation failed
    """
    import uuid
    import datetime
    
    # Загружаем базу транзакций
    try:
        with open("transactions_db.json", 'r', encoding='utf-8') as file:
            transactions = json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        transactions = {"transactions": {}}
    
    # Создаем уникальный ID транзакции
    transaction_id = str(uuid.uuid4())
    
    # Текущее время в ISO формате
    now = datetime.datetime.now().isoformat()
    
    # Создаем запись о транзакции
    transaction = {
        "id": transaction_id,
        "type": transaction_type,
        "user_id": user_id,
        "amount": amount,
        "description": description,
        "status": status,
        "created_at": now,
        "updated_at": now
    }
    
    # Добавляем дополнительные данные о платеже, если они есть
    if payment_data:
        transaction["payment_data"] = payment_data
    
    # Сохраняем транзакцию в базу
    transactions["transactions"][transaction_id] = transaction
    
    try:
        with open("transactions_db.json", 'w', encoding='utf-8') as file:
            json.dump(transactions, file, ensure_ascii=False, indent=4)
        logger.info(f"Added transaction {transaction_id} for user {user_id} ({transaction_type}, {amount}₽)")
        return transaction_id
    except Exception as e:
        logger.error(f"Failed to save transaction: {e}")
        return None

def get_transaction_by_id(transaction_id: str) -> Optional[Dict[str, Any]]:
    """
    Get a transaction by its ID
    
    Args:
        transaction_id: Transaction ID
        
    Returns:
        Dict[str, Any] or None: Transaction data or None if not found
    """
    try:
        with open("transactions_db.json", 'r', encoding='utf-8') as file:
            transactions = json.load(file)
            
        return transactions.get("transactions", {}).get(transaction_id)
    except (FileNotFoundError, json.JSONDecodeError):
        logger.error(f"Failed to load transactions database")
        return None
        
def get_all_users() -> List[Dict[str, Any]]:
    """
    Get all users from the database
    
    Returns:
        List[Dict[str, Any]]: List of all users
    """
    db = load_database()
    users = []
    
    for user_id, user_data in db["users"].items():
        # Добавляем идентификатор пользователя в его данные
        if isinstance(user_data, dict):
            if 'id' not in user_data:
                user_data['id'] = int(user_id)
            users.append(user_data)
    
    return users
    
def update_user_data(user_id: int, user_data: Dict[str, Any]) -> bool:
    """
    Обновляет все данные пользователя
    
    Args:
        user_id: ID пользователя
        user_data: Новые данные пользователя
    
    Returns:
        bool: True если обновление успешно, False в противном случае
    """
    try:
        # Загружаем текущие данные
        db = load_database()
        
        # Обновляем данные пользователя
        db["users"][str(user_id)] = user_data
        
        # Сохраняем в базу данных
        save_database(db)
        
        # Логируем успешное обновление
        logger.info(f"User data updated for user_id: {user_id}")
        return True
    except Exception as e:
        logger.error(f"Error updating user data for user_id {user_id}: {e}")
        return False