#!/usr/bin/env python3
"""
Скрипт для очистки JSON-хранилища, чтобы оставить только реальных пользователей
"""

import json
import os
import shutil
from datetime import datetime

# ID пользователей, которые следует сохранить
KEEP_USER_IDS = [5913639088, 6198324744]

def create_backup(file_path):
    """
    Создает резервную копию файла
    """
    if not os.path.exists(file_path):
        print(f"Файл {file_path} не существует!")
        return False
    
    backup_dir = "json_backup"
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = os.path.join(backup_dir, f"{os.path.basename(file_path)}_backup_{timestamp}")
    
    try:
        shutil.copy2(file_path, backup_file)
        print(f"Создана резервная копия: {backup_file}")
        return True
    except Exception as e:
        print(f"Ошибка при создании резервной копии: {e}")
        return False

def clean_users_db(file_path="users_db.json"):
    """
    Очищает JSON-хранилище пользователей, оставляя только пользователей из KEEP_USER_IDS
    """
    if not os.path.exists(file_path):
        print(f"Файл {file_path} не существует!")
        return
    
    # Создаем резервную копию
    if not create_backup(file_path):
        return
    
    try:
        # Загружаем текущие данные
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Проверка формата данных
        if not isinstance(data, dict):
            print(f"Неожиданный формат данных в файле {file_path}!")
            return
        
        # Проверяем наличие ключа "users"
        if "users" in data:
            # Подсчет пользователей до очистки
            initial_count = len(data["users"])
            
            # Оставляем только нужных пользователей
            cleaned_users = {str(user_id): data["users"].get(str(user_id), {}) 
                             for user_id in KEEP_USER_IDS 
                             if str(user_id) in data["users"]}
            
            # Обновляем только раздел users, сохраняя остальные данные
            cleaned_data = data.copy()
            cleaned_data["users"] = cleaned_users
        else:
            # Простой словарь пользователей
            initial_count = len(data)
            cleaned_data = {str(user_id): data.get(str(user_id), {}) 
                           for user_id in KEEP_USER_IDS 
                           if str(user_id) in data}
        
        # Подсчет пользователей после очистки
        if "users" in cleaned_data:
            final_count = len(cleaned_data["users"])
        else:
            final_count = len(cleaned_data)
        removed_count = initial_count - final_count
        
        # Сохраняем очищенные данные
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(cleaned_data, f, ensure_ascii=False, indent=2)
        
        print(f"JSON-хранилище очищено:")
        print(f"- Было пользователей: {initial_count}")
        print(f"- Осталось пользователей: {final_count}")
        print(f"- Удалено пользователей: {removed_count}")
        
    except Exception as e:
        print(f"Ошибка при очистке JSON-хранилища: {e}")

def main():
    """
    Основная функция
    """
    print("=== Очистка JSON-хранилища ===")
    clean_users_db()
    print("Очистка завершена!")

if __name__ == "__main__":
    main()