#!/usr/bin/env python
# coding: utf-8

"""
Адаптер для интеграции оптимизированного менеджера реферальной системы
Обеспечивает плавный переход со старой реализации на новую
"""

import logging
import os
from typing import Dict, Any, List, Optional, Tuple, Union

from db_models import User, Transaction
from new_referral_code.referral_manager import ReferralManager
from new_referral_code.optimized_referral_manager import OptimizedReferralManager

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Флаг для включения оптимизированной версии
USE_OPTIMIZED_VERSION = os.environ.get("USE_OPTIMIZED_REFERRAL", "1").lower() in ("1", "true", "yes")

# Инициализация менеджеров
original_manager = ReferralManager()
optimized_manager = OptimizedReferralManager()


def get_or_create_referral_code(user_id: int) -> str:
    """
    Получение реферального кода пользователя с автоматическим выбором оптимальной реализации
    
    Args:
        user_id: ID пользователя
        
    Returns:
        str: Реферальный код
    """
    logger.debug(f"Getting referral code for user {user_id}, using optimized: {USE_OPTIMIZED_VERSION}")
    
    if USE_OPTIMIZED_VERSION:
        return optimized_manager.get_or_create_referral_code(user_id)
    else:
        return original_manager.get_or_create_referral_code(user_id)


def add_referral(user_id: int, referral_code: str) -> bool:
    """
    Добавление реферального отношения между пользователями
    
    Args:
        user_id: ID пользователя-реферала
        referral_code: Реферальный код реферера
        
    Returns:
        bool: True, если отношение успешно добавлено, False в противном случае
    """
    logger.debug(f"Adding referral relation for user {user_id} with code {referral_code}, using optimized: {USE_OPTIMIZED_VERSION}")
    
    if USE_OPTIMIZED_VERSION:
        return optimized_manager.add_referral(user_id, referral_code)
    else:
        return original_manager.add_referral(user_id, referral_code)


def process_payment_rewards(user_id: int, amount: float, transaction_id: int, 
                           min_amount: float = 1.0) -> List[Dict[str, Any]]:
    """
    Начисление реферальных вознаграждений за платеж
    
    Args:
        user_id: ID пользователя, совершившего платеж
        amount: Сумма платежа
        transaction_id: ID транзакции платежа
        min_amount: Минимальная сумма вознаграждения для начисления
        
    Returns:
        List[Dict]: Список начисленных вознаграждений
    """
    logger.debug(f"Processing payment rewards for user {user_id}, tx {transaction_id}, using optimized: {USE_OPTIMIZED_VERSION}")
    
    if USE_OPTIMIZED_VERSION:
        return optimized_manager.process_payment_rewards(user_id, amount, transaction_id, min_amount)
    else:
        return original_manager.process_payment_rewards(user_id, amount, transaction_id, min_amount)


def get_pending_rewards(user_id: Optional[int] = None, page: int = 1, page_size: int = 50) -> Union[List[Dict[str, Any]], Tuple[List[Dict[str, Any]], int]]:
    """
    Получение списка ожидающих выплат
    
    Args:
        user_id: ID пользователя (если требуются вознаграждения только для конкретного пользователя)
        page: Номер страницы (используется только в оптимизированной версии)
        page_size: Размер страницы (используется только в оптимизированной версии)
        
    Returns:
        Union[List[Dict], Tuple[List[Dict], int]]: Список ожидающих выплат (и общее количество в оптимизированной версии)
    """
    logger.debug(f"Getting pending rewards for user {user_id}, using optimized: {USE_OPTIMIZED_VERSION}")
    
    if USE_OPTIMIZED_VERSION:
        return optimized_manager.get_pending_rewards(user_id, page, page_size)
    else:
        return original_manager.get_pending_rewards(user_id)


def create_weekly_payout(admin_id: int, description: str) -> Optional[int]:
    """
    Создание еженедельной выплаты
    
    Args:
        admin_id: ID администратора
        description: Описание выплаты
        
    Returns:
        Optional[int]: ID созданной выплаты или None в случае ошибки
    """
    logger.debug(f"Creating weekly payout by admin {admin_id}, using optimized: {USE_OPTIMIZED_VERSION}")
    
    if USE_OPTIMIZED_VERSION:
        return optimized_manager.create_weekly_payout(admin_id, description)
    else:
        return original_manager.create_weekly_payout(admin_id, description)


def process_payout_batch(payout_id: int, batch_size: int = 100) -> Tuple[bool, str, int]:
    """
    Пакетная обработка выплат (доступна только в оптимизированной версии)
    
    Args:
        payout_id: ID выплаты для обработки
        batch_size: Размер пакета обрабатываемых вознаграждений
        
    Returns:
        Tuple[bool, str, int]: (успешно, сообщение, количество обработанных)
    """
    logger.debug(f"Processing payout batch for payout {payout_id}, using optimized: {USE_OPTIMIZED_VERSION}")
    
    if USE_OPTIMIZED_VERSION:
        return optimized_manager.process_payout_batch(payout_id, batch_size)
    else:
        # Эмуляция для совместимости - в оригинальной версии нет батч-обработки
        # Внимание: это может вызвать проблемы с производительностью на больших объемах данных
        logger.warning("Batch processing not available in original implementation")
        return False, "Batch processing not available in original implementation", 0


def get_referral_stats(user_id: int) -> Dict[str, Any]:
    """
    Получение статистики для реферера (доступна только в оптимизированной версии)
    
    Args:
        user_id: ID пользователя
        
    Returns:
        Dict: Статистика реферальной программы
    """
    logger.debug(f"Getting referral stats for user {user_id}, using optimized: {USE_OPTIMIZED_VERSION}")
    
    if USE_OPTIMIZED_VERSION:
        return optimized_manager.get_referral_stats(user_id)
    else:
        # Эмуляция для совместимости
        logger.warning("Referral stats not available in original implementation")
        return {
            "direct_referrals": 0,
            "total_referrals": 0,
            "total_rewards": 0,
            "paid_rewards": {
                "count": 0,
                "amount": 0
            },
            "pending_rewards": {
                "count": 0,
                "amount": 0
            }
        }