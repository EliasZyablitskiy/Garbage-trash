#!/usr/bin/env python
# coding: utf-8

"""
Service for interaction with Perplexity API
"""

import os
import json
import logging
import aiohttp
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)

# Получаем API-ключ из переменных окружения
PERPLEXITY_API_KEY = os.environ.get("PERPLEXITY_API_KEY")

class PerplexityService:
    """Service for interaction with Perplexity AI API"""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize Perplexity service
        
        Args:
            api_key: API key for Perplexity AI (optional, will use environment variable if not provided)
        """
        self.api_key = api_key or PERPLEXITY_API_KEY
        self.api_url = "https://api.perplexity.ai/chat/completions"
        
        if not self.api_key:
            logger.warning("Perplexity API key not set")
    
    def _check_api_key(self) -> bool:
        """
        Check if API key is available
        
        Returns:
            bool: True if API key is available, False otherwise
        """
        if not self.api_key:
            logger.error("Perplexity API key not set")
            return False
        return True
    
    async def generate_completion(
        self, 
        messages: List[Dict[str, str]], 
        model: str = "llama-3.1-sonar-small-128k-online",
        max_tokens: Optional[int] = None,
        temperature: float = 0.2,
        top_p: float = 0.9,
        search_domain_filter: Optional[List[str]] = None,
        return_images: bool = False,
        return_related_questions: bool = False,
        search_recency_filter: str = "month",
        top_k: int = 0,
        stream: bool = False,
        presence_penalty: float = 0,
        frequency_penalty: float = 1
    ) -> Optional[Dict[str, Any]]:
        """
        Generate completion using Perplexity API
        
        Args:
            messages: List of messages for the conversation
            model: Model to use
            max_tokens: Maximum number of tokens to generate
            temperature: Temperature for sampling
            top_p: Top p for sampling
            search_domain_filter: List of domains to restrict search to
            return_images: Whether to return images
            return_related_questions: Whether to return related questions
            search_recency_filter: Recency filter for search (day, week, month, year)
            top_k: Top k for sampling
            stream: Whether to stream the response
            presence_penalty: Presence penalty
            frequency_penalty: Frequency penalty
            
        Returns:
            dict: Response from Perplexity API or None if error
        """
        if not self._check_api_key():
            return None
        
        # Validate model
        valid_models = ["llama-3.1-sonar-small-128k-online", "llama-3.1-sonar-large-128k-online", "llama-3.1-sonar-huge-128k-online"]
        if model not in valid_models:
            logger.warning(f"Invalid model: {model}, using default model")
            model = "llama-3.1-sonar-small-128k-online"
        
        # Prepare request body
        request_data = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "top_p": top_p,
            "return_images": return_images,
            "return_related_questions": return_related_questions,
            "search_recency_filter": search_recency_filter,
            "top_k": top_k,
            "stream": stream,
            "presence_penalty": presence_penalty,
            "frequency_penalty": frequency_penalty
        }
        
        # Add optional parameters
        if max_tokens is not None:
            request_data["max_tokens"] = max_tokens
        
        if search_domain_filter is not None:
            request_data["search_domain_filter"] = search_domain_filter
        
        # Prepare headers
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.api_url, 
                    headers=headers, 
                    json=request_data
                ) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        logger.error(f"Perplexity API error: {response.status} - {error_text}")
                        return None
                    
                    result = await response.json()
                    return result
        except Exception as e:
            logger.error(f"Error calling Perplexity API: {e}")
            return None
    
    async def ask_question(
        self, 
        question: str, 
        system_prompt: Optional[str] = None,
        model: str = "llama-3.1-sonar-small-128k-online",
        search_recency_filter: str = "month"
    ) -> Optional[str]:
        """
        Ask a question to Perplexity AI
        
        Args:
            question: Question to ask
            system_prompt: System prompt for the conversation
            model: Model to use
            search_recency_filter: Recency filter for search (day, week, month, year)
            
        Returns:
            str: Answer from Perplexity AI or None if error
        """
        messages = []
        
        # Add system message if provided
        if system_prompt:
            messages.append({
                "role": "system",
                "content": system_prompt
            })
        
        # Add user message
        messages.append({
            "role": "user",
            "content": question
        })
        
        response = await self.generate_completion(
            messages=messages,
            model=model,
            search_recency_filter=search_recency_filter
        )
        
        if not response:
            return None
        
        try:
            answer = response.get("choices", [{}])[0].get("message", {}).get("content")
            return answer
        except (KeyError, IndexError) as e:
            logger.error(f"Error extracting answer from response: {e}")
            return None
    
    def get_citations(self, response: Dict[str, Any]) -> List[str]:
        """
        Extract citations from response
        
        Args:
            response: Response from Perplexity API
            
        Returns:
            list: List of citations
        """
        if not response:
            return []
        
        return response.get("citations", [])
    
    async def search_web(
        self, 
        query: str, 
        system_prompt: str = "You are an AI assistant that searches the web for answers to questions. Always provide accurate and up-to-date information with citations.",
        model: str = "llama-3.1-sonar-small-128k-online"
    ) -> Dict[str, Any]:
        """
        Search the web for information
        
        Args:
            query: Search query
            system_prompt: System prompt for the conversation
            model: Model to use
            
        Returns:
            dict: Search results with answer and citations
        """
        response = await self.generate_completion(
            messages=[
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": query
                }
            ],
            model=model,
            temperature=0.0,  # Lower temperature for more factual responses
            search_recency_filter="day"  # Use recent information
        )
        
        if not response:
            return {
                "answer": "Не удалось выполнить поиск в интернете. Пожалуйста, попробуйте позже.",
                "citations": []
            }
        
        citations = self.get_citations(response)
        answer = response.get("choices", [{}])[0].get("message", {}).get("content", "")
        
        return {
            "answer": answer,
            "citations": citations
        }

# Создаем экземпляр сервиса для использования в других модулях
perplexity_service = PerplexityService()

async def search_web(query: str) -> Dict[str, Any]:
    """
    Wrapper function for searching the web
    
    Args:
        query: Search query
        
    Returns:
        dict: Search results with answer and citations
    """
    return await perplexity_service.search_web(query)