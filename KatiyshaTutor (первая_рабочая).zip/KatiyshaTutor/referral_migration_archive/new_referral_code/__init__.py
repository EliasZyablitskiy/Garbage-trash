"""
Пакет новой реферальной системы для работы с PostgreSQL
"""

from .referral_manager import ReferralManager
from .referral_handlers import get_referral_handlers, process_referral