#!/usr/bin/env python
# coding: utf-8

"""
Main entry point for the Katiysha Telegram Bot
"""

import logging
import os
import asyncio
from bot import create_bot

# Set up logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.DEBUG
)

logger = logging.getLogger(__name__)

def main():
    """Start the bot and webhook server."""
    try:
        # Create new event loop
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        # Create the bot
        application = loop.run_until_complete(create_bot())
        logger.info("Bot started successfully!")
        
        # Run the bot until the user presses Ctrl-C
        application.run_polling(allowed_updates=None)
        
    except Exception as e:
        logger.error(f"Error starting bot: {e}")
        raise
    finally:
        logger.info("Bot shutting down...")

if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot stopped gracefully!")
    except Exception as e:
        logger.error(f"Bot stopped unexpectedly: {e}")
