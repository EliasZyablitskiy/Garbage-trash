#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для проверки пароля администратора
"""

import os
from db_config import get_flask_app
from db_models import db, AdminUser
from werkzeug.security import check_password_hash

def check_password(telegram_id, test_password):
    """
    Проверяет пароль администратора
    
    Args:
        telegram_id: Telegram ID администратора
        test_password: Пароль для проверки
        
    Returns:
        bool: True, если пароль верный, False в противном случае
    """
    app = get_flask_app()
    
    with app.app_context():
        admin = AdminUser.query.filter_by(telegram_id=telegram_id).first()
        
        if not admin:
            print(f"Администратор с Telegram ID {telegram_id} не найден")
            return False
        
        is_valid = check_password_hash(admin.password_hash, test_password)
        return is_valid

if __name__ == "__main__":
    # Telegram ID супер-администратора
    admin_telegram_id = 5913639088
    
    # Проверяем старый пароль
    old_password = "admin123"
    old_password_valid = check_password(admin_telegram_id, old_password)
    print(f"Старый пароль 'admin123': {'Валидный' if old_password_valid else 'Невалидный'}")
    
    # Проверяем новый пароль
    new_password = "Easdfx1423"
    new_password_valid = check_password(admin_telegram_id, new_password)
    print(f"Новый пароль 'Easdfx1423': {'Валидный' if new_password_valid else 'Невалидный'}")