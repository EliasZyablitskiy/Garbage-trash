#!/usr/bin/env python3

content = ""
with open('handlers.py', 'r') as file:
    content = file.read()

# Заменяем каждый блок отдельно
block1_old = """        emoji = get_emoji("pencil", platform_type)
        confirm_message = adapt_message_for_platform(
            f"{emoji} Задача получена:\\n\\n{text}\\n\\nРешить эту задачу?",
            platform_type, 
            platform_version
        )
        
        # Отправляем подтверждение с учетом специфики платформы
        await update.message.reply_text(
            confirm_message,
            reply_markup=get_problem_keyboard(),
            parse_mode=message_settings.get("parse_mode", None)"""

block1_new = """        emoji = get_emoji("pencil", platform_type)
        
        # Используем новый сервис форматирования сообщений
        confirm_message, parse_mode = format_adaptive_message(
            f"{emoji} Задача получена:\\n\\n{text}\\n\\nРешить эту задачу?",
            platform_type, 
            platform_version
        )
        
        # Отправляем подтверждение с учетом специфики платформы
        await update.message.reply_text(
            confirm_message,
            reply_markup=get_problem_keyboard(),
            parse_mode=parse_mode"""

content = content.replace(block1_old, block1_new)

with open('handlers.py', 'w') as file:
    file.write(content)

print("Завершена замена первого блока")
