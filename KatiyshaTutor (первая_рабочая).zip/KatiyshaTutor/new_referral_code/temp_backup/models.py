#!/usr/bin/env python
# coding: utf-8

"""
Data models for the Katiysha bot
"""

from typing import Optional, List, Dict, Any
from dataclasses import dataclass
from datetime import datetime

@dataclass
class User:
    """User model for storing user information and subscription status"""
    id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    free_request_used: bool = False
    subscription_expiry: Optional[datetime] = None
    
    @property
    def has_active_subscription(self) -> bool:
        """Check if user has an active subscription"""
        if self.subscription_expiry is None:
            return False
        return datetime.now() < self.subscription_expiry
    
    @property
    def can_solve_problem(self) -> bool:
        """Check if user can solve a problem (has free request or active subscription)"""
        return not self.free_request_used or self.has_active_subscription
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'User':
        """Create a User instance from dictionary data"""
        subscription_expiry = None
        if data.get('subscription_expiry'):
            try:
                subscription_expiry = datetime.fromisoformat(data['subscription_expiry'])
            except ValueError:
                pass
                
        return cls(
            id=data['id'],
            username=data.get('username'),
            first_name=data.get('first_name'),
            last_name=data.get('last_name'),
            free_request_used=data.get('free_request_used', False),
            subscription_expiry=subscription_expiry
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert User instance to dictionary for storage"""
        data = {
            'id': self.id,
            'username': self.username,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'free_request_used': self.free_request_used,
        }
        
        if self.subscription_expiry:
            data['subscription_expiry'] = self.subscription_expiry.isoformat()
        else:
            data['subscription_expiry'] = None
            
        return data

@dataclass
class MathProblem:
    """Math problem model for tracking user problems"""
    user_id: int
    problem_text: str
    image_path: Optional[str] = None
    solution: Optional[str] = None
    created_at: datetime = datetime.now()
