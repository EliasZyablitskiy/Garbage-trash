#!/usr/bin/env python
# coding: utf-8

"""
Main entry point for the Katiysha Telegram Bot
"""

# Импортируем Flask приложение для gunicorn (main:app)
from app import app

import os
import sys
import logging
import asyncio
import threading
from concurrent.futures import ThreadPoolExecutor

from bot import create_bot
from webhook_handler import run_webhook_server

# Проверка наличия переменной окружения DATABASE_URL
DATABASE_URL = os.environ.get("DATABASE_URL")
if not DATABASE_URL:
    print("WARNING: DATABASE_URL environment variable not set.")
    print("Running without PostgreSQL database. Some features may not work correctly.")
    print("Set DATABASE_URL to enable PostgreSQL support.")

# Проверка наличия TELEGRAM_TOKEN
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN")
if not TELEGRAM_TOKEN:
    print("ERROR: TELEGRAM_TOKEN environment variable not set.")
    print("Bot cannot function without a valid Telegram token.")
    print("Set TELEGRAM_TOKEN to continue.")
    sys.exit(1)

# Создаем директорию для логов
log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')
os.makedirs(log_dir, exist_ok=True)

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.StreamHandler(),
        logging.handlers.RotatingFileHandler(
            os.path.join(log_dir, 'main.log'),
            maxBytes=10*1024*1024,  # 10 МБ
            backupCount=5
        )
    ]
)
logger = logging.getLogger(__name__)

def init_database():
    """Initialize database if DATABASE_URL is set"""
    if DATABASE_URL:
        try:
            # Инициализируем базу данных
            from db_config import get_flask_app
            
            app = get_flask_app()
            with app.app_context():
                from db_models import db
                from new_referral_models import ReferralCode, ReferralRelation, ReferralReward
                
                db.create_all()
                
                logger.info("Database tables initialized")
                return True
        except Exception as e:
            logger.error(f"Error initializing database: {e}")
            return False
    return True  # Если DATABASE_URL не указан, считаем, что все в порядке

async def start_payout_scheduler(bot):
    """
    Запуск планировщика еженедельных выплат и системы восстановления
    
    Args:
        bot: Telegram bot instance
    """
    try:
        # Создаем планировщик для всех задач
        from apscheduler.schedulers.asyncio import AsyncIOScheduler
        scheduler = AsyncIOScheduler()
        
        # Запускаем планировщик еженедельных выплат
        from services.payout_service import schedule_weekly_payouts
        await schedule_weekly_payouts(bot)
        
        # Запускаем систему восстановления прерванных выплат
        from services.recovery_service import RecoveryService
        # Проверяем и восстанавливаем зависшие выплаты при запуске
        recovery_result = await RecoveryService.recover_all_stalled_payouts(bot)
        
        if recovery_result["payouts"]["recovered"] > 0 or recovery_result["batches"]["recovered"] > 0:
            logger.info(f"Recovered {recovery_result['payouts']['recovered']} payouts and "
                        f"{recovery_result['batches']['recovered']} batch payouts at startup")
        
        # Запускаем проверку восстановления каждые 3 часа
        await RecoveryService.add_recovery_check_to_scheduler(scheduler, bot)
        
        # Добавляем проверку истечения подписок ежедневно в 10:00
        from services.subscription_service import process_expiring_subscriptions
        
        # Запускаем проверку подписок раз в день в 10:00 утра
        scheduler.add_job(
            process_expiring_subscriptions,
            'cron',
            hour=10,
            minute=0,
            id='check_expiring_subscriptions'
        )
        logger.info("Added subscription expiration check to scheduler (daily at 10:00)")
        
        # Также добавляем проверку каждые 8 часов для отправки уведомлений
        # Это позволит отправлять уведомления, которые могли быть пропущены, 
        # например, если сервер был отключен
        scheduler.add_job(
            process_expiring_subscriptions,
            'interval',
            hours=8,
            id='subscription_reminder_backups'
        )
        logger.info("Added backup subscription reminder check to scheduler (every 8 hours)")
        
        # Добавляем периодическую проверку статуса платежей через унифицированную систему
        # Запускаем проверку каждые 30 минут
        from services.payment_verification_service_v2 import check_pending_payments
        
        scheduler.add_job(
            check_pending_payments,
            'interval',
            minutes=30,
            id='payment_status_verification_check'
        )
        logger.info("Added unified payment status check to scheduler (every 30 minutes)")
        
        # Добавляем обработку накопленных реферальных вознаграждений
        # Запускаем каждые 6 часов
        try:
            from services.accumulated_rewards_service import AccumulatedRewardsService
            
            async def process_accumulated_rewards_task():
                """Обрабатывает накопленные вознаграждения, достигшие порога"""
                try:
                    # Создаем контекст Flask-приложения
                    from db_config import get_flask_app
                    
                    app = get_flask_app()
                    with app.app_context():
                        processed, success, message = AccumulatedRewardsService.process_all_accumulated_rewards()
                        logger.info(f"Accumulated rewards processing: {message}")
                except Exception as e:
                    logger.error(f"Error in accumulated rewards processing: {e}", exc_info=True)
            
            scheduler.add_job(
                process_accumulated_rewards_task,
                'interval',
                hours=6,
                id='process_accumulated_rewards'
            )
            logger.info("Added accumulated rewards processing to scheduler (every 6 hours)")
        except Exception as e:
            logger.warning(f"Could not set up accumulated rewards scheduler: {e}")
        
        # Запускаем планировщик, если он еще не запущен
        if not scheduler.running:
            scheduler.start()
            logger.info("Scheduler for payouts and subscription notifications started")
            
    except Exception as e:
        logger.error(f"Error in scheduler setup: {e}", exc_info=True)

# Создаем временные директории, если их нет
def ensure_temp_directories():
    """Создает необходимые временные директории"""
    temp_dirs = ['temp_images', 'temp_voices', 'temp_qr']
    for temp_dir in temp_dirs:
        os.makedirs(temp_dir, exist_ok=True)
        logger.info(f"Created temporary directory: {temp_dir}")

# Функция для настройки планировщика очистки временных файлов
def setup_cleanup_scheduler():
    """Настраивает планировщик очистки временных файлов"""
    try:
        from apscheduler.schedulers.asyncio import AsyncIOScheduler
        from services.cleanup_service import run_cleanup_now
        
        # Запускаем немедленную очистку старых файлов (старше 24 часов)
        run_cleanup_now(max_age_hours=24)
        logger.info("Performed immediate cleanup of temporary files")
        
        # Планируем ежедневную очистку в 3:00
        scheduler = AsyncIOScheduler()
        scheduler.add_job(
            run_cleanup_now,
            'cron',
            hour=3,
            minute=0,
            kwargs={'max_age_hours': 24},
            id='daily_cleanup'
        )
        
        # Запускаем планировщик очистки
        if not scheduler.running:
            scheduler.start()
            logger.info("Scheduled daily cleanup of temporary files at 03:00")
    except Exception as e:
        logger.error(f"Error setting up cleanup scheduler: {e}")

def init_centralized_payment_verification_system(flask_app):
    """
    Инициализация централизованной системы проверки платежей
    
    Args:
        flask_app: Flask-приложение для контекста
    
    Returns:
        bool: True, если инициализация успешна, False в противном случае
    """
    try:
        # Инициализируем централизованную систему проверки платежей
        logger.info("Initializing centralized payment verification system...")
        
        # Инициализация сервиса уведомлений
        from services.notification_service import NotificationService
        telegram_token = os.environ.get('TELEGRAM_TOKEN')
        notification_service = NotificationService(telegram_token=telegram_token)
        flask_app.notification_service = notification_service
        logger.info("Notification service initialized with thread-based queue")
        
        # Инициализация сервиса верификации платежей
        from services.payment_verification_service_v2 import payment_verification_service_v2
        payment_verification_service_v2.init_app(flask_app)
        logger.info("Payment verification service v2 initialized")
        
        # Инициализация фасада процессора платежей
        from services.payment_processor_facade import payment_processor_facade
        payment_processor_facade.init_app(flask_app)
        logger.info("Payment processor facade initialized")
        
        # Регистрация маршрутов для страниц платежей
        from services.payment_pages import register_payment_pages
        register_payment_pages(flask_app)
        logger.info("Payment pages registered")
        
        # Регистрация маршрутов для обработки webhook-ов от платежных систем
        from services.payment_webhook_handler import register_payment_webhooks
        register_payment_webhooks(flask_app)
        logger.info("Payment webhooks registered")
        
        # Настройка периодической проверки статуса платежей через внешние API
        from apscheduler.schedulers.background import BackgroundScheduler
        
        payment_check_scheduler = BackgroundScheduler()
        
        # Функция-обертка для асинхронной проверки статуса платежей
        def check_pending_payments_wrapper():
            """Запускает асинхронную проверку статуса платежей"""
            import asyncio
            from services.payment_verification_service_v2 import check_pending_payments
            
            try:
                # Создаем новый цикл событий для асинхронного вызова
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                # Запускаем асинхронную функцию проверки платежей
                result = loop.run_until_complete(check_pending_payments())
                
                # Закрываем цикл событий
                loop.close()
                
                # Логируем результат
                logger.info(f"Scheduled payment check completed: processed {result} payments")
                
            except Exception as e:
                logger.error(f"Error during scheduled payment check: {e}", exc_info=True)
        
        # Запускаем проверку статуса платежей каждые 3 часа
        payment_check_scheduler.add_job(
            check_pending_payments_wrapper,
            'interval',
            hours=3,
            id='check_pending_payments'
        )
        
        # Запускаем планировщик, если он еще не запущен
        if not payment_check_scheduler.running:
            payment_check_scheduler.start()
            logger.info("Payment status check scheduler started (interval: 3 hours)")
        
        return True
    
    except Exception as e:
        logger.error(f"Error initializing centralized payment verification system: {e}")
        return False

def main():
    """Start the bot and webhook server."""
    try:
        # Создаем необходимые директории
        ensure_temp_directories()
        
        # Настраиваем планировщик очистки временных файлов
        setup_cleanup_scheduler()
        
        # Инициализируем базу данных, если указан DATABASE_URL
        if DATABASE_URL and not init_database():
            logger.error("Failed to initialize database")
            sys.exit(1)
        
        # Запускаем webhook сервер в отдельном потоке на порту 8080 (вместо 5000 для избежания конфликта)
        webhook_thread = threading.Thread(target=run_webhook_server, args=(8080,), daemon=True)
        webhook_thread.start()
        logger.info("Webhook server started on port 8080")
        
        # Получаем Flask-приложение
        from db_config import get_flask_app
        flask_app = get_flask_app()
        
        # Инициализируем единую платежную систему
        init_centralized_payment_verification_system(flask_app)
        logger.info("Unified payment system activated")
        
        # Запускаем бота в основном потоке
        loop = asyncio.get_event_loop()
        bot_app = loop.run_until_complete(create_bot())
        
        if bot_app:
            logger.info("Bot started")
            
            # Запускаем планировщик выплат в отдельной задаче, если включен в конфигурации
            from config import ENABLE_AUTO_PAYOUTS
            if ENABLE_AUTO_PAYOUTS:
                logger.info("Starting weekly payout scheduler...")
                
                # Получаем экземпляр бота
                bot = bot_app.bot
                
                # Запускаем планировщик выплат как асинхронную задачу
                asyncio.create_task(start_payout_scheduler(bot))
                logger.info("Weekly payout scheduler started")
            
            # Запускаем поллинг
            bot_app.run_polling()
        else:
            logger.error("Failed to create bot application")
            sys.exit(1)
            
    except KeyboardInterrupt:
        logger.info("Stopping the bot...")
    except Exception as e:
        logger.error(f"Error in main: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()