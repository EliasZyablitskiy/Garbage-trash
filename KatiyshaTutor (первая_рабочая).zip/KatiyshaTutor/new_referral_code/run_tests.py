#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для запуска всех тестов бота Катюша
"""

import os
import sys
import pytest

if __name__ == "__main__":
    # Add current directory to path to make imports work
    sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
    
    # Default arguments if none provided
    args = sys.argv[1:] or [
        "tests",
        "--cov=.",
        "--cov-report=term",
        "--cov-report=html:coverage_html",
        "-v"
    ]
    
    sys.exit(pytest.main(args)) 