#!/usr/bin/env python3
"""
Скрипт для создания резервной копии базы данных PostgreSQL и загрузки на Яндекс.Диск
"""
import os
import sys
import json
import time
import logging
import datetime
import subprocess
import requests
from typing import Optional, Dict, Any

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('backup.log')
    ]
)
logger = logging.getLogger(__name__)

# Папка для временных файлов
TEMP_DIR = "temp_backup"
os.makedirs(TEMP_DIR, exist_ok=True)

# Настройки базы данных из переменных окружения
PGHOST = os.environ.get("PGHOST")
PGPORT = os.environ.get("PGPORT")
PGUSER = os.environ.get("PGUSER")
PGPASSWORD = os.environ.get("PGPASSWORD")
PGDATABASE = os.environ.get("PGDATABASE")

def get_token_from_file(filename="yandex_token.json") -> Optional[str]:
    """
    Получает токен из файла
    
    Returns:
        str: Токен доступа или None в случае ошибки
    """
    try:
        with open(filename, "r") as f:
            token_data = json.load(f)
        return token_data.get("access_token")
    except Exception as e:
        logger.error(f"Ошибка при чтении токена из файла: {e}")
        return None

def create_database_backup(schema_only: bool = False) -> Optional[str]:
    """
    Создает резервную копию базы данных PostgreSQL с использованием PSQL
    Этот метод работает даже при несоответствии версий PostgreSQL
    
    Args:
        schema_only: Создать бэкап только схемы (без данных)
    
    Returns:
        str: Путь к файлу бэкапа или None в случае ошибки
    """
    try:
        # Формируем имя файла с датой и временем
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        suffix = "_schema" if schema_only else ""
        backup_file = os.path.join(TEMP_DIR, f"backup_{timestamp}{suffix}.sql")
        
        # Устанавливаем переменные окружения для PSQL
        env = os.environ.copy()
        env["PGPASSWORD"] = PGPASSWORD
        
        # Создаем файл для SQL-скрипта
        with open(backup_file, 'w') as f:
            # Добавляем заголовок с информацией о бэкапе
            f.write(f"-- Database Backup created on {datetime.datetime.now().isoformat()}\n")
            f.write(f"-- Database: {PGDATABASE}\n")
            f.write(f"-- Type: {'Schema only' if schema_only else 'Full (schema and data)'}\n")
            f.write(f"-- Created by Katiysha Bot Backup Script\n\n")
            
            # Добавляем команды для очистки и пересоздания схемы
            f.write("-- Reset and recreate schema\n")
            f.write("BEGIN;\n")
            f.write("SET client_min_messages TO WARNING;\n\n")
        
        # Получаем список таблиц
        get_tables_cmd = [
            "psql",
            "-h", PGHOST,
            "-p", PGPORT,
            "-U", PGUSER,
            "-d", PGDATABASE,
            "-t",  # Только данные, без заголовков
            "-c", "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'"
        ]
        
        logger.info("Получение списка таблиц")
        tables_process = subprocess.Popen(
            get_tables_cmd,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        tables_stdout, tables_stderr = tables_process.communicate()
        
        if tables_process.returncode != 0:
            logger.error(f"Ошибка при получении списка таблиц: {tables_stderr.decode()}")
            return None
        
        # Обрабатываем результат
        tables = [table.strip() for table in tables_stdout.decode().strip().split("\n") if table.strip()]
        logger.info(f"Найдено таблиц: {len(tables)}")
        
        # Записываем DROP и CREATE команды для каждой таблицы
        with open(backup_file, 'a') as backup_file_handle:
            for table in tables:
                logger.info(f"Обработка таблицы: {table}")
                
                # Добавляем команду DROP
                backup_file_handle.write(f"\n-- Table: {table}\n")
                backup_file_handle.write(f"DROP TABLE IF EXISTS {table} CASCADE;\n")
                
                # Получаем описание таблицы через PSQL
                get_describe_cmd = [
                    "psql",
                    "-h", PGHOST,
                    "-p", PGPORT,
                    "-U", PGUSER,
                    "-d", PGDATABASE,
                    "-t",  # Только данные, без заголовков
                    "-c", f"\\d {table}"
                ]
                
                describe_process = subprocess.Popen(
                    get_describe_cmd,
                    env=env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                describe_stdout, describe_stderr = describe_process.communicate()
                
                if describe_process.returncode != 0:
                    logger.warning(f"Ошибка при получении описания таблицы {table}: {describe_stderr.decode()}")
                    continue
                
                # Добавляем схему таблицы как комментарий
                backup_file_handle.write(f"-- Table Schema:\n")
                # Преобразуем строки описания в комментарии
                describe_text = describe_stdout.decode().strip()
                describe_lines = describe_text.split('\n')
                for line in describe_lines:
                    backup_file_handle.write(f"-- {line}\n")
                
                # Получаем CREATE TABLE скрипт
                get_create_cmd = [
                    "psql",
                    "-h", PGHOST,
                    "-p", PGPORT,
                    "-U", PGUSER,
                    "-d", PGDATABASE,
                    "-t",  # Только данные, без заголовков
                    "-c", f"SELECT column_name, data_type, character_maximum_length, is_nullable, column_default FROM information_schema.columns WHERE table_name = '{table}' ORDER BY ordinal_position"
                ]
                
                create_process = subprocess.Popen(
                    get_create_cmd,
                    env=env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                create_stdout, create_stderr = create_process.communicate()
                
                if create_process.returncode != 0:
                    logger.warning(f"Ошибка при получении структуры таблицы {table}: {create_stderr.decode()}")
                    continue
                
                # Строим CREATE TABLE вручную
                columns = []
                for line in create_stdout.decode().strip().split("\n"):
                    if not line.strip():
                        continue
                    # Разбиваем строку на части
                    parts = line.strip().split("|")
                    if len(parts) >= 5:
                        column_name = parts[0].strip()
                        data_type = parts[1].strip()
                        max_length = parts[2].strip()
                        nullable = parts[3].strip()
                        default = parts[4].strip()
                        
                        # Формируем определение столбца
                        column_def = f"{column_name} {data_type}"
                        if max_length and max_length != "":
                            column_def += f"({max_length})"
                        if nullable == "NO":
                            column_def += " NOT NULL"
                        if default and default != "":
                            column_def += f" DEFAULT {default}"
                        
                        columns.append(column_def)
                
                if columns:
                    # Создаем CREATE TABLE
                    create_table = f"CREATE TABLE {table} (\n    "
                    create_table += ",\n    ".join(columns)
                    create_table += "\n);"
                    backup_file_handle.write(f"{create_table}\n\n")
                
                # Если требуется полный бэкап (схема+данные), добавляем данные
                if not schema_only:
                    backup_file_handle.write(f"-- Data for table: {table}\n")
                    
                    # Получаем данные таблицы
                    get_data_cmd = [
                        "psql",
                        "-h", PGHOST,
                        "-p", PGPORT,
                        "-U", PGUSER,
                        "-d", PGDATABASE,
                        "-t",  # Только данные, без заголовков
                        "-c", f"SELECT * FROM {table}"
                    ]
                    
                    data_process = subprocess.Popen(
                        get_data_cmd,
                        env=env,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE
                    )
                    data_stdout, data_stderr = data_process.communicate()
                    
                    if data_process.returncode != 0:
                        logger.warning(f"Ошибка при получении данных таблицы {table}: {data_stderr.decode()}")
                    else:
                        # Добавляем данные в виде INSERT команд
                        data = data_stdout.decode().strip()
                        if data:
                            # Получаем имена столбцов
                            column_names_cmd = [
                                "psql",
                                "-h", PGHOST,
                                "-p", PGPORT,
                                "-U", PGUSER,
                                "-d", PGDATABASE,
                                "-t",  # Только данные, без заголовков
                                "-c", f"SELECT column_name FROM information_schema.columns WHERE table_name = '{table}' ORDER BY ordinal_position"
                            ]
                            
                            col_process = subprocess.Popen(
                                column_names_cmd,
                                env=env,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE
                            )
                            col_stdout, col_stderr = col_process.communicate()
                            
                            # Записываем данные
                            if col_process.returncode == 0:
                                column_names = [col.strip() for col in col_stdout.decode().strip().split("\n") if col.strip()]
                                column_str = ", ".join(column_names)
                                
                                backup_file_handle.write(f"-- Inserting data rows\n")
                                for row in data.split("\n"):
                                    if row.strip():
                                        values = row.strip()
                                        backup_file_handle.write(f"INSERT INTO {table} ({column_str}) VALUES ({values});\n")
                                backup_file_handle.write("\n")
            
            # Завершаем транзакцию
            backup_file_handle.write("COMMIT;\n")
        
        # Проверяем размер файла
        file_size = os.path.getsize(backup_file)
        if file_size == 0:
            logger.error("Создан пустой файл бэкапа, возможно проблема с запросами")
            return None
            
        logger.info(f"Бэкап успешно создан: {backup_file} (размер: {file_size} байт)")
        return backup_file
    except Exception as e:
        logger.error(f"Ошибка при создании бэкапа: {e}")
        return None

def upload_to_yandex_disk(local_path: str, remote_folder: str = "backup") -> Optional[str]:
    """
    Загружает файл на Яндекс.Диск
    
    Args:
        local_path: Путь к локальному файлу
        remote_folder: Папка на Яндекс.Диске
        
    Returns:
        str: Путь к файлу на Яндекс.Диске или None в случае ошибки
    """
    try:
        # Получаем токен
        token = get_token_from_file()
        if not token:
            logger.error("Токен Яндекс.Диска не найден")
            return None
        
        # Формируем путь на Яндекс.Диске
        filename = os.path.basename(local_path)
        remote_path = f"{remote_folder}/{filename}"
        
        # Шаг 1: Получаем URL для загрузки файла
        upload_url = "https://cloud-api.yandex.net/v1/disk/resources/upload"
        headers = {
            "Authorization": f"OAuth {token}"
        }
        params = {
            "path": remote_path,
            "overwrite": "true"
        }
        
        response = requests.get(upload_url, headers=headers, params=params)
        response.raise_for_status()
        
        # Получаем URL для загрузки
        href = response.json().get("href")
        if not href:
            logger.error("Не удалось получить URL для загрузки")
            return None
        
        # Шаг 2: Загружаем файл
        with open(local_path, "rb") as f:
            upload_response = requests.put(href, data=f)
            upload_response.raise_for_status()
        
        logger.info(f"Файл успешно загружен на Яндекс.Диск: {remote_path}")
        
        # Сохраняем информацию о бэкапе
        save_backup_info(local_path, remote_path)
        
        return remote_path
    except Exception as e:
        logger.error(f"Ошибка при загрузке файла на Яндекс.Диск: {e}")
        return None

def save_backup_info(local_path: str, remote_path: str) -> None:
    """
    Сохраняет информацию о созданном бэкапе
    
    Args:
        local_path: Путь к локальному файлу бэкапа
        remote_path: Путь к файлу на Яндекс.Диске
    """
    try:
        # Проверяем размер файла
        file_size = os.path.getsize(local_path)
        
        # Формируем информацию о бэкапе
        backup_info = {
            "local_path": local_path,
            "remote_path": remote_path,
            "size_bytes": file_size,
            "created_at": datetime.datetime.now().isoformat()
        }
        
        # Сохраняем информацию в лог
        logger.info(f"Информация о бэкапе: {backup_info}")
        
        # Сохраняем информацию в файл
        with open(os.path.join(TEMP_DIR, "backup_log.json"), "a") as f:
            f.write(json.dumps(backup_info) + "\n")
        
        # Пытаемся сохранить информацию в базу данных
        try:
            from db_models import db, BackupLog
            from db_config import get_flask_app
            
            app = get_flask_app()
            with app.app_context():
                backup_log = BackupLog(
                    backup_file=os.path.basename(local_path),
                    disk_path=remote_path,
                    size_bytes=file_size,
                    status="success"
                )
                db.session.add(backup_log)
                db.session.commit()
                
            logger.info("Информация о бэкапе сохранена в базу данных")
        except ImportError:
            logger.warning("Не удалось импортировать модули для работы с базой данных")
        except Exception as e:
            logger.error(f"Ошибка при сохранении информации о бэкапе в базу данных: {e}")
    except Exception as e:
        logger.error(f"Ошибка при сохранении информации о бэкапе: {e}")

def cleanup_old_backups(keep_days: int = 7) -> None:
    """
    Удаляет старые локальные бэкапы
    
    Args:
        keep_days: Количество дней, в течение которых нужно хранить бэкапы
    """
    try:
        # Получаем текущую дату
        now = datetime.datetime.now()
        
        # Перебираем файлы в папке с бэкапами
        for filename in os.listdir(TEMP_DIR):
            # Пропускаем файлы логов
            if filename == "backup_log.json":
                continue
            
            # Проверяем, является ли файл бэкапом
            if filename.startswith("backup_") and filename.endswith(".sql"):
                file_path = os.path.join(TEMP_DIR, filename)
                
                # Получаем время создания файла
                file_time = datetime.datetime.fromtimestamp(os.path.getctime(file_path))
                
                # Вычисляем разницу в днях
                days_diff = (now - file_time).days
                
                # Если файл старше указанного срока, удаляем его
                if days_diff > keep_days:
                    os.remove(file_path)
                    logger.info(f"Удален старый бэкап: {file_path} (возраст: {days_diff} дней)")
    except Exception as e:
        logger.error(f"Ошибка при очистке старых бэкапов: {e}")

def main() -> None:
    """
    Основная функция
    """
    import argparse
    
    # Парсинг аргументов командной строки
    parser = argparse.ArgumentParser(description='Создание и загрузка резервной копии базы данных на Яндекс.Диск')
    parser.add_argument('--schema-only', action='store_true', help='Создать бэкап только схемы (без данных)')
    args = parser.parse_args()
    
    logger.info("Запуск процесса создания резервной копии базы данных")
    logger.info(f"Режим: {'только схема' if args.schema_only else 'полный (схема + данные)'}")
    
    try:
        # Шаг 1: Создаем бэкап
        backup_file = create_database_backup(schema_only=args.schema_only)
        if not backup_file:
            logger.error("Не удалось создать бэкап")
            return
        
        # Шаг 2: Загружаем бэкап на Яндекс.Диск
        remote_path = upload_to_yandex_disk(backup_file)
        if not remote_path:
            logger.error("Не удалось загрузить бэкап на Яндекс.Диск")
            return
        
        # Шаг 3: Очищаем старые бэкапы
        cleanup_old_backups()
        
        logger.info("Процесс создания резервной копии успешно завершен")
    except Exception as e:
        logger.error(f"Ошибка при создании резервной копии: {e}")

if __name__ == "__main__":
    main()