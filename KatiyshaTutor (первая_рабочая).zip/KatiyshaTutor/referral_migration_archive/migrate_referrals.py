#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для миграции данных реферальной системы из старого формата в новый
"""

import os
import json
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Пути к файлам баз данных
OLD_DB_PATH = "users_db.json"
NEW_DB_PATH = "users_db.json"  # Тот же файл, так как мы сохраняем в ту же БД с новой структурой

def load_database(path: str) -> Dict[str, Any]:
    """Загрузка базы данных из файла"""
    try:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as file:
                return json.load(file)
        else:
            logger.error(f"База данных {path} не найдена")
            return {"users": {}}
    except Exception as e:
        logger.error(f"Ошибка загрузки базы данных: {str(e)}")
        return {"users": {}}

def save_database(db: Dict[str, Any], path: str) -> None:
    """Сохранение базы данных в файл"""
    try:
        # Создаем резервную копию перед сохранением
        if os.path.exists(path):
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"{path}_backup_{timestamp}"
            with open(backup_path, 'w', encoding='utf-8') as file:
                json.dump(db, file, ensure_ascii=False, indent=2)
            logger.info(f"Создана резервная копия базы данных: {backup_path}")
        
        with open(path, 'w', encoding='utf-8') as file:
            json.dump(db, file, ensure_ascii=False, indent=2)
        logger.info(f"База данных успешно сохранена: {path}")
    except Exception as e:
        logger.error(f"Ошибка сохранения базы данных: {str(e)}")

def migrate_referral_data(old_db: Dict[str, Any]) -> Dict[str, Any]:
    """Миграция данных реферальной системы из старого формата в новый"""
    # Создаем копию базы данных, чтобы не изменять оригинал
    new_db = {"users": {}}
    
    # Для отслеживания прогресса
    total_users = len(old_db.get("users", {}))
    migrated_users = 0
    
    # Обрабатываем каждого пользователя
    for user_id, user_data in old_db.get("users", {}).items():
        # Копируем основные данные пользователя
        new_user_data = {
            "id": user_data.get("id"),
            "username": user_data.get("username"),
            "first_name": user_data.get("first_name"),
            "last_name": user_data.get("last_name"),
            "free_request_used": user_data.get("free_request_used", False),
            "subscription_expiry": user_data.get("subscription_expiry"),
            "referral_code": user_data.get("referral_code"),
            "referrer_id": user_data.get("referrer_id"),
            "referrals": {
                "level1": [],
                "level2": [],
                "level3": [],
                "level4": []
            }
        }
        
        # Мигрируем реферальные данные в новый формат
        old_referrals = user_data.get("referrals", [])
        old_referral_levels = user_data.get("referral_levels", {})
        
        # Проверяем, в каком формате хранятся данные о рефералах
        if isinstance(old_referrals, list):
            # Если в виде списка, переносим в level1
            new_user_data["referrals"]["level1"] = old_referrals
        elif isinstance(old_referrals, dict):
            # Если уже в виде словаря с уровнями, просто копируем
            new_user_data["referrals"] = old_referrals
        
        # Если есть старая структура referral_levels, добавляем в новую структуру
        if old_referral_levels:
            for level, referrals in old_referral_levels.items():
                if level in ["1", "2", "3", "4"]:
                    level_key = f"level{level}"
                    if isinstance(referrals, list):
                        # Добавляем только если они уже не добавлены
                        for ref_id in referrals:
                            if ref_id not in new_user_data["referrals"][level_key]:
                                new_user_data["referrals"][level_key].append(ref_id)
        
        # Сохраняем обновленные данные пользователя
        new_db["users"][user_id] = new_user_data
        migrated_users += 1
        
        # Логируем прогресс каждые 100 пользователей
        if migrated_users % 100 == 0:
            logger.info(f"Обработано {migrated_users}/{total_users} пользователей")
    
    logger.info(f"Миграция завершена. Всего обработано {migrated_users} пользователей")
    return new_db

def rebuild_referral_chains(db: Dict[str, Any]) -> Dict[str, Any]:
    """Перестроение реферальных цепочек для обеспечения целостности данных"""
    # Создаем копию базы данных
    updated_db = {"users": {}}
    for user_id, user_data in db["users"].items():
        updated_db["users"][user_id] = user_data.copy()
    
    # Сбрасываем все списки рефералов кроме уровня 1
    for user_id, user_data in updated_db["users"].items():
        if "referrals" in user_data and isinstance(user_data["referrals"], dict):
            # Сохраняем только прямых рефералов (уровень 1)
            level1_referrals = user_data["referrals"].get("level1", [])
            user_data["referrals"] = {
                "level1": level1_referrals,
                "level2": [],
                "level3": [],
                "level4": []
            }
    
    # Проходим по всем пользователям и обновляем их реферальные цепочки
    for user_id, user_data in updated_db["users"].items():
        referrer_id = user_data.get("referrer_id")
        if referrer_id:
            # Если у пользователя есть реферер, обновляем цепочку
            update_referral_chain(updated_db, int(user_id), referrer_id, 1)
    
    logger.info("Реферальные цепочки успешно перестроены")
    return updated_db

def update_referral_chain(db: Dict[str, Any], user_id: int, referrer_id: int, level: int) -> None:
    """
    Рекурсивное обновление цепочки рефералов
    
    Args:
        db: База данных
        user_id: ID пользователя
        referrer_id: ID реферера
        level: Текущий уровень в цепочке
    """
    if level > 4 or not referrer_id:
        return
    
    # Получаем данные реферера
    referrer_data = db["users"].get(str(referrer_id))
    if not referrer_data:
        return
    
    # Добавляем пользователя в список рефералов соответствующего уровня
    level_key = f"level{level}"
    if "referrals" not in referrer_data:
        referrer_data["referrals"] = {
            "level1": [],
            "level2": [],
            "level3": [],
            "level4": [],
        }
    
    if not isinstance(referrer_data["referrals"].get(level_key), list):
        referrer_data["referrals"][level_key] = []
    
    if user_id not in referrer_data["referrals"][level_key]:
        referrer_data["referrals"][level_key].append(user_id)
    
    # Рекурсивно обновляем вышестоящие уровни
    next_referrer_id = referrer_data.get("referrer_id")
    if next_referrer_id:
        update_referral_chain(db, user_id, next_referrer_id, level + 1)

def main() -> None:
    """Основная функция скрипта"""
    logger.info("Начало миграции реферальной системы")
    
    # Загружаем базу данных
    logger.info(f"Загрузка базы данных из {OLD_DB_PATH}")
    old_db = load_database(OLD_DB_PATH)
    
    # Миграция данных
    logger.info("Миграция реферальных данных")
    migrated_db = migrate_referral_data(old_db)
    
    # Перестроение реферальных цепочек
    logger.info("Перестроение реферальных цепочек")
    updated_db = rebuild_referral_chains(migrated_db)
    
    # Сохранение обновленной базы данных
    logger.info(f"Сохранение обновленной базы данных в {NEW_DB_PATH}")
    save_database(updated_db, NEW_DB_PATH)
    
    logger.info("Миграция реферальной системы успешно завершена")

if __name__ == "__main__":
    main()