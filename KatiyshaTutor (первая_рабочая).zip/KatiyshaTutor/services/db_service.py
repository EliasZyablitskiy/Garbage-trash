#!/usr/bin/env python
# coding: utf-8

"""
Service for working with PostgreSQL database
"""

import json
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple, Union

from sqlalchemy.exc import SQLAlchemyError
from flask import Flask

from db_config import get_flask_app
from db_models import db, User, MathProblem, Transaction, WeeklyPayout

logger = logging.getLogger(__name__)

# Получаем Flask приложение с настроенной БД
app = get_flask_app()

def get_user(user_id: int) -> Optional[Dict[str, Any]]:
    """
    Get user data from the database
    
    Args:
        user_id: Telegram user ID
        
    Returns:
        dict: User data or None if not found
    """
    with app.app_context():
        try:
            user = User.query.get(user_id)
            if user:
                return user.to_dict()
            return None
        except SQLAlchemyError as e:
            logger.error(f"Database error getting user {user_id}: {e}")
            return None

def get_total_users_count() -> int:
    """
    Get total number of users in the database
    
    Returns:
        int: Number of users
    """
    with app.app_context():
        try:
            # Используем SQL-запрос напрямую для подсчета пользователей
            result = db.session.execute(db.text("SELECT COUNT(*) FROM users")).scalar()
            logger.debug(f"Total users in the database: {result}")
            return result or 0
        except Exception as e:
            logger.error(f"Database error counting users: {e}")
            return 0

def save_user(user_data: Dict[str, Any]) -> bool:
    """
    Save user data to the database
    
    Args:
        user_data: User data to save (must contain 'id' key)
        
    Returns:
        bool: True if successful, False otherwise
    """
    if "id" not in user_data:
        logger.error("Cannot save user without 'id' field")
        return False
    
    user_id = user_data["id"]
    
    with app.app_context():
        try:
            # Проверяем, существует ли пользователь
            user = User.query.get(user_id)
            
            if not user:
                # Создаем нового пользователя
                user = User(
                    id=user_id,
                    username=user_data.get('username'),
                    first_name=user_data.get('first_name'),
                    last_name=user_data.get('last_name'),
                    free_request_used=user_data.get('free_request_used', False),
                    referral_code=user_data.get('referral_code'),
                    referrer_id=user_data.get('referrer_id')
                )
                
                # Обрабатываем subscription_expiry
                if 'subscription_expiry' in user_data and user_data['subscription_expiry']:
                    try:
                        user.subscription_expiry = datetime.fromisoformat(user_data['subscription_expiry'])
                    except (ValueError, TypeError):
                        user.subscription_expiry = None
                
                # Обрабатываем referrals
                if 'referrals' in user_data:
                    user.referrals_dict = user_data.get('referrals', {
                        "level1": [],
                        "level2": [],
                        "level3": [],
                        "level4": []
                    })
                
                db.session.add(user)
            else:
                # Обновляем существующего пользователя
                user.username = user_data.get('username', user.username)
                user.first_name = user_data.get('first_name', user.first_name)
                user.last_name = user_data.get('last_name', user.last_name)
                user.free_request_used = user_data.get('free_request_used', user.free_request_used)
                user.referral_code = user_data.get('referral_code', user.referral_code)
                user.referrer_id = user_data.get('referrer_id', user.referrer_id)
                
                # Обрабатываем subscription_expiry
                if 'subscription_expiry' in user_data:
                    if user_data['subscription_expiry']:
                        try:
                            user.subscription_expiry = datetime.fromisoformat(user_data['subscription_expiry'])
                        except (ValueError, TypeError):
                            pass
                    else:
                        user.subscription_expiry = None
                
                # Обрабатываем referrals
                if 'referrals' in user_data:
                    user.referrals_dict = user_data.get('referrals')
            
            db.session.commit()
            logger.debug(f"User {user_id} saved to database")
            return True
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error saving user {user_id}: {e}")
            return False

def update_user_subscription(user_id: int, expiry_date: str) -> bool:
    """
    Update a user's subscription expiry date
    
    Args:
        user_id: Telegram user ID
        expiry_date: ISO format date string for subscription expiry
        
    Returns:
        bool: True if successful, False otherwise
    """
    with app.app_context():
        try:
            user = User.query.get(user_id)
            
            if not user:
                logger.warning(f"Attempted to update subscription for non-existent user {user_id}")
                return False
            
            try:
                expiry_datetime = datetime.fromisoformat(expiry_date)
                user.subscription_expiry = expiry_datetime
                user.subscription_end = expiry_datetime  # Обновляем также поле subscription_end для совместимости
                db.session.commit()
                logger.info(f"Updated subscription for user {user_id} to {expiry_date}")
                return True
            except (ValueError, TypeError) as e:
                logger.error(f"Invalid date format for subscription expiry: {e}")
                return False
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error updating subscription for user {user_id}: {e}")
            return False

def get_user_by_referral_code(referral_code: str) -> Optional[Dict[str, Any]]:
    """
    Get user by referral code
    
    Args:
        referral_code: Referral code to search for
        
    Returns:
        dict: User data or None if not found
    """
    with app.app_context():
        try:
            user = User.query.filter_by(referral_code=referral_code).first()
            if user:
                return user.to_dict()
            return None
        except SQLAlchemyError as e:
            logger.error(f"Database error getting user by referral code {referral_code}: {e}")
            return None

def get_users_with_expiring_subscriptions(start_date: datetime, end_date: datetime) -> List[Dict[str, Any]]:
    """
    Получает список пользователей, у которых срок действия подписки истекает в указанном диапазоне дат
    
    Args:
        start_date: Начало периода
        end_date: Конец периода
        
    Returns:
        List[Dict[str, Any]]: Список данных пользователей, у которых истекает подписка
    """
    with app.app_context():
        try:
            # Устанавливаем время до конца дня для end_date
            end_of_day = end_date.replace(hour=23, minute=59, second=59)
            
            # Получаем пользователей, у которых срок подписки истекает в указанном периоде
            users = User.query.filter(
                User.subscription_expiry >= start_date,
                User.subscription_expiry <= end_of_day
            ).all()
            
            # Преобразуем в список словарей
            return [user.to_dict() for user in users]
        except SQLAlchemyError as e:
            logger.error(f"Database error getting users with expiring subscriptions: {e}")
            return []

def save_math_problem(problem_data: Dict[str, Any]) -> Optional[int]:
    """
    Save math problem to database
    
    Args:
        problem_data: Math problem data
        
    Returns:
        int: ID of the saved problem or None if error
    """
    if "user_id" not in problem_data or "problem_text" not in problem_data:
        logger.error("Cannot save math problem without 'user_id' and 'problem_text' fields")
        return None
    
    with app.app_context():
        try:
            problem = MathProblem(
                user_id=problem_data["user_id"],
                problem_text=problem_data["problem_text"],
                image_path=problem_data.get("image_path"),
                solution=problem_data.get("solution")
            )
            
            db.session.add(problem)
            db.session.commit()
            
            logger.debug(f"Math problem saved for user {problem_data['user_id']}")
            return problem.id
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error saving math problem: {e}")
            return None

def add_transaction(
    transaction_type: str,
    user_id: int,
    amount: float,
    description: str,
    related_user_id: Optional[int] = None,
    status: str = "pending",
    payment_data: Optional[Dict[str, Any]] = None
) -> Optional[int]:
    """
    Add a new transaction to the database
    
    Args:
        transaction_type: Type of transaction (subscription, referral_reward, payout)
        user_id: ID of the user associated with the transaction
        amount: Amount of the transaction in rubles
        description: Description of the transaction
        related_user_id: ID of the related user (e.g., referrer for rewards)
        status: Status of the transaction (pending, completed, failed)
        payment_data: Additional payment data
        
    Returns:
        int: ID of the transaction or None if error
    """
    with app.app_context():
        try:
            transaction = Transaction(
                type=transaction_type,
                user_id=user_id,
                amount=amount,
                description=description,
                related_user_id=related_user_id,
                status=status,
                payment_data=payment_data or {}
            )
            
            db.session.add(transaction)
            db.session.commit()
            
            logger.info(f"Added transaction {transaction.id}: {transaction_type} for user {user_id}, amount: {amount}₽")
            return transaction.id
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error adding transaction: {e}")
            return None

def update_transaction_status(transaction_id: int, status: str, payment_data: Optional[Dict[str, Any]] = None) -> bool:
    """
    Update transaction status
    
    Args:
        transaction_id: ID of the transaction
        status: New status (pending, completed, failed)
        payment_data: Additional payment data to update
        
    Returns:
        bool: True if successful, False otherwise
    """
    with app.app_context():
        try:
            transaction = Transaction.query.get(transaction_id)
            
            if not transaction:
                logger.warning(f"Transaction {transaction_id} not found for update")
                return False
            
            transaction.status = status
            
            if payment_data:
                if transaction.payment_data:
                    transaction.payment_data.update(payment_data)
                else:
                    transaction.payment_data = payment_data
            
            db.session.commit()
            
            logger.info(f"Updated status of transaction {transaction_id} to {status}")
            return True
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error updating transaction {transaction_id}: {e}")
            return False

def get_user_pending_rewards(user_id: int) -> float:
    """
    Get total pending rewards for a user
    
    Args:
        user_id: User ID
        
    Returns:
        float: Total pending rewards
    """
    with app.app_context():
        try:
            total = db.session.query(db.func.sum(Transaction.amount)).filter(
                Transaction.user_id == user_id,
                Transaction.type == "referral_reward",
                Transaction.status == "pending"
            ).scalar() or 0.0
            
            return float(total)
        except SQLAlchemyError as e:
            logger.error(f"Database error getting pending rewards for user {user_id}: {e}")
            return 0.0

def get_user_total_rewards(user_id: int) -> Dict[str, float]:
    """
    Get total rewards statistics for a user
    
    Args:
        user_id: User ID
        
    Returns:
        dict: Rewards statistics
    """
    stats = {
        "total_earned": 0.0,      # Всего заработано
        "total_pending": 0.0,      # Всего ожидает выплаты
        "total_paid": 0.0,         # Всего выплачено
        "total_processing": 0.0    # Всего в обработке
    }
    
    with app.app_context():
        try:
            # Всего заработано
            total_earned = db.session.query(db.func.sum(Transaction.amount)).filter(
                Transaction.user_id == user_id,
                Transaction.type == "referral_reward"
            ).scalar() or 0.0
            stats["total_earned"] = float(total_earned)
            
            # Ожидающие выплаты
            total_pending = db.session.query(db.func.sum(Transaction.amount)).filter(
                Transaction.user_id == user_id,
                Transaction.type == "referral_reward",
                Transaction.status == "pending"
            ).scalar() or 0.0
            stats["total_pending"] = float(total_pending)
            
            # Выплаченные
            total_paid = db.session.query(db.func.sum(Transaction.amount)).filter(
                Transaction.user_id == user_id,
                Transaction.type == "referral_reward",
                Transaction.status == "completed"
            ).scalar() or 0.0
            stats["total_paid"] = float(total_paid)
            
            # В обработке
            total_processing = db.session.query(db.func.sum(Transaction.amount)).filter(
                Transaction.user_id == user_id,
                Transaction.type == "referral_reward",
                Transaction.status.in_(["processing", "processing_payout"])
            ).scalar() or 0.0
            stats["total_processing"] = float(total_processing)
            
            return stats
        except SQLAlchemyError as e:
            logger.error(f"Database error getting reward statistics for user {user_id}: {e}")
            return stats

def get_transactions_by_status(status: str, transaction_type: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Get transactions by status and type
    
    Args:
        status: Status to filter by
        transaction_type: Type to filter by (optional)
        
    Returns:
        list: List of transactions
    """
    with app.app_context():
        try:
            query = Transaction.query.filter(Transaction.status == status)
            
            if transaction_type:
                query = query.filter(Transaction.type == transaction_type)
            
            transactions = query.all()
            return [t.to_dict() for t in transactions]
        except SQLAlchemyError as e:
            logger.error(f"Database error getting transactions by status {status}: {e}")
            return []

def create_weekly_payout() -> Optional[int]:
    """
    Create a weekly payout for pending rewards
    
    Returns:
        int: Payout ID or None if error
    """
    with app.app_context():
        try:
            # Получаем ожидающие транзакции
            pending_rewards = Transaction.query.filter_by(
                status="pending",
                type="referral_reward"
            ).all()
            
            if not pending_rewards:
                logger.warning("No pending referral rewards to payout")
                return None
            
            # Группируем транзакции по пользователям
            user_payouts = {}
            for transaction in pending_rewards:
                user_id = transaction.user_id
                if user_id not in user_payouts:
                    user_payouts[str(user_id)] = []
                
                user_payouts[str(user_id)].append(transaction.id)
            
            # Вычисляем общую сумму
            total_amount = sum(t.amount for t in pending_rewards)
            
            # Создаем запись о выплате
            payout = WeeklyPayout(
                status="processing",
                total_amount=total_amount,
                total_users=len(user_payouts),
                payout_data=user_payouts
            )
            
            db.session.add(payout)
            db.session.flush()  # Получаем ID без коммита
            
            # Обновляем транзакции
            for transaction in pending_rewards:
                transaction.status = "processing_payout"
                transaction.payout_id = payout.id
            
            db.session.commit()
            
            logger.info(f"Created weekly payout #{payout.id}: {total_amount}₽ for {len(user_payouts)} users")
            return payout.id
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error creating weekly payout: {e}")
            return None

def get_weekly_payouts(status: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Get weekly payouts
    
    Args:
        status: Status to filter by (optional)
        
    Returns:
        list: List of payouts
    """
    with app.app_context():
        try:
            query = WeeklyPayout.query
            
            if status:
                query = query.filter(WeeklyPayout.status == status)
            
            payouts = query.all()
            return [p.to_dict() for p in payouts]
        except SQLAlchemyError as e:
            logger.error(f"Database error getting weekly payouts: {e}")
            return []

def update_payout_status(payout_id: int, status: str) -> bool:
    """
    Update payout status
    
    Args:
        payout_id: Payout ID
        status: New status
        
    Returns:
        bool: True if successful, False otherwise
    """
    with app.app_context():
        try:
            payout = WeeklyPayout.query.get(payout_id)
            
            if not payout:
                logger.warning(f"Payout {payout_id} not found for update")
                return False
            
            # Обновляем статус выплаты
            payout.status = status
            
            # Обновляем статус связанных транзакций
            new_transaction_status = "completed" if status == "completed" else "pending"
            
            transactions = Transaction.query.filter_by(payout_id=payout_id).all()
            for transaction in transactions:
                transaction.status = new_transaction_status
            
            db.session.commit()
            
            logger.info(f"Updated status of payout {payout_id} to {status}")
            return True
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error updating payout {payout_id}: {e}")
            return False

def get_referral_statistics() -> Dict[str, Any]:
    """
    Get overall referral program statistics
    
    Returns:
        dict: Referral statistics
    """
    stats = {
        "total_subscriptions": 0,
        "total_referral_rewards": 0.0,
        "total_pending_rewards": 0.0,
        "total_paid_rewards": 0.0,
        "total_users_with_referrals": 0,
        "total_referred_users": 0
    }
    
    with app.app_context():
        try:
            # Общее количество подписок
            stats["total_subscriptions"] = db.session.query(db.func.count()).filter(
                User.subscription_expiry.isnot(None)
            ).scalar() or 0
            
            # Общая сумма реферальных вознаграждений
            stats["total_referral_rewards"] = float(db.session.query(db.func.sum(Transaction.amount)).filter(
                Transaction.type == "referral_reward"
            ).scalar() or 0.0)
            
            # Общая сумма ожидающих вознаграждений
            stats["total_pending_rewards"] = float(db.session.query(db.func.sum(Transaction.amount)).filter(
                Transaction.type == "referral_reward",
                Transaction.status == "pending"
            ).scalar() or 0.0)
            
            # Общая сумма выплаченных вознаграждений
            stats["total_paid_rewards"] = float(db.session.query(db.func.sum(Transaction.amount)).filter(
                Transaction.type == "referral_reward",
                Transaction.status == "completed"
            ).scalar() or 0.0)
            
            # Количество пользователей с рефералами
            stats["total_users_with_referrals"] = db.session.query(db.func.count(db.distinct(User.referrer_id))).filter(
                User.referrer_id.isnot(None)
            ).scalar() or 0
            
            # Количество пользователей, пришедших по реферальным ссылкам
            stats["total_referred_users"] = db.session.query(db.func.count()).filter(
                User.referrer_id.isnot(None)
            ).scalar() or 0
            
            return stats
        except SQLAlchemyError as e:
            logger.error(f"Database error getting referral statistics: {e}")
            return stats

def process_referral_rewards(subscriber_id: int, referrer_id: int) -> List[int]:
    """
    Process referral rewards when a subscription is activated
    
    Args:
        subscriber_id: ID of the user who activated the subscription
        referrer_id: ID of the referrer
        
    Returns:
        list: List of created transaction IDs
    """
    import config
    from config import SUBSCRIPTION_PRICE, REFERRAL_RATES
    
    # Стоимость подписки в рублях (конвертируем из копеек)
    SUBSCRIPTION_AMOUNT = SUBSCRIPTION_PRICE / 100.0
    
    transaction_ids = []
    
    with app.app_context():
        try:
            # Получаем данные реферера 1 уровня
            level1_referrer = User.query.get(referrer_id)
            
            if level1_referrer:
                # Рассчитываем вознаграждение
                level1_reward = SUBSCRIPTION_AMOUNT * REFERRAL_RATES["level1"]
                
                # Создаем транзакцию вознаграждения
                level1_transaction_id = add_transaction(
                    transaction_type="referral_reward",
                    user_id=referrer_id,
                    amount=level1_reward,
                    description=f"Реферальное вознаграждение 1 уровня от пользователя {subscriber_id}",
                    related_user_id=subscriber_id,
                    status="pending"
                )
                
                if level1_transaction_id:
                    transaction_ids.append(level1_transaction_id)
                
                # Обрабатываем реферера 2 уровня
                level2_referrer_id = level1_referrer.referrer_id
                if level2_referrer_id:
                    level2_referrer = User.query.get(level2_referrer_id)
                    
                    if level2_referrer:
                        # Рассчитываем вознаграждение
                        level2_reward = SUBSCRIPTION_AMOUNT * REFERRAL_RATES["level2"]
                        
                        # Создаем транзакцию вознаграждения
                        level2_transaction_id = add_transaction(
                            transaction_type="referral_reward",
                            user_id=level2_referrer_id,
                            amount=level2_reward,
                            description=f"Реферальное вознаграждение 2 уровня от пользователя {subscriber_id}",
                            related_user_id=subscriber_id,
                            status="pending"
                        )
                        
                        if level2_transaction_id:
                            transaction_ids.append(level2_transaction_id)
                        
                        # Обрабатываем реферера 3 уровня
                        level3_referrer_id = level2_referrer.referrer_id
                        if level3_referrer_id:
                            level3_referrer = User.query.get(level3_referrer_id)
                            
                            if level3_referrer:
                                # Рассчитываем вознаграждение
                                level3_reward = SUBSCRIPTION_AMOUNT * REFERRAL_RATES["level3"]
                                
                                # Создаем транзакцию вознаграждения
                                level3_transaction_id = add_transaction(
                                    transaction_type="referral_reward",
                                    user_id=level3_referrer_id,
                                    amount=level3_reward,
                                    description=f"Реферальное вознаграждение 3 уровня от пользователя {subscriber_id}",
                                    related_user_id=subscriber_id,
                                    status="pending"
                                )
                                
                                if level3_transaction_id:
                                    transaction_ids.append(level3_transaction_id)
                                
                                # Обрабатываем реферера 4 уровня
                                level4_referrer_id = level3_referrer.referrer_id
                                if level4_referrer_id:
                                    level4_referrer = User.query.get(level4_referrer_id)
                                    
                                    if level4_referrer:
                                        # Рассчитываем вознаграждение
                                        level4_reward = SUBSCRIPTION_AMOUNT * REFERRAL_RATES["level4"]
                                        
                                        # Создаем транзакцию вознаграждения
                                        level4_transaction_id = add_transaction(
                                            transaction_type="referral_reward",
                                            user_id=level4_referrer_id,
                                            amount=level4_reward,
                                            description=f"Реферальное вознаграждение 4 уровня от пользователя {subscriber_id}",
                                            related_user_id=subscriber_id,
                                            status="pending"
                                        )
                                        
                                        if level4_transaction_id:
                                            transaction_ids.append(level4_transaction_id)
            
            return transaction_ids
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error processing referral rewards: {e}")
            return []