#!/usr/bin/env python
# coding: utf-8

"""
Запуск веб-сервера с Flask-приложением
"""

import logging
from webhook_handler import app

if __name__ == "__main__":
    logging.basicConfig(
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level=logging.INFO
    )
    app.run(host="0.0.0.0", port=5000, debug=True)