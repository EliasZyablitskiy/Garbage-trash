#!/usr/bin/env python3
"""
Скрипт для сохранения ручного токена Яндекс.Диска
"""
import os
import sys
import json
import datetime

def save_token_to_file(token, filename="yandex_token.json"):
    """
    Сохраняет токен в файл
    """
    try:
        # Формируем структуру данных как у обычного OAuth-токена
        token_data = {
            "access_token": token,
            "token_type": "Bearer",
            "obtained_at": datetime.datetime.now().isoformat()
        }
        
        with open(filename, "w") as f:
            json.dump(token_data, f, indent=4)
        print(f"Токен сохранен в файл: {filename}")
        return token_data
    except Exception as e:
        print(f"Ошибка при сохранении токена в файл: {e}")
        return None

def save_token_to_database(token_data):
    """
    Сохраняет токен в базу данных
    """
    try:
        from db_models import db, YandexDiskToken
        from db_config import get_flask_app
        
        app = get_flask_app()
        with app.app_context():
            # Удаляем существующие токены
            YandexDiskToken.query.delete()
            
            # Создаем новый токен
            new_token = YandexDiskToken(
                access_token=token_data.get("access_token"),
                token_type=token_data.get("token_type", "Bearer")
            )
            
            db.session.add(new_token)
            db.session.commit()
            
        print("Токен успешно сохранен в базе данных")
        return True
    except ImportError:
        print("Модули для работы с базой данных не найдены. Токен сохранен только в файл.")
        return False
    except Exception as e:
        print(f"Ошибка при сохранении токена в базу данных: {e}")
        return False

def main():
    """
    Основная функция
    """
    if len(sys.argv) > 1:
        # Получаем токен из аргумента командной строки
        token = sys.argv[1].strip()
        print(f"Используем токен: {token[:5]}...")
        
        # Сохраняем токен в файл и получаем структуру данных
        token_data = save_token_to_file(token)
        if token_data:
            # Сохраняем токен в базу данных
            save_token_to_database(token_data)
            print("\nУспешно! Теперь вы можете использовать Яндекс.Диск для бэкапов.")
    else:
        print("Использование:")
        print("   python save_yandex_token.py ТОКЕН")
        print("\nГде ТОКЕН - это OAuth-токен, полученный вручную с")
        print("https://yandex.ru/dev/disk/poligon/")
        print("\nШаги для получения токена:")
        print("1. Перейдите на https://yandex.ru/dev/disk/poligon/")
        print("2. Нажмите кнопку \"Получить OAuth-токен\"")
        print("3. Разрешите доступ")
        print("4. Скопируйте полученный токен")
        print("5. Запустите этот скрипт с токеном в качестве аргумента")

if __name__ == "__main__":
    main()