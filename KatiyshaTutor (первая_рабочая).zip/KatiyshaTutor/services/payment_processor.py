#!/usr/bin/env python
# coding: utf-8

"""
Сервис для обработки платежей с двухфазным коммитом и автоматическим закрытием просроченных платежей
"""

import os
import logging
import datetime
import json
import asyncio
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime, timedelta

from db_models import db, Transaction, User, UserPlatform
from database import get_user, update_user_data
from services.subscription_service import update_subscription_with_audit, log_subscription_audit
from services.platform_detection_service import (
    PLATFORM_UNKNOWN, PLATFORM_IOS, PLATFORM_ANDROID, 
    PLATFORM_DESKTOP, PLATFORM_WEB
)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Создаем и настраиваем обработчик файлового логирования
file_handler = logging.FileHandler("logs/payment_processor.log")
file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logger.addHandler(file_handler)

# Настройки для автоматического закрытия просроченных платежей
PAYMENT_EXPIRY_CHECK_INTERVAL = 60 * 30  # 30 минут
DEFAULT_PAYMENT_TIMEOUT_MINUTES = 60  # 1 час
PAYMENT_GRACE_PERIOD_MINUTES = 5  # Дополнительный период ожидания

class PaymentProcessor:
    """Процессор платежей с двухфазным коммитом и обработкой просроченных платежей"""
    
    def __init__(self, app=None):
        """
        Инициализация процессора платежей
        
        Args:
            app: Экземпляр Flask-приложения
        """
        self.app = app
        self.is_running = False
        self.task = None
    
    async def start(self, interval: int = PAYMENT_EXPIRY_CHECK_INTERVAL):
        """
        Запуск периодической проверки просроченных платежей
        
        Args:
            interval: Интервал проверки в секундах
        """
        if self.is_running:
            logger.warning("Payment processor is already running")
            return
        
        self.interval = interval
        self.is_running = True
        
        # Создаем и запускаем асинхронную задачу
        self.task = asyncio.create_task(self._run_periodic_check())
        logger.info(f"Payment processor started with interval {interval} seconds")
    
    async def stop(self):
        """Остановка процессора платежей"""
        if not self.is_running:
            logger.warning("Payment processor is not running")
            return
        
        self.is_running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            self.task = None
        
        logger.info("Payment processor stopped")
    
    async def _run_periodic_check(self):
        """Периодическая проверка просроченных платежей"""
        try:
            while self.is_running:
                # Немедленно выполняем первую проверку
                await self.process_expired_payments()
                
                # Ждем указанный интервал перед следующей проверкой
                for _ in range(self.interval):
                    if not self.is_running:
                        break
                    await asyncio.sleep(1)
        except asyncio.CancelledError:
            logger.info("Periodic payment check cancelled")
            raise
        except Exception as e:
            logger.error(f"Error in periodic payment check: {e}")
            # Перезапускаем задачу в случае неожиданной ошибки
            if self.is_running:
                self.task = asyncio.create_task(self._run_periodic_check())
    
    async def process_expired_payments(self) -> int:
        """
        Обрабатывает просроченные платежи
        
        Returns:
            int: Количество закрытых платежей
        """
        closed_count = 0
        
        if not self.app:
            logger.error("Cannot process payments: Flask app not provided")
            return closed_count
        
        try:
            # Время, до которого платежи считаются просроченными
            now = datetime.now()
            expiry_cutoff = now - timedelta(minutes=DEFAULT_PAYMENT_TIMEOUT_MINUTES + PAYMENT_GRACE_PERIOD_MINUTES)
            
            # Используем контекст Flask-приложения для работы с SQL базой данных
            with self.app.app_context():
                # Получаем все незавершенные платежи, у которых истек срок
                expired_payments = Transaction.query.filter(
                    Transaction.status == "pending",
                    Transaction.payment_method.in_(["sbp", "sbp_link", "sbp_manual", "sbp_link_auto", "sbp_link_desktop", "robokassa"]),
                    Transaction.payment_expires_at.isnot(None),
                    Transaction.payment_expires_at <= now
                ).all()
                
                # Также проверяем платежи без указанного срока истечения, но созданные давно
                old_payments = Transaction.query.filter(
                    Transaction.status == "pending",
                    Transaction.payment_method.in_(["sbp", "sbp_link", "sbp_manual", "sbp_link_auto", "sbp_link_desktop", "robokassa"]),
                    (Transaction.payment_expires_at.is_(None)) & 
                    (Transaction.created_at <= expiry_cutoff)
                ).all()
                
                expired_payments.extend(old_payments)
                
                # Обрабатываем каждый просроченный платеж
                for payment in expired_payments:
                    try:
                        # Отмечаем платеж как просроченный
                        payment.status = "expired"
                        payment.updated_at = now
                        
                        # Добавляем запись о причине истечения срока
                        if not payment.notes:
                            payment.notes = {}
                        
                        if isinstance(payment.notes, str):
                            try:
                                notes = json.loads(payment.notes)
                            except:
                                notes = {}
                        else:
                            notes = payment.notes
                        
                        notes["expired_reason"] = "Timeout: payment not completed within allowed time"
                        notes["expired_at"] = now.isoformat()
                        payment.notes = notes
                        
                        db.session.commit()
                        closed_count += 1
                        
                        logger.info(f"Marked payment as expired: transaction_id={payment.id}, user_id={payment.user_id}, method={payment.payment_method}")
                    except Exception as e:
                        db.session.rollback()
                        logger.error(f"Error processing expired payment {payment.id}: {e}")
                
                if closed_count > 0:
                    logger.info(f"Processed {closed_count} expired payments")
        
        except Exception as e:
            logger.error(f"Error in process_expired_payments: {e}")
        
        return closed_count
    
    def get_user_platform_info(self, user_id: int) -> Dict[str, Any]:
        """
        Получает информацию о платформе пользователя из базы данных
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Dict[str, Any]: Информация о платформе пользователя или словарь с платформой по умолчанию
        """
        if not self.app:
            return {"platform": PLATFORM_UNKNOWN, "version": None}
            
        try:
            with self.app.app_context():
                platform_info = UserPlatform.query.filter_by(user_id=user_id).order_by(
                    UserPlatform.last_seen.desc()
                ).first()
                
                if platform_info:
                    return {
                        "platform": platform_info.platform_type,
                        "version": platform_info.platform_version,
                        "device": platform_info.device_type,
                        "last_updated": platform_info.last_seen.isoformat() if platform_info.last_seen else None,
                        "user_agent": platform_info.user_agent
                    }
        except Exception as e:
            logger.error(f"Error getting platform info for user {user_id}: {e}")
            
        return {"platform": PLATFORM_UNKNOWN, "version": None}
    
    async def process_payment(self, transaction_id: int, verify_callback=None) -> Tuple[bool, str, Dict[str, Any]]:
        """
        Обрабатывает платеж с использованием двухфазного коммита
        с учетом платформы пользователя
        
        Args:
            transaction_id: ID транзакции для обработки
            verify_callback: Опциональная функция для дополнительной верификации платежа
        
        Returns:
            Tuple[bool, str, Dict[str, Any]]: (успех, сообщение, данные результата)
        """
        if not self.app:
            return False, "Flask app not provided", {}
        
        result_data = {
            "transaction_id": transaction_id,
            "status": "error",
            "logs": [],
            "platform_specific_processing": False
        }
        
        # Используем контекст Flask-приложения для работы с SQL базой данных
        with self.app.app_context():
            # Начинаем транзакцию
            db_session = db.session
            
            try:
                # Фаза 1: Проверка и подготовка
                transaction = Transaction.query.get(transaction_id)
                if not transaction:
                    return False, f"Transaction not found: {transaction_id}", result_data
                
                # Получаем информацию о платформе пользователя
                platform_info = self.get_user_platform_info(transaction.user_id)
                result_data["platform_info"] = platform_info
                
                result_data["user_id"] = transaction.user_id
                result_data["amount"] = transaction.amount
                result_data["logs"].append(f"Started processing transaction {transaction_id} for platform {platform_info['platform']}")
                
                # Проверяем текущий статус транзакции
                if transaction.status != "pending":
                    message = f"Transaction {transaction_id} is not in pending status (current: {transaction.status})"
                    result_data["logs"].append(message)
                    result_data["status"] = transaction.status
                    return False, message, result_data
                
                # Проверяем, не истек ли срок платежа
                if transaction.payment_expires_at and transaction.payment_expires_at <= datetime.now():
                    message = f"Transaction {transaction_id} has expired at {transaction.payment_expires_at.isoformat()}"
                    result_data["logs"].append(message)
                    
                    # Отмечаем платеж как просроченный в отдельной транзакции
                    transaction.status = "expired"
                    transaction.updated_at = datetime.now()
                    db_session.commit()
                    
                    result_data["status"] = "expired"
                    return False, message, result_data
                
                # Если передан колбэк для верификации, вызываем его
                if verify_callback:
                    is_valid, verify_message = await verify_callback(transaction)
                    if not is_valid:
                        result_data["logs"].append(f"Verification failed: {verify_message}")
                        return False, verify_message, result_data
                    result_data["logs"].append("Payment verification succeeded")
                
                # Получаем пользователя из базы данных
                user = User.query.get(transaction.user_id)
                if not user:
                    message = f"User not found: {transaction.user_id}"
                    result_data["logs"].append(message)
                    return False, message, result_data
                
                # Получаем информацию о платформе пользователя
                platform_info = self.get_user_platform_info(transaction.user_id)
                result_data["platform_info"] = platform_info
                result_data["logs"].append(f"Platform: {platform_info.get('platform', PLATFORM_UNKNOWN)}, version: {platform_info.get('version', 'unknown')}")
                
                # Проверяем, нужна ли платформо-специфичная обработка
                platform_type = platform_info.get("platform", PLATFORM_UNKNOWN)
                if platform_type != PLATFORM_UNKNOWN:
                    result_data["platform_specific_processing"] = True
                    # Добавляем информацию о платформе в заметки транзакции для последующего анализа
                    if not transaction.notes:
                        transaction.notes = {}
                    elif isinstance(transaction.notes, str):
                        try:
                            transaction.notes = json.loads(transaction.notes)
                        except:
                            transaction.notes = {}
                    transaction.notes["platform"] = platform_type
                    transaction.notes["platform_version"] = platform_info.get("version")
                    transaction.notes["device"] = platform_info.get("device")
                    db_session.commit()
                result_data["logs"].append(f"Found user {user.id}")
                
                # Определяем новый срок подписки
                payment_type = transaction.type
                subscription_details = {}
                
                if payment_type == "subscription_payment":
                    # Стандартный платеж за подписку на 30 дней
                    now = datetime.now()
                    
                    # Если у пользователя уже есть активная подписка, продлеваем ее
                    if user.subscription_end and user.subscription_end > now:
                        new_end_date = user.subscription_end + timedelta(days=30)
                        subscription_details["action"] = "extend"
                        subscription_details["old_date"] = user.subscription_end.isoformat()
                    else:
                        new_end_date = now + timedelta(days=30)
                        subscription_details["action"] = "activate"
                        subscription_details["old_date"] = str(user.subscription_end) if user.subscription_end else "None"
                    
                    subscription_details["new_date"] = new_end_date.isoformat()
                    result_data["logs"].append(f"Calculated new subscription end date: {new_end_date.isoformat()}")
                
                # Фаза 2: Фиксация
                try:
                    # Обновляем статус транзакции на "processing"
                    transaction.status = "processing"
                    transaction.updated_at = datetime.now()
                    db_session.commit()
                    result_data["logs"].append("Transaction marked as processing")
                    
                    # Обновляем подписку пользователя
                    if payment_type == "subscription_payment":
                        # Обновляем в SQL
                        user.subscription_expiry = new_end_date
                        user.subscription_end = new_end_date
                        db_session.commit()
                        result_data["logs"].append("SQL subscription updated")
                        
                        # Обновляем в JSON с аудитом
                        from services.subscription_service import update_subscription_with_audit
                        await update_subscription_with_audit(
                            user_id=user.id,
                            expiry_date=new_end_date,
                            reason="payment",
                            details={
                                "transaction_id": transaction.id,
                                "payment_method": transaction.payment_method,
                                "amount": transaction.amount
                            }
                        )
                        result_data["logs"].append("JSON subscription updated")
                    
                    # Выполняем платформо-зависимую обработку, если требуется
                    if result_data.get("platform_specific_processing", False):
                        platform_type = result_data.get("platform_info", {}).get("platform", PLATFORM_UNKNOWN)
                        result_data["logs"].append(f"Applying platform-specific processing for {platform_type}")
                        
                        # Особая обработка для iOS
                        if platform_type == PLATFORM_IOS:
                            # Для iOS добавляем пометку в notes об особенностях обработки
                            if not transaction.notes:
                                transaction.notes = {}
                            elif isinstance(transaction.notes, str):
                                try:
                                    transaction.notes = json.loads(transaction.notes)
                                except:
                                    transaction.notes = {}
                            transaction.notes["ios_optimization"] = True
                            transaction.notes["ios_formatted_date"] = new_end_date.strftime("%d.%m.%Y")
                            result_data["logs"].append(f"Applied iOS-specific optimizations")
                        
                        # Особая обработка для Android
                        elif platform_type == PLATFORM_ANDROID:
                            if not transaction.notes:
                                transaction.notes = {}
                            elif isinstance(transaction.notes, str):
                                try:
                                    transaction.notes = json.loads(transaction.notes)
                                except:
                                    transaction.notes = {}
                            transaction.notes["android_optimization"] = True
                            result_data["logs"].append(f"Applied Android-specific optimizations")
                    
                    # Обновляем статус транзакции на "completed"
                    transaction.status = "completed"
                    transaction.updated_at = datetime.now()
                    
                    # Добавляем информацию о примененных изменениях
                    if not transaction.notes:
                        transaction.notes = {}
                    
                    if isinstance(transaction.notes, str):
                        try:
                            notes = json.loads(transaction.notes)
                        except:
                            notes = {}
                    else:
                        notes = transaction.notes
                    
                    notes["subscription_details"] = subscription_details
                    notes["completed_at"] = datetime.now().isoformat()
                    transaction.notes = notes
                    
                    db_session.commit()
                    result_data["logs"].append("Transaction marked as completed")
                    
                    # Формируем результат
                    result_data["status"] = "completed"
                    return True, "Payment processed successfully", result_data
                    
                except Exception as inner_e:
                    # Если что-то пошло не так, откатываем изменения и записываем ошибку
                    db_session.rollback()
                    # Получаем информацию о платформе из result_data
                    platform_info = result_data.get("platform_info", {})
                    platform_type = platform_info.get("platform", PLATFORM_UNKNOWN)
                    
                    # Логируем ошибку с информацией о платформе
                    logger.error(f"Error in payment processing (phase 2) for platform {platform_type}: {inner_e}")
                    result_data["logs"].append(f"Error in phase 2 for platform {platform_type}: {str(inner_e)}")
                    result_data["platform_error"] = True
                    
                    # Отмечаем транзакцию как failed
                    try:
                        transaction = Transaction.query.get(transaction_id)
                        transaction.status = "failed"
                        transaction.updated_at = datetime.now()
                        
                        if not transaction.notes:
                            transaction.notes = {}
                        
                        if isinstance(transaction.notes, str):
                            try:
                                notes = json.loads(transaction.notes)
                            except:
                                notes = {}
                        else:
                            notes = transaction.notes
                        
                        notes["error"] = str(inner_e)
                        notes["failed_at"] = datetime.now().isoformat()
                        transaction.notes = notes
                        
                        db_session.commit()
                        result_data["logs"].append("Transaction marked as failed")
                    except Exception as recovery_e:
                        logger.error(f"Error recovering from payment failure: {recovery_e}")
                        result_data["logs"].append(f"Recovery error: {str(recovery_e)}")
                    
                    return False, f"Error processing payment: {str(inner_e)}", result_data
            
            except Exception as e:
                logger.error(f"Error in payment processing (phase 1): {e}")
                result_data["logs"].append(f"Error in phase 1: {str(e)}")
                return False, f"Error preparing payment: {str(e)}", result_data


# Создаем глобальный экземпляр процессора платежей
payment_processor = None

def init_payment_processor(app, auto_start: bool = True, interval: int = PAYMENT_EXPIRY_CHECK_INTERVAL) -> PaymentProcessor:
    """
    Инициализирует и возвращает глобальный экземпляр процессора платежей
    
    Args:
        app: Экземпляр Flask-приложения
        auto_start: Автоматически запускать проверку просроченных платежей
        interval: Интервал проверки в секундах
        
    Returns:
        PaymentProcessor: Экземпляр процессора платежей
    """
    global payment_processor
    
    if payment_processor is None:
        payment_processor = PaymentProcessor(app)
        
        if auto_start:
            # Запускаем процессор асинхронно
            loop = asyncio.get_event_loop()
            loop.create_task(payment_processor.start(interval))
    
    return payment_processor

async def process_single_payment(app, transaction_id: int, verify_callback=None) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Выполняет однократную обработку платежа
    
    Args:
        app: Экземпляр Flask-приложения
        transaction_id: ID транзакции для обработки
        verify_callback: Опциональная функция для дополнительной верификации платежа
        
    Returns:
        Tuple[bool, str, Dict[str, Any]]: (успех, сообщение, данные результата)
    """
    # Создаем временный экземпляр процессора платежей
    temp_processor = PaymentProcessor(app)
    return await temp_processor.process_payment(transaction_id, verify_callback)