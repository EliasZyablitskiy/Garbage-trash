#!/usr/bin/env python
# coding: utf-8

"""
Data models for the Katiysha bot
"""

from datetime import datetime
import random
import string
import logging
from typing import Dict, Any, Optional, List, Union, Tuple

# Set up logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

class User:
    """User model for storing user information and subscription status"""
    id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    free_request_used: bool = False
    subscription_expiry: Optional[datetime] = None
    referral_code: Optional[str] = None
    referrer_id: Optional[int] = None
    referrals: Optional[Dict[str, Any]] = None
    
    def __init__(self, user_id: int, username: Optional[str] = None, 
                 first_name: Optional[str] = None, last_name: Optional[str] = None):
        self.id = user_id
        self.username = username
        self.first_name = first_name
        self.last_name = last_name
        self.free_request_used = False
        self.subscription_expiry = None
        self.referral_code = None
        self.referrer_id = None
        self.referrals = {
            "level1": [],  # 5% (прямые рефералы)
            "level2": [],  # 2% (рефералы 2-го уровня)
            "level3": [],  # 2% (рефералы 3-го уровня)
            "level4": [],  # 2% (рефералы 4-го уровня)
        }
    
    def has_active_subscription(self) -> bool:
        """Check if user has an active subscription"""
        if not self.subscription_expiry:
            return False
        
        return datetime.now() < self.subscription_expiry
    
    def generate_referral_code(self) -> str:
        """Generate a unique referral code for the user"""
        if not self.referral_code:
            import uuid
            import base64
            # Создаем уникальный код на основе ID пользователя и случайного UUID
            code_base = f"{self.id}_{uuid.uuid4().hex[:8]}"
            # Кодируем в base64 и берем первые 10 символов
            self.referral_code = base64.b64encode(code_base.encode()).decode()[:10]
        return self.referral_code
    
    def get_referral_link(self) -> str:
        """Get full referral link for the user"""
        # We are importing here to avoid circular imports
        import config
        code = self.generate_referral_code()
        return f"https://t.me/{config.BOT_USERNAME}?start=ref_{code}"
    
    def can_solve_problem(self) -> bool:
        """Check if user can solve a problem (has free request or active subscription)"""
        return not self.free_request_used or self.has_active_subscription()
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'User':
        """Create a User instance from dictionary data"""
        user = cls(
            user_id=data['id'],
            username=data.get('username'),
            first_name=data.get('first_name'),
            last_name=data.get('last_name')
        )
        
        user.free_request_used = data.get('free_request_used', False)
        
        if 'subscription_expiry' in data and data['subscription_expiry']:
            try:
                user.subscription_expiry = datetime.fromisoformat(data['subscription_expiry'])
            except (ValueError, TypeError):
                user.subscription_expiry = None
        
        # Добавляем загрузку данных о рефералах
        user.referral_code = data.get('referral_code')
        user.referrer_id = data.get('referrer_id')
        user.referrals = data.get('referrals', {
            "level1": [],  # 5% (прямые рефералы)
            "level2": [],  # 2% (рефералы 2-го уровня)
            "level3": [],  # 2% (рефералы 3-го уровня)
            "level4": [],  # 2% (рефералы 4-го уровня)
        })
        
        return user
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert User instance to dictionary for storage"""
        data = {
            'id': self.id,
            'username': self.username,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'free_request_used': self.free_request_used
        }
        
        if self.subscription_expiry:
            data['subscription_expiry'] = self.subscription_expiry.isoformat()
        else:
            data['subscription_expiry'] = None
        
        # Добавляем сохранение данных о рефералах
        data['referral_code'] = self.referral_code
        data['referrer_id'] = self.referrer_id
        data['referrals'] = self.referrals
            
        return data

class MathProblem:
    """Math problem model for tracking user problems"""
    user_id: int
    problem_text: str
    image_path: Optional[str] = None
    solution: Optional[str] = None
    created_at: datetime = datetime.now()
    
    def __init__(self, user_id: int, problem_text: str, image_path: Optional[str] = None):
        self.user_id = user_id
        self.problem_text = problem_text
        self.image_path = image_path
        self.solution = None
        self.created_at = datetime.now()

class ReferralSystem:
    """Handles referral functionality including code generation, tracking, and commission calculation"""
    
    def __init__(self):
        """Initialize the referral system"""
        import database
        import config
        self.database = database
        self.config = config
    
    def generate_referral_code(self, user_id: int) -> str:
        """Generate a unique referral code for a user
        
        Args:
            user_id: The telegram ID of the user
            
        Returns:
            The generated referral code
        """
        user_data = self.database.get_user_data(user_id)
        if not user_data:
            logger.error(f"User {user_id} not found in database when generating referral code")
            return None
            
        if user_data.get('referral_code'):
            return user_data['referral_code']
            
        # Generate a unique code using user ID and random characters
        chars = string.ascii_uppercase + string.digits
        code_suffix = ''.join(random.choice(chars) for _ in range(6))
        ref_code = f"REF{user_id % 10000}{code_suffix}"
        
        # Update user data with the new code
        self.database.update_user_data(user_id, {"referral_code": ref_code})
        
        return ref_code
    
    def get_user_by_referral_code(self, code: str) -> Dict[str, Any]:
        """Find a user by their referral code
        
        Args:
            code: The referral code to search for
            
        Returns:
            The user data dictionary or None if not found
        """
        all_users = self.database.get_all_users()
        for user_id, user_data in all_users.items():
            if user_data.get('referral_code') == code:
                return user_data
        return None
    
    def add_referral(self, user_id: int, referral_code: str) -> bool:
        """Add a referral relationship between users
        
        Args:
            user_id: The ID of the user to be referred
            referral_code: The referral code of the referrer
            
        Returns:
            True if successful, False otherwise
        """
        # Get user data
        user_data = self.database.get_user_data(user_id)
        if not user_data:
            logger.error(f"User {user_id} not found in database")
            return False
        
        # Check if user already has a referrer
        if user_data.get('referrer_id'):
            logger.info(f"User {user_id} already has a referrer")
            return False
        
        # Find the referrer by code
        referrer_data = self.get_user_by_referral_code(referral_code)
        if not referrer_data:
            logger.info(f"No user found with referral code {referral_code}")
            return False
        
        # Prevent self-referrals
        if int(user_id) == int(referrer_data['id']):
            logger.warning(f"User {user_id} attempted to refer themselves")
            return False
        
        referrer_id = referrer_data['id']
        
        # Update the referred user's data
        self.database.update_user_data(user_id, {"referrer_id": referrer_id})
        
        # Update referrer's direct referrals
        if 'referrals' not in referrer_data:
            referrer_data['referrals'] = []
        if user_id not in referrer_data['referrals']:
            referrer_data['referrals'].append(user_id)
        
        # Initialize referral levels if not present
        if 'referral_levels' not in referrer_data:
            referrer_data['referral_levels'] = {"1": [], "2": [], "3": [], "4": []}
        
        # Add user to level 1 referrals of the referrer
        if user_id not in referrer_data['referral_levels']["1"]:
            referrer_data['referral_levels']["1"].append(user_id)
        
        # Update the referrer's data
        self.database.update_user_data(referrer_id, {"referrals": referrer_data['referrals'], 
                                                   "referral_levels": referrer_data['referral_levels']})
        
        # Update the referral chain up to 4 levels
        self._update_referral_chain(user_id, referrer_id, level=2)
        
        return True
    
    def _update_referral_chain(self, user_id: int, current_referrer_id: int, level: int) -> None:
        """Recursively update the referral chain for higher level referrers
        
        Args:
            user_id: The ID of the new user being added to the chain
            current_referrer_id: The ID of the current referrer in the chain
            level: The current level in the referral chain (2-4)
        """
        if level > 4:
            return
        
        # Get the referrer's data
        referrer_data = self.database.get_user_data(current_referrer_id)
        if not referrer_data or not referrer_data.get('referrer_id'):
            return
        
        # Get the next level referrer
        next_referrer_id = referrer_data['referrer_id']
        next_referrer_data = self.database.get_user_data(next_referrer_id)
        
        if not next_referrer_data:
            return
        
        # Initialize referral levels if not present
        if 'referral_levels' not in next_referrer_data:
            next_referrer_data['referral_levels'] = {"1": [], "2": [], "3": [], "4": []}
        
        # Add user to the appropriate level of the next referrer
        level_key = str(level)
        if user_id not in next_referrer_data['referral_levels'][level_key]:
            next_referrer_data['referral_levels'][level_key].append(user_id)
            
            # Update the next referrer's data
            self.database.update_user_data(next_referrer_id, {"referral_levels": next_referrer_data['referral_levels']})
            
            # Continue up the chain
            self._update_referral_chain(user_id, next_referrer_id, level + 1)
    
    def calculate_commission(self, payment_amount: float, user_id: int) -> List[Tuple[int, float]]:
        """Calculate commissions for all referrers in the chain when a user makes a payment
        
        Args:
            payment_amount: The amount paid by the user
            user_id: The ID of the user who made the payment
            
        Returns:
            List of tuples containing (referrer_id, commission_amount)
        """
        user_data = self.database.get_user_data(user_id)
        if not user_data or not user_data.get('referrer_id'):
            return []
        
        commissions = []
        current_user_id = user_id
        level = 1
        
        while level <= 4:
            current_user_data = self.database.get_user_data(current_user_id)
            if not current_user_data or not current_user_data.get('referrer_id'):
                break
                
            referrer_id = current_user_data['referrer_id']
            
            # Calculate commission based on level
            if level == 1:
                rate = self.config.REFERRAL_LEVEL1_RATE
            elif level == 2:
                rate = self.config.REFERRAL_LEVEL2_RATE
            elif level == 3:
                rate = self.config.REFERRAL_LEVEL3_RATE
            elif level == 4:
                rate = self.config.REFERRAL_LEVEL4_RATE
            
            commission = round(payment_amount * rate, 2)
            commissions.append((referrer_id, commission))
            
            # Move up the chain
            current_user_id = referrer_id
            level += 1
        
        return commissions
    
    def get_user_referrals(self, user_id: int) -> Dict[str, List[Dict[str, Any]]]:
        """Get detailed information about a user's referrals at all levels
        
        Args:
            user_id: The ID of the user
            
        Returns:
            Dictionary with referral information at each level
        """
        user_data = self.database.get_user_data(user_id)
        if not user_data or 'referral_levels' not in user_data:
            return {"1": [], "2": [], "3": [], "4": []}
        
        referral_data = {"1": [], "2": [], "3": [], "4": []}
        
        for level in range(1, 5):
            level_key = str(level)
            referral_ids = user_data['referral_levels'].get(level_key, [])
            
            for ref_id in referral_ids:
                ref_user_data = self.database.get_user_data(ref_id)
                if ref_user_data:
                    # Get total earnings from this referral
                    transactions = self.database.get_transactions_by_user(ref_id)
                    total_spent = sum(tx['amount'] for tx_id, tx in transactions.items() 
                                    if tx['type'] == 'subscription' and tx['status'] == 'completed')
                    
                    # Create a simplified representation of the referral
                    referral_info = {
                        'id': ref_id,
                        'username': ref_user_data.get('username', 'Unknown'),
                        'first_name': ref_user_data.get('first_name', 'Unknown'),
                        'date_joined': ref_user_data.get('created_at', 'Unknown'),
                        'total_spent': total_spent
                    }
                    
                    referral_data[level_key].append(referral_info)
        
        return referral_data
    
    def get_referral_stats(self, user_id: int) -> Dict[str, Any]:
        """Get statistics about a user's referral performance
        
        Args:
            user_id: The ID of the user
            
        Returns:
            Dictionary with statistics about the user's referrals
        """
        user_data = self.database.get_user_data(user_id)
        if not user_data:
            return {
                'total_referrals': 0,
                'active_referrals': 0,
                'total_earned': 0,
                'levels': {
                    '1': 0,
                    '2': 0,
                    '3': 0,
                    '4': 0
                }
            }
        
        # Count referrals by level
        referral_levels = user_data.get('referral_levels', {"1": [], "2": [], "3": [], "4": []})
        level_counts = {
            '1': len(referral_levels.get('1', [])),
            '2': len(referral_levels.get('2', [])),
            '3': len(referral_levels.get('3', [])),
            '4': len(referral_levels.get('4', []))
        }
        
        # Get total earned from referrals
        total_earned = user_data.get('total_earned', 0)
        
        # Count active referrals (with active subscriptions)
        active_referrals = 0
        for ref_id in referral_levels.get('1', []):
            ref_data = self.database.get_user_data(ref_id)
            if ref_data and ref_data.get('subscription_end_date'):
                try:
                    end_date = datetime.fromisoformat(ref_data['subscription_end_date'])
                    if end_date > datetime.now():
                        active_referrals += 1
                except (ValueError, TypeError):
                    pass
        
        return {
            'total_referrals': sum(len(refs) for refs in referral_levels.values()),
            'active_referrals': active_referrals,
            'total_earned': total_earned,
            'levels': level_counts
        }