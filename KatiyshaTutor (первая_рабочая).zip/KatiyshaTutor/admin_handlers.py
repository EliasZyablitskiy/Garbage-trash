#!/usr/bin/env python
# coding: utf-8

"""
Обработчики административных команд для управления реферальными выплатами
"""

import logging
import datetime
import asyncio
import json
import time
import re
import os
from typing import Dict, Any, List, Optional, Set, Tuple, Union

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from services.db_transaction_service import DBSessionManager
from services.platform_feedback_service import PlatformFeedbackService

import config
from db_models import db

# Настройка логирования
logger = logging.getLogger(__name__)
from transactions import (
    get_user_total_rewards,
    get_transactions_by_status,
    create_weekly_payout,
    get_weekly_payouts,
    update_payout_status,
    get_referral_statistics
)
# Импортируем сервис анализа совместимости платформ
from services.platform_compatibility_analyzer import (
    get_platform_compatibility_summary,
    generate_compatibility_report,
    generate_platform_chart,
    generate_feature_chart
)
from services.platform_feedback_service import PlatformFeedbackService
# Импортируем обработчики мониторинга платежей
from admin_payment_handlers import get_payment_handlers
# Импортируем новые функции для работы с базой данных (замены для функций из transactions.py)
from services.db_transaction_service import (
    get_transactions_by_status as db_get_transactions_by_status,
    create_weekly_payout as db_create_weekly_payout,
    get_weekly_payouts as db_get_weekly_payouts,
    update_payout_status as db_update_payout_status,
    get_user_total_rewards as db_get_user_total_rewards,
    get_referral_statistics as db_get_referral_statistics,
    DBSessionManager
)
from services.payout_service import (
    process_payout_by_tiers,
    group_notify_about_pending_payouts
)
from services.recovery_service import RecoveryService, manual_recovery
from services.payment_validation_service import (
    validate_payout_amount,
    validate_transaction_group,
    group_transactions_by_tier,
    PaymentValidationError
)
from services.notification_service import (
    NotificationService,
    log_admin_action,
    NotificationType
)
from services.payment_error_handler import (
    analyze_robokassa_error,
    get_user_friendly_error,
    get_admin_error_message
)
from services.task_queue import payout_queue

logger = logging.getLogger(__name__)

# Используем обновленные настройки для администраторов из конфигурации
from config import ADMIN_USER_ID, ADMIN_IDS, ADDITIONAL_ADMIN_IDS, MIN_PAYOUT_AMOUNT

def is_admin(user_id: int) -> bool:
    """
    Проверка, является ли пользователь администратором
    
    Args:
        user_id: ID пользователя для проверки
        
    Returns:
        bool: True, если пользователь администратор, False в противном случае
    """
    return user_id in ADMIN_IDS

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик команды /admin - проверяет права администратора и показывает меню
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text(
            "⛔️ У вас нет прав администратора для выполнения этой команды."
        )
        return
    
    # Формируем административное меню
    keyboard = [
        [InlineKeyboardButton("📊 Статистика реферальной программы", callback_data="admin_stats")],
        [InlineKeyboardButton("💰 Ожидающие выплаты", callback_data="admin_pending_payments")],
        [InlineKeyboardButton("📝 Создать еженедельную выплату", callback_data="admin_create_payout")],
        [InlineKeyboardButton("📋 Список выплат", callback_data="admin_payouts_list")],
        [InlineKeyboardButton("🔄 Восстановить прерванные выплаты", callback_data="admin_recover_payouts")],
        [InlineKeyboardButton("💳 Мониторинг платежей", callback_data="admin_payment_stats")],
        [InlineKeyboardButton("⚠️ Анти-фрод система", callback_data="admin_antifraud")],
        [InlineKeyboardButton("📱 Кросс-платформенная совместимость", callback_data="admin_platform_compatibility")],
        [InlineKeyboardButton("📈 Расширенная отчетность", callback_data="admin_advanced_reports")]
    ]
    
    await update.message.reply_text(
        "🔐 *Панель администратора Катюша бот*\n\n"
        "Выберите действие из меню ниже:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def admin_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения статистики реферальной программы
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Получаем статистику
    stats = get_referral_statistics()
    
    # Форматируем сообщение
    message = (
        "📊 *Статистика реферальной программы*\n\n"
        f"💵 Доход от подписок: {stats['total_subscription_revenue']:.2f}₽\n"
        f"🔢 Количество подписок: {stats['total_subscriptions']}\n\n"
        f"💰 Всего начислено вознаграждений: {stats['total_rewards']:.2f}₽\n"
        f"✅ Выплачено вознаграждений: {stats['total_paid_rewards']:.2f}₽\n"
        f"⏳ Ожидает выплаты: {stats['total_pending_rewards']:.2f}₽\n\n"
        f"📅 *За последние 30 дней:*\n"
        f"💵 Доход от подписок: {stats['monthly_subscription_revenue']:.2f}₽\n"
        f"💰 Начислено вознаграждений: {stats['monthly_rewards']:.2f}₽\n\n"
        f"📈 Процент выплат от дохода: {stats['reward_percentage']:.2f}%"
    )
    
    # Добавляем кнопку возврата в административное меню
    keyboard = [[InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]]
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def admin_pending_payments_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения ожидающих выплат
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Используем новую оптимизированную систему для получения ожидающих выплат
    from new_referral_code.referral_adapter import get_pending_rewards
    
    # Получаем ожидающие выплаты через адаптер
    # Новая оптимизированная версия возвращает кортеж (список наград, общее количество)
    try:
        rewards_result = get_pending_rewards(page=1, page_size=100)
        
        # Обрабатываем возможность возврата разных типов из адаптера
        if isinstance(rewards_result, tuple):
            pending_rewards, total_count = rewards_result
        else:
            pending_rewards = rewards_result
            total_count = len(pending_rewards)
    except Exception as e:
        logger.error(f"Error getting pending rewards: {e}")
        # Если произошла ошибка с новой системой, используем старую в качестве запасного варианта
        pending_rewards = get_transactions_by_status("pending", "referral_reward")
    
    if not pending_rewards:
        message = "🔍 Нет ожидающих выплат реферальных вознаграждений."
        keyboard = [[InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]]
        
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return
    
    # Группируем награды по пользователям
    user_payouts = {}
    for reward in pending_rewards:
        # Структура данных может отличаться между старой и новой системами
        if isinstance(reward, dict):
            user_id = reward.get("user_id")
            amount = reward.get("amount", 0)
        else:
            # Предполагаем, что это объект из новой системы
            try:
                user_id = reward.referral_relation.user_id
                amount = reward.amount
            except AttributeError:
                # Если не удается получить данные, пропускаем эту запись
                continue
                
        if not user_id:
            continue
            
        if user_id not in user_payouts:
            user_payouts[user_id] = {
                "amount": 0.0,
                "count": 0
            }
        
        user_payouts[user_id]["amount"] += amount
        user_payouts[user_id]["count"] += 1
    
    # Формируем сообщение
    total_amount = sum(payout["amount"] for payout in user_payouts.values())
    total_transactions = sum(payout["count"] for payout in user_payouts.values())
    
    message = (
        "💰 *Ожидающие выплаты реферальных вознаграждений*\n\n"
        f"👥 Количество пользователей: {len(user_payouts)}\n"
        f"🧾 Количество транзакций: {total_transactions}\n"
        f"💵 Общая сумма: {total_amount:.2f}₽\n\n"
        "Топ 5 пользователей по сумме вознаграждений:\n"
    )
    
    # Сортируем пользователей по сумме вознаграждений
    sorted_users = sorted(
        user_payouts.items(),
        key=lambda x: x[1]["amount"],
        reverse=True
    )[:5]
    
    for i, (user_id, data) in enumerate(sorted_users, 1):
        message += f"{i}. ID: {user_id} - {data['amount']:.2f}₽ ({data['count']} транзакций)\n"
    
    # Добавляем кнопки
    keyboard = [
        [InlineKeyboardButton("✅ Создать еженедельную выплату", callback_data="admin_create_payout")],
        [InlineKeyboardButton("📄 Показать все (с пагинацией)", callback_data="admin_pending_pagination_1")],
        [InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]
    ]
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def admin_create_payout_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для создания еженедельной выплаты
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Создаем еженедельную выплату через новую оптимизированную систему
    try:
        from new_referral_code.referral_adapter import create_weekly_payout as optimized_create_weekly_payout
        
        admin_id = query.from_user.id
        description = f"Еженедельная выплата от {datetime.datetime.now().strftime('%d.%m.%Y')}"
        
        # Используем оптимизированную версию
        payout_id = optimized_create_weekly_payout(admin_id, description)
        
        if payout_id:
            message = (
                "✅ *Выплата успешно создана*\n\n"
                f"ID выплаты: #{payout_id}\n"
                "Все вознаграждения отмечены как 'в обработке'.\n\n"
                "Вы можете перейти к списку выплат, чтобы увидеть созданную выплату."
            )
        else:
            # В случае проблем с оптимизированной версией, используем старую в качестве запасного варианта
            legacy_payout_id = create_weekly_payout()
            
            if legacy_payout_id == -1:
                message = "ℹ️ Нет ожидающих реферальных вознаграждений для выплаты."
            else:
                message = (
                    "✅ *Выплата успешно создана*\n\n"
                    f"ID выплаты: #{legacy_payout_id}\n"
                    "Все транзакции отмечены как 'в обработке'.\n\n"
                    "Вы можете перейти к списку выплат, чтобы увидеть созданную выплату."
                )
    except Exception as e:
        logger.error(f"Error creating weekly payout: {e}")
        
        # При ошибке используем старую версию как запасной вариант
        legacy_payout_id = create_weekly_payout()
        
        if legacy_payout_id == -1:
            message = "ℹ️ Нет ожидающих реферальных вознаграждений для выплаты."
        else:
            message = (
                "✅ *Выплата успешно создана (через старую систему)*\n\n"
                f"ID выплаты: #{legacy_payout_id}\n"
                "Все транзакции отмечены как 'в обработке'.\n\n"
                "Вы можете перейти к списку выплат, чтобы увидеть созданную выплату."
            )
    
    # Добавляем кнопки
    keyboard = [
        [InlineKeyboardButton("📋 Список выплат", callback_data="admin_payouts_list")],
        [InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]
    ]
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def admin_payouts_list_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для отображения списка выплат
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Получаем список выплат через новую оптимизированную систему
    try:
        from new_referral_code.optimized_referral_manager import OptimizedReferralManager
        manager = OptimizedReferralManager()
        
        # Получаем выплаты из новой системы (с пагинацией)
        new_payouts = manager.get_weekly_payouts(page=1, page_size=10)
        
        if new_payouts:
            payouts = new_payouts
        else:
            # Если в новой системе нет выплат, проверяем старую
            payouts = get_weekly_payouts()
    except Exception as e:
        logger.error(f"Error getting weekly payouts from new system: {e}")
        # При ошибке используем старую систему
        payouts = get_weekly_payouts()
    
    if not payouts:
        message = "🔍 Нет созданных выплат."
        keyboard = [[InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]]
        
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return
    
    # Сортируем выплаты по дате создания (новые первыми)
    sorted_payouts = sorted(
        payouts,
        key=lambda x: x["created_at"],
        reverse=True
    )[:5]  # Показываем только 5 последних
    
    message = "📋 *Список последних выплат*\n\n"
    
    for payout in sorted_payouts:
        status_emoji = {
            "pending": "⏳",
            "processing": "🔄",
            "completed": "✅",
            "failed": "❌"
        }.get(payout["status"], "❓")
        
        created_at = datetime.datetime.fromisoformat(payout["created_at"]).strftime("%d.%m.%Y")
        
        message += (
            f"{status_emoji} *Выплата #{payout['id']}* ({created_at})\n"
            f"Статус: {payout['status']}\n"
            f"Пользователей: {payout['total_users']}\n"
            f"Сумма: {payout['total_amount']:.2f}₽\n\n"
        )
    
    # Добавляем кнопки
    keyboard = [
        [InlineKeyboardButton("📝 Создать новую выплату", callback_data="admin_create_payout")],
        [InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]
    ]
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def admin_recover_payouts_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для восстановления прерванных выплат
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Отправляем сообщение о начале восстановления
    progress_message = await query.edit_message_text(
        "⏳ *Поиск и восстановление прерванных выплат...*\n\n"
        "Это может занять некоторое время. Пожалуйста, подождите.",
        parse_mode='Markdown'
    )
    
    try:
        # Запускаем процесс восстановления выплат
        admin_id = query.from_user.id
        
        # Логируем действие администратора
        async_session = None
        try:
            logger.info(f"Администратор {admin_id} запустил процесс восстановления выплат")
            async_session = await DBSessionManager.get_async_session()
            
            # Логируем действие в базе данных
            await log_admin_action(
                session=async_session,
                admin_id=admin_id,
                action="recover_stalled_payouts",
                details={"initiated_by": admin_id}
            )
            await async_session.commit()
            logger.info(f"Действие администратора {admin_id} успешно зарегистрировано")
            
        except Exception as log_error:
            logger.error(f"Ошибка при логировании действия администратора: {log_error}", exc_info=True)
            if async_session:
                try:
                    await async_session.rollback()
                    logger.info("Выполнен откат транзакции логирования")
                except Exception as rollback_error:
                    logger.error(f"Ошибка при откате транзакции логирования: {rollback_error}")
        finally:
            if async_session:
                try:
                    await async_session.close()
                    logger.info("Сессия логирования закрыта")
                except Exception as close_error:
                    logger.error(f"Ошибка при закрытии сессии логирования: {close_error}")
        
        # Запускаем восстановление выплат
        logger.info("Запуск процесса восстановления выплат через manual_recovery")
        recovery_result = await manual_recovery(context.bot)
        logger.info(f"Процесс восстановления завершен с результатом: {recovery_result}")
        
        # Формируем сообщение о результатах
        payouts_recovered = recovery_result.get("payouts", {}).get("recovered", 0)
        batches_recovered = recovery_result.get("batches", {}).get("recovered", 0)
        
        total_transactions = (
            recovery_result.get("payouts", {}).get("recovered_transactions", 0) +
            recovery_result.get("batches", {}).get("recovered_transactions", 0)
        )
        
        if payouts_recovered > 0 or batches_recovered > 0:
            message = (
                "✅ *Восстановление выплат завершено успешно*\n\n"
                f"📊 *Результаты:*\n"
                f"- Восстановлено выплат: {payouts_recovered}\n"
                f"- Восстановлено пакетных выплат: {batches_recovered}\n"
                f"- Общее количество восстановленных транзакций: {total_transactions}\n\n"
                "Подробная информация отправлена всем администраторам."
            )
            logger.info(f"Восстановление успешно завершено: выплат - {payouts_recovered}, "
                      f"пакетов - {batches_recovered}, транзакций - {total_transactions}")
        else:
            message = (
                "ℹ️ *Восстановление завершено*\n\n"
                "Не найдено прерванных выплат, требующих восстановления."
            )
            logger.info("Восстановление завершено, прерванные выплаты не найдены")
            
    except Exception as recovery_error:
        logger.error(f"Ошибка при восстановлении выплат: {recovery_error}", exc_info=True)
        message = (
            "❌ *Ошибка при восстановлении выплат*\n\n"
            f"Детали ошибки: {str(recovery_error)}\n\n"
            "Пожалуйста, проверьте логи сервера и повторите попытку позже."
        )
    
    # Добавляем кнопку возврата
    keyboard = [[InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]]
    
    await progress_message.edit_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )


async def admin_pending_pagination_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для постраничного отображения ожидающих выплат
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Получаем номер страницы из callback_data
    # Формат callback_data: admin_pending_pagination_{page_number}
    callback_data = query.data
    page = int(callback_data.split("_")[-1])
    page_size = 20  # Количество транзакций на странице
    
    # Используем новую оптимизированную систему для получения ожидающих выплат
    try:
        from new_referral_code.referral_adapter import get_pending_rewards
        
        # Получаем выплаты с пагинацией
        rewards_result = get_pending_rewards(page=page, page_size=page_size)
        
        # Обрабатываем возможность возврата разных типов из адаптера
        if isinstance(rewards_result, tuple):
            pending_rewards, total_count = rewards_result
        else:
            pending_rewards = rewards_result
            total_count = len(pending_rewards)
            
        # Получаем общее количество страниц
        total_pages = (total_count + page_size - 1) // page_size
    except Exception as e:
        logger.error(f"Error getting paginated pending rewards: {e}")
        await query.edit_message_text(
            f"❌ Ошибка при получении данных: {str(e)}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="admin_pending_payments")]])
        )
        return
    
    if not pending_rewards:
        message = "🔍 Нет ожидающих выплат на этой странице."
        keyboard = [[InlineKeyboardButton("◀️ Назад к списку", callback_data="admin_pending_payments")]]
        
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return
    
    # Формируем список транзакций для текущей страницы
    message = (
        f"💰 *Ожидающие выплаты (страница {page}/{total_pages})*\n\n"
        f"Всего найдено: {total_count} транзакций\n\n"
    )
    
    # Выводим список транзакций
    for i, reward in enumerate(pending_rewards, 1):
        # Структура данных может отличаться между старой и новой системами
        if isinstance(reward, dict):
            user_id = reward.get("user_id")
            amount = reward.get("amount", 0)
            created_at = reward.get("created_at", "неизвестно")
            if isinstance(created_at, str):
                try:
                    created_at = datetime.datetime.fromisoformat(created_at).strftime("%d.%m.%Y")
                except (ValueError, TypeError):
                    created_at = "неизвестно"
        else:
            # Предполагаем, что это объект из новой системы
            try:
                user_id = reward.referral_relation.user_id
                amount = reward.amount
                created_at = reward.created_at.strftime("%d.%m.%Y") if hasattr(reward, "created_at") else "неизвестно"
            except AttributeError:
                continue
                
        message += f"{i}. ID: {user_id} - {amount:.2f}₽ ({created_at})\n"
    
    # Создаем кнопки навигации
    keyboard = []
    
    # Добавляем кнопки пагинации
    pagination_row = []
    
    # Кнопка "Предыдущая страница"
    if page > 1:
        pagination_row.append(InlineKeyboardButton("◀️", callback_data=f"admin_pending_pagination_{page-1}"))
    
    # Кнопка "Следующая страница"
    if page < total_pages:
        pagination_row.append(InlineKeyboardButton("▶️", callback_data=f"admin_pending_pagination_{page+1}"))
    
    if pagination_row:
        keyboard.append(pagination_row)
    
    # Добавляем кнопку возврата
    keyboard.append([InlineKeyboardButton("◀️ Назад к списку", callback_data="admin_pending_payments")])
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def admin_back_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для возврата в административное меню
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Формируем административное меню
    keyboard = [
        [InlineKeyboardButton("📊 Статистика реферальной программы", callback_data="admin_stats")],
        [InlineKeyboardButton("💰 Ожидающие выплаты", callback_data="admin_pending_payments")],
        [InlineKeyboardButton("📝 Создать еженедельную выплату", callback_data="admin_create_payout")],
        [InlineKeyboardButton("📋 Список выплат", callback_data="admin_payouts_list")],
        [InlineKeyboardButton("🔄 Восстановить прерванные выплаты", callback_data="admin_recover_payouts")],
        [InlineKeyboardButton("🔄 Групповая обработка выплат", callback_data="admin_group_payout")],
        [InlineKeyboardButton("📣 Уведомить о доступных выплатах", callback_data="admin_notify_pending")]
    ]
    
    await query.edit_message_text(
        "🔐 *Панель администратора Катюша бот*\n\n"
        "Выберите действие из меню ниже:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def admin_process_payout_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для обработки выплаты по выбранному ID с улучшенной безопасностью и логированием
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    admin_id = query.from_user.id
    if not is_admin(admin_id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Получаем ID выплаты из callback_data
    # Формат callback_data: admin_process_payout:{payout_id}
    callback_data = query.data
    payout_id = int(callback_data.split(":")[-1])
    
    # Отправляем сообщение о начале обработки
    progress_message = await query.edit_message_text(
        f"⏳ Начинаем обработку выплаты #{payout_id}...\n\n"
        "Это может занять некоторое время. Пожалуйста, подождите.",
        parse_mode='Markdown'
    )
    
    # Логируем действие администратора
    action_details = {
        "action": "process_payout",
        "payout_id": payout_id,
        "admin_id": admin_id,
        "timestamp": datetime.datetime.now().isoformat()
    }
    async with db.begin() as session:
        await log_admin_action(session, admin_id, "process_payout", action_details)
    
    try:
        start_time = time.time()
        
        # Получаем сервис уведомлений
        notification_service = NotificationService.get_instance(context.bot)
        
        # Получаем информацию о выплате
        payout_info = get_weekly_payouts(payout_id=payout_id)
        if not payout_info:
            raise ValueError(f"Выплата с ID {payout_id} не найдена")
            
        payout_info = payout_info[0]  # Берем первый элемент, так как возвращается список
        
        # Уведомляем администраторов о начале обработки
        notification_message = (
            f"🔄 *Начата обработка выплаты #{payout_id}*\n\n"
            f"👥 Количество пользователей: {payout_info['total_users']}\n"
            f"💰 Общая сумма: {payout_info['total_amount']:.2f}₽\n\n"
            "Пожалуйста, подождите..."
        )
        
        # Отправляем уведомление всем администраторам
        for admin_id in ADMIN_IDS:
            await notification_service.send_notification(
                user_id=admin_id,
                notification_type=NotificationType.SYSTEM,
                context={'message': notification_message}
            )
        
        # Обновляем статус выплаты
        update_payout_status(payout_id, "processing")
        
        # Запускаем процесс обработки выплаты с использованием очереди задач
        task_id = await payout_queue.add_task(
            process_payout_by_tiers,
            context.bot,
            int(payout_id),
            task_id=f"payout_{payout_id}_{int(time.time())}"
        )
        
        # Ждем некоторое время для начала обработки
        await asyncio.sleep(2)
        
        # Проверяем статус задачи
        task_info = payout_queue.get_task_info(task_id)
        
        if task_info and task_info["status"] == "completed":
            # Если задача уже завершилась, получаем результаты
            results = task_info.get("result", {})
        else:
            # Запускаем обычную обработку, если задача еще не завершилась
            results = await process_payout_by_tiers(context.bot, int(payout_id))
        
        # Вычисляем время обработки
        processing_time = time.time() - start_time
        
        if isinstance(results, dict) and "error" in results:
            # В случае ошибки
            error_message = results.get("error", "Неизвестная ошибка")
            
            # Пытаемся получить детали ошибки
            error_code = results.get("error_code", "TECHNICAL_ERROR")
            admin_error_message = get_admin_error_message(error_code, error_message)
            
            message = f"❌ *Ошибка при обработке выплаты #{payout_id}*\n\n{admin_error_message}"
            
            # Отправляем уведомление об ошибке всем администраторам
            error_notification = (
                f"❌ *Ошибка при обработке выплаты #{payout_id}*\n\n"
                f"Причина: {error_message}"
            )
            
            for admin_id in ADMIN_IDS:
                await notification_service.send_notification(
                    user_id=admin_id,
                    notification_type=NotificationType.SYSTEM,
                    context={'message': error_notification}
                )
        else:
            # Формируем сообщение с результатами
            success_count = results.get("success", 0)
            failed_count = results.get("failed", 0)
            total_users = results.get("total_users", 0)
            total_amount = results.get("total_amount", 0.0)
            
            message = (
                f"✅ *Выплата #{payout_id} обработана*\n\n"
                f"👥 Всего пользователей: {total_users}\n"
                f"💰 Общая сумма: {total_amount:.2f}₽\n\n"
                f"✅ Успешно: {success_count}\n"
                f"❌ Неудачно: {failed_count}\n"
                f"⏱ Время обработки: {processing_time:.2f} сек.\n\n"
                "📊 *Детали по группам:*\n"
            )
            
            # Добавляем информацию по группам
            for tier_name, tier_result in results.get("tiers", {}).items():
                message += f"• {tier_name}: {tier_result['success']}/{tier_result['total']} успешно\n"
            
            # Отправляем уведомление о завершении выплаты всем администраторам
            success_notification = (
                f"✅ *Выплата #{payout_id} успешно обработана*\n\n"
                f"👥 Всего пользователей: {total_users}\n"
                f"💰 Общая сумма: {total_amount:.2f}₽\n\n"
                f"✅ Успешно: {success_count}\n"
                f"❌ Неудачно: {failed_count}\n"
                f"⏱ Время обработки: {processing_time:.2f} сек."
            )
            
            # Создаем клавиатуру для отчета
            keyboard_markup = InlineKeyboardMarkup([
                [InlineKeyboardButton("📊 Подробный отчет", callback_data=f"payout_report_{payout_id}")]
            ])
            
            # Отправляем уведомление всем администраторам
            for admin_id in ADMIN_IDS:
                try:
                    await context.bot.send_message(
                        chat_id=admin_id,
                        text=success_notification,
                        parse_mode='Markdown',
                        reply_markup=keyboard_markup
                    )
                except Exception as e:
                    logger.error(f"Ошибка при отправке уведомления администратору {admin_id}: {e}")
        
        # Добавляем кнопки для пользовательского интерфейса
        keyboard = [
            [InlineKeyboardButton("📋 Список выплат", callback_data="admin_payouts_list")],
            [InlineKeyboardButton("📊 Подробный отчет", callback_data=f"payout_report_{payout_id}")],
            [InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]
        ]
        
        # Обновляем сообщение с результатами
        await progress_message.edit_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='Markdown'
        )
        
        # Логируем результат действия администратора
        result_details = {
            "action": "process_payout_completed",
            "payout_id": payout_id,
            "admin_id": admin_id,
            "success_count": results.get("success", 0),
            "failed_count": results.get("failed", 0),
            "total_amount": results.get("total_amount", 0.0),
            "processing_time": processing_time,
            "timestamp": datetime.datetime.now().isoformat()
        }
        async with db.begin() as session:
            await log_admin_action(session, admin_id, "process_payout_completed", result_details)
        
    except Exception as e:
        logger.error(f"Ошибка при обработке выплаты #{payout_id}: {e}", exc_info=True)
        
        # Логируем ошибку
        error_details = {
            "action": "process_payout_error",
            "payout_id": payout_id,
            "admin_id": admin_id,
            "error": str(e),
            "timestamp": datetime.datetime.now().isoformat()
        }
        async with db.begin() as session:
            await log_admin_action(session, admin_id, "process_payout_error", error_details)
        
        # Пытаемся отправить уведомление об ошибке
        try:
            notification_service = NotificationService.get_instance(context.bot)
            error_message = (
                f"❌ *Ошибка при обработке выплаты #{payout_id}*\n\n"
                f"Причина: {str(e)}"
            )
            
            # Отправляем уведомление всем администраторам
            for admin_id in ADMIN_IDS:
                await notification_service.send_notification(
                    user_id=admin_id,
                    notification_type=NotificationType.SYSTEM,
                    context={'message': error_message}
                )
        except Exception as notify_error:
            logger.error(f"Ошибка при отправке уведомления об ошибке: {notify_error}")
        
        # В случае исключения
        await progress_message.edit_text(
            f"❌ *Произошла ошибка при обработке выплаты #{payout_id}*\n\n"
            f"Детали ошибки: {e}",
            parse_mode='Markdown',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📋 Список выплат", callback_data="admin_payouts_list")],
                [InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]
            ])
        )

async def admin_group_payout_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для групповой обработки выплат
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Получаем список выплат со статусом "processing"
    processing_payouts = get_weekly_payouts("processing")
    
    if not processing_payouts:
        # Если нет выплат в обработке
        message = (
            "ℹ️ *Нет выплат в статусе 'Обработка'*\n\n"
            "Создайте новую выплату или обновите статус существующей выплаты на 'processing'."
        )
        
        keyboard = [
            [InlineKeyboardButton("📝 Создать выплату", callback_data="admin_create_payout")],
            [InlineKeyboardButton("📋 Список выплат", callback_data="admin_payouts_list")],
            [InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]
        ]
        
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='Markdown'
        )
        return
    
    # Сортируем выплаты по дате создания (новые первыми)
    sorted_payouts = sorted(
        processing_payouts,
        key=lambda x: x["created_at"],
        reverse=True
    )
    
    # Формируем список кнопок для выплат
    keyboard = []
    for payout in sorted_payouts:
        payout_id = payout["id"]
        created_at = datetime.datetime.fromisoformat(payout["created_at"]).strftime("%d.%m.%Y")
        button_text = f"Выплата #{payout_id} от {created_at} - {payout['total_amount']:.2f}₽"
        
        keyboard.append([
            InlineKeyboardButton(button_text, callback_data=f"admin_process_payout:{payout_id}")
        ])
    
    # Добавляем кнопку возврата
    keyboard.append([InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")])
    
    # Отправляем сообщение со списком выплат
    await query.edit_message_text(
        "🔄 *Выберите выплату для обработки*\n\n"
        "Нажмите на кнопку с нужной выплатой, чтобы начать процесс отправки уведомлений "
        "пользователям и создания ссылок для выплат.",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def admin_notify_pending_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для уведомления пользователей о доступных выплатах
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Запрашиваем подтверждение перед отправкой уведомлений
    keyboard = [
        [
            InlineKeyboardButton("✅ Да, отправить", callback_data="admin_notify_confirm"),
            InlineKeyboardButton("❌ Отмена", callback_data="admin_back")
        ]
    ]
    
    await query.edit_message_text(
        f"📣 *Уведомление о доступных выплатах*\n\n"
        f"Вы собираетесь отправить уведомления всем пользователям, у которых накопились "
        f"вознаграждения более {MIN_PAYOUT_AMOUNT:.2f}₽.\n\n"
        f"Это действие отправит сообщения непосредственно пользователям. "
        f"Продолжить?",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )

async def admin_notify_confirm_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для подтверждения отправки уведомлений
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔️ У вас нет прав администратора.")
        return
    
    # Отправляем уведомление о начале процесса
    progress_message = await query.edit_message_text(
        "⏳ *Отправка уведомлений...*\n\n"
        "Пожалуйста, подождите. Процесс может занять некоторое время, "
        "особенно если у вас много пользователей с доступными выплатами.",
        parse_mode='Markdown'
    )
    
    try:
        # Запускаем процесс отправки уведомлений
        results = await group_notify_about_pending_payouts(context.bot)
        
        if "status" in results and results["status"] == "no_eligible_users":
            # Если нет пользователей с доступными выплатами
            message = (
                "ℹ️ *Нет пользователей с доступными выплатами*\n\n"
                f"Не найдено пользователей с накопленными вознаграждениями более {results.get('min_amount', MIN_PAYOUT_AMOUNT):.2f}₽."
            )
        else:
            # Проверяем наличие всех необходимых ключей
            total_users = results.get('total_users', 0)
            notified = results.get('notified', 0)
            failed = results.get('failed', 0)
            
            # Формируем сообщение с результатами
            message = (
                "✅ *Уведомления отправлены*\n\n"
                f"👥 Всего пользователей: {total_users}\n"
                f"✅ Успешно отправлено: {notified}\n"
                f"❌ Ошибки при отправке: {failed}\n\n"
            )
            
            # Если были ошибки, добавляем дополнительную информацию
            if failed > 0:
                message += (
                    "⚠️ *Примечание:* Не всем пользователям удалось отправить уведомления. "
                    "Возможно, они заблокировали бота или изменили настройки приватности."
                )
        
        # Добавляем кнопки
        keyboard = [[InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]]
        
        # Обновляем сообщение с результатами
        await progress_message.edit_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='Markdown'
        )
    except Exception as e:
        logger.error(f"Ошибка при отправке уведомлений: {e}")
        
        # В случае исключения
        await progress_message.edit_text(
            "❌ *Произошла ошибка при отправке уведомлений*\n\n"
            f"Детали ошибки: {e}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад к меню", callback_data="admin_back")]
            ]),
            parse_mode='Markdown'
        )

async def admin_platform_compatibility_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик для просмотра статистики кросс-платформенной совместимости
    """
    if not await is_admin(update, context):
        return
    
    query = update.callback_query
    await query.answer()
    
    # Создаем клавиатуру для выбора опций отчета
    keyboard = [
        [
            InlineKeyboardButton("Общая статистика", callback_data="admin_platform_summary"),
            InlineKeyboardButton("Полный отчет", callback_data="admin_platform_report")
        ],
        [
            InlineKeyboardButton("График платформ", callback_data="admin_platform_chart"),
            InlineKeyboardButton("График функций", callback_data="admin_features_chart")
        ],
        [
            InlineKeyboardButton("📊 Статистика отзывов", callback_data="admin_feedback_stats"),
            InlineKeyboardButton("📝 Просмотр отзывов", callback_data="admin_feedback_list")
        ],
        [
            InlineKeyboardButton("« Назад", callback_data="admin_back")
        ]
    ]
    
    # Формируем сообщение
    message_text = (
        "📊 *Кросс-платформенная совместимость*\n\n"
        "Выберите тип отчета о совместимости бота с различными платформами:"
    )
    
    # Редактируем сообщение
    await query.edit_message_text(
        text=message_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

async def admin_platform_summary_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Показывает краткую сводку о совместимости различных платформ
    """
    if not await is_admin(update, context):
        return
    
    query = update.callback_query
    await query.answer()
    
    # Сообщаем о начале загрузки статистики
    await query.edit_message_text(
        text="⏳ Загрузка статистики совместимости платформ... Пожалуйста, подождите.",
        parse_mode="Markdown"
    )
    
    # Получаем статистику по платформам
    try:
        summary = get_platform_compatibility_summary(30)  # за последние 30 дней
        
        if summary["status"] == "no_data":
            message_text = (
                "📊 *Статистика кросс-платформенной совместимости*\n\n"
                "❌ За последние 30 дней нет данных о тестировании платформ.\n\n"
                "Для сбора данных пользователи должны использовать команду /test_platform."
            )
        else:
            # Формируем сообщение со статистикой
            message_text = (
                "📊 *Статистика кросс-платформенной совместимости*\n\n"
                f"Период: последние 30 дней\n"
                f"Всего тестов: {summary['overall']['total_tests']}\n"
                f"Процент успешности: {summary['overall']['pass_rate']}%\n"
                f"Уникальных пользователей: {summary['overall']['unique_users']}\n\n"
                "По платформам:\n"
            )
            
            # Сортируем платформы по убыванию процента успешности
            sorted_platforms = sorted(
                summary["platforms"].items(), 
                key=lambda x: x[1]["pass_rate"], 
                reverse=True
            )
            
            for platform, stats in sorted_platforms:
                # Выбираем эмодзи в зависимости от процента успешности
                if stats["pass_rate"] >= 90:
                    emoji = "✅"
                elif stats["pass_rate"] >= 70:
                    emoji = "⚠️"
                else:
                    emoji = "❌"
                
                message_text += (
                    f"{emoji} *{stats['display_name']}*: {stats['pass_rate']}% "
                    f"({stats['passed_tests']}/{stats['total_tests']} тестов)\n"
                )
            
            # Добавляем информацию о возможных действиях
            message_text += (
                "\nДля получения полного отчета выберите соответствующую опцию."
            )
        
    except Exception as e:
        logger.error(f"Ошибка при получении статистики совместимости: {e}")
        message_text = (
            "⚠️ *Ошибка при получении статистики*\n\n"
            f"Произошла ошибка: {str(e)}\n\n"
            "Пожалуйста, повторите попытку позже."
        )
    
    # Клавиатура для возврата к выбору отчетов
    keyboard = [
        [
            InlineKeyboardButton("Полный отчет", callback_data="admin_platform_report"),
            InlineKeyboardButton("График платформ", callback_data="admin_platform_chart")
        ],
        [
            InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
        ]
    ]
    
    # Обновляем сообщение
    await query.edit_message_text(
        text=message_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

async def admin_platform_report_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Показывает полный отчет о совместимости различных платформ
    """
    if not await is_admin(update, context):
        return
    
    query = update.callback_query
    await query.answer()
    
    # Сообщаем о начале генерации отчета
    await query.edit_message_text(
        text="⏳ Генерация полного отчета о совместимости... Пожалуйста, подождите.",
        parse_mode="Markdown"
    )
    
    # Получаем полный отчет
    try:
        report = generate_compatibility_report(30, "markdown")  # за последние 30 дней в формате Markdown
        
        # Проверяем длину отчета и при необходимости разбиваем на части
        if len(report) > 4000:
            # Отправляем первую часть
            first_part = report[:4000]
            await query.edit_message_text(
                text=first_part,
                parse_mode="Markdown"
            )
            
            # Отправляем вторую часть в новом сообщении
            second_part = report[4000:]
            keyboard = [
                [
                    InlineKeyboardButton("График платформ", callback_data="admin_platform_chart"),
                    InlineKeyboardButton("График функций", callback_data="admin_features_chart")
                ],
                [
                    InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
                ]
            ]
            
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=second_part,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown"
            )
        else:
            # Если отчет помещается в одно сообщение
            keyboard = [
                [
                    InlineKeyboardButton("График платформ", callback_data="admin_platform_chart"),
                    InlineKeyboardButton("График функций", callback_data="admin_features_chart")
                ],
                [
                    InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
                ]
            ]
            
            await query.edit_message_text(
                text=report,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown"
            )
    
    except Exception as e:
        logger.error(f"Ошибка при генерации отчета о совместимости: {e}")
        # Клавиатура для возврата
        keyboard = [
            [
                InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
            ]
        ]
        
        await query.edit_message_text(
            text=f"⚠️ *Ошибка при генерации отчета*\n\n{str(e)}",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

async def admin_platform_chart_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Показывает график совместимости по платформам
    """
    if not await is_admin(update, context):
        return
    
    query = update.callback_query
    await query.answer()
    
    # Сообщаем о начале генерации графика
    await query.edit_message_text(
        text="⏳ Генерация графика совместимости платформ... Пожалуйста, подождите.",
        parse_mode="Markdown"
    )
    
    try:
        # Генерируем график
        chart_data, chart_path = generate_platform_chart(30)
        
        if chart_data is None:
            # Если данных нет или возникла ошибка
            keyboard = [
                [
                    InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
                ]
            ]
            
            await query.edit_message_text(
                text=f"⚠️ *Ошибка при генерации графика*\n\n{chart_path}",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown"
            )
            return
        
        # Отправляем график
        keyboard = [
            [
                InlineKeyboardButton("Общая статистика", callback_data="admin_platform_summary"),
                InlineKeyboardButton("График функций", callback_data="admin_features_chart")
            ],
            [
                InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
            ]
        ]
        
        # Подготавливаем caption для графика
        caption = "📊 *График совместимости платформ за последние 30 дней*"
        
        # Отправляем новое сообщение с графиком, так как edit_message не поддерживает добавление фото
        await context.bot.send_photo(
            chat_id=update.effective_chat.id,
            photo=chart_data,
            caption=caption,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        
        # Удаляем предыдущее сообщение
        await query.delete_message()
        
    except Exception as e:
        logger.error(f"Ошибка при генерации графика совместимости платформ: {e}")
        keyboard = [
            [
                InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
            ]
        ]
        
        await query.edit_message_text(
            text=f"⚠️ *Ошибка при генерации графика*\n\n{str(e)}",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

async def admin_features_chart_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Показывает график совместимости по функциям
    """
    if not await is_admin(update, context):
        return
    
    query = update.callback_query
    await query.answer()
    
    # Сообщаем о начале генерации графика
    await query.message.edit_text(
        "🔄 Генерация графика совместимости функций...",
        reply_markup=None
    )
    
    try:
        from services.platform_compatibility_analyzer import generate_feature_chart
        
        # Генерируем график за последние 30 дней
        chart_data, chart_path = generate_feature_chart(30)
        
        if chart_path and os.path.exists(chart_path):
            # Отправляем график
            with open(chart_path, 'rb') as chart_file:
                await query.message.reply_photo(
                    photo=chart_file,
                    caption="📊 График совместимости функций по платформам\nДанные за последние 30 дней",
                    reply_markup=InlineKeyboardMarkup([
                        [
                            InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
                        ]
                    ])
                )
            
            # Удаляем сообщение о генерации
            await query.message.delete()
            
            # Удаляем временный файл графика
            try:
                os.remove(chart_path)
            except Exception as e:
                logger.error(f"Ошибка при удалении файла графика: {e}")
        else:
            # Если не удалось сгенерировать график
            keyboard = [
                [
                    InlineKeyboardButton("Общая статистика", callback_data="admin_platform_summary"),
                    InlineKeyboardButton("График платформ", callback_data="admin_platform_chart")
                ],
                [
                    InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
                ]
            ]
            
            await query.message.edit_text(
                "❌ Не удалось сгенерировать график совместимости функций. Недостаточно данных или произошла ошибка.",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
    except Exception as e:
        logger.error(f"Ошибка при генерации графика функций: {e}")
        
        keyboard = [
            [
                InlineKeyboardButton("Общая статистика", callback_data="admin_platform_summary"),
                InlineKeyboardButton("График платформ", callback_data="admin_platform_chart")
            ],
            [
                InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
            ]
        ]
        
        await query.message.edit_text(
            f"⚠️ Произошла ошибка при генерации графика: {str(e)}",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
async def admin_feedback_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик для отображения статистики отзывов пользователей
    """
    if not await is_admin(update, context):
        return
    
    query = update.callback_query
    await query.answer()
    
    try:
        await query.message.edit_text(
            "🔄 Получение статистики отзывов...",
            reply_markup=None
        )
        
        # Получаем статистику отзывов через сервис
        stats = PlatformFeedbackService.get_rating_statistics()
        
        # Проверяем, есть ли какие-то отзывы
        if stats["total_count"] == 0:
            keyboard = [
                [InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")]
            ]
            await query.message.edit_text(
                "📊 Статистика отзывов\n\n"
                "Пока нет отзывов пользователей. Чтобы собрать отзывы, пользователи должны использовать "
                "команду /feedback для отправки своих впечатлений о работе различных функций бота.",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return
            
        # Формируем текст статистики
        text = f"📊 *Статистика отзывов пользователей*\n\n"
        text += f"Всего отзывов: {stats['total_count']}\n"
        text += f"Средняя оценка: {stats['average_rating']} / 5\n"
        text += f"Нерешенных проблем: {stats['unresolved_count']}\n\n"
        
        # Статистика по платформам
        text += "*Статистика по платформам:*\n"
        sorted_platforms = sorted(
            stats["platform_stats"].items(), 
            key=lambda x: x[1]["count"], 
            reverse=True
        )
        
        for platform, data in sorted_platforms:
            text += f"• {platform.capitalize()}: {data['avg']} / 5 ({data['count']} отзывов)\n"
        
        text += "\n*Статистика по функциям:*\n"
        sorted_features = sorted(
            stats["feature_stats"].items(), 
            key=lambda x: x[1]["count"], 
            reverse=True
        )
        
        for feature, data in sorted_features:
            text += f"• {feature}: {data['avg']} / 5 ({data['count']} отзывов)\n"
        
        # Создаем клавиатуру с действиями
        keyboard = [
            [
                InlineKeyboardButton("📝 Просмотр отзывов", callback_data="admin_feedback_list")
            ],
            [
                InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
            ]
        ]
        
        await query.message.edit_text(
            text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        
    except Exception as e:
        logger.error(f"Ошибка при получении статистики отзывов: {e}")
        keyboard = [
            [InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")]
        ]
        await query.message.edit_text(
            f"⚠️ Произошла ошибка при получении статистики отзывов: {str(e)}",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        
async def admin_feedback_list_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик для просмотра списка отзывов пользователей
    """
    if not await is_admin(update, context):
        return
    
    query = update.callback_query
    await query.answer()
    
    # Получаем параметры из callback_data (если есть)
    callback_data = query.data
    
    # Разбор параметров пагинации и фильтрации
    page = 0
    filter_platform = None
    filter_feature = None
    filter_resolved = None
    
    # Проверяем наличие дополнительных параметров
    if '_p' in callback_data:
        # Формат: admin_feedback_list_p{page}_plat{platform}_feat{feature}_res{resolved}
        parts = callback_data.split('_')
        for part in parts:
            if part.startswith('p') and part[1:].isdigit():
                page = int(part[1:])
            elif part.startswith('plat'):
                filter_platform = part[4:] if part[4:] != 'all' else None
            elif part.startswith('feat'):
                filter_feature = part[4:] if part[4:] != 'all' else None
            elif part.startswith('res'):
                filter_resolved = part[3:] == '1' if part[3:] in ['0', '1'] else None
    
    try:
        # Отображаем сообщение о загрузке
        await query.message.edit_text(
            "🔄 Загрузка списка отзывов...",
            reply_markup=None
        )
        
        # Получаем список отзывов с учетом фильтров и пагинации
        limit = 10
        offset = page * limit
        
        # Получаем отзывы через сервис
        feedbacks = PlatformFeedbackService.get_all_feedback(
            limit=limit,
            platform_type=filter_platform,
            feature_type=filter_feature,
            resolved=filter_resolved
        )
        
        # Проверяем, есть ли отзывы
        if not feedbacks:
            keyboard = [
                [
                    InlineKeyboardButton("📊 Статистика отзывов", callback_data="admin_feedback_stats")
                ],
                [
                    InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
                ]
            ]
            
            await query.message.edit_text(
                "📝 Список отзывов\n\n"
                "Отзывы не найдены. Возможно, пользователи еще не оставили отзывов "
                "или они не соответствуют заданным фильтрам.",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return
        
        # Ограничиваем список для текущей страницы
        total_pages = (len(feedbacks) + limit - 1) // limit
        page_feedbacks = feedbacks[offset:offset+limit]
        
        # Формируем текст со списком отзывов
        text = f"📝 *Список отзывов пользователей*\n"
        text += f"Страница {page+1} из {max(1, total_pages)}\n\n"
        
        # Добавляем информацию о текущих фильтрах
        if filter_platform or filter_feature or filter_resolved is not None:
            text += "*Активные фильтры:*\n"
            if filter_platform:
                text += f"• Платформа: {filter_platform}\n"
            if filter_feature:
                text += f"• Функция: {filter_feature}\n"
            if filter_resolved is not None:
                text += f"• Статус: {'Решено' if filter_resolved else 'Не решено'}\n"
            text += "\n"
        
        # Выводим отзывы
        for i, feedback in enumerate(page_feedbacks, 1):
            # Форматируем дату
            date_str = feedback.get("timestamp", "").split(".")[0].replace("T", " ")
            
            # Определяем статус
            status = "✅ Решено" if feedback.get("is_resolved") else "⏳ Не решено"
            
            # Формируем основную информацию
            text += f"*{i}. Отзыв #{feedback.get('id')}*\n"
            text += f"👤 Пользователь: {feedback.get('user_id')}\n"
            text += f"📱 Платформа: {feedback.get('platform_type')} {feedback.get('platform_version') or ''}\n"
            text += f"🔧 Функция: {feedback.get('feature_type')}\n"
            text += f"⭐ Оценка: {feedback.get('rating')}/5\n"
            text += f"📅 Дата: {date_str}\n"
            text += f"📊 Статус: {status}\n"
            
            # Добавляем текст отзыва (если есть)
            if feedback.get('feedback_text'):
                text += f"💬 Отзыв: {feedback.get('feedback_text')[:100]}{'...' if len(feedback.get('feedback_text', '')) > 100 else ''}\n"
            
            # Добавляем комментарий администратора (если есть)
            if feedback.get('admin_notes'):
                text += f"🔷 Комментарий: {feedback.get('admin_notes')[:100]}{'...' if len(feedback.get('admin_notes', '')) > 100 else ''}\n"
            
            text += "\n"
        
        # Создаем клавиатуру с пагинацией и фильтрами
        keyboard = []
        
        # Кнопки для управления статусами отзывов (в будущих версиях)
        
        # Кнопки пагинации
        pagination_buttons = []
        if page > 0:
            pagination_buttons.append(
                InlineKeyboardButton("◀️ Назад", callback_data=f"admin_feedback_list_p{page-1}")
            )
        if page < total_pages - 1:
            pagination_buttons.append(
                InlineKeyboardButton("▶️ Вперед", callback_data=f"admin_feedback_list_p{page+1}")
            )
        
        if pagination_buttons:
            keyboard.append(pagination_buttons)
        
        # Кнопки фильтрации
        filter_buttons = []
        filter_keyboard = [
            [
                InlineKeyboardButton(
                    "🔍 Фильтр по платформе", 
                    callback_data="admin_feedback_filter_platform"
                ),
                InlineKeyboardButton(
                    "🔍 Фильтр по функции", 
                    callback_data="admin_feedback_filter_feature"
                )
            ],
            [
                InlineKeyboardButton(
                    "🔄 Сбросить фильтры", 
                    callback_data="admin_feedback_list"
                )
            ]
        ]
        
        keyboard.extend(filter_keyboard)
        
        # Кнопки навигации
        keyboard.append([
            InlineKeyboardButton("📊 Статистика отзывов", callback_data="admin_feedback_stats")
        ])
        keyboard.append([
            InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
        ])
        
        await query.message.edit_text(
            text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
    
    except Exception as e:
        logger.error(f"Ошибка при получении списка отзывов: {e}")
        keyboard = [
            [InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")]
        ]
        await query.message.edit_text(
            f"⚠️ Произошла ошибка при получении списка отзывов: {str(e)}",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    
    # Сообщаем о начале генерации графика
    await query.edit_message_text(
        text="⏳ Генерация графика совместимости функций... Пожалуйста, подождите.",
        parse_mode="Markdown"
    )
    
    try:
        # Генерируем график
        chart_data, chart_path = generate_feature_chart(30)
        
        if chart_data is None:
            # Если данных нет или возникла ошибка
            keyboard = [
                [
                    InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
                ]
            ]
            
            await query.edit_message_text(
                text=f"⚠️ *Ошибка при генерации графика функций*\n\n{chart_path}",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown"
            )
            return
        
        # Отправляем график
        keyboard = [
            [
                InlineKeyboardButton("Общая статистика", callback_data="admin_platform_summary"),
                InlineKeyboardButton("График платформ", callback_data="admin_platform_chart")
            ],
            [
                InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
            ]
        ]
        
        # Подготавливаем caption для графика
        caption = "📊 *График совместимости функций за последние 30 дней*"
        
        # Отправляем новое сообщение с графиком
        await context.bot.send_photo(
            chat_id=update.effective_chat.id,
            photo=chart_data,
            caption=caption,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        
        # Удаляем предыдущее сообщение
        await query.delete_message()
        
    except Exception as e:
        logger.error(f"Ошибка при генерации графика совместимости функций: {e}")
        keyboard = [
            [
                InlineKeyboardButton("« Назад к выбору", callback_data="admin_platform_compatibility")
            ]
        ]
        
        await query.edit_message_text(
            text=f"⚠️ *Ошибка при генерации графика функций*\n\n{str(e)}",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

def get_admin_handlers() -> Tuple[Dict[str, callable], Dict[str, callable]]:
    """
    Получение словарей обработчиков административных команд
    
    Returns:
        Tuple[Dict, Dict]: Кортеж из двух словарей:
            1. Словарь статических обработчиков {callback_data: handler_function}
            2. Словарь динамических обработчиков {prefix: handler_function}
    """
    # Базовые обработчики
    handlers = {
        "admin_stats": admin_stats_callback,
        "admin_pending_payments": admin_pending_payments_callback,
        "admin_create_payout": admin_create_payout_callback,
        "admin_payouts_list": admin_payouts_list_callback,
        "admin_back": admin_back_callback,
        "admin_group_payout": admin_group_payout_callback,
        "admin_notify_pending": admin_notify_pending_callback,
        "admin_notify_confirm": admin_notify_confirm_callback,
        "admin_recover_payouts": admin_recover_payouts_callback,
        # Добавляем обработчики кросс-платформенной совместимости
        "admin_platform_compatibility": admin_platform_compatibility_callback,
        "admin_platform_summary": admin_platform_summary_callback,
        "admin_platform_report": admin_platform_report_callback,
        "admin_platform_chart": admin_platform_chart_callback,
        "admin_features_chart": admin_features_chart_callback,
        # Добавляем обработчики отзывов о платформенной совместимости
        "admin_feedback_stats": admin_feedback_stats_callback,
        "admin_feedback_list": admin_feedback_list_callback
    }
    
    # Добавляем обработчики мониторинга платежей
    payment_handlers, payment_patterns = get_payment_handlers()
    handlers.update(payment_handlers)
    
    # Регистрируем обработчик пагинации для постраничного вывода ожидающих выплат
    def dynamic_pagination_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """
        Динамический обработчик для пагинации выплат
        """
        return admin_pending_pagination_callback(update, context)
    
    # Добавляем специальный обработчик для динамических колбэков с ID выплаты
    def dynamic_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработчик для динамических callback_data"""
        callback_data = update.callback_query.data
        
        # Обрабатываем разные форматы callback_data
        if callback_data.startswith("admin_process_payout:"):
            return admin_process_payout_callback(update, context)
        
        # Другие потенциальные обработчики динамических колбэков
        
        # Если ничего не подошло, возвращаемся в админ-меню
        return admin_back_callback(update, context)
    
    # Добавляем обработчик для всех колбэков, начинающихся с admin_process_payout:
    handlers["admin_process_payout"] = dynamic_handler
    
    # Добавляем обработчик для пагинации
    dynamic_handlers = {
        "admin_pending_pagination_": dynamic_pagination_handler
    }
    
    # Добавляем динамические обработчики мониторинга платежей
    dynamic_handlers.update(payment_patterns)
    
    return handlers, dynamic_handlers