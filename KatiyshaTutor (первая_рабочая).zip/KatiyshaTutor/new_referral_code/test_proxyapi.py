#!/usr/bin/env python
# coding: utf-8

"""
Тестовый скрипт для проверки работы с ProxyAPI и решения математических задач
с использованием каскадного механизма
"""

import os
import logging
import sys
import asyncio
from services.deepseek_service import test_proxyapi_status, solve_math_problem

# Настройка логирования
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

async def test_proxy_api():
    """
    Тестирование доступности ProxyAPI и его различных URL-форматов
    """
    logger.info("=== Starting ProxyAPI Test ===")
    
    # Проверяем доступность ProxyAPI
    is_available = await test_proxyapi_status()
    logger.info(f"ProxyAPI availability: {'✅ Available' if is_available else '❌ Not available'}")
    
    # Если API доступен, проверяем решение задачи
    if is_available:
        test_problem = "16x-7x=612"
        logger.info(f"Testing problem solving with: '{test_problem}'")
        
        # Решаем тестовую задачу
        solution = await solve_math_problem(test_problem)
        
        # Выводим результат
        if "временно недоступен" not in solution and "перегружен" not in solution:
            logger.info(f"✅ Problem solved successfully: {solution[:100]}...")
            return True
        else:
            logger.error(f"❌ Problem solving failed: {solution[:100]}...")
            return False
    
    return is_available

async def main():
    logger.info("Running ProxyAPI test...")
    try:
        success = await test_proxy_api()
        
        if success:
            logger.info("✅ ProxyAPI test passed - API is available and working")
        else:
            logger.error("❌ ProxyAPI test failed - check API key and connectivity")

        return success
    except Exception as e:
        logger.error(f"❌ Unexpected error during testing: {str(e)}")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)