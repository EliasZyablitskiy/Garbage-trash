#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для создания администратора в новой системе
"""

import os
import sys
from datetime import datetime
from werkzeug.security import generate_password_hash
from db_config import get_flask_app
from db_models import db, AdminUser

# Telegram ID администратора, пароль и роль
ADMIN_TELEGRAM_ID = 5913639088
ADMIN_PASSWORD = "admin123"  # Этот пароль используется в старой системе
ADMIN_ROLE = "super_admin"  # super_admin, finance_admin, monitoring_admin, support_admin

def create_admin_user():
    """
    Создает запись администратора в базе данных
    """
    app = get_flask_app()
    
    with app.app_context():
        # Проверяем, существует ли уже администратор с таким Telegram ID
        existing_admin = AdminUser.query.filter_by(telegram_id=ADMIN_TELEGRAM_ID).first()
        
        if existing_admin:
            print(f"Администратор с Telegram ID {ADMIN_TELEGRAM_ID} уже существует")
            return
        
        # Создаем нового администратора
        password_hash = generate_password_hash(ADMIN_PASSWORD)
        
        admin_user = AdminUser(
            telegram_id=ADMIN_TELEGRAM_ID,
            password_hash=password_hash,
            role=ADMIN_ROLE,
            is_active=True,
            created_at=datetime.now()
        )
        
        try:
            db.session.add(admin_user)
            db.session.commit()
            print(f"Администратор с Telegram ID {ADMIN_TELEGRAM_ID} успешно создан")
        except Exception as e:
            db.session.rollback()
            print(f"Ошибка при создании администратора: {e}")
            raise

if __name__ == "__main__":
    create_admin_user()