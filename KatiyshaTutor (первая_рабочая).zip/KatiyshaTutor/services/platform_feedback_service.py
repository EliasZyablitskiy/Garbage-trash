import logging
import os
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple

from sqlalchemy import desc
from sqlalchemy.exc import SQLAlchemyError

from db_models import db
from db_models import PlatformFeedback, User


logger = logging.getLogger(__name__)


class PlatformFeedbackService:
    """Сервис для работы с обратной связью по совместимости платформ"""
    
    @staticmethod
    def submit_feedback(
        user_id: int,
        platform_type: str,
        platform_version: str,
        device_info: str,
        feature_type: str,
        rating: int,
        feedback_text: Optional[str] = None,
        screenshot_path: Optional[str] = None
    ) -> Tuple[bool, str]:
        """
        Сохраняет отзыв о работе определенной функции на определенной платформе
        
        Args:
            user_id: ID пользователя
            platform_type: Тип платформы (Android, iOS, Windows, Linux, etc)
            platform_version: Версия платформы
            device_info: Информация о устройстве
            feature_type: Тип функции (AI, QR, UI, etc)
            rating: Оценка (1-5)
            feedback_text: Текстовый отзыв
            screenshot_path: Путь к скриншоту
            
        Returns:
            Tuple[bool, str]: (успех, сообщение)
        """
        try:
            # Проверяем, что пользователь существует
            user = User.query.filter_by(id=user_id).first()
            if not user:
                return False, "Пользователь не найден"
            
            # Проверяем, что оценка в допустимом диапазоне
            if rating < 1 or rating > 5:
                return False, "Оценка должна быть от 1 до 5"
            
            # Создаем новый отзыв
            feedback = PlatformFeedback(
                user_id=user_id,
                platform_type=platform_type,
                platform_version=platform_version,
                device_info=device_info,
                feature_type=feature_type,
                rating=rating,
                feedback_text=feedback_text,
                screenshot_path=screenshot_path,
                timestamp=datetime.now()
            )
            
            db.session.add(feedback)
            db.session.commit()
            
            logger.info(f"Сохранен отзыв о функции {feature_type} на платформе {platform_type} от пользователя {user_id}")
            return True, f"Отзыв сохранен (ID: {feedback.id})"
                
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Ошибка при сохранении отзыва: {str(e)}")
            return False, f"Ошибка базы данных: {str(e)}"
        except Exception as e:
            db.session.rollback()
            logger.error(f"Неожиданная ошибка при сохранении отзыва: {str(e)}")
            return False, f"Неизвестная ошибка: {str(e)}"
    
    @staticmethod
    def save_screenshot(user_id: int, image_data: bytes) -> Optional[str]:
        """
        Сохраняет скриншот и возвращает путь к нему
        
        Args:
            user_id: ID пользователя
            image_data: Данные изображения
            
        Returns:
            Optional[str]: Путь к сохраненному изображению или None при ошибке
        """
        try:
            # Создаем директорию, если её нет
            screenshot_dir = "temp_feedback_screenshots"
            os.makedirs(screenshot_dir, exist_ok=True)
            
            # Генерируем имя файла
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{screenshot_dir}/feedback_{user_id}_{timestamp}.jpg"
            
            # Сохраняем изображение
            with open(filename, "wb") as f:
                f.write(image_data)
                
            logger.info(f"Скриншот сохранен: {filename}")
            return filename
        except Exception as e:
            logger.error(f"Ошибка при сохранении скриншота: {str(e)}")
            return None
    
    @staticmethod
    def get_user_feedback(user_id: int, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Получает историю отзывов пользователя
        
        Args:
            user_id: ID пользователя
            limit: Ограничение количества записей
            
        Returns:
            List[Dict[str, Any]]: Список отзывов
        """
        try:
            feedbacks = PlatformFeedback.query\
                .filter_by(user_id=user_id)\
                .order_by(desc(PlatformFeedback.timestamp))\
                .limit(limit)\
                .all()
            
            return [feedback.to_dict() for feedback in feedbacks]
        except Exception as e:
            logger.error(f"Ошибка при получении отзывов пользователя: {str(e)}")
            return []
    
    @staticmethod
    def get_all_feedback(
        limit: int = 100,
        platform_type: Optional[str] = None,
        feature_type: Optional[str] = None,
        min_rating: Optional[int] = None,
        max_rating: Optional[int] = None,
        resolved: Optional[bool] = None
    ) -> List[Dict[str, Any]]:
        """
        Получает все отзывы с возможностью фильтрации
        
        Args:
            limit: Ограничение количества записей
            platform_type: Фильтр по типу платформы
            feature_type: Фильтр по типу функции
            min_rating: Минимальная оценка
            max_rating: Максимальная оценка
            resolved: Статус разрешения проблемы
            
        Returns:
            List[Dict[str, Any]]: Список отзывов
        """
        try:
            query = PlatformFeedback.query
            
            # Применяем фильтры
            if platform_type:
                query = query.filter_by(platform_type=platform_type)
            if feature_type:
                query = query.filter_by(feature_type=feature_type)
            if min_rating is not None:
                query = query.filter(PlatformFeedback.rating >= min_rating)
            if max_rating is not None:
                query = query.filter(PlatformFeedback.rating <= max_rating)
            if resolved is not None:
                query = query.filter_by(is_resolved=resolved)
            
            # Получаем результаты
            feedbacks = query.order_by(desc(PlatformFeedback.timestamp)).limit(limit).all()
            return [feedback.to_dict() for feedback in feedbacks]
        except Exception as e:
            logger.error(f"Ошибка при получении всех отзывов: {str(e)}")
            return []
    
    @staticmethod
    def update_feedback_status(feedback_id: int, is_resolved: bool, admin_notes: Optional[str] = None) -> Tuple[bool, str]:
        """
        Обновляет статус обратной связи и добавляет комментарий администратора
        
        Args:
            feedback_id: ID отзыва
            is_resolved: Статус разрешения
            admin_notes: Комментарий администратора
            
        Returns:
            Tuple[bool, str]: (успех, сообщение)
        """
        try:
            feedback = PlatformFeedback.query.get(feedback_id)
            if not feedback:
                return False, "Отзыв не найден"
            
            feedback.is_resolved = is_resolved
            if admin_notes:
                feedback.admin_notes = admin_notes
            
            db.session.commit()
            
            status = "разрешен" if is_resolved else "не разрешен"
            logger.info(f"Статус отзыва {feedback_id} изменен на '{status}'")
            return True, f"Статус отзыва изменен на '{status}'"
        except Exception as e:
            db.session.rollback()
            logger.error(f"Ошибка при обновлении статуса отзыва: {str(e)}")
            return False, f"Ошибка: {str(e)}"
    
    @staticmethod
    def get_rating_statistics() -> Dict[str, Any]:
        """
        Получает статистику оценок по платформам и функциям
        
        Returns:
            Dict[str, Any]: Статистика оценок
        """
        try:
            # Получаем общее количество отзывов
            total_count = PlatformFeedback.query.count()
            
            # Считаем средний рейтинг
            all_feedbacks = PlatformFeedback.query.all()
            
            # Группируем по платформам
            platform_stats = {}
            feature_stats = {}
            
            for feedback in all_feedbacks:
                platform = feedback.platform_type
                feature = feedback.feature_type
                rating = feedback.rating
                
                # Статистика по платформам
                if platform not in platform_stats:
                    platform_stats[platform] = {"count": 0, "sum": 0}
                platform_stats[platform]["count"] += 1
                platform_stats[platform]["sum"] += rating
                
                # Статистика по функциям
                if feature not in feature_stats:
                    feature_stats[feature] = {"count": 0, "sum": 0}
                feature_stats[feature]["count"] += 1
                feature_stats[feature]["sum"] += rating
            
            # Вычисляем средние значения
            for platform in platform_stats:
                platform_stats[platform]["avg"] = round(
                    platform_stats[platform]["sum"] / platform_stats[platform]["count"], 2
                )
            
            for feature in feature_stats:
                feature_stats[feature]["avg"] = round(
                    feature_stats[feature]["sum"] / feature_stats[feature]["count"], 2
                )
            
            # Собираем результаты
            result = {
                "total_count": total_count,
                "average_rating": round(sum(f.rating for f in all_feedbacks) / total_count, 2) if total_count > 0 else 0,
                "platform_stats": platform_stats,
                "feature_stats": feature_stats,
                "unresolved_count": PlatformFeedback.query.filter_by(is_resolved=False).count()
            }
            
            return result
        except Exception as e:
            logger.error(f"Ошибка при получении статистики оценок: {str(e)}")
            return {
                "total_count": 0,
                "average_rating": 0,
                "platform_stats": {},
                "feature_stats": {},
                "unresolved_count": 0,
                "error": str(e)
            }
    
    @staticmethod
    def get_available_platforms() -> List[str]:
        """
        Получает список всех уникальных платформ, по которым есть отзывы
        
        Returns:
            List[str]: Список типов платформ
        """
        try:
            # Получаем уникальные значения platform_type
            result = db.session.query(PlatformFeedback.platform_type)\
                .distinct()\
                .order_by(PlatformFeedback.platform_type)\
                .all()
            
            # Преобразуем результат в список строк
            platforms = [r[0] for r in result]
            
            # Если список пуст, возвращаем список основных платформ
            if not platforms:
                return ["android", "ios", "windows", "linux", "macos", "web"]
                
            return platforms
        except Exception as e:
            logger.error(f"Ошибка при получении списка платформ: {str(e)}")
            # Возвращаем список по умолчанию в случае ошибки
            return ["android", "ios", "windows", "linux", "macos", "web"]
    
    @staticmethod
    def get_available_features() -> List[str]:
        """
        Получает список всех уникальных функций, по которым есть отзывы
        
        Returns:
            List[str]: Список типов функций
        """
        try:
            # Получаем уникальные значения feature_type
            result = db.session.query(PlatformFeedback.feature_type)\
                .distinct()\
                .order_by(PlatformFeedback.feature_type)\
                .all()
            
            # Преобразуем результат в список строк
            features = [r[0] for r in result]
            
            # Если список пуст, возвращаем список основных функций
            if not features:
                return ["AI", "OCR", "QR", "UI", "Voice", "Payments"]
                
            return features
        except Exception as e:
            logger.error(f"Ошибка при получении списка функций: {str(e)}")
            # Возвращаем список по умолчанию в случае ошибки
            return ["AI", "OCR", "QR", "UI", "Voice", "Payments"]