#!/usr/bin/env python3
"""
Сервис для работы с Яндекс.Диском через REST API
Примечание: В отличие от стандартной библиотеки YaDisk, этот модуль
использует прямые HTTP-запросы к API для лучшей совместимости с OAuth
"""
import os
import sys
import logging
import datetime
import json
import requests
from typing import List, Dict, Any, Optional
from pathlib import Path

# Настройка логирования
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# API URL
API_BASE_URL = "https://cloud-api.yandex.net/v1/disk"

def get_token_from_db() -> Optional[Dict[str, Any]]:
    """
    Получает токен доступа из базы данных
    
    Returns:
        dict: Информация о токене или None в случае ошибки
    """
    try:
        from db_config import get_flask_app
        from db_models import YandexDiskToken
        
        app = get_flask_app()
        with app.app_context():
            token = YandexDiskToken.query.order_by(YandexDiskToken.created_at.desc()).first()
            
            if not token:
                logger.error("Токен Яндекс.Диска не найден в базе данных")
                return None
            
            # Проверяем срок действия токена
            if token.expires_at and token.expires_at < datetime.datetime.now():
                logger.warning("Токен Яндекс.Диска истек, необходимо обновить")
                # Обновляем токен
                new_token = refresh_token(token.refresh_token)
                if not new_token:
                    logger.error("Не удалось обновить токен")
                    return None
                
                # Сохраняем новый токен
                token.access_token = new_token.get("access_token")
                token.refresh_token = new_token.get("refresh_token")
                token.token_type = new_token.get("token_type", "Bearer")
                
                # Устанавливаем время истечения токена
                expires_in = new_token.get("expires_in")
                if expires_in:
                    token.expires_at = datetime.datetime.now() + datetime.timedelta(seconds=expires_in)
                
                token.updated_at = datetime.datetime.now()
                
                from db_models import db
                db.session.commit()
                
                logger.info("Токен Яндекс.Диска успешно обновлен")
            
            # Возвращаем информацию о токене
            return {
                "access_token": token.access_token,
                "refresh_token": token.refresh_token,
                "token_type": token.token_type,
                "expires_at": token.expires_at
            }
    except Exception as e:
        logger.error(f"Ошибка при получении токена из базы данных: {e}")
        return None

def refresh_token(refresh_token: str) -> Optional[Dict[str, Any]]:
    """
    Обновляет токен доступа
    
    Args:
        refresh_token: Токен обновления
        
    Returns:
        dict: Информация о новом токене или None в случае ошибки
    """
    try:
        # Получаем переменные окружения
        client_id = os.environ.get("YANDEX_OAUTH_CLIENT_ID")
        client_secret = os.environ.get("YANDEX_OAUTH_CLIENT_SECRET")
        
        if not client_id or not client_secret:
            logger.error("Не указаны переменные окружения YANDEX_OAUTH_CLIENT_ID или YANDEX_OAUTH_CLIENT_SECRET")
            return None
        
        # Отправляем запрос на обновление токена
        url = "https://oauth.yandex.ru/token"
        data = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": client_id,
            "client_secret": client_secret
        }
        
        response = requests.post(url, data=data)
        response.raise_for_status()
        
        token_data = response.json()
        logger.info("Токен доступа успешно обновлен")
        
        return token_data
    except Exception as e:
        logger.error(f"Ошибка обновления токена: {e}")
        return None

def make_api_request(endpoint: str, method: str = "GET", params: Optional[Dict[str, Any]] = None, 
                     data: Optional[Dict[str, Any]] = None, files: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """
    Выполняет запрос к API Яндекс.Диска
    
    Args:
        endpoint: Конечная точка API
        method: HTTP-метод (GET, POST, PUT, DELETE)
        params: Параметры запроса
        data: Данные запроса
        files: Файлы для загрузки
        
    Returns:
        dict: Ответ API или None в случае ошибки
    """
    try:
        # Получаем токен доступа
        token = get_token_from_db()
        if not token:
            logger.error("Не удалось получить токен доступа")
            return None
        
        # Формируем URL
        url = f"{API_BASE_URL}{endpoint}"
        
        # Заголовки запроса
        headers = {
            "Authorization": f"{token.get('token_type', 'Bearer')} {token.get('access_token')}"
        }
        
        # Выполняем запрос
        if method == "GET":
            response = requests.get(url, headers=headers, params=params)
        elif method == "POST":
            response = requests.post(url, headers=headers, params=params, json=data, files=files)
        elif method == "PUT":
            response = requests.put(url, headers=headers, params=params, json=data, files=files)
        elif method == "DELETE":
            response = requests.delete(url, headers=headers, params=params)
        else:
            logger.error(f"Неподдерживаемый HTTP-метод: {method}")
            return None
        
        # Проверяем статус ответа
        response.raise_for_status()
        
        # Если ответ пустой, возвращаем True
        if not response.text:
            return {"success": True}
        
        # Возвращаем данные ответа
        return response.json()
    except requests.exceptions.HTTPError as e:
        logger.error(f"HTTP-ошибка: {e}")
        
        # Если есть ответ с ошибкой от API, логируем его
        try:
            error_data = e.response.json()
            logger.error(f"Ошибка API: {error_data}")
        except:
            logger.error(f"Ошибка API без JSON-ответа: {e.response.text}")
        
        return None
    except Exception as e:
        logger.error(f"Ошибка при выполнении запроса: {e}")
        return None

def check_disk_connection() -> bool:
    """
    Проверяет подключение к Яндекс.Диску
    
    Returns:
        bool: True, если подключение успешно, False в противном случае
    """
    try:
        # Запрашиваем информацию о диске
        response = make_api_request("/")
        if not response:
            logger.error("Не удалось получить информацию о диске")
            return False
        
        # Проверяем наличие поля total_space
        if "total_space" not in response:
            logger.error("Неверный формат ответа от API")
            return False
        
        logger.info(f"Подключение к Яндекс.Диску успешно. Доступно {response.get('free_space')} байт из {response.get('total_space')} байт")
        return True
    except Exception as e:
        logger.error(f"Ошибка при проверке подключения к Яндекс.Диску: {e}")
        return False

def folder_exists(path: str) -> bool:
    """
    Проверяет существование папки на Яндекс.Диске
    
    Args:
        path: Путь к папке
        
    Returns:
        bool: True, если папка существует, False в противном случае
    """
    try:
        # Запрашиваем метаданные ресурса
        response = make_api_request("/resources", params={"path": path})
        
        # Если запрос успешный, значит ресурс существует
        return response is not None
    except Exception as e:
        logger.error(f"Ошибка при проверке существования папки: {e}")
        return False

def create_folder(path: str) -> bool:
    """
    Создает папку на Яндекс.Диске
    
    Args:
        path: Путь к папке
        
    Returns:
        bool: True, если папка создана, False в противном случае
    """
    try:
        # Создаем папку
        response = make_api_request("/resources", method="PUT", params={"path": path})
        
        return response is not None
    except Exception as e:
        logger.error(f"Ошибка при создании папки: {e}")
        return False

def ensure_backup_folder() -> bool:
    """
    Проверяет наличие и при необходимости создает папку для резервных копий
    
    Returns:
        bool: True, если папка существует или успешно создана, False в противном случае
    """
    try:
        # Путь к папке с резервными копиями
        backup_folder = "/backups"
        
        # Проверяем наличие папки
        if folder_exists(backup_folder):
            logger.info(f"Папка {backup_folder} уже существует")
            return True
        
        # Создаем папку
        if create_folder(backup_folder):
            logger.info(f"Папка {backup_folder} успешно создана")
            return True
        
        logger.error(f"Не удалось создать папку {backup_folder}")
        return False
    except Exception as e:
        logger.error(f"Ошибка при проверке/создании папки для резервных копий: {e}")
        return False

def get_upload_url(path: str) -> Optional[str]:
    """
    Получает URL для загрузки файла на Яндекс.Диск
    
    Args:
        path: Путь к файлу на Яндекс.Диске
        
    Returns:
        str: URL для загрузки или None в случае ошибки
    """
    try:
        # Запрашиваем URL для загрузки
        response = make_api_request("/resources/upload", params={"path": path, "overwrite": "true"})
        if not response or "href" not in response:
            logger.error("Не удалось получить URL для загрузки")
            return None
        
        return response.get("href")
    except Exception as e:
        logger.error(f"Ошибка при получении URL для загрузки: {e}")
        return None

def upload_file(local_path: str, remote_path: str) -> bool:
    """
    Загружает файл на Яндекс.Диск
    
    Args:
        local_path: Путь к локальному файлу
        remote_path: Путь к файлу на Яндекс.Диске
        
    Returns:
        bool: True, если файл загружен, False в противном случае
    """
    try:
        # Получаем URL для загрузки
        upload_url = get_upload_url(remote_path)
        if not upload_url:
            return False
        
        # Загружаем файл
        with open(local_path, "rb") as f:
            response = requests.put(upload_url, data=f)
            response.raise_for_status()
        
        logger.info(f"Файл {local_path} успешно загружен на Яндекс.Диск")
        return True
    except Exception as e:
        logger.error(f"Ошибка при загрузке файла: {e}")
        return False

def get_download_url(path: str) -> Optional[str]:
    """
    Получает URL для скачивания файла с Яндекс.Диска
    
    Args:
        path: Путь к файлу на Яндекс.Диске
        
    Returns:
        str: URL для скачивания или None в случае ошибки
    """
    try:
        # Запрашиваем URL для скачивания
        response = make_api_request("/resources/download", params={"path": path})
        if not response or "href" not in response:
            logger.error("Не удалось получить URL для скачивания")
            return None
        
        return response.get("href")
    except Exception as e:
        logger.error(f"Ошибка при получении URL для скачивания: {e}")
        return None

def download_file(remote_path: str, local_path: str) -> bool:
    """
    Скачивает файл с Яндекс.Диска
    
    Args:
        remote_path: Путь к файлу на Яндекс.Диске
        local_path: Путь к локальному файлу
        
    Returns:
        bool: True, если файл скачан, False в противном случае
    """
    try:
        # Получаем URL для скачивания
        download_url = get_download_url(remote_path)
        if not download_url:
            return False
        
        # Скачиваем файл
        response = requests.get(download_url, stream=True)
        response.raise_for_status()
        
        with open(local_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        logger.info(f"Файл {remote_path} успешно скачан")
        return True
    except Exception as e:
        logger.error(f"Ошибка при скачивании файла: {e}")
        return False

def get_resource_meta(path: str) -> Optional[Dict[str, Any]]:
    """
    Получает метаданные ресурса
    
    Args:
        path: Путь к ресурсу на Яндекс.Диске
        
    Returns:
        dict: Метаданные ресурса или None в случае ошибки
    """
    try:
        # Запрашиваем метаданные ресурса
        response = make_api_request("/resources", params={"path": path})
        
        return response
    except Exception as e:
        logger.error(f"Ошибка при получении метаданных ресурса: {e}")
        return None

def list_folder(path: str) -> Optional[List[Dict[str, Any]]]:
    """
    Получает список файлов в папке
    
    Args:
        path: Путь к папке на Яндекс.Диске
        
    Returns:
        list: Список файлов или None в случае ошибки
    """
    try:
        # Запрашиваем метаданные ресурса
        response = make_api_request("/resources", params={"path": path, "limit": 1000})
        if not response or "_embedded" not in response or "items" not in response["_embedded"]:
            logger.error("Не удалось получить список файлов")
            return None
        
        return response["_embedded"]["items"]
    except Exception as e:
        logger.error(f"Ошибка при получении списка файлов: {e}")
        return None

def delete_resource(path: str) -> bool:
    """
    Удаляет ресурс
    
    Args:
        path: Путь к ресурсу на Яндекс.Диске
        
    Returns:
        bool: True, если ресурс удален, False в противном случае
    """
    try:
        # Удаляем ресурс
        response = make_api_request("/resources", method="DELETE", params={"path": path, "permanently": "true"})
        
        return response is not None
    except Exception as e:
        logger.error(f"Ошибка при удалении ресурса: {e}")
        return False

def _save_backup_log(backup_file: str, disk_path: str, size_bytes: Optional[int] = None, status: str = "success", error_message: Optional[str] = None) -> bool:
    """
    Сохраняет информацию о бэкапе в базе данных
    
    Args:
        backup_file: Имя файла бэкапа
        disk_path: Путь на Яндекс.Диске
        size_bytes: Размер файла в байтах
        status: Статус операции (success, failed)
        error_message: Сообщение об ошибке
        
    Returns:
        bool: True, если информация сохранена, False в противном случае
    """
    try:
        from db_config import get_flask_app
        from db_models import BackupLog, db
        
        app = get_flask_app()
        with app.app_context():
            backup_log = BackupLog(
                backup_file=backup_file,
                disk_path=disk_path,
                size_bytes=size_bytes,
                status=status,
                error_message=error_message
            )
            
            db.session.add(backup_log)
            db.session.commit()
            
            logger.info(f"Информация о бэкапе сохранена в базе данных (ID: {backup_log.id})")
            return True
    except Exception as e:
        logger.error(f"Ошибка при сохранении информации о бэкапе: {e}")
        return False

# Публичные функции для использования в других модулях

def upload_to_yandex_disk(local_path: str, remote_path: str) -> Optional[str]:
    """
    Загружает файл на Яндекс.Диск и сохраняет информацию о бэкапе
    
    Args:
        local_path: Путь к локальному файлу
        remote_path: Путь к файлу на Яндекс.Диске
        
    Returns:
        str: Путь к файлу на Яндекс.Диске или None в случае ошибки
    """
    try:
        # Проверяем подключение к Яндекс.Диску
        if not check_disk_connection():
            logger.error("Нет подключения к Яндекс.Диску")
            return None
        
        # Проверяем существование папки для резервных копий
        if not ensure_backup_folder():
            logger.error("Не удалось создать папку для резервных копий")
            return None
        
        # Загружаем файл
        if not upload_file(local_path, remote_path):
            logger.error(f"Не удалось загрузить файл {local_path}")
            _save_backup_log(
                backup_file=os.path.basename(local_path),
                disk_path=remote_path,
                status="failed",
                error_message="Не удалось загрузить файл"
            )
            return None
        
        # Получаем информацию о загруженном файле
        file_meta = get_resource_meta(remote_path)
        size_bytes = file_meta.get("size", None) if file_meta else None
        
        # Сохраняем информацию о бэкапе
        _save_backup_log(
            backup_file=os.path.basename(local_path),
            disk_path=remote_path,
            size_bytes=size_bytes
        )
        
        return remote_path
    except Exception as e:
        logger.error(f"Ошибка при загрузке файла на Яндекс.Диск: {e}")
        _save_backup_log(
            backup_file=os.path.basename(local_path),
            disk_path=remote_path,
            status="failed",
            error_message=str(e)
        )
        return None

def download_from_yandex_disk(remote_path: str, local_path: str) -> bool:
    """
    Скачивает файл с Яндекс.Диска
    
    Args:
        remote_path: Путь к файлу на Яндекс.Диске
        local_path: Путь к локальному файлу
        
    Returns:
        bool: True, если файл скачан, False в противном случае
    """
    try:
        # Проверяем подключение к Яндекс.Диску
        if not check_disk_connection():
            logger.error("Нет подключения к Яндекс.Диску")
            return False
        
        # Скачиваем файл
        return download_file(remote_path, local_path)
    except Exception as e:
        logger.error(f"Ошибка при скачивании файла с Яндекс.Диска: {e}")
        return False

def list_backups() -> Optional[List[Dict[str, Any]]]:
    """
    Получает список резервных копий
    
    Returns:
        list: Список резервных копий или None в случае ошибки
    """
    try:
        # Проверяем подключение к Яндекс.Диску
        if not check_disk_connection():
            logger.error("Нет подключения к Яндекс.Диску")
            return None
        
        # Путь к папке с резервными копиями
        backup_folder = "/backups"
        
        # Проверяем наличие папки
        if not folder_exists(backup_folder):
            logger.warning(f"Папка {backup_folder} не существует")
            return []
        
        # Получаем список файлов
        items = list_folder(backup_folder)
        if not items:
            logger.warning(f"В папке {backup_folder} нет файлов")
            return []
        
        # Фильтруем только файлы с расширением .sql
        backups = []
        for item in items:
            if item.get("type") == "file" and item.get("name", "").endswith(".sql"):
                backups.append({
                    "name": item.get("name"),
                    "path": item.get("path"),
                    "created": item.get("created"),
                    "modified": item.get("modified"),
                    "size": item.get("size")
                })
        
        return backups
    except Exception as e:
        logger.error(f"Ошибка при получении списка резервных копий: {e}")
        return None

def delete_backup(path: str) -> bool:
    """
    Удаляет резервную копию
    
    Args:
        path: Путь к файлу на Яндекс.Диске
        
    Returns:
        bool: True, если файл удален, False в противном случае
    """
    try:
        # Проверяем подключение к Яндекс.Диску
        if not check_disk_connection():
            logger.error("Нет подключения к Яндекс.Диску")
            return False
        
        # Проверяем существование файла
        if not folder_exists(path):
            logger.warning(f"Файл {path} не существует")
            return False
        
        # Удаляем файл
        return delete_resource(path)
    except Exception as e:
        logger.error(f"Ошибка при удалении резервной копии: {e}")
        return False

# Этот блок будет выполнен только при прямом запуске скрипта
if __name__ == "__main__":
    # Тестирование подключения к Яндекс.Диску
    if check_disk_connection():
        print("Подключение к Яндекс.Диску успешно")
    else:
        print("Ошибка подключения к Яндекс.Диску")
        sys.exit(1)
    
    # Проверяем/создаем папку для резервных копий
    if ensure_backup_folder():
        print("Папка для резервных копий готова")
    else:
        print("Ошибка при подготовке папки для резервных копий")
        sys.exit(1)
    
    # Выводим список резервных копий
    backups = list_backups()
    if backups:
        print("\nСписок резервных копий:")
        for backup in backups:
            print(f"  - {backup['name']} ({backup['created']})")
    else:
        print("Резервные копии не найдены")
    
    print("\nМодуль Яндекс.Диск готов к использованию")