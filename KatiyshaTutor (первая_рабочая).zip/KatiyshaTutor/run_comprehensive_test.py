#!/usr/bin/env python3
"""
Запускает всестороннее тестирование системы и выводит результаты
"""
import os
import logging
import time
import json
import traceback
from comprehensive_system_test import SystemTester

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    """Запуск тестирования и вывод результатов"""
    logger.info("Запуск всестороннего тестирования системы...")
    
    try:
        # Инициализируем тестер
        tester = SystemTester()
        
        # Запускаем тестирование
        logger.info("Выполнение тестов...")
        results = tester.run_all_tests()
        
        # Сохраняем результаты в файл
        timestamp = time.strftime("%Y%m%d%H%M%S")
        results_file = f"system_test_results_{timestamp}.json"
        tester.save_results_to_file(results_file)
        
        # Выводим результаты тестирования
        print("\n" + "="*80)
        print("РЕЗУЛЬТАТЫ ВСЕСТОРОННЕГО ТЕСТИРОВАНИЯ СИСТЕМЫ")
        print("="*80)
        
        print(f"\nУспешно выполнено {results['successful_tests']} из {results['total_tests']} тестов ({results['success_rate']:.0%})")
        
        # Для каждого тестируемого модуля, выводим результат
        for module_name, module_results in results['results'].items():
            success_icon = "✅" if module_results.get('success', False) else "❌"
            print(f"\n{success_icon} {module_name.upper()}:")
            
            if not module_results.get('success', False) and 'error' in module_results:
                print(f"   Ошибка: {module_results['error']}")
            
            # Выводим детали, если они есть и не слишком объемные
            if 'details' in module_results:
                for detail_name, detail_value in module_results['details'].items():
                    if isinstance(detail_value, bool):
                        status = "Успешно" if detail_value else "Не выполнено"
                        print(f"   - {detail_name}: {status}")
                    elif isinstance(detail_value, dict) and 'success' in detail_value:
                        status = "Успешно" if detail_value['success'] else "Не выполнено"
                        print(f"   - {detail_name}: {status}")
        
        # Анализируем результаты и выводим предложения по исправлению
        suggestions = tester.analyze_results_and_suggest_fixes()
        
        if suggestions:
            print("\n" + "="*80)
            print("ПРЕДЛОЖЕНИЯ ПО ИСПРАВЛЕНИЮ ПРОБЛЕМ")
            print("="*80)
            
            for system_name, system_suggestions in suggestions.items():
                print(f"\n{system_name.upper()}:")
                
                if system_suggestions["issues"]:
                    print("  Выявленные проблемы:")
                    for issue in system_suggestions["issues"]:
                        print(f"    - {issue}")
                
                if system_suggestions["suggestions"]:
                    print("  Предложения по исправлению:")
                    for suggestion in system_suggestions["suggestions"]:
                        print(f"    - {suggestion}")
        
        print("\n" + "="*80)
        if results["overall_success"]:
            print("✅ ВСЕ СИСТЕМЫ РАБОТАЮТ КОРРЕКТНО!")
        else:
            print(f"⚠️ ВЫЯВЛЕНЫ ПРОБЛЕМЫ. Детальные результаты в файле: {results_file}")
        print("="*80 + "\n")
        
        return 0
        
    except Exception as e:
        logger.error(f"Ошибка при запуске тестирования: {str(e)}")
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    exit_code = main()
    exit(exit_code)