#!/usr/bin/env python3
"""
Скрипт для создания пустого JSON-хранилища с правильной структурой
"""

import json
import os

def create_empty_json():
    """
    Создаем пустой JSON-файл с правильной структурой
    """
    data = {
        "users": {}
    }
    
    with open('users_db.json', 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    print("Создан пустой JSON-файл с правильной структурой")

if __name__ == "__main__":
    create_empty_json()