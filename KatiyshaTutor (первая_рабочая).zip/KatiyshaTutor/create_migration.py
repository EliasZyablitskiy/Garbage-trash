#!/usr/bin/env python
# coding: utf-8

"""
Script for creating initial database migration
"""

import os
import sys
import logging
import subprocess
from pathlib import Path

# Настраиваем логирование
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def create_initial_migration():
    """
    Create initial database migration using Flask-Migrate
    """
    try:
        # Проверяем, указан ли DATABASE_URL
        database_url = os.environ.get("DATABASE_URL")
        if not database_url:
            logger.error("DATABASE_URL environment variable not set")
            return False
        
        # Создаем Flask приложение
        from db_config import get_flask_app
        
        app = get_flask_app()
        
        # Инициализируем Flask-Migrate
        from flask_migrate import Migrate, init, migrate, upgrade
        from db_models import db
        
        migrate_instance = Migrate(app, db)
        
        with app.app_context():
            # Создаем директорию migrations, если она не существует
            migrations_dir = Path("migrations")
            if not migrations_dir.exists():
                logger.info("Creating migrations directory")
                migrations_dir.mkdir(exist_ok=True)
                
                # Инициализация миграций
                logger.info("Initializing migrations")
                init()
            
            # Создаем миграцию
            logger.info("Creating migration")
            migrate(message="Initial migration")
            
            # Применяем миграцию
            logger.info("Applying migration")
            upgrade()
            
            logger.info("Migration created and applied successfully")
            return True
    except ImportError as e:
        logger.error(f"Missing required package: {e}")
        logger.info("Run 'python install_dependencies.py' to install all required packages")
        return False
    except Exception as e:
        logger.error(f"Error creating migration: {e}")
        return False

def main():
    """
    Main function
    """
    # Создаем начальную миграцию
    if not create_initial_migration():
        logger.error("Failed to create initial migration")
        sys.exit(1)
    
    logger.info("Initial migration created and applied successfully")

if __name__ == "__main__":
    main()