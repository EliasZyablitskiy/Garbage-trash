#!/usr/bin/env python
# coding: utf-8

"""
Сервис валидации платежей и выплат
"""

import re
import json
import logging
import datetime
from enum import Enum
from typing import Dict, List, Any, Optional, Tuple, Union

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func, or_, and_, desc, asc

from db_models import db, Transaction, User, WeeklyPayout, BatchPayout, AdminActionLog

logger = logging.getLogger(__name__)

# Минимальная сумма для выплаты
MIN_PAYOUT_AMOUNT = 1000.0  # 1000 рублей

# Максимальная сумма для одной транзакции
MAX_TRANSACTION_AMOUNT = 15000.0  # 15000 рублей

# Максимальная сумма для одной пакетной выплаты
MAX_BATCH_AMOUNT = 100000.0  # 100000 рублей

# Минимальный интервал между выплатами одному пользователю (в днях)
MIN_PAYOUT_INTERVAL_DAYS = 7  # 7 дней

# Максимальное количество попыток для транзакции
MAX_RETRY_COUNT = 3

# Определяем тиры для группировки транзакций
PAYMENT_TIERS = {
    "tier_1": {"min": 1000, "max": 3000, "name": "Малые выплаты (1000₽ - 3000₽)"},
    "tier_2": {"min": 3001, "max": 5000, "name": "Средние выплаты (3001₽ - 5000₽)"},
    "tier_3": {"min": 5001, "max": 10000, "name": "Крупные выплаты (5001₽ - 10000₽)"},
    "tier_4": {"min": 10001, "max": 15000, "name": "Особо крупные выплаты (свыше 10000₽)"}
}

class PaymentValidationError(Exception):
    """Исключение для ошибок валидации платежей"""
    def __init__(self, message: str, code: str = "VALIDATION_ERROR", details: Dict[str, Any] = None):
        self.message = message
        self.code = code
        self.details = details or {}
        super().__init__(self.message)


class TransactionValidationRule(Enum):
    """Перечисление правил валидации транзакций"""
    AMOUNT_RANGE = "amount_range"  # Проверка диапазона суммы
    DUPLICATE_CHECK = "duplicate_check"  # Проверка на дубликаты
    USER_EXISTENCE = "user_existence"  # Проверка существования пользователя
    TRANSACTION_STATUS = "transaction_status"  # Проверка статуса транзакции
    PAYOUT_INTERVAL = "payout_interval"  # Проверка интервала между выплатами
    RETRY_COUNT = "retry_count"  # Проверка количества попыток


class PayoutValidationRule(Enum):
    """Перечисление правил валидации выплат"""
    TOTAL_AMOUNT = "total_amount"  # Проверка общей суммы
    USER_COUNT = "user_count"  # Проверка количества пользователей
    TRANSACTION_COUNT = "transaction_count"  # Проверка количества транзакций
    BATCH_SIZE = "batch_size"  # Проверка размера пакета
    ADMIN_PERMISSION = "admin_permission"  # Проверка прав администратора


def validate_transaction_amount(amount: float) -> bool:
    """
    Валидация суммы транзакции
    
    Args:
        amount: Сумма транзакции
        
    Returns:
        bool: True, если сумма допустима, иначе False
    """
    return 0 < amount <= MAX_TRANSACTION_AMOUNT


def validate_payout_amount(total_amount: float) -> bool:
    """
    Валидация общей суммы выплаты
    
    Args:
        total_amount: Общая сумма выплаты
        
    Returns:
        bool: True, если сумма допустима, иначе False
    """
    return total_amount >= MIN_PAYOUT_AMOUNT and total_amount <= MAX_BATCH_AMOUNT


async def validate_transaction(session: AsyncSession, transaction: Dict[str, Any], rules: List[TransactionValidationRule] = None) -> Dict[str, Any]:
    """
    Валидация транзакции по указанным правилам
    
    Args:
        session: Активная сессия базы данных
        transaction: Словарь с данными транзакции
        rules: Список правил для валидации (если None, применяются все правила)
        
    Returns:
        dict: Результаты валидации {success: bool, errors: list}
    """
    if rules is None:
        rules = list(TransactionValidationRule)
        
    results = {
        "success": True,
        "errors": [],
        "warnings": []
    }
    
    # Получаем данные транзакции
    tx_id = transaction.get("transaction_id", "")
    user_id = transaction.get("user_id")
    amount = float(transaction.get("amount", 0))
    tx_type = transaction.get("type", "unknown")
    status = transaction.get("status", "pending")
    
    # Проверка существования пользователя
    if TransactionValidationRule.USER_EXISTENCE in rules and user_id:
        user_result = await session.execute(
            select(User).where(User.id == user_id)
        )
        user = user_result.scalars().first()
        
        if not user:
            results["success"] = False
            results["errors"].append({
                "rule": TransactionValidationRule.USER_EXISTENCE.value,
                "message": f"Пользователь с ID {user_id} не найден",
                "code": "USER_NOT_FOUND"
            })
    
    # Проверка суммы транзакции
    if TransactionValidationRule.AMOUNT_RANGE in rules:
        if not validate_transaction_amount(amount):
            results["success"] = False
            results["errors"].append({
                "rule": TransactionValidationRule.AMOUNT_RANGE.value,
                "message": f"Сумма транзакции ({amount}₽) выходит за допустимые пределы (0 - {MAX_TRANSACTION_AMOUNT}₽)",
                "code": "INVALID_AMOUNT"
            })
    
    # Проверка на дубликаты
    if TransactionValidationRule.DUPLICATE_CHECK in rules and tx_id:
        # Проверяем наличие транзакции с таким же ID
        tx_result = await session.execute(
            select(Transaction).where(Transaction.transaction_id == tx_id)
        )
        existing_tx = tx_result.scalars().first()
        
        if existing_tx:
            if existing_tx.status in ('completed', 'failed'):
                results["success"] = False
                results["errors"].append({
                    "rule": TransactionValidationRule.DUPLICATE_CHECK.value,
                    "message": f"Транзакция с ID {tx_id} уже существует и имеет статус {existing_tx.status}",
                    "code": "DUPLICATE_TRANSACTION"
                })
            else:
                results["warnings"].append({
                    "rule": TransactionValidationRule.DUPLICATE_CHECK.value,
                    "message": f"Транзакция с ID {tx_id} уже существует со статусом {existing_tx.status}",
                    "code": "EXISTING_TRANSACTION"
                })
    
    # Проверка статуса транзакции
    if TransactionValidationRule.TRANSACTION_STATUS in rules and tx_id:
        valid_statuses = ['pending', 'processing', 'completed', 'failed', 'cancelled']
        if status not in valid_statuses:
            results["success"] = False
            results["errors"].append({
                "rule": TransactionValidationRule.TRANSACTION_STATUS.value,
                "message": f"Недопустимый статус транзакции: {status}. Допустимые статусы: {', '.join(valid_statuses)}",
                "code": "INVALID_STATUS"
            })
    
    # Проверка интервала между выплатами
    if TransactionValidationRule.PAYOUT_INTERVAL in rules and user_id and tx_type == 'referral_reward':
        cutoff_date = datetime.datetime.now() - datetime.timedelta(days=MIN_PAYOUT_INTERVAL_DAYS)
        
        # Ищем последнюю завершенную выплату этому пользователю
        tx_result = await session.execute(
            select(Transaction)
            .where(
                and_(
                    Transaction.user_id == user_id,
                    Transaction.transaction_type == 'referral_reward',
                    Transaction.status == 'completed',
                    Transaction.created_at > cutoff_date
                )
            )
            .order_by(desc(Transaction.created_at))
            .limit(1)
        )
        last_payout = tx_result.scalars().first()
        
        if last_payout:
            days_since_last = (datetime.datetime.now() - last_payout.created_at).days
            if days_since_last < MIN_PAYOUT_INTERVAL_DAYS:
                results["warnings"].append({
                    "rule": TransactionValidationRule.PAYOUT_INTERVAL.value,
                    "message": f"Последняя выплата пользователю была {days_since_last} дней назад (минимальный интервал: {MIN_PAYOUT_INTERVAL_DAYS} дней)",
                    "code": "PAYOUT_INTERVAL_WARNING",
                    "details": {
                        "last_payout_date": last_payout.created_at.isoformat(),
                        "days_since_last": days_since_last,
                        "min_interval": MIN_PAYOUT_INTERVAL_DAYS
                    }
                })
    
    # Проверка количества попыток
    if TransactionValidationRule.RETRY_COUNT in rules and tx_id:
        retry_count = transaction.get("retry_count", 0)
        if retry_count >= MAX_RETRY_COUNT:
            results["warnings"].append({
                "rule": TransactionValidationRule.RETRY_COUNT.value,
                "message": f"Превышено максимальное количество попыток ({retry_count} из {MAX_RETRY_COUNT})",
                "code": "MAX_RETRY_COUNT_EXCEEDED"
            })
    
    return results


async def validate_transactions_batch(session: AsyncSession, transactions: List[Dict[str, Any]], rules: List[TransactionValidationRule] = None) -> Dict[str, Any]:
    """
    Валидация пакета транзакций
    
    Args:
        session: Активная сессия базы данных
        transactions: Список словарей с данными транзакций
        rules: Список правил для валидации
        
    Returns:
        dict: Результаты валидации {success: bool, errors: list, validated: list}
    """
    results = {
        "success": True,
        "total": len(transactions),
        "valid": 0,
        "invalid": 0,
        "with_warnings": 0,
        "errors": [],
        "warnings": [],
        "validated": []
    }
    
    # Проверка на пустой список
    if not transactions:
        results["success"] = False
        results["errors"].append({
            "message": "Список транзакций пуст",
            "code": "EMPTY_TRANSACTION_LIST"
        })
        return results
    
    # Валидируем каждую транзакцию
    for tx in transactions:
        tx_result = await validate_transaction(session, tx, rules)
        
        # Добавляем результат валидации
        validated_tx = {
            "transaction": tx,
            "valid": tx_result["success"],
            "errors": tx_result["errors"],
            "warnings": tx_result["warnings"]
        }
        results["validated"].append(validated_tx)
        
        # Обновляем общие результаты
        if tx_result["success"]:
            results["valid"] += 1
        else:
            results["invalid"] += 1
            results["success"] = False
            # Добавляем ошибки в общий список
            for error in tx_result["errors"]:
                error["transaction_id"] = tx.get("transaction_id", "")
                results["errors"].append(error)
        
        # Проверяем наличие предупреждений
        if tx_result["warnings"]:
            results["with_warnings"] += 1
            # Добавляем предупреждения в общий список
            for warning in tx_result["warnings"]:
                warning["transaction_id"] = tx.get("transaction_id", "")
                results["warnings"].append(warning)
    
    return results


async def validate_payout(session: AsyncSession, payout_data: Dict[str, Any], rules: List[PayoutValidationRule] = None) -> Dict[str, Any]:
    """
    Валидация выплаты
    
    Args:
        session: Активная сессия базы данных
        payout_data: Словарь с данными выплаты
        rules: Список правил для валидации
        
    Returns:
        dict: Результаты валидации {success: bool, errors: list}
    """
    if rules is None:
        rules = list(PayoutValidationRule)
        
    results = {
        "success": True,
        "errors": [],
        "warnings": []
    }
    
    # Получаем данные выплаты
    payout_id = payout_data.get("id")
    total_amount = float(payout_data.get("total_amount", 0))
    total_users = payout_data.get("total_users", 0)
    admin_id = payout_data.get("admin_id")
    transactions = payout_data.get("transactions", [])
    
    # Проверка общей суммы
    if PayoutValidationRule.TOTAL_AMOUNT in rules:
        if not validate_payout_amount(total_amount):
            results["success"] = False
            results["errors"].append({
                "rule": PayoutValidationRule.TOTAL_AMOUNT.value,
                "message": f"Общая сумма выплаты ({total_amount}₽) выходит за допустимые пределы (мин. {MIN_PAYOUT_AMOUNT}₽, макс. {MAX_BATCH_AMOUNT}₽)",
                "code": "INVALID_TOTAL_AMOUNT"
            })
    
    # Проверка количества пользователей
    if PayoutValidationRule.USER_COUNT in rules:
        if total_users <= 0:
            results["success"] = False
            results["errors"].append({
                "rule": PayoutValidationRule.USER_COUNT.value,
                "message": "Количество пользователей должно быть больше 0",
                "code": "INVALID_USER_COUNT"
            })
    
    # Проверка количества транзакций
    if PayoutValidationRule.TRANSACTION_COUNT in rules:
        if not transactions:
            results["success"] = False
            results["errors"].append({
                "rule": PayoutValidationRule.TRANSACTION_COUNT.value,
                "message": "Список транзакций пуст",
                "code": "EMPTY_TRANSACTION_LIST"
            })
    
    # Проверка размера пакета
    if PayoutValidationRule.BATCH_SIZE in rules and transactions:
        tx_count = len(transactions)
        if tx_count > 1000:  # Ограничим максимальное количество транзакций в одной выплате
            results["warnings"].append({
                "rule": PayoutValidationRule.BATCH_SIZE.value,
                "message": f"Большое количество транзакций ({tx_count}). Рекомендуется разбить на несколько выплат.",
                "code": "LARGE_BATCH_SIZE"
            })
    
    # Проверка прав администратора
    if PayoutValidationRule.ADMIN_PERMISSION in rules and admin_id:
        # Проверяем, является ли пользователь администратором
        from config import ADMIN_IDS
        if admin_id not in ADMIN_IDS:
            results["success"] = False
            results["errors"].append({
                "rule": PayoutValidationRule.ADMIN_PERMISSION.value,
                "message": f"Пользователь с ID {admin_id} не имеет прав администратора",
                "code": "ADMIN_PERMISSION_DENIED"
            })
    
    return results


def group_transactions_by_tier(transactions: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    """
    Группировка транзакций по тирам в зависимости от суммы
    
    Args:
        transactions: Список транзакций для группировки
        
    Returns:
        dict: Словарь с транзакциями, сгруппированными по тирам
    """
    result = {}
    
    # Инициализируем тиры
    for tier_id, tier_info in PAYMENT_TIERS.items():
        result[tier_id] = {
            "name": tier_info["name"],
            "min": tier_info["min"],
            "max": tier_info["max"],
            "transactions": []
        }
    
    # Группируем транзакции по тирам
    for tx in transactions:
        amount = float(tx.get("amount", 0))
        
        # Определяем, к какому тиру относится транзакция
        assigned = False
        for tier_id, tier_info in PAYMENT_TIERS.items():
            if tier_info["min"] <= amount <= tier_info["max"]:
                result[tier_id]["transactions"].append(tx)
                assigned = True
                break
        
        # Если не попали ни в один тир, добавляем в самый верхний
        if not assigned:
            result["tier_4"]["transactions"].append(tx)
    
    return result


def validate_transaction_group(tier_id: str, transactions: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Валидация группы транзакций перед созданием пакетной выплаты
    
    Args:
        tier_id: Идентификатор тира
        transactions: Список транзакций в группе
        
    Returns:
        dict: Результаты валидации
    """
    results = {
        "success": True,
        "tier_id": tier_id,
        "tier_name": PAYMENT_TIERS.get(tier_id, {}).get("name", "Неизвестный тир"),
        "transaction_count": len(transactions),
        "total_amount": sum(float(tx.get("amount", 0)) for tx in transactions),
        "errors": [],
        "warnings": []
    }
    
    # Проверка на пустой список
    if not transactions:
        results["success"] = False
        results["errors"].append({
            "message": "Список транзакций пуст",
            "code": "EMPTY_TRANSACTION_LIST"
        })
        return results
    
    # Проверка на соответствие тиру
    tier_info = PAYMENT_TIERS.get(tier_id)
    if not tier_info:
        results["success"] = False
        results["errors"].append({
            "message": f"Неизвестный тир: {tier_id}",
            "code": "UNKNOWN_TIER"
        })
        return results
    
    # Проверка общей суммы
    total_amount = results["total_amount"]
    if total_amount > MAX_BATCH_AMOUNT:
        results["success"] = False
        results["errors"].append({
            "message": f"Общая сумма выплаты ({total_amount}₽) превышает максимально допустимую ({MAX_BATCH_AMOUNT}₽)",
            "code": "BATCH_AMOUNT_EXCEEDED"
        })
    
    # Проверка количества транзакций
    tx_count = len(transactions)
    if tx_count > 500:  # Ограничим максимальное количество транзакций в одном пакете
        results["warnings"].append({
            "message": f"Большое количество транзакций ({tx_count}). Обработка может занять длительное время.",
            "code": "LARGE_TRANSACTION_COUNT"
        })
    
    # Проверка отдельных транзакций
    for tx in transactions:
        amount = float(tx.get("amount", 0))
        
        # Проверка на соответствие диапазону тира
        if not (tier_info["min"] <= amount <= tier_info["max"]) and tier_id != "tier_4":
            results["warnings"].append({
                "message": f"Транзакция с ID {tx.get('transaction_id', '')} имеет сумму {amount}₽, что не соответствует диапазону тира {tier_info['name']} ({tier_info['min']}₽ - {tier_info['max']}₽)",
                "code": "TRANSACTION_OUT_OF_TIER_RANGE",
                "transaction_id": tx.get("transaction_id", "")
            })
    
    return results


async def log_validation_result(session: AsyncSession, admin_id: int, validation_type: str, validation_result: Dict[str, Any], entity_id: Optional[str] = None) -> None:
    """
    Логирование результатов валидации
    
    Args:
        session: Активная сессия базы данных
        admin_id: ID администратора
        validation_type: Тип валидации (transaction, batch, payout)
        validation_result: Результаты валидации
        entity_id: ID сущности (транзакции, выплаты и т.д.)
    """
    log_entry = AdminActionLog(
        admin_id=admin_id,
        action_type=f"validate_{validation_type}",
        details=json.dumps({
            "entity_id": entity_id,
            "validation_result": validation_result,
            "timestamp": datetime.datetime.now().isoformat()
        })
    )
    session.add(log_entry)
    await session.commit()