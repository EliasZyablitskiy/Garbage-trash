#!/usr/bin/env python
# coding: utf-8

"""
Service for interacting with AI through ProxyAPI to solve math problems
"""

import logging
import json
import aiohttp
import config

logger = logging.getLogger(__name__)

# Using ProxyAPI as a proxy for OpenAI API
# ProxyAPI предоставляет доступ к GPT-4o, который недоступен напрямую из России
PROXYAPI_URL = "https://api.proxyapi.ru/openai/v1/chat/completions"

async def solve_math_problem(problem_text: str) -> str:
    """
    Solve a math problem using AI through ProxyAPI
    
    Args:
        problem_text: The math problem to solve
        
    Returns:
        str: The solution to the problem
    """
    if not config.PROXYAPI_KEY:
        raise ValueError("ProxyAPI key not found. Please set the PROXYAPI_KEY environment variable.")
    
    # Format the prompt for better results
    prompt = config.SOLUTION_PROMPT.format(problem=problem_text)
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {config.PROXYAPI_KEY}"
    }
    
    payload = {
        "model": "gpt-4o",  # Using GPT-4o through ProxyAPI
        "messages": [
            {"role": "system", "content": "You are a helpful math tutor that solves math problems step by step. Always show your work and explain your approach clearly. IMPORTANT: Use only plain text format for all math expressions. DO NOT use LaTeX format, math formatting codes or special symbols like \\[ or \\]. Do not use subscripts or superscripts. Express all math as plain text (e.g. write 'x^2' instead of 'x²', write 'a_i' instead of subscript). Use only numbers, letters, and basic symbols (+, -, *, /, =, >, <, etc.) that display correctly in plain text."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.3,
        "max_tokens": 4000
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(PROXYAPI_URL, headers=headers, json=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    solution = data["choices"][0]["message"]["content"]
                    return solution
                else:
                    error_text = await response.text()
                    logger.error(f"ProxyAPI error: {response.status} - {error_text}")
                    raise Exception(f"Failed to get solution from ProxyAPI: {response.status}")
    except Exception as e:
        logger.error(f"Error calling ProxyAPI: {e}")
        raise Exception(f"Failed to get solution: {e}")
