#!/usr/bin/env python
# coding: utf-8

"""
Веб-интерфейс администратора для бота Катюша
Включает авторизацию через Telegram Login Widget и административную панель
"""

import os
import time
import json
import hmac
import hashlib
import logging
from urllib.parse import urlparse, parse_qs
from functools import wraps
from datetime import datetime, timedelta

from flask import Blueprint, render_template, render_template_string, request, redirect, url_for, session, flash, abort, jsonify, g
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func, desc, asc, or_, and_
import asyncio

import config
from db_models import User, Transaction, WeeklyPayout, AdminActionLog, SubscriptionAuditLog
from db_config import db
from services.notification_service import log_admin_action
from services.payout_monitoring_service import PayoutMonitoringService, ReportFormat
from services.admin_roles import has_role_permission, get_admin_role, get_admin_permitted_actions
from services.subscription_service import synchronize_all_subscriptions, process_expiring_subscriptions, is_subscription_active
# Импортируем функции для генерации отчетов
from services.reporting_service import generate_report_pdf, generate_report_excel, generate_report_json
# Импортируем функцию для получения сервиса отчетов
from services.scheduled_reports_service import get_scheduled_reports_service

logger = logging.getLogger(__name__)

# Создаем Blueprint для маршрутов веб-интерфейса администратора
admin_web = Blueprint('admin_blueprint', __name__, url_prefix='/admin')

# Контекстный процессор для добавления общих переменных в шаблоны
@admin_web.context_processor
def inject_now():
    """
    Добавляет текущую дату и время в контекст шаблона
    """
    return {'now': datetime.now()}

# Контекст-процессор для добавления прав доступа во все шаблоны
@admin_web.context_processor
def inject_permitted_actions():
    """Добавляет permitted_actions во все шаблоны"""
    permitted_actions = []
    if hasattr(g, 'permitted_actions'):
        permitted_actions = g.permitted_actions
    elif 'admin_id' in session:
        permitted_actions = get_admin_permitted_actions(session['admin_id'])
    
    return {'permitted_actions': permitted_actions}

# Настройки проверки подписи данных Telegram Login Widget
def validate_telegram_data(data):
    """
    Проверяет подлинность данных, полученных от Telegram Login Widget
    
    Args:
        data: Словарь с данными от Telegram Login Widget
        
    Returns:
        bool: True если данные валидны, False в противном случае
    """
    if 'hash' not in data:
        return False
        
    bot_token = config.TELEGRAM_TOKEN
    data_check_list = []
    
    # Создаем отсортированный список параметров для проверки
    hash_value = data.pop('hash')
    for key in sorted(data.keys()):
        data_check_list.append(f"{key}={data[key]}")
    
    # Создаем строку для хеширования
    data_check_string = '\n'.join(data_check_list)
    
    # Вычисляем секретный ключ на основе токена бота
    secret_key = hashlib.sha256(bot_token.encode()).digest()
    
    # Вычисляем хеш для сравнения
    computed_hash = hmac.new(
        secret_key,
        data_check_string.encode(),
        hashlib.sha256
    ).hexdigest()
    
    # Сравниваем вычисленный хеш с полученным
    return hmac.compare_digest(computed_hash, hash_value)

def admin_required(f):
    """Декоратор, проверяющий авторизацию и права администратора"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_id' not in session:
            flash('Пожалуйста, войдите в систему через Telegram', 'warning')
            return redirect(url_for('admin_login'))
        
        admin_id = session['admin_id']
        
        # Проверяем, является ли пользователь администратором
        if admin_id not in config.ADMIN_IDS and admin_id not in config.ADDITIONAL_ADMIN_IDS:
            flash('У вас нет прав доступа к этой странице', 'danger')
            return redirect(url_for('admin_blueprint.login'))
        
        # Получаем разрешенные действия для текущего администратора
        # и добавляем их в контекст для всех шаблонов
        g.permitted_actions = get_admin_permitted_actions(admin_id)
            
        return f(*args, **kwargs)
    return decorated_function

def role_required(role_permission):
    """Декоратор, проверяющий роль администратора и наличие прав"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'admin_id' not in session:
                flash('Пожалуйста, войдите в систему через Telegram', 'warning')
                return redirect(url_for('admin_blueprint.login'))
            
            admin_id = session['admin_id']
            
            # Проверяем права доступа для роли администратора
            if not has_role_permission(admin_id, role_permission):
                flash('У вас нет прав для выполнения этого действия', 'danger')
                return redirect(url_for('admin_blueprint.dashboard'))
                
            return f(*args, **kwargs)
        return decorated_function
    return decorator

@admin_web.route('/login', methods=['GET', 'POST'])
def login():
    """Страница авторизации для администраторов - без Telegram Login Widget"""
    if request.method == 'POST':
        # Обработка данных формы входа
        admin_id_str = request.form.get('admin_id')
        password = request.form.get('password')
        
        try:
            # Проверяем формат ID администратора
            admin_id = int(admin_id_str)
            
            # Проверяем пароль (для демонстрации и разработки)
            admin_password = os.environ.get("ADMIN_PASSWORD", "admin123")
            if password == admin_password:
                # Проверяем, является ли пользователь администратором
                if admin_id in config.ADMIN_IDS or admin_id in config.ADDITIONAL_ADMIN_IDS:
                    # Получаем пользователя из базы данных (если есть)
                    user = db.session.query(User).get(admin_id)
                    
                    # Определяем имя пользователя
                    username = user.username if user and hasattr(user, 'username') else "admin"
                    first_name = user.first_name if user and hasattr(user, 'first_name') else "Администратор"
                    
                    # Сохраняем данные в сессии
                    session['admin_id'] = admin_id
                    session['admin_username'] = username
                    session['admin_first_name'] = first_name
                    session['admin_photo_url'] = None
                    
                    # Определяем роль администратора
                    admin_role = get_admin_role(admin_id)
                    # Проверяем, что роль определена, иначе используем значение по умолчанию
                    if admin_role and hasattr(admin_role, 'value'):
                        session['admin_role'] = admin_role.value
                    else:
                        session['admin_role'] = "support_admin"
                    
                    # Логируем успешный вход в систему
                    details = {
                        'username': username,
                        'login_time': datetime.now().isoformat(),
                        'method': 'web_interface_direct'
                    }
                    
                    # Асинхронный вызов через sync-wrapper для Flask
                    log_admin_action_sync(admin_id, "admin_web_login", details)
                    
                    flash('Вы успешно вошли в систему', 'success')
                    return redirect(url_for('admin_blueprint.dashboard'))
                else:
                    flash('У вас нет прав администратора', 'danger')
            else:
                flash('Неверный пароль', 'danger')
        except ValueError:
            flash('Неверный формат ID администратора', 'danger')
    
    # Готовим данные для шаблона
    default_admin_id = config.ADMIN_USER_ID
        
    # Формируем страницу входа (без использования внешнего шаблона)
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Вход в панель администратора</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h4 class="mb-0">Вход в панель администратора</h4>
                        </div>
                        <div class="card-body">
                            {% with messages = get_flashed_messages(with_categories=true) %}
                                {% if messages %}
                                    {% for category, message in messages %}
                                        <div class="alert alert-{{ category }}">{{ message }}</div>
                                    {% endfor %}
                                {% endif %}
                            {% endwith %}
                            
                            <form method="post" action="{{ url_for('admin_blueprint.login') }}">
                                <div class="mb-3">
                                    <label for="admin_id" class="form-label">ID администратора</label>
                                    <input type="text" class="form-control" id="admin_id" name="admin_id" value="{{ default_admin_id }}" required>
                                    <div class="form-text">ID администратора из config.py</div>
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">Пароль</label>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                    <div class="form-text">По умолчанию: admin123 (или значение ADMIN_PASSWORD)</div>
                                </div>
                                <button type="submit" class="btn btn-primary w-100">Войти</button>
                            </form>
                            
                            <div class="mt-4">
                                <div class="alert alert-info">
                                    <h5 class="alert-heading">Информация</h5>
                                    <p>Это простая форма входа для разработки и тестирования. В продакшн-окружении следует использовать Telegram Login Widget.</p>
                                    <hr>
                                    <p class="mb-0">Для настройки Telegram Login Widget:</p>
                                    <ol>
                                        <li>Разместите бота на хостинге с реальным доменом</li>
                                        <li>Откройте BotFather: <a href="https://t.me/BotFather" target="_blank">@BotFather</a></li>
                                        <li>Отправьте команду /mybots</li>
                                        <li>Выберите вашего бота</li>
                                        <li>Нажмите "Bot Settings"</li>
                                        <li>Выберите "Domain"</li>
                                        <li>Введите реальный домен вашего сайта без протокола</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    """
    
    # Отображаем встроенный HTML-шаблон
    try:
        return render_template_string(html, default_admin_id=default_admin_id)
    except Exception as e:
        logger.error(f"Error rendering login template: {e}")
        return f"Error: {e}. Please check server logs."

@admin_web.route('/logout')
def logout():
    """Выход из административного интерфейса"""
    if 'admin_id' in session:
        # Логируем выход из системы
        details = {
            'username': session.get('admin_username'),
            'logout_time': datetime.now().isoformat(),
            'method': 'web_interface'
        }
        
        admin_id = session['admin_id']
        log_admin_action_sync(admin_id, "admin_web_logout", details)
        
        # Очищаем сессию
        session.clear()
        flash('Вы успешно вышли из системы', 'success')
    
    return redirect(url_for('admin_blueprint.login'))

@admin_web.route('/')
@admin_required
def dashboard():
    """Главная страница административного интерфейса"""
    admin_id = session['admin_id']
    admin_role = get_admin_role(admin_id)
    permitted_actions = get_admin_permitted_actions(admin_id)
    
    # Получаем статистику для разных ролей
    stats = {}
    
    # Запрашиваем общую статистику (доступна всем администраторам)
    users_count = db.session.query(func.count(User.id)).scalar() or 0
    
    # В модели User поле для подписки называется subscription_expiry, а не subscription_end_date
    active_users_count = db.session.query(func.count(User.id)).filter(
        User.subscription_expiry >= datetime.now()
    ).scalar() or 0
    
    stats['users'] = {
        'total': users_count,
        'active_subscriptions': active_users_count,
        'conversion_rate': round(active_users_count / users_count * 100, 2) if users_count > 0 else 0
    }
    
    # Статистика для финансовых администраторов
    if 'view_financial_stats' in permitted_actions:
        # Сумма всех транзакций за последние 30 дней
        thirty_days_ago = datetime.now() - timedelta(days=30)
        total_revenue = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.type == 'subscription',
            Transaction.status == 'completed',
            Transaction.created_at >= thirty_days_ago
        ).scalar() or 0
        
        # Количество выплат в ожидании
        pending_payouts = db.session.query(func.count(WeeklyPayout.id)).filter(
            WeeklyPayout.status == 'pending'
        ).scalar() or 0
        
        stats['finance'] = {
            'total_revenue_30d': float(total_revenue),
            'pending_payouts': pending_payouts
        }
    
    # Статистика для администраторов мониторинга
    if 'view_monitoring_stats' in permitted_actions:
        # Количество активных пользователей за последние 7 дней (используем updated_at вместо last_activity_date)
        seven_days_ago = datetime.now() - timedelta(days=7)
        active_users_7d = db.session.query(func.count(User.id)).filter(
            User.updated_at >= seven_days_ago
        ).scalar() or 0
        
        # Логи действий администраторов за последние 24 часа
        one_day_ago = datetime.now() - timedelta(days=1)
        admin_actions_24h = db.session.query(func.count(AdminActionLog.id)).filter(
            AdminActionLog.timestamp >= one_day_ago
        ).scalar() or 0
        
        stats['monitoring'] = {
            'active_users_7d': active_users_7d,
            'admin_actions_24h': admin_actions_24h
        }
    
    return render_template('admin_dashboard.html', 
                          stats=stats, 
                          permitted_actions=permitted_actions,
                          admin_role=admin_role)

@admin_web.route('/users')
@admin_required
@role_required('view_users')
def users():
    """Страница управления пользователями"""
    admin_id = session['admin_id']
    permitted_actions = get_admin_permitted_actions(admin_id)
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    search = request.args.get('search', '')
    
    # Базовый запрос
    query = db.session.query(User)
    
    # Поиск по тексту
    if search:
        query = query.filter(or_(
            User.username.ilike(f'%{search}%'),
            User.first_name.ilike(f'%{search}%'),
            User.last_name.ilike(f'%{search}%')
        ))
    
    # Пагинация
    pagination = query.order_by(User.id.desc()).paginate(page=page, per_page=per_page)
    
    return render_template('admin_users.html', 
                          pagination=pagination, 
                          search=search,
                          permitted_actions=permitted_actions)

@admin_web.route('/users/<int:user_id>')
@admin_required
@role_required('view_user_details')
def user_details(user_id):
    """Страница с детальной информацией о пользователе"""
    admin_id = session['admin_id']
    permitted_actions = get_admin_permitted_actions(admin_id)
    
    user = db.session.query(User).get_or_404(user_id)
    
    # Получаем транзакции пользователя
    transactions = db.session.query(Transaction).filter(
        Transaction.user_id == user_id
    ).order_by(Transaction.created_at.desc()).limit(50).all()
    
    # Статистика пользователя
    referrals = db.session.query(User).filter(User.referrer_id == user_id).all()
    
    return render_template('admin_user_details.html', 
                          user=user,
                          transactions=transactions,
                          referrals=referrals,
                          permitted_actions=permitted_actions)

@admin_web.route('/transactions')
@admin_required
@role_required('view_transactions')
def transactions():
    """Страница управления транзакциями"""
    admin_id = session['admin_id']
    permitted_actions = get_admin_permitted_actions(admin_id)
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    transaction_type = request.args.get('type', '')
    status = request.args.get('status', '')
    
    # Базовый запрос
    query = db.session.query(Transaction)
    
    # Фильтрация по типу транзакции
    if transaction_type:
        query = query.filter(Transaction.type == transaction_type)
    
    # Фильтрация по статусу
    if status:
        query = query.filter(Transaction.status == status)
    
    # Пагинация
    pagination = query.order_by(Transaction.created_at.desc()).paginate(page=page, per_page=per_page)
    
    # Получаем типы транзакций и статусы для фильтров
    transaction_types = db.session.query(Transaction.type).distinct().all()
    transaction_statuses = db.session.query(Transaction.status).distinct().all()
    
    return render_template('admin_transactions.html', 
                          pagination=pagination,
                          transaction_type=transaction_type,
                          status=status,
                          transaction_types=[t[0] for t in transaction_types],
                          transaction_statuses=[s[0] for s in transaction_statuses],
                          permitted_actions=permitted_actions)

@admin_web.route('/payouts')
@admin_required
@role_required('view_payouts')
def payouts():
    """Страница управления выплатами"""
    admin_id = session['admin_id']
    permitted_actions = get_admin_permitted_actions(admin_id)
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    status = request.args.get('status', '')
    
    # Базовый запрос
    query = db.session.query(WeeklyPayout)
    
    # Фильтрация по статусу
    if status:
        query = query.filter(WeeklyPayout.status == status)
    
    # Пагинация
    pagination = query.order_by(WeeklyPayout.created_at.desc()).paginate(page=page, per_page=per_page)
    
    # Статистика для страницы выплат
    stats = {
        'total_payouts': db.session.query(func.count(WeeklyPayout.id)).scalar() or 0,
        'pending_payouts': db.session.query(func.count(WeeklyPayout.id)).filter(
            WeeklyPayout.status == 'pending'
        ).scalar() or 0,
        'total_amount': db.session.query(func.sum(WeeklyPayout.total_amount)).filter(
            WeeklyPayout.status == 'completed'
        ).scalar() or 0,
        'pending_amount': db.session.query(func.sum(WeeklyPayout.total_amount)).filter(
            WeeklyPayout.status == 'pending'
        ).scalar() or 0
    }
    
    # Добавляем данные для вкладки ожидающих выплат
    pending_stats = {
        'total_users': 0,
        'total_amount': 0,
        'eligible_users': 0,
        'eligible_amount': 0
    }
    
    # Добавляем минимальную сумму для выплаты
    min_payout_amount = 500  # Минимальная сумма выплаты в рублях
    
    # Данные для вкладки транзакций
    transactions = []
    transaction_status = request.args.get('transaction_status', 'all')
    transactions_current_page = 1
    transactions_total_pages = 1
    
    return render_template('admin_payouts.html', 
                          pagination=pagination,
                          status=status,
                          stats=stats,
                          pending_stats=pending_stats,
                          min_payout_amount=min_payout_amount,
                          transactions=transactions,
                          transaction_status=transaction_status,
                          transactions_current_page=transactions_current_page,
                          transactions_total_pages=transactions_total_pages,
                          permitted_actions=permitted_actions)

@admin_web.route('/reports')
@admin_required
@role_required('view_reports')
def reports():
    """Страница управления отчетами"""
    # Добавляем пустой словарь для report_schedules
    report_schedules = {
        'user_activity': {'enabled': False, 'schedule_type': 'daily'},
        'fraud': {'enabled': False, 'schedule_type': 'weekly'},
        'referral': {'enabled': False, 'schedule_type': 'monthly'},
        'payout': {'enabled': False, 'schedule_type': 'weekly'}
    }
    
    # Получаем список отчетов из базы (если они есть)
    try:
        # В будущем здесь будет логика загрузки реальных расписаний отчетов
        pass
    except Exception as e:
        logger.error(f"Error loading report schedules: {e}")
    
    # Добавляем переменные для доступных форматов отчетов
    report_formats = ['pdf', 'excel', 'json']
    period_options = [7, 14, 30, 90]
    
    return render_template('admin_reports.html',
                          report_schedules=report_schedules,
                          report_formats=report_formats,
                          period_options=period_options)

@admin_web.route('/generate_report', methods=['POST'])
@admin_required
@role_required('generate_reports')
def generate_report():
    """Генерация отчета по запросу"""
    report_type = request.form.get('report_type')
    report_format = request.form.get('report_format', 'pdf')
    period_days = int(request.form.get('period_days', 30))
    
    # Проверка валидности типа отчета
    valid_report_types = ['payout', 'fraud', 'referral', 'user_activity']
    if report_type not in valid_report_types:
        flash('Неверный тип отчета', 'danger')
        return redirect(url_for('admin_blueprint.reports'))
    
    # Определение формата отчета
    if report_format == 'pdf':
        report_format_enum = ReportFormat.PDF
    elif report_format == 'excel':
        report_format_enum = ReportFormat.EXCEL
    else:
        report_format_enum = ReportFormat.JSON
    
    # Генерация отчета
    try:
        # Асинхронный вызов через синхронный интерфейс для Flask
        service = get_scheduled_reports_service()
        report_success = service.generate_and_send_custom_report_sync(
            report_type=report_type,
            period_days=period_days,
            admin_id=session['admin_id'],
            report_format=report_format_enum
        )
        
        if report_success:
            flash('Отчет успешно сгенерирован и отправлен вам', 'success')
            
            # Логируем действие
            details = {
                'username': session.get('admin_username'),
                'report_type': report_type,
                'report_format': report_format,
                'period_days': period_days
            }
            log_admin_action_sync(session['admin_id'], "generate_report", details)
        else:
            flash('Ошибка при генерации отчета', 'danger')
    except Exception as e:
        logger.error(f"Error generating report: {e}")
        flash(f'Ошибка при генерации отчета: {str(e)}', 'danger')
    
    return redirect(url_for('admin_blueprint.reports'))

@admin_web.route('/schedule_report', methods=['POST'])
@admin_required
@role_required('schedule_reports')
def schedule_report():
    """Настройка расписания отчетов"""
    report_type = request.form.get('report_type')
    schedule_type = request.form.get('schedule_type')
    enabled = request.form.get('enabled') == 'on'
    
    try:
        # Асинхронный вызов через синхронный интерфейс для Flask
        service = get_scheduled_reports_service()
        result = service.update_report_schedule_sync(
            report_type=report_type,
            schedule_type=schedule_type,
            enabled=enabled
        )
        
        if result:
            flash('Расписание отчетов успешно обновлено', 'success')
            
            # Логируем действие
            details = {
                'username': session.get('admin_username'),
                'report_type': report_type,
                'schedule_type': schedule_type,
                'enabled': enabled
            }
            log_admin_action_sync(session['admin_id'], "update_report_schedule", details)
        else:
            flash('Ошибка при обновлении расписания отчетов', 'danger')
    except Exception as e:
        logger.error(f"Error updating report schedule: {e}")
        flash(f'Ошибка при обновлении расписания: {str(e)}', 'danger')
    
    return redirect(url_for('admin_blueprint.reports'))

@admin_web.route('/activity_log')
@admin_required
@role_required('view_activity_log')
def activity_log():
    """Страница просмотра журнала действий администраторов"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    admin_filter = request.args.get('admin_id', '')
    action_filter = request.args.get('action_type', '')
    
    # Базовый запрос
    query = db.session.query(AdminActionLog)
    
    # Фильтрация по администратору
    if admin_filter:
        query = query.filter(AdminActionLog.admin_id == int(admin_filter))
    
    # Фильтрация по типу действия
    if action_filter:
        query = query.filter(AdminActionLog.action_type == action_filter)
    
    # Пагинация
    pagination = query.order_by(AdminActionLog.timestamp.desc()).paginate(page=page, per_page=per_page)
    
    # Получаем список администраторов и типов действий для фильтров
    admins = db.session.query(AdminActionLog.admin_id, User.username).join(
        User, User.id == AdminActionLog.admin_id, isouter=True
    ).distinct().all()
    
    action_types = db.session.query(AdminActionLog.action_type).distinct().all()
    
    return render_template('admin_activity_log.html',
                          pagination=pagination,
                          admins=admins,
                          action_types=[a[0] for a in action_types],
                          admin_filter=admin_filter,
                          action_filter=action_filter)

@admin_web.route('/block_user/<int:user_id>', methods=['POST'])
@admin_required
@role_required('block_users')
def block_user(user_id):
    """Блокировка пользователя"""
    reason = request.form.get('reason', 'Заблокирован администратором')
    
    user = db.session.query(User).get_or_404(user_id)
    user.is_blocked = True
    user.block_reason = reason
    user.block_date = datetime.now()
    
    db.session.commit()
    
    # Логируем действие
    details = {
        'username': session.get('admin_username'),
        'user_id': user_id,
        'user_username': user.username,
        'reason': reason
    }
    log_admin_action_sync(session['admin_id'], "block_user", details)
    
    flash(f'Пользователь {user.username or user_id} успешно заблокирован', 'success')
    return redirect(url_for('admin_blueprint.user_details', user_id=user_id))

@admin_web.route('/unblock_user/<int:user_id>', methods=['POST'])
@admin_required
@role_required('block_users')
def unblock_user(user_id):
    """Разблокировка пользователя"""
    user = db.session.query(User).get_or_404(user_id)
    user.is_blocked = False
    user.block_reason = None
    
    db.session.commit()
    
    # Логируем действие
    details = {
        'username': session.get('admin_username'),
        'user_id': user_id,
        'user_username': user.username
    }
    log_admin_action_sync(session['admin_id'], "unblock_user", details)
    
    flash(f'Пользователь {user.username or user_id} успешно разблокирован', 'success')
    return redirect(url_for('admin_blueprint.user_details', user_id=user_id))

@admin_web.route('/process_payout/<int:payout_id>', methods=['POST'])
@admin_required
@role_required('process_payouts')
def process_payout(payout_id):
    """Обработка выплаты"""
    status = request.form.get('status')
    comment = request.form.get('comment', '')
    
    payout = db.session.query(WeeklyPayout).get_or_404(payout_id)
    payout.status = status
    payout.comment = comment
    payout.processed_at = datetime.now()
    payout.processed_by = session['admin_id']
    
    db.session.commit()
    
    # Логируем действие
    details = {
        'username': session.get('admin_username'),
        'payout_id': payout_id,
        'new_status': status,
        'comment': comment
    }
    log_admin_action_sync(session['admin_id'], "process_payout", details)
    
    flash(f'Статус выплаты #{payout_id} обновлен на {status}', 'success')
    return redirect(url_for('admin_blueprint.payouts'))

@admin_web.route('/approve_transaction/<int:transaction_id>', methods=['POST'])
@admin_required
@role_required('manage_transactions')
def approve_transaction(transaction_id):
    """Подтверждение транзакции"""
    transaction = db.session.query(Transaction).get_or_404(transaction_id)
    
    if transaction.status != 'pending':
        flash('Эта транзакция не находится в статусе ожидания', 'danger')
        return redirect(url_for('admin_blueprint.transactions'))
    
    # Обновляем статус транзакции
    transaction.status = 'completed'
    transaction.updated_at = datetime.now()
    
    # Если это транзакция оплаты подписки, обновляем подписку пользователя
    if transaction.type == 'subscription':
        user = db.session.query(User).get(transaction.user_id)
        if user:
            # Рассчитываем дату окончания подписки
            if user.subscription_expiry and user.subscription_expiry > datetime.now():
                # Продлеваем текущую подписку
                user.subscription_expiry = user.subscription_expiry + timedelta(days=30)
            else:
                # Создаем новую подписку
                user.subscription_expiry = datetime.now() + timedelta(days=30)
    
    db.session.commit()
    
    # Логируем действие
    details = {
        'username': session.get('admin_username'),
        'transaction_id': transaction_id,
        'transaction_type': transaction.type,
        'amount': str(transaction.amount),
        'user_id': transaction.user_id
    }
    log_admin_action_sync(session['admin_id'], "approve_transaction", details)
    
    flash(f'Транзакция #{transaction_id} успешно подтверждена', 'success')
    return redirect(url_for('admin_blueprint.transactions'))

@admin_web.route('/reject_transaction/<int:transaction_id>', methods=['POST'])
@admin_required
@role_required('manage_transactions')
def reject_transaction(transaction_id):
    """Отклонение транзакции"""
    transaction = db.session.query(Transaction).get_or_404(transaction_id)
    
    if transaction.status != 'pending':
        flash('Эта транзакция не находится в статусе ожидания', 'danger')
        return redirect(url_for('admin_blueprint.transactions'))
    
    # Обновляем статус транзакции
    transaction.status = 'failed'
    transaction.updated_at = datetime.now()
    transaction.note = f"{transaction.note or ''} Отклонено администратором {session.get('admin_username') or session['admin_id']}."
    
    db.session.commit()
    
    # Логируем действие
    details = {
        'username': session.get('admin_username'),
        'transaction_id': transaction_id,
        'transaction_type': transaction.type,
        'amount': str(transaction.amount),
        'user_id': transaction.user_id
    }
    log_admin_action_sync(session['admin_id'], "reject_transaction", details)
    
    flash(f'Транзакция #{transaction_id} отклонена', 'success')
    return redirect(url_for('admin_blueprint.transactions'))

@admin_web.route('/resend_report', methods=['POST'])
@admin_required
@role_required('generate_reports')
def resend_report():
    """Повторная отправка отчета"""
    report_id = request.form.get('report_id')
    send_to = request.form.get('send_to', 'self')
    
    # Здесь будет логика повторной отправки отчета
    # В зависимости от параметра send_to отправляем либо только текущему админу, либо всем
    
    flash(f'Отчет #{report_id} отправлен повторно', 'success')
    return redirect(url_for('admin_blueprint.reports'))

@admin_web.route('/retry_report')
@admin_required
@role_required('generate_reports')
def retry_report():
    """Повторная генерация отчета"""
    report_id = request.args.get('report_id')
    
    # Здесь будет логика перезапуска генерации отчета
    
    flash(f'Генерация отчета #{report_id} запущена повторно', 'success')
    return redirect(url_for('admin_blueprint.reports'))

@admin_web.route('/api/stats/users')
@admin_required
@role_required('view_monitoring_stats')
def api_stats_users():
    """API для статистики пользователей (для графиков)"""
    days = request.args.get('days', 30, type=int)
    period_start = datetime.now() - timedelta(days=days)
    
    # Получаем данные о новых пользователях по дням
    new_users_query = db.session.query(
        func.date(User.created_at).label('date'),
        func.count(User.id).label('count')
    ).filter(
        User.created_at >= period_start
    ).group_by(
        'date'
    ).order_by(
        'date'
    ).all()
    
    # Преобразуем в формат для графика
    new_users_data = [
        {'date': str(row[0]), 'new_users': row[1]}
        for row in new_users_query
    ]
    
    return jsonify(new_users_data)

@admin_web.route('/api/stats/transactions')
@admin_required
@role_required('view_financial_stats')
def api_stats_transactions():
    """API для статистики транзакций (для графиков)"""
    days = request.args.get('days', 30, type=int)
    period_start = datetime.now() - timedelta(days=days)
    
    # Получаем данные о транзакциях по дням
    transactions_query = db.session.query(
        func.date(Transaction.created_at).label('date'),
        func.sum(Transaction.amount).label('amount')
    ).filter(
        Transaction.created_at >= period_start,
        Transaction.type == 'subscription',
        Transaction.status == 'completed'
    ).group_by(
        'date'
    ).order_by(
        'date'
    ).all()
    
    # Преобразуем в формат для графика
    transactions_data = [
        {'date': str(row[0]), 'amount': float(row[1])}
        for row in transactions_query
    ]
    
    return jsonify(transactions_data)

def log_admin_action_sync(admin_id, action, details=None):
    """
    Синхронная обертка для асинхронной функции log_admin_action
    """
    try:
        # Поучаем IP адрес и user agent если доступны
        ip_address = request.remote_addr if request and hasattr(request, 'remote_addr') else None
        user_agent = request.user_agent.string if request and hasattr(request, 'user_agent') else None
        
        # Преобразуем details в JSON строку, если это словарь
        details_json = json.dumps(details, ensure_ascii=False) if details else None
        
        # Создаем запись в базе данных
        log_entry = AdminActionLog(
            admin_id=admin_id,
            action_type=action,
            details=details_json,  # Используем поле details вместо action_data
            ip_address=ip_address,
            user_agent=user_agent,
            timestamp=datetime.now()  # Используем поле timestamp вместо created_at
        )
        db.session.add(log_entry)
        db.session.commit()
        
        logger.info(f"Admin action by {admin_id}: {action}, details: {str(details)}")
        return True
    except Exception as e:
        logger.error(f"Failed to log admin action: {e}")
        return False
        
# Маршруты для управления подписками
@admin_web.route('/subscriptions')
@admin_required
def subscriptions():
    """Страница управления подписками"""
    try:
        # Проверяем наличие результатов синхронизации в сессии
        sync_results = session.pop('sync_results', None)
        
        # Получаем последние записи из журнала аудита подписок
        recent_logs = db.session.query(SubscriptionAuditLog).order_by(
            SubscriptionAuditLog.created_at.desc()
        ).limit(50).all()
        
        # Получаем статистику по подпискам
        now = datetime.now()
        three_days_later = now + timedelta(days=3)
        
        # Получаем общее количество пользователей
        total_users = db.session.query(func.count(User.id)).scalar() or 0
        
        # Получаем количество пользователей с активными подписками
        active_subs_query = db.session.query(func.count(User.id)).filter(
            User.subscription_end.isnot(None),
            User.subscription_end > now
        ).scalar() or 0
        
        # Получаем количество пользователей с подписками, которые скоро истекут
        expiring_soon_query = db.session.query(func.count(User.id)).filter(
            User.subscription_end.isnot(None),
            User.subscription_end > now,
            User.subscription_end <= three_days_later
        ).scalar() or 0
        
        # Получаем количество пользователей с истекшими подписками
        expired_query = db.session.query(func.count(User.id)).filter(
            User.subscription_end.isnot(None),
            User.subscription_end <= now
        ).scalar() or 0
        
        # Получаем результаты последней синхронизации из сессии
        sync_results = session.get('sync_results')
        
        # Готовим данные для шаблона
        subscription_stats = {
            'total_users': total_users,
            'active': active_subs_query,
            'expiring_soon': expiring_soon_query,
            'expired': expired_query
        }
        
        return render_template('admin/subscriptions.html', 
                              recent_logs=recent_logs,
                              subscription_stats=subscription_stats,
                              sync_results=sync_results)
    except Exception as e:
        logger.error(f"Error in subscriptions page: {e}")
        flash(f'Произошла ошибка при загрузке данных: {e}', 'danger')
        return redirect(url_for('admin_blueprint.dashboard'))

@admin_web.route('/sync_subscriptions', methods=['POST'])
@admin_required
def sync_subscriptions():
    """Запускает синхронизацию полей подписки между базами данных SQL и JSON"""
    try:
        # Создаем временный экземпляр синхронизатора
        from services.subscription_synchronizer import run_one_time_sync
        from db_config import get_flask_app
        
        # Получаем Flask-приложение
        flask_app = get_flask_app()
        
        # Запускаем синхронизацию в отдельном потоке
        loop = asyncio.new_event_loop()
        processed, updated, errors = loop.run_until_complete(run_one_time_sync(flask_app))
        loop.close()
        
        # Преобразуем все значения в целые числа для безопасности
        processed = int(processed) if processed is not None else 0
        updated = int(updated) if updated is not None else 0
        errors = int(errors) if errors is not None else 0
        
        # Записываем действие администратора
        log_admin_action(
            session['admin_id'],
            'sync_subscriptions',
            {
                'processed': processed,
                'updated': updated,
                'errors': errors,
                'timestamp': datetime.now().isoformat()
            }
        )
        
        # Сохраняем результаты в сессии для отображения на странице
        session['sync_results'] = {
            'processed': processed,
            'updated': updated,
            'errors': errors,
            'expired_notifications': 0,
            'expiring_notifications': 0,
            'deactivated': 0,
            'duration_seconds': 0,
            'completed_at': datetime.now().strftime('%d.%m.%Y %H:%M:%S')
        }
        
        flash(f'Синхронизация завершена. Обработано: {processed}, обновлено: {updated}, ошибок: {errors}', 'success')
    except Exception as e:
        logger.error(f"Error in sync_subscriptions: {e}")
        flash(f'Произошла ошибка при синхронизации: {e}', 'danger')
    
    return redirect(url_for('admin_blueprint.subscriptions'))

@admin_web.route('/process_expiring_subscriptions', methods=['POST'])
@admin_required
def process_expiring_subscriptions_route():
    """Запускает обработку истекающих подписок"""
    try:
        # Получаем параметр force_update из формы
        force_update = request.form.get('force_update', '0') == '1'
        
        # Запускаем обработку в отдельном потоке
        loop = asyncio.new_event_loop()
        expired, expiring, deactivated = loop.run_until_complete(process_expiring_subscriptions(force_update))
        loop.close()
        
        # Преобразуем все значения в целые числа для безопасности
        expired = int(expired) if expired is not None else 0
        expiring = int(expiring) if expiring is not None else 0
        deactivated = int(deactivated) if deactivated is not None else 0
        
        # Записываем действие администратора
        log_admin_action(
            session['admin_id'],
            'process_expiring_subscriptions',
            {
                'force_update': force_update,
                'expired_notifications': expired,
                'expiring_notifications': expiring,
                'deactivated': deactivated,
                'timestamp': datetime.now().isoformat()
            }
        )
        
        # Сохраняем результаты в сессии для отображения на странице
        prev_results = session.get('sync_results', {})
        session['sync_results'] = {
            'processed': prev_results.get('processed', 0),
            'updated': prev_results.get('updated', 0),
            'errors': prev_results.get('errors', 0),
            'expired_notifications': expired,
            'expiring_notifications': expiring,
            'deactivated': deactivated,
            'duration_seconds': prev_results.get('duration_seconds', 0),
            'completed_at': datetime.now().strftime('%d.%m.%Y %H:%M:%S')
        }
        
        message = f'Обработка истекающих подписок завершена. '
        message += f'Отправлено уведомлений об истекших подписках: {expired}, '
        message += f'о скором истечении: {expiring}, '
        
        if force_update:
            message += f'деактивировано: {deactivated}.'
        
        flash(message, 'success')
    except Exception as e:
        logger.error(f"Error in process_expiring_subscriptions: {e}")
        flash(f'Произошла ошибка при обработке истекающих подписок: {e}', 'danger')
    
    return redirect(url_for('admin_blueprint.subscriptions'))