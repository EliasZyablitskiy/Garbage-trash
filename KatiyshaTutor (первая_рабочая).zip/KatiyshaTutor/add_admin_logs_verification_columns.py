#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для добавления колонок is_verified и verification_hash в таблицу admin_action_logs
Используются для улучшенной безопасности и проверки целостности записей
"""

import os
import sys
import logging
from sqlalchemy import Column, Boolean, String, create_engine, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Получаем DATABASE_URL из переменных окружения
DATABASE_URL = os.environ.get("DATABASE_URL")
if not DATABASE_URL:
    logger.error("DATABASE_URL environment variable not set")
    sys.exit(1)

# Создаем соединение с базой данных
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
session = Session()

def add_verification_columns():
    """
    Добавляет колонки is_verified и verification_hash в таблицу admin_action_logs
    """
    try:
        # Проверяем, существует ли уже колонка is_verified
        check_verified_query = text("SELECT column_name FROM information_schema.columns WHERE table_name = 'admin_action_logs' AND column_name = 'is_verified';")
        result_verified = session.execute(check_verified_query).fetchall()
        
        if not result_verified:
            # Добавляем колонку is_verified
            add_verified_column_query = text("ALTER TABLE admin_action_logs ADD COLUMN is_verified BOOLEAN NOT NULL DEFAULT FALSE;")
            session.execute(add_verified_column_query)
            logger.info("Колонка is_verified успешно добавлена в таблицу admin_action_logs")
        else:
            logger.info("Колонка is_verified уже существует в таблице admin_action_logs")
        
        # Проверяем, существует ли уже колонка verification_hash
        check_hash_query = text("SELECT column_name FROM information_schema.columns WHERE table_name = 'admin_action_logs' AND column_name = 'verification_hash';")
        result_hash = session.execute(check_hash_query).fetchall()
        
        if not result_hash:
            # Добавляем колонку verification_hash
            add_hash_column_query = text("ALTER TABLE admin_action_logs ADD COLUMN verification_hash VARCHAR(255);")
            session.execute(add_hash_column_query)
            logger.info("Колонка verification_hash успешно добавлена в таблицу admin_action_logs")
        else:
            logger.info("Колонка verification_hash уже существует в таблице admin_action_logs")
        
        session.commit()
        
    except Exception as e:
        session.rollback()
        logger.error(f"Ошибка при добавлении колонок: {e}")
        raise

def main():
    """
    Основная функция
    """
    try:
        add_verification_columns()
        logger.info("Миграция успешно выполнена")
    except Exception as e:
        logger.error(f"Ошибка при выполнении миграции: {e}")
        sys.exit(1)
    finally:
        session.close()

if __name__ == "__main__":
    main()