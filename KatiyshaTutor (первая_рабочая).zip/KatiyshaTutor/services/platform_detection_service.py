#!/usr/bin/env python
# coding: utf-8

"""
Сервис определения платформы клиента для адаптации функциональности бота
"""

import logging
import re
import json
from typing import Dict, Optional, Any, Union, List, Tuple
from telegram import Update
from telegram.ext import CallbackContext
from datetime import datetime

from db_models import db, UserPlatform

# Настройка логгера
logger = logging.getLogger(__name__)

# Определение констант для типов платформ
PLATFORM_IOS = "ios"
PLATFORM_ANDROID = "android"
PLATFORM_DESKTOP = "desktop"
PLATFORM_UNKNOWN = "unknown"
PLATFORM_WEB = "web"

# Версии iOS, с которыми были обнаружены проблемы
PROBLEMATIC_IOS_VERSIONS = ["13.", "14.0", "14.1", "14.2"]


class PlatformDetector:
    """Класс для определения платформы пользователя на основе данных из Telegram"""
    
    @staticmethod
    def _parse_user_agent(user_agent: str) -> Dict[str, str]:
        """
        Парсинг User-Agent строки для извлечения информации о платформе
        
        Args:
            user_agent: Строка User-Agent
            
        Returns:
            Dict[str, str]: Словарь с информацией о платформе
        """
        platform_info = {
            "platform": PLATFORM_UNKNOWN,
            "version": None,
            "device": None
        }
        
        if not user_agent:
            return platform_info
        
        # iOS паттерны
        ios_pattern = re.compile(r'(?:iPhone|iPad|iPod).*OS\s+(\d+[._]\d+)')
        ios_match = ios_pattern.search(user_agent)
        if ios_match:
            platform_info["platform"] = PLATFORM_IOS
            # Заменяем _ на . для стандартизации формата версии
            platform_info["version"] = ios_match.group(1).replace('_', '.')
            
            # Определение модели устройства
            device_pattern = re.compile(r'(iPhone|iPad|iPod)(?:\d+,\d+)?')
            device_match = device_pattern.search(user_agent)
            if device_match:
                platform_info["device"] = device_match.group(0)
            
            return platform_info
        
        # Android паттерны
        android_pattern = re.compile(r'Android\s+(\d+(?:\.\d+)+)')
        android_match = android_pattern.search(user_agent)
        if android_match:
            platform_info["platform"] = PLATFORM_ANDROID
            platform_info["version"] = android_match.group(1)
            
            # Определение модели устройства
            device_pattern = re.compile(r';\s*([^;]+(?:\s+Build|\s+MIUI|\s+\w+))')
            device_match = device_pattern.search(user_agent)
            if device_match:
                device = device_match.group(1).strip()
                # Убираем Build и другие суффиксы
                device = re.sub(r'\s+Build.*$|\s+MIUI.*$|\s+\w+$', '', device)
                platform_info["device"] = device
            
            return platform_info
        
        # Desktop паттерны (Windows, macOS, Linux)
        if re.search(r'Windows NT|Macintosh|Linux', user_agent):
            platform_info["platform"] = PLATFORM_DESKTOP
            
            if 'Windows NT' in user_agent:
                platform_info["version"] = "windows"
                version_pattern = re.compile(r'Windows NT\s+(\d+\.\d+)')
                version_match = version_pattern.search(user_agent)
                if version_match:
                    platform_info["version"] = f"windows_{version_match.group(1)}"
            elif 'Macintosh' in user_agent:
                platform_info["version"] = "macos"
                version_pattern = re.compile(r'Mac OS X\s+(\d+[._]\d+)')
                version_match = version_pattern.search(user_agent)
                if version_match:
                    platform_info["version"] = f"macos_{version_match.group(1).replace('_', '.')}"
            elif 'Linux' in user_agent:
                platform_info["version"] = "linux"
        
        # Web-клиент
        if 'Telegram Web' in user_agent or 'TelegramWebApp' in user_agent:
            platform_info["platform"] = PLATFORM_WEB
        
        return platform_info
    
    @staticmethod
    def detect_platform_from_update(update: Update) -> Dict[str, Any]:
        """
        Определяет платформу пользователя на основе данных из Update объекта Telegram
        
        Args:
            update: Объект Update из Telegram
            
        Returns:
            Dict[str, Any]: Словарь с информацией о платформе
        """
        platform_info = {
            "platform": PLATFORM_UNKNOWN,
            "version": None,
            "device": None,
            "user_agent": None,
            "has_compatibility_issues": False
        }
        
        if not update or not update.effective_user:
            return platform_info
        
        # Прямые индикаторы платформы в объекте update могут отсутствовать
        # Основное определение будет через хранимые данные или косвенные признаки
        
        # Пытаемся получить UserAgent из веб-приложения (если доступно)
        web_app_data = None
        if update.effective_message and update.effective_message.web_app_data:
            try:
                web_app_data = json.loads(update.effective_message.web_app_data.data)
                if "user_agent" in web_app_data:
                    platform_info["user_agent"] = web_app_data["user_agent"]
                    parsed_info = PlatformDetector._parse_user_agent(platform_info["user_agent"])
                    platform_info.update(parsed_info)
            except (json.JSONDecodeError, AttributeError):
                pass
        
        # Пытаемся определить по косвенным признакам в сообщении
        if update.effective_message:
            # iOS обычно отправляет фото и видео с определенными метаданными
            if update.effective_message.photo and len(update.effective_message.photo) > 0:
                # В будущем можно анализировать метаданные фото для определения платформы
                pass
            
            # Голосовые сообщения также могут содержать индикаторы платформы
            if update.effective_message.voice:
                # В будущем можно анализировать формат голосового сообщения
                pass
        
        # Проверяем, есть ли проблемы совместимости для данной платформы и версии
        if platform_info["platform"] == PLATFORM_IOS and platform_info["version"]:
            for problematic_version in PROBLEMATIC_IOS_VERSIONS:
                if platform_info["version"].startswith(problematic_version):
                    platform_info["has_compatibility_issues"] = True
                    break
        
        return platform_info


def get_platform_from_update(update: Update) -> Dict[str, Any]:
    """
    Получает информацию о платформе пользователя из объекта Update
    
    Args:
        update: Объект Update из Telegram
        
    Returns:
        Dict[str, Any]: Словарь с информацией о платформе
    """
    return PlatformDetector.detect_platform_from_update(update)


def get_user_platform(user_id: int) -> Optional[UserPlatform]:
    """
    Получает сохраненную информацию о платформе пользователя из базы данных
    
    Args:
        user_id: ID пользователя в Telegram
        
    Returns:
        Optional[UserPlatform]: Объект с информацией о платформе или None
    """
    from db_config import flask_app
    
    try:
        # Используем контекст приложения Flask
        with flask_app.app_context():
            return UserPlatform.query.filter_by(user_id=user_id).first()
    except Exception as e:
        logger.error(f"Ошибка при получении платформы пользователя {user_id}: {e}")
        return None


def store_user_platform(user_id: int, platform_info: Dict[str, Any]) -> bool:
    """
    Сохраняет информацию о платформе пользователя в базу данных
    
    Args:
        user_id: ID пользователя в Telegram
        platform_info: Словарь с информацией о платформе
        
    Returns:
        bool: True если успешно, False в случае ошибки
    """
    from db_config import flask_app
    
    try:
        # Используем контекст приложения Flask
        with flask_app.app_context():
            # Проверяем, существует ли запись для данного пользователя
            platform_record = UserPlatform.query.filter_by(user_id=user_id).first()
            
            if platform_record:
                # Обновляем существующую запись
                platform_record.platform_type = platform_info.get("platform", PLATFORM_UNKNOWN)
                platform_record.platform_version = platform_info.get("version")
                platform_record.device_model = platform_info.get("device")
                platform_record.user_agent = platform_info.get("user_agent")
            else:
                # Создаем новую запись
                platform_record = UserPlatform(
                    user_id=user_id,
                    platform_type=platform_info.get("platform", PLATFORM_UNKNOWN),
                    platform_version=platform_info.get("version"),
                    device_model=platform_info.get("device"),
                    user_agent=platform_info.get("user_agent")
                )
                db.session.add(platform_record)
            
            db.session.commit()
            return True
    except Exception as e:
        # Перехватываем и откатываем сессию в случае ошибки
        try:
            with flask_app.app_context():
                db.session.rollback()
        except:
            pass
        logger.error(f"Ошибка при сохранении платформы пользователя {user_id}: {e}")
        return False


def update_platform_detection_middleware(update: Update, context: CallbackContext) -> None:
    """
    Middleware для автоматического обновления информации о платформе пользователя
    
    Args:
        update: Объект Update из Telegram
        context: Контекст обработчика
    """
    if not update or not update.effective_user:
        return
    
    user_id = update.effective_user.id
    platform_info = get_platform_from_update(update)
    
    # Обновляем информацию о платформе только если удалось определить что-то конкретное
    if platform_info["platform"] != PLATFORM_UNKNOWN:
        store_user_platform(user_id, platform_info)
        
        # Сохраняем информацию о платформе в контексте для доступа в обработчиках
        if not context.user_data:
            context.user_data = {}
        context.user_data["platform_info"] = platform_info


def is_problematic_ios(platform_info: Dict[str, Any]) -> bool:
    """
    Проверяет, является ли платформа проблемной версией iOS
    
    Args:
        platform_info: Информация о платформе
    
    Returns:
        bool: True если это проблемная версия iOS
    """
    return (
        platform_info.get("platform") == PLATFORM_IOS and
        platform_info.get("version") and
        any(platform_info["version"].startswith(v) for v in PROBLEMATIC_IOS_VERSIONS)
    )


def get_platform_compatibility_flags(user_id: int) -> Dict[str, bool]:
    """
    Получает флаги совместимости для различных функций на основе платформы пользователя
    
    Args:
        user_id: ID пользователя
        
    Returns:
        Dict[str, bool]: Словарь с флагами совместимости для различных функций
    """
    # Значения по умолчанию для совместимости
    compatibility = {
        "supports_deepseek_model": True,
        "supports_inline_buttons": True,
        "supports_web_app": True,
        "direct_payment_compatible": True,  # Совместимость с прямыми платежами СБП
        "prefers_html_formatting": True,  # Использовать HTML вместо Markdown
        "supports_start_button": True,  # Поддерживает ли кнопку Start
        "supports_subscribe_button": True  # Поддерживает ли кнопку Subscribe
    }
    
    platform_record = get_user_platform(user_id)
    if not platform_record:
        return compatibility
    
    # Настройка флагов на основе платформы
    if platform_record.platform_type == PLATFORM_IOS:
        # Проверка версии iOS
        if platform_record.platform_version:
            version_parts = platform_record.platform_version.split('.')
            if len(version_parts) > 0:
                major_version = int(version_parts[0]) if version_parts[0].isdigit() else 0
                
                # iOS ниже 15 имеет проблемы с некоторыми моделями
                if major_version < 15:
                    compatibility["supports_deepseek_model"] = False
                
                # iOS ниже 14 имеет проблемы с веб-приложениями
                if major_version < 14:
                    compatibility["supports_web_app"] = False
                
                # Настройки прямых платежей для разных версий
                if major_version >= 15:
                    compatibility["direct_payment_method"] = "sbp_link"
                elif major_version <= 13:
                    compatibility["direct_payment_method"] = "sbp_manual"
    
    elif platform_record.platform_type == PLATFORM_ANDROID:
        # Android обычно хорошо поддерживает Markdown
        compatibility["prefers_html_formatting"] = False
        
        # Для Android настраиваем прямой метод оплаты
        compatibility["direct_payment_method"] = "sbp_link_auto"
        
        # На Android есть проблемы с кнопками "start" и "subscribe"
        compatibility["supports_start_button"] = False
        compatibility["supports_subscribe_button"] = False
    
    elif platform_record.platform_type == PLATFORM_DESKTOP:
        # Десктоп клиенты хорошо поддерживают все функции
        compatibility["direct_payment_method"] = "sbp_link_desktop"
    
    return compatibility