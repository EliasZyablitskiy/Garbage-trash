import logging
import os
from enum import Enum
from io import BytesIO
from typing import Dict, Any, Optional, List, Union, Tuple, cast

from PIL import Image
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ContextTypes, ConversationHandler, CommandHandler, MessageHandler, CallbackQueryHandler
from telegram.ext import filters

from db_models import db
from db_models import User
from keyboards import get_main_keyboard
from services.platform_detection_service import PlatformDetector, get_platform_from_update, get_user_platform, PLATFORM_UNKNOWN
from services.platform_feedback_service import PlatformFeedbackService


# Настройка логирования
logger = logging.getLogger(__name__)

# Состояния диалога для сбора отзыва
class FeedbackState(Enum):
    SELECT_FEATURE = 1
    PROVIDE_RATING = 2
    PROVIDE_FEEDBACK = 3
    ATTACH_SCREENSHOT = 4
    CONFIRM_SUBMISSION = 5


# Типы функций для отзывов
FEATURE_TYPES = {
    "ai": "🤖 Искусственный интеллект",
    "qr": "📱 QR-коды и платежи",
    "ui": "🖼 Интерфейс бота",
    "images": "🖼 Отображение изображений",
    "voice": "🎤 Распознавание голоса",
    "ocr": "📷 Распознавание текста с фото",
    "notifications": "🔔 Уведомления",
    "referrals": "👥 Реферальная система"
}

# Рейтинги
RATINGS = {
    "1": "⭐ 1 - Очень плохо",
    "2": "⭐⭐ 2 - Плохо",
    "3": "⭐⭐⭐ 3 - Нормально",
    "4": "⭐⭐⭐⭐ 4 - Хорошо",
    "5": "⭐⭐⭐⭐⭐ 5 - Отлично"
}


async def feedback_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Начинает процесс сбора отзыва о работе функций на разных платформах"""
    if update.effective_chat is None or update.effective_user is None:
        return ConversationHandler.END
    
    # Получаем информацию о пользователе и его платформе
    user_id = update.effective_user.id
    platform_info = get_platform_from_update(update)
    
    # Сохраняем информацию о платформе в контексте
    context.user_data["platform_feedback"] = {
        "user_id": user_id,
        "platform_type": platform_info.get("platform", PLATFORM_UNKNOWN),
        "platform_version": platform_info.get("version"),
        "device_info": platform_info.get("device", "")
    }
    
    # Создаем клавиатуру с типами функций
    keyboard = []
    row = []
    for i, (feature_id, feature_name) in enumerate(FEATURE_TYPES.items()):
        row.append(InlineKeyboardButton(feature_name, callback_data=f"feature_{feature_id}"))
        if (i + 1) % 2 == 0 or i == len(FEATURE_TYPES) - 1:
            keyboard.append(row)
            row = []
    
    keyboard.append([InlineKeyboardButton("❌ Отмена", callback_data="feedback_cancel")])
    
    await update.effective_message.reply_text(
        f"🔄 Помогите нам улучшить совместимость бота с разными платформами!\n\n"
        f"🔍 <b>Определена платформа:</b> {platform_info.get('platform', 'неизвестно')} "
        f"{platform_info.get('version', '')}\n\n"
        f"Выберите, о какой функции бота вы хотите оставить отзыв:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="HTML"
    )
    
    return FeedbackState.SELECT_FEATURE


async def feature_selection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Обрабатывает выбор функции и переходит к оценке"""
    query = update.callback_query
    if not query or not query.data or not context.user_data.get("platform_feedback"):
        return ConversationHandler.END
    
    await query.answer()
    
    if query.data == "feedback_cancel":
        await query.edit_message_text("❌ Отзыв отменен")
        return ConversationHandler.END
    
    feature_id = query.data.replace("feature_", "")
    if feature_id not in FEATURE_TYPES:
        await query.edit_message_text("⚠️ Ошибка: неизвестный тип функции")
        return ConversationHandler.END
    
    # Сохраняем выбранную функцию
    context.user_data["platform_feedback"]["feature_type"] = feature_id
    context.user_data["platform_feedback"]["feature_name"] = FEATURE_TYPES[feature_id]
    
    # Создаем клавиатуру с рейтингами
    keyboard = []
    for rating, label in RATINGS.items():
        keyboard.append([InlineKeyboardButton(label, callback_data=f"rating_{rating}")])
    
    keyboard.append([InlineKeyboardButton("❌ Отмена", callback_data="feedback_cancel")])
    
    await query.edit_message_text(
        f"Вы выбрали функцию: <b>{FEATURE_TYPES[feature_id]}</b>\n\n"
        f"Оцените, насколько хорошо эта функция работает на вашей платформе "
        f"({context.user_data['platform_feedback']['platform_type']} "
        f"{context.user_data['platform_feedback']['platform_version']}):",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="HTML"
    )
    
    return FeedbackState.PROVIDE_RATING


async def rating_selection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Обрабатывает выбор рейтинга и запрашивает комментарий"""
    query = update.callback_query
    if not query or not query.data or not context.user_data.get("platform_feedback"):
        return ConversationHandler.END
    
    await query.answer()
    
    if query.data == "feedback_cancel":
        await query.edit_message_text("❌ Отзыв отменен")
        return ConversationHandler.END
    
    rating = query.data.replace("rating_", "")
    if rating not in RATINGS:
        await query.edit_message_text("⚠️ Ошибка: неизвестная оценка")
        return ConversationHandler.END
    
    # Сохраняем выбранный рейтинг
    context.user_data["platform_feedback"]["rating"] = int(rating)
    
    # Клавиатура для отмены
    keyboard = [[InlineKeyboardButton("❌ Отмена", callback_data="feedback_cancel")]]
    
    await query.edit_message_text(
        f"Вы поставили оценку: <b>{RATINGS[rating]}</b>\n\n"
        f"Теперь напишите, пожалуйста, подробный отзыв о работе функции "
        f"<b>{context.user_data['platform_feedback']['feature_name']}</b> "
        f"на вашей платформе.\n\n"
        f"Что работает хорошо? Что можно улучшить? С какими проблемами вы столкнулись?",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="HTML"
    )
    
    return FeedbackState.PROVIDE_FEEDBACK


async def receive_feedback_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Получает текстовый отзыв и запрашивает скриншот"""
    if not update.message or not context.user_data.get("platform_feedback"):
        return ConversationHandler.END
    
    # Сохраняем текстовый отзыв
    context.user_data["platform_feedback"]["feedback_text"] = update.message.text
    
    # Клавиатура с опциями
    keyboard = [
        [InlineKeyboardButton("📷 Прикрепить скриншот", callback_data="attach_screenshot")],
        [InlineKeyboardButton("⏩ Пропустить", callback_data="skip_screenshot")],
        [InlineKeyboardButton("❌ Отмена", callback_data="feedback_cancel")]
    ]
    
    await update.message.reply_text(
        "Спасибо за отзыв! Вы можете также прикрепить скриншот проблемы, "
        "если у вас возникли какие-то ошибки или визуальные баги.",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
    return FeedbackState.ATTACH_SCREENSHOT


async def screenshot_option(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Обрабатывает выбор опции прикрепления скриншота"""
    query = update.callback_query
    if not query or not query.data or not context.user_data.get("platform_feedback"):
        return ConversationHandler.END
    
    await query.answer()
    
    if query.data == "feedback_cancel":
        await query.edit_message_text("❌ Отзыв отменен")
        return ConversationHandler.END
    
    if query.data == "attach_screenshot":
        await query.edit_message_text(
            "Пожалуйста, отправьте скриншот проблемы.\n\n"
            "Для отмены отправьте команду /cancel"
        )
        return FeedbackState.ATTACH_SCREENSHOT
    
    if query.data == "skip_screenshot":
        # Переходим к подтверждению без скриншота
        return await show_confirmation(update, context)
    
    return FeedbackState.ATTACH_SCREENSHOT


async def receive_screenshot(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Получает скриншот от пользователя"""
    if not update.message or not update.message.photo or not context.user_data.get("platform_feedback"):
        await update.message.reply_text("⚠️ Пожалуйста, отправьте изображение (фото)")
        return FeedbackState.ATTACH_SCREENSHOT
    
    # Получаем файл с наибольшим разрешением
    photo = update.message.photo[-1]
    photo_file = await context.bot.get_file(photo.file_id)
    
    # Скачиваем файл
    photo_bytes = BytesIO()
    await photo_file.download_to_memory(photo_bytes)
    photo_bytes.seek(0)
    
    try:
        # Сохраняем скриншот
        screenshot_path = PlatformFeedbackService.save_screenshot(
            user_id=context.user_data["platform_feedback"]["user_id"],
            image_data=photo_bytes.getvalue()
        )
        
        if screenshot_path:
            context.user_data["platform_feedback"]["screenshot_path"] = screenshot_path
            await update.message.reply_text("✅ Скриншот успешно загружен!")
        else:
            await update.message.reply_text(
                "⚠️ Произошла ошибка при сохранении скриншота. Продолжим без него."
            )
    except Exception as e:
        logger.error(f"Ошибка при обработке скриншота: {str(e)}")
        await update.message.reply_text(
            "⚠️ Произошла ошибка при обработке скриншота. Продолжим без него."
        )
    
    # Переходим к подтверждению
    return await show_confirmation(update, context)


async def show_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Показывает сводку и запрашивает подтверждение"""
    feedback_data = context.user_data.get("platform_feedback", {})
    
    if not feedback_data:
        if update.callback_query:
            await update.callback_query.edit_message_text("⚠️ Данные отзыва были потеряны. Пожалуйста, начните заново.")
        elif update.message:
            await update.message.reply_text("⚠️ Данные отзыва были потеряны. Пожалуйста, начните заново.")
        return ConversationHandler.END
    
    # Формируем сводку
    rating_text = RATINGS.get(str(feedback_data.get("rating", "")), "Не указана")
    feature_name = feedback_data.get("feature_name", "Неизвестная функция")
    platform_type = feedback_data.get("platform_type", "неизвестно")
    platform_version = feedback_data.get("platform_version", "")
    feedback_text = feedback_data.get("feedback_text", "Не указан")
    has_screenshot = "screenshot_path" in feedback_data and feedback_data["screenshot_path"] is not None
    
    summary = (
        f"📋 <b>Сводка отзыва:</b>\n\n"
        f"🔍 <b>Платформа:</b> {platform_type} {platform_version}\n"
        f"📱 <b>Функция:</b> {feature_name}\n"
        f"⭐ <b>Оценка:</b> {rating_text}\n"
        f"💬 <b>Комментарий:</b> {feedback_text}\n"
        f"📷 <b>Скриншот:</b> {'Прикреплен' if has_screenshot else 'Нет'}\n\n"
        f"Всё верно? Подтвердите отправку отзыва:"
    )
    
    # Клавиатура для подтверждения
    keyboard = [
        [InlineKeyboardButton("✅ Подтвердить", callback_data="confirm_feedback")],
        [InlineKeyboardButton("❌ Отмена", callback_data="feedback_cancel")]
    ]
    
    # Отправляем сообщение
    if update.callback_query:
        await update.callback_query.edit_message_text(
            summary,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(
            summary,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="HTML"
        )
    
    return FeedbackState.CONFIRM_SUBMISSION


async def submit_feedback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Отправляет отзыв и завершает диалог"""
    query = update.callback_query
    if not query or not query.data or not context.user_data.get("platform_feedback"):
        return ConversationHandler.END
    
    await query.answer()
    
    if query.data == "feedback_cancel":
        await query.edit_message_text("❌ Отзыв отменен")
        return ConversationHandler.END
    
    if query.data != "confirm_feedback":
        return FeedbackState.CONFIRM_SUBMISSION
    
    # Получаем данные отзыва
    feedback_data = context.user_data["platform_feedback"]
    
    try:
        # Сохраняем отзыв в базе данных
        success, message = PlatformFeedbackService.submit_feedback(
            user_id=feedback_data["user_id"],
            platform_type=feedback_data["platform_type"],
            platform_version=feedback_data["platform_version"],
            device_info=feedback_data["device_info"],
            feature_type=feedback_data["feature_type"],
            rating=feedback_data["rating"],
            feedback_text=feedback_data.get("feedback_text"),
            screenshot_path=feedback_data.get("screenshot_path")
        )
        
        if success:
            await query.edit_message_text(
                f"✅ Спасибо за ваш отзыв! Ваше мнение очень важно для нас.\n\n"
                f"Мы используем эти данные, чтобы сделать бота лучше для всех платформ.\n\n"
                f"{message}",
                reply_markup=get_main_keyboard()
            )
        else:
            await query.edit_message_text(
                f"⚠️ Произошла ошибка при сохранении отзыва: {message}\n\n"
                f"Пожалуйста, попробуйте позже.",
                reply_markup=get_main_keyboard()
            )
    except Exception as e:
        logger.error(f"Ошибка при отправке отзыва: {str(e)}")
        await query.edit_message_text(
            f"⚠️ Произошла неожиданная ошибка при сохранении отзыва.\n\n"
            f"Подробности: {str(e)}",
            reply_markup=get_main_keyboard()
        )
    
    # Очищаем данные
    if "platform_feedback" in context.user_data:
        del context.user_data["platform_feedback"]
    
    return ConversationHandler.END


async def cancel_feedback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Отменяет процесс сбора отзыва"""
    # Очищаем данные
    if "platform_feedback" in context.user_data:
        del context.user_data["platform_feedback"]
    
    await update.message.reply_text(
        "❌ Отзыв отменен.",
        reply_markup=get_main_keyboard()
    )
    
    return ConversationHandler.END


async def my_feedback_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Показывает историю отзывов пользователя"""
    if not update.effective_user:
        return
    
    user_id = update.effective_user.id
    
    # Получаем историю отзывов
    feedbacks = PlatformFeedbackService.get_user_feedback(user_id)
    
    if not feedbacks:
        await update.message.reply_text(
            "У вас пока нет отзывов о совместимости функций бота с вашей платформой.\n\n"
            "Вы можете оставить отзыв с помощью команды /feedback.",
            reply_markup=get_main_keyboard()
        )
        return
    
    # Формируем текст с историей отзывов
    result = "📋 <b>Ваши отзывы о работе бота:</b>\n\n"
    
    for i, feedback in enumerate(feedbacks[:5], 1):
        # Получаем названия
        feature_name = FEATURE_TYPES.get(feedback.get("feature_type", ""), "Неизвестная функция")
        rating = feedback.get("rating", 0)
        rating_stars = "⭐" * rating
        timestamp = feedback.get("timestamp", "")
        is_resolved = "✅ Решено" if feedback.get("is_resolved") else "⏳ В обработке"
        admin_notes = feedback.get("admin_notes", "")
        
        result += (
            f"<b>{i}. {feature_name}</b> на {feedback.get('platform_type', '')} "
            f"{feedback.get('platform_version', '')}\n"
            f"⭐ <b>Оценка:</b> {rating_stars} ({rating}/5)\n"
            f"🕐 <b>Дата:</b> {timestamp}\n"
            f"📊 <b>Статус:</b> {is_resolved}\n"
        )
        
        if admin_notes:
            result += f"👨‍💻 <b>Комментарий администратора:</b> {admin_notes}\n"
        
        result += "\n"
    
    if len(feedbacks) > 5:
        result += f"...и еще {len(feedbacks) - 5} отзывов\n\n"
    
    result += "Вы можете оставить новый отзыв с помощью команды /feedback."
    
    await update.message.reply_text(
        result,
        parse_mode="HTML",
        reply_markup=get_main_keyboard()
    )


def get_feedback_handlers() -> List[Union[CommandHandler, ConversationHandler]]:
    """Возвращает список обработчиков для сбора обратной связи"""
    # Создаем обработчик разговора для сбора отзыва
    feedback_conversation = ConversationHandler(
        entry_points=[CommandHandler("feedback", feedback_command)],
        states={
            FeedbackState.SELECT_FEATURE: [
                CallbackQueryHandler(feature_selection, pattern=r"^feature_|feedback_cancel$")
            ],
            FeedbackState.PROVIDE_RATING: [
                CallbackQueryHandler(rating_selection, pattern=r"^rating_|feedback_cancel$")
            ],
            FeedbackState.PROVIDE_FEEDBACK: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_feedback_text),
                CallbackQueryHandler(lambda u, c: ConversationHandler.END, pattern=r"^feedback_cancel$")
            ],
            FeedbackState.ATTACH_SCREENSHOT: [
                CallbackQueryHandler(screenshot_option, pattern=r"^attach_screenshot|skip_screenshot|feedback_cancel$"),
                MessageHandler(filters.PHOTO, receive_screenshot)
            ],
            FeedbackState.CONFIRM_SUBMISSION: [
                CallbackQueryHandler(submit_feedback, pattern=r"^confirm_feedback|feedback_cancel$")
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel_feedback)],
        name="feedback_conversation",
        persistent=False
    )
    
    # Добавляем обработчик для просмотра истории отзывов
    my_feedback_handler = CommandHandler("myfeedback", my_feedback_command)
    
    return [feedback_conversation, my_feedback_handler]