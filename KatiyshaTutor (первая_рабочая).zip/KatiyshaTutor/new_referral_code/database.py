#!/usr/bin/env python
# coding: utf-8

"""
Simple database management for user data persistence
"""

import os
import json
import logging
import datetime
from typing import Dict, List, Any, Optional, Tuple

logger = logging.getLogger(__name__)

DATABASE_PATH = "users_db.json"
TRANSACTIONS_PATH = "transactions_db.json"

def load_database() -> Dict[str, Any]:
    """
    Load the database from file or create a new one if it doesn't exist
    
    Returns:
        dict: Database with users
    """
    if os.path.exists(DATABASE_PATH):
        try:
            with open(DATABASE_PATH, 'r', encoding='utf-8') as file:
                return json.load(file)
        except json.JSONDecodeError:
            logger.error(f"Failed to decode JSON in {DATABASE_PATH}")
            return {"users": {}, "admins": []}
        except Exception as e:
            logger.error(f"Error loading database: {e}")
            return {"users": {}, "admins": []}
    else:
        return {"users": {}, "admins": []}

def save_database(db: Dict[str, Any]) -> None:
    """
    Save the database to file
    
    Args:
        db: Database to save
    """
    try:
        with open(DATABASE_PATH, 'w', encoding='utf-8') as file:
            json.dump(db, file, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Error saving database: {e}")

def get_user(user_id: int) -> Optional[Dict[str, Any]]:
    """
    Get user data from the database
    
    Args:
        user_id: Telegram user ID
        
    Returns:
        dict: User data or None if not found
    """
    db = load_database()
    user_id_str = str(user_id)  # Convert to string for JSON keys
    
    if user_id_str in db["users"]:
        return db["users"][user_id_str]
    else:
        return None
    
def get_user_by_referral_code(referral_code: str) -> Optional[int]:
    """
    Get user data from the database by referral code
    
    Args:
        referal_code: Telegram user ID
        
    Returns:
        int: User ID or None if not found
    """
    db = load_database()
    
    for user_id, user_data in db["users"].items():
        
        if user_data.get("referral_code") == referral_code:
            return user_id
    return None

def save_user(user_data: Dict[str, Any]) -> None:
    """
    Save user data to the database
    
    Args:
        user_data: User data to save (must contain 'id' key)
    """
    if "id" not in user_data:
        logger.error("Cannot save user without 'id' field")
        return
    
    user_id = str(user_data["id"])  # Convert to string for JSON keys
    db = load_database()
    
    db["users"][user_id] = user_data
    save_database(db)
    logger.debug(f"User {user_id} saved to database")

def update_user(user_id: int, user_data: Dict[str, Any]) -> None:
    """
    Update user data in the database
    
    Args:
        user_id: Telegram user ID
        user_data: Updated user data
    """
    user_id_str = str(user_id)  # Convert to string for JSON keys
    db = load_database()
    
    if user_id_str in db["users"]:
        # Ensure ID is preserved
        user_data["id"] = user_id
        db["users"][user_id_str] = user_data
        save_database(db)
        logger.debug(f"User {user_id} updated in database")
    else:
        logger.warning(f"Attempted to update non-existent user {user_id}")
        # Create user if doesn't exist
        save_user(user_data)

def update_user_subscription(user_id: int, expiry_date: str) -> None:
    """
    Update a user's subscription expiry date
    
    Args:
        user_id: Telegram user ID
        expiry_date: ISO format date string for subscription expiry
    """
    user_data = get_user(user_id)
    
    if user_data:
        user_data['subscription_expiry'] = expiry_date
        save_user(user_data)
        logger.info(f"Updated subscription for user {user_id} to {expiry_date}")
        
        # Process referral rewards when subscription is updated/renewed
        process_subscription_referral_rewards(user_id)
    else:
        logger.warning(f"Attempted to update subscription for non-existent user {user_id}")

# New functions for referral payment tracking

def load_transactions() -> Dict[str, Any]:
    """
    Load the transactions database or create a new one if it doesn't exist
    
    Returns:
        dict: Database with transactions
    """
    if os.path.exists(TRANSACTIONS_PATH):
        try:
            with open(TRANSACTIONS_PATH, 'r', encoding='utf-8') as file:
                return json.load(file)
        except json.JSONDecodeError:
            logger.error(f"Failed to decode JSON in {TRANSACTIONS_PATH}")
            return {"transactions": [], "weekly_payouts": []}
        except Exception as e:
            logger.error(f"Error loading transactions database: {e}")
            return {"transactions": [], "weekly_payouts": []}
    else:
        return {"transactions": [], "weekly_payouts": []}

def save_transactions(transactions_db: Dict[str, Any]) -> None:
    """
    Save the transactions database to file
    
    Args:
        transactions_db: Transactions database to save
    """
    try:
        with open(TRANSACTIONS_PATH, 'w', encoding='utf-8') as file:
            json.dump(transactions_db, file, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Error saving transactions database: {e}")

def add_transaction(
    transaction_type: str,
    user_id: int,
    amount: float,
    description: str,
    related_user_id: Optional[int] = None,
    status: str = "pending",
    payment_data: Optional[Dict[str, Any]] = None
) -> int:
    """
    Add a new transaction to the database
    
    Args:
        transaction_type: Type of transaction (subscription, reward, payout)
        user_id: User ID associated with the transaction
        amount: Transaction amount in rubles
        description: Transaction description
        related_user_id: Related user ID (e.g. referrer for subscription rewards)
        status: Transaction status (pending, completed, failed)
        payment_data: Additional payment data
        
    Returns:
        int: Transaction ID
    """
    transactions_db = load_transactions()
    
    # Generate transaction ID
    transaction_id = len(transactions_db["transactions"]) + 1
    
    # Create transaction record
    transaction = {
        "id": transaction_id,
        "type": transaction_type,
        "user_id": user_id,
        "amount": amount,
        "description": description,
        "related_user_id": related_user_id,
        "status": status,
        "created_at": datetime.datetime.now().isoformat(),
        "updated_at": datetime.datetime.now().isoformat(),
        "payment_data": payment_data or {}
    }
    
    # Add to transactions list
    transactions_db["transactions"].append(transaction)
    
    # Save transactions database
    save_transactions(transactions_db)
    
    logger.info(f"Added transaction {transaction_id}: {transaction_type} for user {user_id}, amount: {amount}₽")
    
    return transaction_id

def update_transaction_status(transaction_id: int, status: str, payment_data: Optional[Dict[str, Any]] = None) -> bool:
    """
    Update the status of a transaction
    
    Args:
        transaction_id: Transaction ID
        status: New status (pending, completed, failed)
        payment_data: Optional payment data to update
        
    Returns:
        bool: True if transaction was updated, False otherwise
    """
    transactions_db = load_transactions()
    
    for transaction in transactions_db["transactions"]:
        if transaction["id"] == transaction_id:
            transaction["status"] = status
            transaction["updated_at"] = datetime.datetime.now().isoformat()
            
            if payment_data:
                transaction["payment_data"].update(payment_data)
            
            save_transactions(transactions_db)
            logger.info(f"Updated transaction {transaction_id} status to {status}")
            return True
    
    logger.warning(f"Attempted to update non-existent transaction {transaction_id}")
    return False

def process_subscription_referral_rewards(subscriber_id: int) -> List[int]:
    """
    Process referral rewards when a user subscribes or renews
    This function calculates rewards for up to 4 levels of referrers
    
    Args:
        subscriber_id: ID of the user who subscribed
        
    Returns:
        List[int]: List of transaction IDs created for referral rewards
    """
    SUBSCRIPTION_AMOUNT = 199.0  # Subscription cost in rubles
    REFERRAL_RATES = {
        "level1": 0.05,  # 5% for level 1
        "level2": 0.02,  # 2% for level 2
        "level3": 0.02,  # 2% for level 3
        "level4": 0.02,  # 2% for level 4
    }
    
    transaction_ids = []
    db = load_database()
    
    user_data = get_user(subscriber_id)
    if not user_data:
        logger.warning(f"Subscriber {subscriber_id} not found in database")
        return transaction_ids
    
    # Get referrer ID
    referrer_id = user_data.get("referrer_id")
    if not referrer_id:
        # No referrer, no rewards to process
        return transaction_ids
    
    # Process level 1 referrer (direct referrer)
    level1_referrer_data = get_user(referrer_id)
    if level1_referrer_data:
        # Calculate reward amount
        level1_reward = SUBSCRIPTION_AMOUNT * REFERRAL_RATES["level1"]
        
        # Create reward transaction
        transaction_id = add_transaction(
            transaction_type="referral_reward",
            user_id=referrer_id,
            amount=level1_reward,
            description=f"Level 1 referral reward from user {subscriber_id}",
            related_user_id=subscriber_id,
            status="pending"
        )
        transaction_ids.append(transaction_id)
        
        # Process level 2 referrer
        level2_referrer_id = level1_referrer_data.get("referrer_id")
        if level2_referrer_id:
            level2_referrer_data = get_user(level2_referrer_id)
            if level2_referrer_data:
                # Calculate reward amount
                level2_reward = SUBSCRIPTION_AMOUNT * REFERRAL_RATES["level2"]
                
                # Create reward transaction
                transaction_id = add_transaction(
                    transaction_type="referral_reward",
                    user_id=level2_referrer_id,
                    amount=level2_reward,
                    description=f"Level 2 referral reward from user {subscriber_id}",
                    related_user_id=subscriber_id,
                    status="pending"
                )
                transaction_ids.append(transaction_id)
                
                # Process level 3 referrer
                level3_referrer_id = level2_referrer_data.get("referrer_id")
                if level3_referrer_id:
                    level3_referrer_data = get_user(level3_referrer_id)
                    if level3_referrer_data:
                        # Calculate reward amount
                        level3_reward = SUBSCRIPTION_AMOUNT * REFERRAL_RATES["level3"]
                        
                        # Create reward transaction
                        transaction_id = add_transaction(
                            transaction_type="referral_reward",
                            user_id=level3_referrer_id,
                            amount=level3_reward,
                            description=f"Level 3 referral reward from user {subscriber_id}",
                            related_user_id=subscriber_id,
                            status="pending"
                        )
                        transaction_ids.append(transaction_id)
                        
                        # Process level 4 referrer
                        level4_referrer_id = level3_referrer_data.get("referrer_id")
                        if level4_referrer_id:
                            level4_referrer_data = get_user(level4_referrer_id)
                            if level4_referrer_data:
                                # Calculate reward amount
                                level4_reward = SUBSCRIPTION_AMOUNT * REFERRAL_RATES["level4"]
                                
                                # Create reward transaction
                                transaction_id = add_transaction(
                                    transaction_type="referral_reward",
                                    user_id=level4_referrer_id,
                                    amount=level4_reward,
                                    description=f"Level 4 referral reward from user {subscriber_id}",
                                    related_user_id=subscriber_id,
                                    status="pending"
                                )
                                transaction_ids.append(transaction_id)
    
    return transaction_ids

def get_user_pending_rewards(user_id: int) -> float:
    """
    Get the total pending reward amount for a user
    
    Args:
        user_id: User ID
        
    Returns:
        float: Total pending reward amount
    """
    transactions_db = load_transactions()
    
    total_pending = 0.0
    
    for transaction in transactions_db["transactions"]:
        if (transaction["user_id"] == user_id and 
            transaction["type"] == "referral_reward" and 
            transaction["status"] == "pending"):
            total_pending += transaction["amount"]
    
    return total_pending

def get_user_total_rewards(user_id: int) -> Dict[str, float]:
    """
    Get statistics about a user's referral rewards
    
    Args:
        user_id: User ID
        
    Returns:
        Dict: Dictionary with statistics about rewards
    """
    transactions_db = load_transactions()
    
    stats = {
        "total_pending": 0.0,
        "total_paid": 0.0,
        "total_all_time": 0.0
    }
    
    for transaction in transactions_db["transactions"]:
        if transaction["user_id"] == user_id and transaction["type"] == "referral_reward":
            if transaction["status"] == "pending":
                stats["total_pending"] += transaction["amount"]
            elif transaction["status"] == "completed":
                stats["total_paid"] += transaction["amount"]
            
            stats["total_all_time"] += transaction["amount"]
    
    return stats

def collect_weekly_payouts() -> Tuple[int, float]:
    """
    Collect all pending referral rewards into a weekly payout batch
    
    Returns:
        Tuple[int, float]: (Number of transactions collected, Total amount)
    """
    transactions_db = load_transactions()
    
    # Get current date for the payout period
    now = datetime.datetime.now()
    period_start = (now - datetime.timedelta(days=7)).isoformat()
    period_end = now.isoformat()
    
    # Group transactions by user
    user_payouts = {}
    transaction_ids = []
    
    for transaction in transactions_db["transactions"]:
        if (transaction["type"] == "referral_reward" and 
            transaction["status"] == "pending"):
            
            user_id = transaction["user_id"]
            if user_id not in user_payouts:
                user_payouts[user_id] = {
                    "user_id": user_id,
                    "amount": 0.0,
                    "transaction_ids": []
                }
            
            user_payouts[user_id]["amount"] += transaction["amount"]
            user_payouts[user_id]["transaction_ids"].append(transaction["id"])
            transaction_ids.append(transaction["id"])
    
    # Create weekly payout record
    weekly_payout = {
        "id": len(transactions_db["weekly_payouts"]) + 1,
        "period_start": period_start,
        "period_end": period_end,
        "user_payouts": list(user_payouts.values()),
        "total_users": len(user_payouts),
        "total_amount": sum(payout["amount"] for payout in user_payouts.values()),
        "status": "pending",
        "created_at": now.isoformat()
    }
    
    transactions_db["weekly_payouts"].append(weekly_payout)
    save_transactions(transactions_db)
    
    logger.info(f"Created weekly payout batch with {len(transaction_ids)} transactions, total: {weekly_payout['total_amount']}₽")
    
    return len(transaction_ids), weekly_payout["total_amount"]

def process_payout_for_user(user_id: int) -> Tuple[float, int]:
    """
    Create a payout transaction for a specific user's pending rewards
    
    Args:
        user_id: User ID to process payout for
        
    Returns:
        Tuple[float, int]: (Payout amount, Transaction ID)
    """
    # Get pending rewards
    pending_amount = get_user_pending_rewards(user_id)
    
    if pending_amount <= 0:
        logger.info(f"No pending rewards for user {user_id}")
        return 0.0, 0
    
    # Create payout transaction
    transaction_id = add_transaction(
        transaction_type="payout",
        user_id=user_id,
        amount=pending_amount,
        description=f"Referral rewards payout",
        status="pending"
    )
    
    # Mark all pending reward transactions as processed
    transactions_db = load_transactions()
    
    for transaction in transactions_db["transactions"]:
        if (transaction["user_id"] == user_id and 
            transaction["type"] == "referral_reward" and 
            transaction["status"] == "pending"):
            transaction["status"] = "processed"
            transaction["updated_at"] = datetime.datetime.now().isoformat()
    
    save_transactions(transactions_db)
    
    logger.info(f"Created payout transaction {transaction_id} for user {user_id}, amount: {pending_amount}₽")
    
    return pending_amount, transaction_id

def is_admin(user_id: int) -> bool:
    """
    Check if a user is an admin
    
    Args:
        user_id: User ID to check
        
    Returns:
        bool: True if user is an admin, False otherwise
    """
    logger.debug(f"Проверка прав администратора для user_id={user_id}")
    
    # Проверяем, является ли пользователь супер-админом
    import config
    super_admin_id = config.ADMIN_USER_ID
    logger.debug(f"Супер-админ из конфига: {super_admin_id}")
    
    if user_id == super_admin_id:
        logger.debug(f"user_id={user_id} является супер-админом")
        return True
    
    # Проверяем, есть ли пользователь в списке админов
    db = load_database()
    admins = db.get("admins", [])
    logger.debug(f"Список администраторов в базе: {admins}")
    
    # Преобразуем ID пользователя в строку для сравнения, если в базе хранятся строковые ID
    str_user_id = str(user_id)
    
    # Проверяем оба варианта - и числовой, и строковый
    is_admin_result = user_id in admins or str_user_id in admins
    logger.debug(f"Результат проверки прав администратора для user_id={user_id}: {is_admin_result}")
    
    return is_admin_result

def add_admin(user_id: int) -> bool:
    """
    Add a user to the admin list
    
    Args:
        user_id: User ID to add as admin
        
    Returns:
        bool: True if user was added, False if already an admin
    """
    db = load_database()
    
    if "admins" not in db:
        db["admins"] = []
    
    if user_id not in db["admins"]:
        db["admins"].append(user_id)
        save_database(db)
        logger.info(f"Added user {user_id} as admin")
        return True
    
    return False

def remove_admin(user_id: int) -> bool:
    """
    Remove a user from the admin list
    
    Args:
        user_id: User ID to remove from admin
        
    Returns:
        bool: True if user was removed, False if not an admin
    """
    db = load_database()
    
    if "admins" not in db:
        return False
    
    if user_id in db["admins"]:
        db["admins"].remove(user_id)
        save_database(db)
        logger.info(f"Removed user {user_id} from admin list")
        return True
    
    return False

def get_subscription_stats(period_days: int = 7) -> Dict[str, Any]:
    """
    Get subscription statistics for a given period
    
    Args:
        period_days: Number of days to look back
        
    Returns:
        Dict: Dictionary with subscription statistics
    """
    db = load_database()
    
    # Calculate cutoff date
    cutoff_date = (datetime.datetime.now() - datetime.timedelta(days=period_days)).isoformat()
    
    active_subscriptions = 0
    inactive_subscriptions = 0
    
    for user_id, user_data in db["users"].items():
        if "subscription_expiry" in user_data and user_data["subscription_expiry"]:
            try:
                expiry_date = datetime.datetime.fromisoformat(user_data["subscription_expiry"])
                if datetime.datetime.now() < expiry_date:
                    active_subscriptions += 1
                else:
                    inactive_subscriptions += 1
            except (ValueError, TypeError):
                inactive_subscriptions += 1
        else:
            inactive_subscriptions += 1
    
    # Calculate subscription revenue
    transactions_db = load_transactions()
    subscription_revenue = 0.0
    
    for transaction in transactions_db["transactions"]:
        if (transaction["type"] == "subscription" and 
            transaction["status"] == "completed" and 
            transaction["created_at"] >= cutoff_date):
            subscription_revenue += transaction["amount"]
    
    # Calculate referral payouts
    referral_payouts = 0.0
    
    for transaction in transactions_db["transactions"]:
        if (transaction["type"] == "payout" and 
            transaction["status"] == "completed" and 
            transaction["created_at"] >= cutoff_date):
            referral_payouts += transaction["amount"]
    
    # Calculate referral percentage
    referral_percentage = 0
    if subscription_revenue > 0:
        referral_percentage = (referral_payouts / subscription_revenue) * 100
    
    return {
        "active_subscriptions": active_subscriptions,
        "inactive_subscriptions": inactive_subscriptions,
        "subscription_revenue": subscription_revenue,
        "referral_payouts": referral_payouts,
        "referral_percentage": referral_percentage,
        "period_days": period_days
    }

def update_referral_rates(new_rates: Dict[str, float]) -> bool:
    """
    Update the referral rates in the config
    
    Args:
        new_rates: Dictionary with new rates (keys: level1, level2, level3, level4)
        
    Returns:
        bool: True if rates were updated, False otherwise
    """
    try:
        import config
        
        for level, rate in new_rates.items():
            if level in ["level1", "level2", "level3", "level4"]:
                setattr(config, f"REFERRAL_RATE_{level.upper()}", rate)
        
        logger.info(f"Updated referral rates: {new_rates}")
        return True
    except Exception as e:
        logger.error(f"Error updating referral rates: {e}")
        return False