#!/usr/bin/env python
# coding: utf-8

"""
Simple database management for user data persistence
"""

import json
import os
import logging
from typing import Dict, Optional, Any

logger = logging.getLogger(__name__)

# Database file path
DB_FILE = "users_db.json"

def load_database() -> Dict[str, Any]:
    """
    Load the database from file or create a new one if it doesn't exist
    
    Returns:
        dict: Database with users
    """
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except json.JSONDecodeError:
            logger.error(f"Error decoding {DB_FILE}, creating new database")
            return {"users": {}}
    else:
        return {"users": {}}

def save_database(db: Dict[str, Any]) -> None:
    """
    Save the database to file
    
    Args:
        db: Database to save
    """
    try:
        with open(DB_FILE, "w", encoding="utf-8") as f:
            json.dump(db, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Error saving database: {e}")

def get_user(user_id: int) -> Optional[Dict[str, Any]]:
    """
    Get user data from the database
    
    Args:
        user_id: Telegram user ID
        
    Returns:
        dict: User data or None if not found
    """
    db = load_database()
    return db["users"].get(str(user_id))

def save_user(user_data: Dict[str, Any]) -> None:
    """
    Save user data to the database
    
    Args:
        user_data: User data to save (must contain 'id' key)
    """
    db = load_database()
    user_id = str(user_data["id"])
    db["users"][user_id] = user_data
    save_database(db)

def update_user_subscription(user_id: int, expiry_date: str) -> None:
    """
    Update a user's subscription expiry date
    
    Args:
        user_id: Telegram user ID
        expiry_date: ISO format date string for subscription expiry
    """
    user_data = get_user(user_id)
    if user_data:
        user_data["subscription_expiry"] = expiry_date
        save_user(user_data)
