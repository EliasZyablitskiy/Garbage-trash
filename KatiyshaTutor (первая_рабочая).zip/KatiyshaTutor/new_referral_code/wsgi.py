#!/usr/bin/env python
# coding: utf-8

"""
WSGI entry point для Flask-приложения
"""

from webhook_handler import app

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)