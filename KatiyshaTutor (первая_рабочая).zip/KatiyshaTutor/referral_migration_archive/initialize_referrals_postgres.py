#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для инициализации таблиц реферальной системы в PostgreSQL
"""

import logging
import sys
from datetime import datetime

from db_config import get_flask_app
from db_models import db, User, Transaction, WeeklyPayout
from new_referral_models import ReferralCode, ReferralRelation, ReferralReward

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def check_tables_exist():
    """
    Проверка существования необходимых таблиц в базе данных
    
    Returns:
        bool: True, если все таблицы существуют, False в противном случае
    """
    app = get_flask_app()
    with app.app_context():
        tables = {
            "user": False,
            "referral_code": False,
            "referral_relation": False,
            "transaction": False,
            "weekly_payout": False
        }
        
        # Проверяем каждую таблицу
        try:
            # User
            if db.session.query(User).first() is not None or db.session.query(User).count() == 0:
                tables["user"] = True
                
            # ReferralCode
            if db.session.query(ReferralCode).first() is not None or db.session.query(ReferralCode).count() == 0:
                tables["referral_code"] = True
                
            # ReferralRelation
            if db.session.query(ReferralRelation).first() is not None or db.session.query(ReferralRelation).count() == 0:
                tables["referral_relation"] = True
                
            # Transaction
            if db.session.query(Transaction).first() is not None or db.session.query(Transaction).count() == 0:
                tables["transaction"] = True
                
            # WeeklyPayout
            if db.session.query(WeeklyPayout).first() is not None or db.session.query(WeeklyPayout).count() == 0:
                tables["weekly_payout"] = True
            
            # Выводим статус проверки
            for table, exists in tables.items():
                logger.info(f"Table {table}: {'EXISTS' if exists else 'NOT FOUND'}")
            
            return all(tables.values())
        
        except Exception as e:
            logger.error(f"Error checking tables: {e}")
            return False

def create_tables():
    """
    Создание необходимых таблиц в базе данных
    
    Returns:
        bool: True, если таблицы успешно созданы, False в противном случае
    """
    app = get_flask_app()
    with app.app_context():
        try:
            # Создаем все таблицы
            db.create_all()
            logger.info("All tables created successfully")
            return True
        except Exception as e:
            logger.error(f"Error creating tables: {e}")
            return False

def initialize_metadata():
    """
    Инициализация метаданных для корректной работы реферальной системы
    """
    app = get_flask_app()
    with app.app_context():
        try:
            # Создаем основной транзакционный ключ для технического использования
            now = datetime.now()
            
            # Проверяем наличие минимального набора выплат в системе
            if WeeklyPayout.query.count() == 0:
                # Создаем первую запись о выплатах (пустой "шаблон")
                initial_payout = WeeklyPayout(
                    created_at=now,
                    start_date=now,
                    end_date=now,
                    status="template",
                    description="Initial payout template"
                )
                db.session.add(initial_payout)
                db.session.commit()
                logger.info("Initial payout template created")
            
            logger.info("Metadata initialization completed")
            return True
        except Exception as e:
            logger.error(f"Error initializing metadata: {e}")
            db.session.rollback()
            return False

def main():
    """
    Основная функция
    """
    try:
        logger.info("Checking if required tables exist")
        tables_exist = check_tables_exist()
        
        if not tables_exist:
            logger.info("Creating required tables")
            if not create_tables():
                logger.error("Failed to create tables")
                return 1
        
        logger.info("Initializing metadata")
        if not initialize_metadata():
            logger.error("Failed to initialize metadata")
            return 1
        
        logger.info("Referral system PostgreSQL initialization completed successfully!")
        return 0
    except Exception as e:
        logger.error(f"Error during initialization: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())