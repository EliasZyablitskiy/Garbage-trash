#!/usr/bin/env python3
"""
Простой скрипт для авторизации в Яндекс.Диске
"""
import os
import sys
import json
import requests
import datetime

# Простое прямое формирование ссылки без сложностей
def get_auth_url(client_id):
    """
    Формирует URL для авторизации на Яндекс.Диске
    """
    # Используем именно такой формат, который точно работает
    return f"https://oauth.yandex.ru/authorize?response_type=code&client_id={client_id}&redirect_uri=https://oauth.yandex.ru/verification_code&scope=disk:read+disk:write"

def get_token(client_id, client_secret, code):
    """
    Обменивает код авторизации на токен доступа
    """
    try:
        # URL для обмена кода на токен
        url = "https://oauth.yandex.ru/token"
        
        # Данные запроса
        data = {
            "grant_type": "authorization_code",
            "code": code,
            "client_id": client_id,
            "client_secret": client_secret,
            "redirect_uri": "https://oauth.yandex.ru/verification_code"
        }
        
        # Отправляем запрос
        response = requests.post(url, data=data)
        response.raise_for_status()
        
        # Получаем данные токена
        token_data = response.json()
        print("Токен успешно получен!")
        return token_data
    except Exception as e:
        print(f"Ошибка при получении токена: {e}")
        if 'response' in locals():
            print(f"Ответ сервера: {response.text}")
        return None

def save_token_to_file(token_data, filename="yandex_token.json"):
    """
    Сохраняет токен в файл
    """
    try:
        with open(filename, "w") as f:
            json.dump(token_data, f, indent=4)
        print(f"Токен сохранен в файл: {filename}")
        return True
    except Exception as e:
        print(f"Ошибка при сохранении токена в файл: {e}")
        return False

def save_token_to_database(token_data):
    """
    Сохраняет токен в базу данных
    """
    try:
        from db_models import db, YandexDiskToken
        from db_config import get_flask_app
        
        app = get_flask_app()
        with app.app_context():
            # Удаляем существующие токены
            YandexDiskToken.query.delete()
            
            # Создаем новый токен
            new_token = YandexDiskToken(
                access_token=token_data.get("access_token"),
                refresh_token=token_data.get("refresh_token"),
                token_type=token_data.get("token_type", "Bearer")
            )
            
            # Устанавливаем время истечения
            expires_in = token_data.get("expires_in")
            if expires_in:
                new_token.expires_at = datetime.datetime.now() + datetime.timedelta(seconds=expires_in)
            
            db.session.add(new_token)
            db.session.commit()
            
        print("Токен успешно сохранен в базе данных")
        return True
    except ImportError:
        print("Модули для работы с базой данных не найдены. Токен сохранен только в файл.")
        return False
    except Exception as e:
        print(f"Ошибка при сохранении токена в базу данных: {e}")
        return False

def main():
    """
    Основная функция
    """
    # Получаем ID и секрет приложения из переменных окружения
    client_id = os.environ.get("YANDEX_OAUTH_CLIENT_ID")
    client_secret = os.environ.get("YANDEX_OAUTH_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        print("Ошибка: Не установлены YANDEX_OAUTH_CLIENT_ID или YANDEX_OAUTH_CLIENT_SECRET")
        return
    
    # Проверяем аргументы командной строки
    if len(sys.argv) > 1:
        # Если передан код авторизации как аргумент
        code = sys.argv[1].strip()
        print(f"Используем код авторизации: {code[:5]}...")
        
        # Обмениваем код на токен
        token_data = get_token(client_id, client_secret, code)
        if token_data:
            # Сохраняем токен
            save_token_to_file(token_data)
            save_token_to_database(token_data)
            print("\nУспешно! Теперь вы можете использовать Яндекс.Диск для бэкапов.")
    else:
        # Если код не передан, выводим ссылку для авторизации
        auth_url = get_auth_url(client_id)
        print("\n1. Перейдите по ссылке для авторизации:")
        print(f"{auth_url}")
        print("\n2. Разрешите доступ приложению и получите код авторизации.")
        print("\n3. Запустите скрипт с кодом авторизации в качестве аргумента:")
        print("   python simple_yandex_auth.py КОД_АВТОРИЗАЦИИ")

if __name__ == "__main__":
    main()