#!/usr/bin/env python
# coding: utf-8

"""
Обработчик webhook-ов от платежных систем
Регистрирует маршруты Flask для обработки уведомлений от платежных систем
"""

import os
import json
import logging
import hashlib
from functools import wraps
from datetime import datetime
from typing import Dict, Any, Tuple, Optional, List, Union
from flask import request, jsonify, Blueprint, redirect

from db_models import db, Transaction
from services.payment_verification_service_v2 import payment_verification_service_v2, PAYMENT_STATUS, PAYMENT_SYSTEMS

# Настройка логирования
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Создание обработчика для вывода в консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

# Создание файлового обработчика
import os
os.makedirs('logs', exist_ok=True)
file_handler = logging.FileHandler('logs/payment_webhooks.log')
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

# Создаем Blueprint для регистрации маршрутов
payment_webhooks_bp = Blueprint('payment_webhooks', __name__)

# Список доверенных IP-адресов для платежных систем
TRUSTED_IPS = {
    'robokassa': [
        '127.0.0.1',  # Для локального тестирования
        '185.59.216.0/24',  # Диапазон IP Robokassa
        '91.200.28.0/24'  # Альтернативный диапазон Robokassa
    ],
    'sbp': [
        '127.0.0.1',  # Для локального тестирования
        '185.71.76.0/24',  # Примерный диапазон IP СБП
        '91.198.174.0/24'  # Альтернативный диапазон СБП
    ]
}

def register_payment_webhooks(app):
    """
    Регистрация обработчиков webhook-ов от платежных систем
    
    Args:
        app: Flask-приложение
    """
    # Регистрируем Blueprint
    app.register_blueprint(payment_webhooks_bp)
    
    # Дополнительно регистрируем маршруты для страниц успеха/неудачи
    @app.route('/payment/success')
    def payment_success():
        transaction_id = request.args.get('transaction_id')
        if transaction_id:
            return redirect(f"/payment/status/{transaction_id}")
        return _get_success_page()
    
    @app.route('/payment/fail')
    def payment_fail():
        transaction_id = request.args.get('transaction_id')
        if transaction_id:
            return redirect(f"/payment/status/{transaction_id}")
        return _get_fail_page()
    
    logger.info("Зарегистрированы обработчики webhook-ов платежных систем")
    
    return app

def validate_ip(f):
    """
    Декоратор для проверки IP-адреса источника webhook
    
    Args:
        f: Функция для декорирования
        
    Returns:
        Декорированная функция
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Получаем IP-адрес клиента
        client_ip = request.remote_addr
        
        # Определяем тип платежной системы по URL
        payment_system = None
        
        if '/payment/robokassa/notification' in request.path:
            payment_system = 'robokassa'
        elif '/payment/sbp/notification' in request.path:
            payment_system = 'sbp'
        
        if not payment_system:
            logger.warning(f"Unknown payment system webhook: {request.path}")
            return jsonify({'success': False, 'message': 'Unknown payment system'}), 400
        
        # Проверяем, что IP-адрес клиента в списке доверенных
        trusted = False
        
        for ip_range in TRUSTED_IPS.get(payment_system, []):
            if '/' in ip_range:  # CIDR-нотация
                import ipaddress
                try:
                    network = ipaddress.ip_network(ip_range)
                    # Безопасное преобразование IP-адреса
                    if client_ip and str(client_ip).strip():  # проверяем что IP не пустой
                        if ipaddress.ip_address(str(client_ip)) in network:
                            trusted = True
                            break
                except Exception as e:
                    logger.error(f"Error checking IP in network: {str(e)}")
            else:  # Прямое сравнение IP
                if client_ip == ip_range:
                    trusted = True
                    break
        
        # Локальные тесты всегда проходят проверку
        if client_ip == '127.0.0.1' or client_ip == 'localhost':
            trusted = True
        
        if not trusted:
            logger.warning(f"Unauthorized IP for {payment_system} webhook: {client_ip}")
            return jsonify({'success': False, 'message': 'Unauthorized IP'}), 403
        
        # IP-адрес проверен, вызываем исходную функцию
        return f(*args, **kwargs)
    
    return decorated_function

@payment_webhooks_bp.route('/payment/robokassa/notification', methods=['POST'])
@validate_ip
def robokassa_webhook():
    """
    Обработчик webhook от Robokassa
    
    Поддерживает как старый сервис проверки платежей, так и новый (v2)
    Выбор сервиса происходит через переменную окружения USE_NEW_PAYMENT_SERVICE
    
    Returns:
        Ответ для Robokassa
    """
    try:
        # Получаем данные из запроса
        notification_data = {}
        
        # Robokassa может отправлять данные как в form-data, так и в query string
        if request.form:
            notification_data = request.form.to_dict()
        elif request.args:
            notification_data = request.args.to_dict()
        elif request.json:
            notification_data = request.json
        
        logger.info(f"Received Robokassa notification: {notification_data}")
        
        # Проверяем обязательные параметры
        if 'OutSum' not in notification_data or 'InvId' not in notification_data or 'SignatureValue' not in notification_data:
            logger.warning(f"Incomplete Robokassa notification: {notification_data}")
            return "ERROR: Incomplete notification data", 400
        
        # Импортируем здесь для избежания циклических импортов
        from services.payment_result import PaymentResult
        from services.instance_lock_service import instance_lock_service
        
        # Получаем InvId для использования в блокировке
        inv_id = notification_data.get('InvId', 'unknown')
        lock_name = f"robokassa_payment_{inv_id}"
        
        # Пытаемся получить блокировку для обработки этого платежа
        if not instance_lock_service.acquire_lock(lock_name, timeout=30):
            logger.warning(f"Payment processing already in progress for InvId={inv_id}")
            # Возвращаем успешный ответ, чтобы Robokassa не пыталась повторно отправить уведомление
            return f"OK{inv_id}"
        
        try:
            # Используем улучшенный сервис верификации платежей (v2)
            logger.info(f"Using payment verification service for InvId={inv_id}")
            
            # Проверяем уведомление через новый сервис v2
            payment_result = payment_verification_service_v2.verify_payment_unified(
                notification_data=notification_data,
                payment_system=PAYMENT_SYSTEMS['ROBOKASSA']
            )
            
            # Логируем результат проверки
            logger.info(f"Payment verification result: success={payment_result.success}, " 
                      f"code={payment_result.result_code.name if payment_result.result_code else 'None'}, "
                      f"message={payment_result.message}")
            
            if not payment_result.success:
                logger.warning(f"Failed to verify Robokassa notification: {payment_result.message}")
                return f"ERROR: {payment_result.message}", 400
            
            # Обрабатываем платеж через сервис верификации
            process_result = payment_verification_service_v2.process_payment(payment_result)
            
            # Добавляем информацию о блокировке в лог обработки
            process_result.add_log(f"Payment processed with lock: {lock_name}")
        finally:
            # Освобождаем блокировку в любом случае
            instance_lock_service.release_lock(lock_name)
            logger.debug(f"Payment lock released: {lock_name}")
        
        if not process_result.success:
            logger.error(f"Failed to process payment: {process_result.message}")
            # Всё равно возвращаем OK чтобы Robokassa не пытался отправить платеж заново
            return f"OK{notification_data['InvId']}"
        
        # Логируем успешное завершение обработки платежа
        logger.info(f"Successfully processed Robokassa payment: {notification_data['InvId']}")
        
        # Возвращаем номер инвойса в качестве подтверждения
        return f"OK{notification_data['InvId']}"
        
    except Exception as e:
        logger.error(f"Error processing Robokassa webhook: {str(e)}")
        return f"ERROR: {str(e)}", 500

@payment_webhooks_bp.route('/payment/sbp/notification', methods=['POST'])
@validate_ip
def sbp_webhook():
    """
    Обработчик webhook от СБП с улучшенной обработкой и блокировками
    
    Поддерживает как старый сервис проверки платежей, так и новый (v2)
    Выбор сервиса происходит через переменную окружения USE_NEW_PAYMENT_SERVICE
    
    Returns:
        Ответ для СБП
    """
    try:
        # Получаем данные из запроса
        notification_data = request.json or {}
        
        logger.info(f"Received SBP notification: {notification_data}")
        
        # Проверяем обязательные параметры (order_id или payment_id)
        if 'order_id' not in notification_data and 'payment_id' not in notification_data:
            logger.warning(f"Incomplete SBP notification: {notification_data}")
            return jsonify({'success': False, 'message': 'Missing order_id or payment_id'}), 400
        
        # Импортируем здесь для избежания циклических импортов
        from services.payment_result import PaymentResult
        from services.instance_lock_service import instance_lock_service
        
        # Получаем идентификатор для использования в блокировке
        payment_id = notification_data.get('payment_id', notification_data.get('order_id', 'unknown'))
        lock_name = f"sbp_payment_{payment_id}"
        
        # Пытаемся получить блокировку для обработки этого платежа
        if not instance_lock_service.acquire_lock(lock_name, timeout=30):
            logger.warning(f"Payment processing already in progress for payment_id={payment_id}")
            # Возвращаем успешный ответ, чтобы СБП не пытался повторно отправить уведомление
            return jsonify({
                'success': True,
                'message': 'Payment processing already in progress',
                'transaction_id': None
            })
        
        try:
            # Используем улучшенный сервис верификации платежей (v2)
            logger.info(f"Using payment verification service for payment_id={payment_id}")
            
            # Проверяем уведомление через сервис v2
            payment_result = payment_verification_service_v2.verify_payment_unified(
                notification_data=notification_data,
                payment_system=PAYMENT_SYSTEMS['SBP_LINK']
            )
            
            # Логируем результат проверки
            logger.info(f"Payment verification result: success={payment_result.success}, " 
                       f"code={payment_result.result_code.name if payment_result.result_code else 'None'}, "
                       f"message={payment_result.message}")
            
            if not payment_result.success:
                logger.warning(f"Failed to verify SBP notification: {payment_result.message}")
                return jsonify({'success': False, 'message': payment_result.message}), 400
            
            # Обрабатываем платеж через сервис
            process_result = payment_verification_service_v2.process_payment(payment_result)
            
            # Добавляем информацию о блокировке в лог обработки
            process_result.add_log(f"Payment processed with lock: {lock_name}")
            
            # Формируем ответ на основе результата обработки
            response = {
                'success': process_result.success,
                'message': process_result.message,
                'transaction_id': process_result.transaction_id
            }
            
            # Логируем успешное завершение обработки платежа
            logger.info(f"Successfully processed SBP payment: {payment_id}")
            
            return jsonify(response)
        finally:
            # Освобождаем блокировку в любом случае
            instance_lock_service.release_lock(lock_name)
            logger.debug(f"Payment lock released: {lock_name}")
        
    except Exception as e:
        logger.error(f"Error processing SBP webhook: {str(e)}")
        return jsonify({'success': False, 'message': str(e)}), 500

@payment_webhooks_bp.route('/payment/check/<int:transaction_id>', methods=['GET'])
def check_payment(transaction_id):
    """
    Проверка статуса платежа
    
    Args:
        transaction_id: ID транзакции
        
    Returns:
        JSON с информацией о статусе платежа
    """
    try:
        # Импортируем здесь, чтобы избежать циклических импортов
        from services.payment_processor_facade import payment_processor_facade
        
        # Проверяем статус платежа
        success, message, transaction_data = payment_processor_facade.check_payment_status(transaction_id)
        
        if not success:
            return jsonify({
                'success': False,
                'message': message
            }), 404
        
        # Возвращаем информацию о платеже
        return jsonify({
            'success': True,
            'message': message,
            'status': transaction_data.get('status', 'unknown'),
            'data': transaction_data
        })
        
    except Exception as e:
        logger.error(f"Error checking payment status: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Error checking payment status: {str(e)}"
        }), 500

def _get_success_page():
    """
    Генерация HTML-страницы успешной оплаты
    
    Returns:
        str: HTML-страница успешной оплаты
    """
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Оплата успешно выполнена</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
            }
            .success-container {
                margin-top: 30px;
                padding: 20px;
                background-color: #d4edda;
                border-radius: 10px;
            }
            h1 {
                color: #155724;
            }
            .success-icon {
                font-size: 64px;
                margin-bottom: 20px;
            }
            .success-message {
                margin: 20px 0;
                font-size: 16px;
                color: #333;
            }
            .cta-button {
                display: inline-block;
                padding: 12px 24px;
                background-color: #4a76a8;
                color: white;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                margin: 20px 0;
            }
        </style>
    </head>
    <body>
        <div class="success-container">
            <div class="success-icon">✅</div>
            <h1>Оплата успешно выполнена!</h1>
            <div class="success-message">Ваш платеж был успешно обработан. Подписка активирована.</div>
            <a href="https://t.me/Katiysha_bot" class="cta-button">Вернуться к боту</a>
        </div>
    </body>
    </html>
    """

def _get_fail_page():
    """
    Генерация HTML-страницы неудачной оплаты
    
    Returns:
        str: HTML-страница неудачной оплаты
    """
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Ошибка при обработке платежа</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
            }
            .fail-container {
                margin-top: 30px;
                padding: 20px;
                background-color: #f8d7da;
                border-radius: 10px;
            }
            h1 {
                color: #721c24;
            }
            .fail-icon {
                font-size: 64px;
                margin-bottom: 20px;
            }
            .fail-message {
                margin: 20px 0;
                font-size: 16px;
                color: #333;
            }
            .cta-button {
                display: inline-block;
                padding: 12px 24px;
                background-color: #4a76a8;
                color: white;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                margin: 20px 0;
            }
        </style>
    </head>
    <body>
        <div class="fail-container">
            <div class="fail-icon">❌</div>
            <h1>Ошибка при обработке платежа</h1>
            <div class="fail-message">К сожалению, при обработке платежа возникла ошибка. Пожалуйста, попробуйте снова или выберите другой способ оплаты.</div>
            <a href="https://t.me/Katiysha_bot" class="cta-button">Вернуться к боту</a>
        </div>
    </body>
    </html>
    """