import unittest
from unittest.mock import patch, MagicMock, Mock
import pytest
import sys
import os
import json
from datetime import datetime, timedelta

# Add the project root directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Import payment service functions
from services.payment_service import (
    generate_payment_url,
    process_payout,
    get_robokassa_signature,
    verify_robokassa_signature,
    generate_payment_signature,
    process_payment_notification,
    generate_payout_url,
    process_pending_payouts,
    mark_transaction_paid
)

# Import database functions for mocking
from database import (
    create_transaction,
    update_transaction,
    get_user_data
)

class TestPaymentService(unittest.TestCase):
    
    def setUp(self):
        """Set up test environment before each test"""
        # Create a test user
        self.test_user = {
            "id": 12345,
            "username": "testuser",
            "first_name": "Test User",
            "subscription_end": None,
            "subscription_type": None,
            "total_earned": 100.0
        }
        
        # Mock configuration
        self.robokassa_config = {
            "ROBOKASSA_MERCHANT_LOGIN": "test_merchant",
            "ROBOKASSA_MERCHANT_PASSWORD_1": "test_password1",
            "ROBOKASSA_MERCHANT_PASSWORD_2": "test_password2",
            "ROBOKASSA_TEST_MODE": True,
            "ROBOKASSA_PAYMENT_URL": "https://test.robokassa.ru/Index.aspx",
            "SUBSCRIPTION_PRICES": {
                "monthly": 100.0,
                "quarterly": 270.0,
                "annual": 960.0
            }
        }
        
        # Create mock transaction data
        self.mock_transactions = {
            "trans1": {
                "id": "trans1",
                "user_id": 12345,
                "amount": 50.0,
                "type": "referral_reward",
                "status": "pending_payout",
                "created_at": (datetime.now() - timedelta(days=7)).isoformat(),
                "updated_at": (datetime.now() - timedelta(days=7)).isoformat(),
                "description": "Referral reward for user subscription"
            },
            "trans2": {
                "id": "trans2",
                "user_id": 67890,
                "amount": 30.0,
                "type": "referral_reward",
                "status": "pending_payout",
                "created_at": (datetime.now() - timedelta(days=5)).isoformat(),
                "updated_at": (datetime.now() - timedelta(days=5)).isoformat(),
                "description": "Referral reward for user subscription"
            },
            "trans3": {
                "id": "trans3",
                "user_id": 54321,
                "amount": 100.0,
                "type": "subscription",
                "status": "completed",
                "created_at": (datetime.now() - timedelta(days=2)).isoformat(),
                "updated_at": (datetime.now() - timedelta(days=2)).isoformat(),
                "description": "Monthly subscription"
            }
        }
        
        # Create mock user data
        self.mock_users = {
            "12345": {
                "id": 12345,
                "username": "testuser",
                "first_name": "Test User",
                "wallet": "test_wallet_123",
                "total_earned": 50.0
            },
            "67890": {
                "id": 67890,
                "username": "referrer",
                "first_name": "Referrer User",
                "wallet": "test_wallet_456",
                "total_earned": 80.0
            }
        }
        
        # Mock config data
        self.mock_config = {
            "robokassa": {
                "merchant_login": "test_merchant",
                "password1": "test_password1",
                "password2": "test_password2",
                "test_mode": True
            },
            "referral_rates": {
                "level_1": 0.05,
                "level_2": 0.02,
                "level_3": 0.02,
                "level_4": 0.02
            }
        }
    
    @patch("services.payment_service.create_transaction")
    @patch("services.payment_service.get_user_data")
    @patch("services.payment_service.config")
    def test_generate_payment_url(self, mock_config, mock_get_user_data, mock_create_transaction):
        """Test generating a payment URL for a subscription"""
        # Setup mocks
        mock_config.ROBOKASSA_MERCHANT_LOGIN = self.robokassa_config["ROBOKASSA_MERCHANT_LOGIN"]
        mock_config.ROBOKASSA_MERCHANT_PASSWORD_1 = self.robokassa_config["ROBOKASSA_MERCHANT_PASSWORD_1"]
        mock_config.ROBOKASSA_TEST_MODE = self.robokassa_config["ROBOKASSA_TEST_MODE"]
        mock_config.ROBOKASSA_PAYMENT_URL = self.robokassa_config["ROBOKASSA_PAYMENT_URL"]
        mock_config.SUBSCRIPTION_PRICES = self.robokassa_config["SUBSCRIPTION_PRICES"]
        
        mock_get_user_data.return_value = self.test_user
        mock_create_transaction.return_value = "test_transaction_id"
        
        # Call the function
        result = generate_payment_url(12345, "monthly")
        
        # Assertions
        mock_get_user_data.assert_called_once_with(12345)
        mock_create_transaction.assert_called_once()
        
        # Check that the URL contains all required parameters
        assert "https://test.robokassa.ru/Index.aspx" in result
        assert "MerchantLogin=test_merchant" in result
        assert "OutSum=100.0" in result
        assert "InvId=test_transaction_id" in result
        assert "SignatureValue=" in result
        
        # If test mode is enabled, check for IsTest parameter
        assert "IsTest=1" in result
    
    @patch("services.payment_service.get_user_data")
    @patch("services.payment_service.create_transaction")
    @patch("services.payment_service.update_transaction")
    @patch("services.payment_service.requests.post")
    @patch("services.payment_service.config")
    def test_process_payout(self, mock_config, mock_post, mock_update_transaction, 
                            mock_create_transaction, mock_get_user_data):
        """Test processing a payout to a user"""
        # Setup mocks
        mock_config.ROBOKASSA_MERCHANT_LOGIN = self.robokassa_config["ROBOKASSA_MERCHANT_LOGIN"]
        mock_config.ROBOKASSA_MERCHANT_PASSWORD_1 = self.robokassa_config["ROBOKASSA_MERCHANT_PASSWORD_1"]
        mock_config.ROBOKASSA_TEST_MODE = self.robokassa_config["ROBOKASSA_TEST_MODE"]
        
        mock_get_user_data.return_value = self.test_user
        mock_create_transaction.return_value = "payout_transaction_id"
        
        # Mock the API response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"result": "success"}
        mock_post.return_value = mock_response
        
        # Call the function
        result = process_payout(12345, 50.0, "test_method", "test_details")
        
        # Assertions
        mock_get_user_data.assert_called_once_with(12345)
        mock_create_transaction.assert_called_once()
        mock_post.assert_called_once()
        mock_update_transaction.assert_called_once()
        
        # The function should return True for successful payout
        assert result is True
    
    @patch("services.payment_service.config")
    def test_get_robokassa_signature(self, mock_config):
        """Test generating a Robokassa signature"""
        # Setup mocks
        mock_config.ROBOKASSA_MERCHANT_LOGIN = self.robokassa_config["ROBOKASSA_MERCHANT_LOGIN"]
        mock_config.ROBOKASSA_MERCHANT_PASSWORD_1 = self.robokassa_config["ROBOKASSA_MERCHANT_PASSWORD_1"]
        
        # Call the function
        signature = get_robokassa_signature("100.0", "12345")
        
        # Calculate expected signature (using the same logic from the function)
        import hashlib
        expected_signature = hashlib.md5(
            f"test_merchant:100.0:12345:test_password1".encode()
        ).hexdigest()
        
        # Assertions
        assert signature == expected_signature
    
    @patch("services.payment_service.config")
    def test_verify_robokassa_signature(self, mock_config):
        """Test verifying a Robokassa signature"""
        # Setup mocks
        mock_config.ROBOKASSA_MERCHANT_PASSWORD_2 = self.robokassa_config["ROBOKASSA_MERCHANT_PASSWORD_2"]
        
        # Create a signature to verify
        import hashlib
        signature = hashlib.md5(
            f"100.0:12345:test_password2".encode()
        ).hexdigest()
        
        # Parameters as they would come from Robokassa
        params = {
            "OutSum": "100.0",
            "InvId": "12345",
            "SignatureValue": signature
        }
        
        # Call the function
        result = verify_robokassa_signature(params)
        
        # Assertions
        assert result is True
        
        # Test with an invalid signature
        params["SignatureValue"] = "invalid_signature"
        result = verify_robokassa_signature(params)
        assert result is False
    
    @patch("services.payment_service.config")
    def test_generate_payment_signature(self, mock_config):
        """Test generating a payment signature for the Robokassa form"""
        # Setup mocks
        mock_config.ROBOKASSA_MERCHANT_LOGIN = self.robokassa_config["ROBOKASSA_MERCHANT_LOGIN"]
        mock_config.ROBOKASSA_MERCHANT_PASSWORD_1 = self.robokassa_config["ROBOKASSA_MERCHANT_PASSWORD_1"]
        
        # Call the function with additional parameters
        signature = generate_payment_signature(
            "100.0", 
            "12345", 
            {"Email": "test@example.com", "Description": "Test payment"}
        )
        
        # Calculate expected signature with additional parameters
        import hashlib
        expected_signature = hashlib.md5(
            f"test_merchant:100.0:12345:Description=Test payment:Email=test@example.com:test_password1".encode()
        ).hexdigest().lower()
        
        # Assertions
        assert signature == expected_signature
    
    @patch('services.payment_service.database.get_transaction_data')
    @patch('services.payment_service.database.update_transaction')
    @patch('services.payment_service.config')
    @patch('services.payment_service.requests.post')
    @patch('services.payment_service.database.get_user_data')
    def test_generate_payout_url(self, mock_get_user, mock_post, mock_config, 
                                mock_update_transaction, mock_get_transaction):
        """Test generating a payout URL for a referral reward"""
        # Mock configuration
        mock_config.ROBOKASSA_MERCHANT_LOGIN = self.mock_config["robokassa"]["merchant_login"]
        mock_config.ROBOKASSA_PASSWORD1 = self.mock_config["robokassa"]["password1"]
        mock_config.ROBOKASSA_TEST_MODE = self.mock_config["robokassa"]["test_mode"]
        
        # Mock transaction data
        transaction_id = "trans1"
        mock_get_transaction.return_value = self.mock_transactions[transaction_id]
        
        # Mock user data
        user_id = 12345
        mock_get_user.return_value = self.mock_users[str(user_id)]
        
        # Mock response from Robokassa API
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"result": "success", "payoutUrl": "https://test.robokassa.ru/payout/12345"}
        mock_post.return_value = mock_response
        
        # Call the function
        result = generate_payout_url(user_id, 50.0, transaction_id)
        
        # Verify result
        self.assertEqual(result, "https://test.robokassa.ru/payout/12345")
        
        # Verify API was called with correct parameters
        mock_post.assert_called_once()
        call_args = mock_post.call_args[1]
        self.assertIn("json", call_args)
        self.assertEqual(call_args["json"]["merchantLogin"], "test_merchant")
        self.assertEqual(call_args["json"]["amount"], 50.0)
        
        # Verify transaction was updated
        mock_update_transaction.assert_called_once()
        update_args = mock_update_transaction.call_args[0]
        self.assertEqual(update_args[0], transaction_id)
        self.assertEqual(update_args[1]["status"], "processing_payout")
    
    @patch('services.payment_service.database.get_transactions_by_status')
    @patch('services.payment_service.generate_payout_url')
    @patch('services.payment_service.notify_user')
    def test_process_pending_payouts(self, mock_notify_user, mock_generate_url, mock_get_transactions):
        """Test processing pending payouts"""
        # Mock transactions data
        pending_transactions = [
            self.mock_transactions["trans1"],
            self.mock_transactions["trans2"]
        ]
        mock_get_transactions.return_value = pending_transactions
        
        # Mock generate_payout_url to return a URL
        mock_generate_url.side_effect = lambda user_id, amount, tx_id: f"https://test.robokassa.ru/payout/{tx_id}"
        
        # Call the function
        result = process_pending_payouts()
        
        # Verify correct number of payouts were processed
        self.assertEqual(len(result), 2)
        
        # Verify generate_payout_url was called for each transaction
        self.assertEqual(mock_generate_url.call_count, 2)
        
        # Verify notify_user was called for each transaction
        self.assertEqual(mock_notify_user.call_count, 2)
        
        # Verify the result structure
        for item in result:
            self.assertIn("transaction_id", item)
            self.assertIn("user_id", item)
            self.assertIn("amount", item)
            self.assertIn("payout_url", item)
    
    @patch('services.payment_service.database.get_transaction_data')
    @patch('services.payment_service.database.update_transaction')
    @patch('services.payment_service.database.get_user_data')
    @patch('services.payment_service.database.update_user_data')
    def test_mark_transaction_paid(self, mock_update_user, mock_get_user, 
                                  mock_update_transaction, mock_get_transaction):
        """Test marking a transaction as paid"""
        # Mock transaction data
        transaction_id = "trans1"
        mock_get_transaction.return_value = self.mock_transactions[transaction_id]
        
        # Mock user data
        user_id = 12345
        mock_get_user.return_value = self.mock_users[str(user_id)]
        
        # Call the function
        result = mark_transaction_paid(transaction_id)
        
        # Verify result
        self.assertTrue(result)
        
        # Verify transaction was updated
        mock_update_transaction.assert_called_once()
        update_args = mock_update_transaction.call_args[0]
        self.assertEqual(update_args[0], transaction_id)
        self.assertEqual(update_args[1]["status"], "completed")
        
        # Verify user was updated with correct total_earned
        mock_update_user.assert_called_once()
        user_update_args = mock_update_user.call_args[0]
        self.assertEqual(user_update_args[0], user_id)
        self.assertEqual(user_update_args[1]["total_earned"], 50.0)
    
    @patch('services.payment_service.database.get_transaction_data')
    @patch('services.payment_service.models.ReferralSystem.process_referral_rewards')
    @patch('services.payment_service.database.update_transaction')
    @patch('services.payment_service.config')
    def test_process_payment_notification_subscription(self, mock_config, mock_update_transaction, 
                                                     mock_process_rewards, mock_get_transaction):
        """Test processing a payment notification for subscription"""
        # Mock config
        mock_config.ROBOKASSA_PASSWORD2 = self.mock_config["robokassa"]["password2"]
        
        # Mock transaction data
        transaction_id = "trans3"
        mock_get_transaction.return_value = self.mock_transactions[transaction_id]
        
        # Create notification data
        notification_data = {
            "OutSum": "100.0",
            "InvId": transaction_id,
            "SignatureValue": "test_signature",  # This would be validated in the real function
            "UserID": "54321"
        }
        
        # Call the function with patched signature validation
        with patch('services.payment_service.verify_signature', return_value=True):
            result = process_payment_notification(notification_data)
        
        # Verify result
        self.assertTrue(result)
        
        # Verify transaction was updated
        mock_update_transaction.assert_called_once()
        update_args = mock_update_transaction.call_args[0]
        self.assertEqual(update_args[0], transaction_id)
        self.assertEqual(update_args[1]["status"], "completed")
        
        # Verify referral rewards were processed
        mock_process_rewards.assert_called_once()
        rewards_args = mock_process_rewards.call_args[0]
        self.assertEqual(rewards_args[0], 54321)  # user_id
        self.assertEqual(rewards_args[1], 100.0)  # amount

if __name__ == "__main__":
    pytest.main() 