#!/usr/bin/env python
# coding: utf-8

"""
Сервис уведомлений администраторов о критических ошибках
"""

import os
import logging
import asyncio
from logging.handlers import RotatingFileHandler
from typing import List, Optional, Union
import threading
from datetime import datetime, timedelta

# Настройка оптимизированного логирования
logger = logging.getLogger(__name__)

# Определяем уровень логирования в зависимости от среды
is_production = os.environ.get('ENVIRONMENT') == 'production'
log_level = logging.INFO if is_production else logging.DEBUG
logger.setLevel(log_level)

# Создаем обработчик для вывода в консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(log_level)

# Создаем обработчик для ротации файлов логов
log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')
os.makedirs(log_dir, exist_ok=True)
file_handler = RotatingFileHandler(
    os.path.join(log_dir, 'admin_notification.log'),
    maxBytes=10*1024*1024,  # 10 МБ
    backupCount=5
)
file_handler.setLevel(log_level)

# Определяем формат сообщений
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)

# Добавляем обработчики к логгеру
logger.addHandler(console_handler)
logger.addHandler(file_handler)

# Настройки для предотвращения спама уведомлений
DEFAULT_COOLDOWN = 3600  # 1 час между повторными уведомлениями того же типа
ERROR_HISTORY = {}  # Словарь для хранения информации о последних отправленных уведомлениях


class AdminNotifier:
    """Класс для отправки уведомлений администраторам"""
    # Переменные класса для хранения конфигурации
    _bot = None  # Экземпляр бота для отправки сообщений
    _admin_ids = []  # Список ID администраторов для уведомлений
    _initialized = False  # Флаг инициализации
    _lock = threading.Lock()  # Блокировка для потокобезопасности
    
    @classmethod
    def initialize(cls, bot, admin_ids: Optional[List[int]] = None):
        """
        Инициализация сервиса уведомлений
        
        Args:
            bot: Экземпляр бота Telegram
            admin_ids: Список ID администраторов (если None, будет использован config.ADMIN_IDS)
        """
        with cls._lock:
            if cls._initialized:
                logger.warning("AdminNotifier already initialized, skipping")
                return
                
            cls._bot = bot
            
            if admin_ids is None:
                try:
                    # Пробуем импортировать из конфигурации
                    from config import ADMIN_IDS
                    cls._admin_ids = ADMIN_IDS
                except (ImportError, AttributeError):
                    # Если не удалось, устанавливаем пустой список
                    cls._admin_ids = []
                    logger.warning("Failed to import ADMIN_IDS from config, using empty list")
            else:
                cls._admin_ids = admin_ids
                
            cls._initialized = True
            logger.info(f"AdminNotifier initialized with {len(cls._admin_ids)} admin IDs")
    
    @classmethod
    async def notify_critical_error(cls, 
                             error_message: str, 
                             error_type: str = "general", 
                             cooldown: int = DEFAULT_COOLDOWN) -> bool:
        """
        Отправляет уведомление о критической ошибке администраторам
        
        Args:
            error_message: Текст сообщения об ошибке
            error_type: Тип ошибки (для группировки и cooldown)
            cooldown: Задержка в секундах между отправкой уведомлений одного типа
            
        Returns:
            bool: True если уведомление отправлено, False в противном случае
        """
        if not cls._initialized:
            logger.error("AdminNotifier not initialized, can't send notification")
            return False
            
        if not cls._admin_ids:
            logger.warning("No admin IDs configured for notification")
            return False
            
        # Проверяем, инициализирован ли бот
        if cls._bot is None:
            logger.error("AdminNotifier bot not set, can't send notification")
            return False
            
        # Проверяем, не отправляли ли мы недавно такое же уведомление
        current_time = datetime.now()
        if error_type in ERROR_HISTORY:
            last_time = ERROR_HISTORY[error_type]["time"]
            if current_time - last_time < timedelta(seconds=cooldown):
                # Увеличиваем счетчик пропущенных уведомлений
                ERROR_HISTORY[error_type]["count"] += 1
                logger.info(f"Notification for error type '{error_type}' skipped (cooldown), count: {ERROR_HISTORY[error_type]['count']}")
                return False
                
        # Экранируем специальные символы Markdown в сообщении об ошибке
        safe_error_message = error_message[:3000]
        
        # Заменяем символы, которые могут конфликтовать с Markdown
        # Используем функцию для корректного экранирования
        def escape_markdown(text):
            # Сначала экранируем обратные слеши
            text = text.replace('\\', '\\\\')
            # Затем экранируем все остальные специальные символы
            for char in ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!']:
                text = text.replace(char, '\\' + char)
            return text
            
        safe_error_message = escape_markdown(safe_error_message)
        
        # Форматируем сообщение
        message = (
            f"⚠️ *КРИТИЧЕСКАЯ ОШИБКА* ⚠️\n\n"
            f"Тип: {error_type}\n"
            f"Время: {current_time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            f"{safe_error_message}\n"  # Используем безопасный текст ошибки без оформления кодом
        )
        
        # Если были пропущенные уведомления, добавляем информацию о них
        if error_type in ERROR_HISTORY and ERROR_HISTORY[error_type]["count"] > 0:
            message += f"\nПропущено {ERROR_HISTORY[error_type]['count']} подобных уведомлений с {ERROR_HISTORY[error_type]['time'].strftime('%H:%M:%S')}"
            
        # Обновляем историю уведомлений
        ERROR_HISTORY[error_type] = {
            "time": current_time,
            "count": 0
        }
        
        # Отправляем уведомления всем администраторам
        success = True
        for admin_id in cls._admin_ids:
            try:
                # Пробуем сначала отправить с Markdown
                try:
                    await cls._bot.send_message(
                        chat_id=admin_id,
                        text=message,
                        parse_mode="MarkdownV2"  # Используем более современную версию Markdown
                    )
                except Exception as md_error:
                    # Если не получилось с Markdown, отправляем без форматирования
                    logger.warning(f"Failed to send formatted error notification: {md_error}")
                    plain_message = (
                        f"⚠️ КРИТИЧЕСКАЯ ОШИБКА ⚠️\n\n"
                        f"Тип: {error_type}\n"
                        f"Время: {current_time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                        f"{error_message[:3000]}\n"
                    )
                    await cls._bot.send_message(
                        chat_id=admin_id,
                        text=plain_message,
                        parse_mode=None  # Без форматирования
                    )
                logger.info(f"Critical error notification sent to admin {admin_id}")
            except Exception as e:
                logger.error(f"Failed to send notification to admin {admin_id}: {e}")
                success = False
                
        return success
    
    @classmethod
    def notify_critical_error_sync(cls, 
                                error_message: str, 
                                error_type: str = "general", 
                                cooldown: int = DEFAULT_COOLDOWN) -> bool:
        """
        Синхронная версия метода для отправки уведомлений из неасинхронного кода
        
        Args:
            error_message: Текст сообщения об ошибке
            error_type: Тип ошибки (для группировки и cooldown)
            cooldown: Задержка в секундах между отправкой уведомлений одного типа
            
        Returns:
            bool: True если уведомление запланировано, False в противном случае
        """
        if not cls._initialized:
            logger.error("AdminNotifier not initialized, can't send notification")
            return False
            
        try:
            # Создаем новый event loop в текущем потоке если его нет
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
            # Запускаем асинхронный метод уведомления
            if loop.is_running():
                # Если loop уже запущен, создаем задачу
                asyncio.create_task(cls.notify_critical_error(error_message, error_type, cooldown))
                logger.debug("Created async task for admin notification")
                return True
            else:
                # Если loop не запущен, выполняем корутину
                return loop.run_until_complete(cls.notify_critical_error(error_message, error_type, cooldown))
        except Exception as e:
            logger.error(f"Failed to schedule admin notification: {e}")
            return False


# Настраиваем специальный обработчик логов для отправки критических ошибок администраторам
class AdminNotificationHandler(logging.Handler):
    """
    Обработчик логов для отправки критических ошибок администраторам
    """
    def __init__(self, level=logging.ERROR):
        super().__init__(level)
        
    def emit(self, record):
        """
        Отправляет уведомление администраторам при критической ошибке
        
        Args:
            record: Запись лога
        """
        # Отправляем только ошибки уровня ERROR и выше
        if record.levelno >= logging.ERROR:
            try:
                # Форматируем сообщение
                error_message = self.format(record)
                error_type = record.name  # Используем имя логгера как тип ошибки
                
                # Очищаем сообщение от символов форматирования и обрезаем длину
                clean_message = error_message
                if len(clean_message) > 3000:
                    clean_message = clean_message[:3000] + "..."
                
                # Отправляем уведомление с защитой от ошибок
                AdminNotifier.notify_critical_error_sync(clean_message, error_type)
            except Exception as e:
                # Оборачиваем в try-except, чтобы ошибка в уведомлении не вызвала рекурсивные уведомления
                # Используем print вместо логирования, чтобы избежать бесконечной рекурсии
                print(f"Error in admin notification handler: {e}")


def setup_admin_notifications(bot):
    """
    Настраивает сервис уведомлений администраторов
    
    Args:
        bot: Экземпляр бота Telegram
    """
    try:
        # Инициализируем сервис уведомлений
        AdminNotifier.initialize(bot)
        
        # Настраиваем перехватчик для корневого логгера
        root_logger = logging.getLogger()
        
        # Создаем обработчик для отправки критических ошибок администраторам
        admin_handler = AdminNotificationHandler(level=logging.ERROR)
        admin_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s\n%(pathname)s:%(lineno)d\n%(funcName)s\n\n%(message)s'))
        
        # Добавляем обработчик к корневому логгеру
        root_logger.addHandler(admin_handler)
        
        logger.info("Admin notification service configured")
        return True
    except Exception as e:
        logger.error(f"Failed to setup admin notifications: {e}")
        return False
        
# Вспомогательные функции для удобного использования

def notify_admins(message: str, error_type: str = "manual_notification") -> bool:
    """
    Удобная функция для отправки уведомления администраторам из любого места в коде
    
    Args:
        message: Текст сообщения
        error_type: Тип уведомления
        
    Returns:
        bool: True если уведомление запланировано, False в противном случае
    """
    return AdminNotifier.notify_critical_error_sync(message, error_type)

async def notify_admins_async(message: str, error_type: str = "manual_notification") -> bool:
    """
    Асинхронная версия функции для отправки уведомления администраторам
    
    Args:
        message: Текст сообщения
        error_type: Тип уведомления
        
    Returns:
        bool: True если уведомление отправлено, False в противном случае
    """
    return await AdminNotifier.notify_critical_error(message, error_type)