#!/usr/bin/env python
# coding: utf-8

"""
Тестовый скрипт для проверки реферальной системы
"""

import json
import datetime
import uuid
import base64
from models import User
from database import save_user, get_user, load_database

def test_referral_system():
    """
    Тестирует работу реферальной системы
    
    1. Создает тестового пользователя - пригласившего
    2. Создает код приглашения
    3. Создает тестового пользователя - приглашенного, с указанием реферера
    4. Активирует подписку приглашенного
    5. Проверяет, что в БД сохранились корректные данные рефералов
    """
    print("== Тестирование реферальной системы ==")
    
    # 1. Создаем пригласившего пользователя
    referrer_id = 999991
    referrer_user = User(
        user_id=referrer_id,
        username="test_referrer",
        first_name="Тестовый",
        last_name="Приглашающий"
    )
    
    # Генерируем реферальный код
    referrer_user.generate_referral_code()
    referral_code = referrer_user.referral_code
    print(f"Создан тестовый пригласивший пользователь с ID {referrer_id}")
    print(f"Сгенерирован реферальный код: {referral_code}")
    
    # Сохраняем пользователя в базу
    user_data = referrer_user.to_dict()
    save_user(user_data)
    print(f"Пользователь сохранен в базу данных")
    
    # 2. Создаем приглашенного пользователя
    referred_id = 999992
    referred_user = User(
        user_id=referred_id,
        username="test_referred",
        first_name="Тестовый",
        last_name="Приглашенный"
    )
    referred_user.referrer_id = referrer_id
    
    # Сохраняем приглашенного в базу
    referred_data = referred_user.to_dict()
    save_user(referred_data)
    print(f"Создан тестовый приглашенный пользователь с ID {referred_id}")
    print(f"Указан реферер с ID {referrer_id}")
    
    # 3. Обновляем реферальные данные в базе
    db = load_database()
    
    # Получаем данные пригласившего
    referrer_data = db['users'].get(str(referrer_id))
    if not referrer_data:
        print("Ошибка: реферер не найден в базе!")
        return
    
    # Добавляем приглашенного в список рефералов первого уровня
    if 'referrals' not in referrer_data:
        referrer_data['referrals'] = {
            "level1": [],
            "level2": [],
            "level3": [],
            "level4": [],
        }
    
    if not isinstance(referrer_data['referrals'].get('level1'), list):
        referrer_data['referrals']['level1'] = []
    
    referrer_data['referrals']['level1'].append(referred_id)
    save_user(referrer_data)
    print(f"Обновлены данные рефералов для пользователя {referrer_id}")
    
    # 4. Активируем подписку приглашенного
    now = datetime.datetime.now()
    expiry_date = now + datetime.timedelta(days=30)
    referred_data['subscription_expiry'] = expiry_date.isoformat()
    save_user(referred_data)
    print(f"Активирована подписка для приглашенного пользователя {referred_id}")
    
    # 5. Проверяем данные
    print("\n=== Проверка данных ===")
    db = load_database()
    
    # Проверяем данные пригласившего
    referrer_data = db['users'].get(str(referrer_id))
    if not referrer_data:
        print("Ошибка: реферер не найден в базе после обновления!")
        return
    
    print(f"Данные пригласившего {referrer_id}:")
    print(f"Реферальный код: {referrer_data.get('referral_code')}")
    print(f"Рефералы 1 уровня: {referrer_data.get('referrals', {}).get('level1', [])}")
    
    # Проверяем данные приглашенного
    referred_data = db['users'].get(str(referred_id))
    if not referred_data:
        print("Ошибка: приглашенный не найден в базе!")
        return
    
    print(f"\nДанные приглашенного {referred_id}:")
    print(f"Реферер: {referred_data.get('referrer_id')}")
    print(f"Дата окончания подписки: {referred_data.get('subscription_expiry')}")
    
    # Очистка тестовых данных
    print("\n=== Очистка тестовых данных ===")
    db = load_database()
    if str(referrer_id) in db['users']:
        del db['users'][str(referrer_id)]
        print(f"Удален тестовый пользователь {referrer_id}")
    
    if str(referred_id) in db['users']:
        del db['users'][str(referred_id)]
        print(f"Удален тестовый пользователь {referred_id}")
    
    # Сохраняем изменения в файл
    with open('users_db.json', 'w', encoding='utf-8') as f:
        json.dump(db, f, ensure_ascii=False, indent=2)
    
    print("Тестирование завершено.")

if __name__ == '__main__':
    test_referral_system()