#!/usr/bin/env python
# coding: utf-8

"""
Сервис для планирования и отправки регулярных отчетов
"""

import os
import json
import logging
import datetime
from typing import Dict, List, Any, Optional, Union, Literal
from enum import Enum

import config
from services.reporting_service import ReportingService, ReportFormat

logger = logging.getLogger(__name__)

class ScheduleType(Enum):
    """Типы расписаний для отчетов"""
    DAILY = "daily"       # Ежедневно
    WEEKLY = "weekly"     # Еженедельно
    MONTHLY = "monthly"   # Ежемесячно

class ScheduledReportsService:
    """Сервис для планирования и отправки регулярных отчетов"""
    
    _instance = None
    
    def __init__(self):
        """Инициализация сервиса"""
        self.reports_config = self._load_reports_config()
    
    @staticmethod
    def _load_reports_config() -> Dict[str, Any]:
        """
        Загрузка конфигурации отчетов из файла или создание стандартной
        
        Returns:
            Dict[str, Any]: Конфигурация отчетов
        """
        config_path = "reports_config.json"
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading reports config: {e}")
        
        # Стандартная конфигурация
        default_config = {
            "reports": {
                "payout": {
                    "schedule": "weekly",
                    "enabled": True,
                    "format": "pdf",
                    "recipients": [],
                    "next_run": datetime.datetime.now().isoformat()
                },
                "fraud": {
                    "schedule": "daily",
                    "enabled": True,
                    "format": "pdf",
                    "recipients": [],
                    "next_run": datetime.datetime.now().isoformat()
                },
                "referral": {
                    "schedule": "monthly",
                    "enabled": True,
                    "format": "excel",
                    "recipients": [],
                    "next_run": datetime.datetime.now().isoformat()
                },
                "user_activity": {
                    "schedule": "weekly",
                    "enabled": True,
                    "format": "excel",
                    "recipients": [],
                    "next_run": datetime.datetime.now().isoformat()
                }
            }
        }
        
        # Сохраняем стандартную конфигурацию
        try:
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(default_config, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Error saving default reports config: {e}")
        
        return default_config
    
    def _save_reports_config(self) -> bool:
        """
        Сохранение конфигурации отчетов в файл
        
        Returns:
            bool: True, если сохранение успешно, иначе False
        """
        config_path = "reports_config.json"
        try:
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(self.reports_config, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            logger.error(f"Error saving reports config: {e}")
            return False
    
    def update_report_schedule(self, report_type: str, schedule_type: str, enabled: bool = True) -> bool:
        """
        Обновление расписания отчета
        
        Args:
            report_type: Тип отчета
            schedule_type: Тип расписания (daily, weekly, monthly)
            enabled: Включен ли отчет
            
        Returns:
            bool: True, если обновление успешно, иначе False
        """
        if report_type not in self.reports_config.get("reports", {}):
            logger.error(f"Unknown report type: {report_type}")
            return False
        
        try:
            schedule = ScheduleType(schedule_type).value
        except ValueError:
            logger.error(f"Invalid schedule type: {schedule_type}")
            return False
        
        self.reports_config["reports"][report_type]["schedule"] = schedule
        self.reports_config["reports"][report_type]["enabled"] = enabled
        
        # Обновляем время следующего запуска
        next_run = self._calculate_next_run(schedule)
        self.reports_config["reports"][report_type]["next_run"] = next_run.isoformat()
        
        return self._save_reports_config()
    
    def _calculate_next_run(self, schedule_type: str) -> datetime.datetime:
        """
        Расчет времени следующего запуска отчета
        
        Args:
            schedule_type: Тип расписания (daily, weekly, monthly)
            
        Returns:
            datetime.datetime: Время следующего запуска
        """
        now = datetime.datetime.now()
        
        if schedule_type == ScheduleType.DAILY.value:
            # Ежедневно в 9:00
            next_day = now.replace(hour=9, minute=0, second=0, microsecond=0)
            if next_day <= now:
                next_day += datetime.timedelta(days=1)
            return next_day
        elif schedule_type == ScheduleType.WEEKLY.value:
            # Еженедельно в понедельник в 10:00
            days_ahead = 0 - now.weekday()
            if days_ahead <= 0:  # Сегодня понедельник или позже
                days_ahead += 7
            next_monday = now.replace(hour=10, minute=0, second=0, microsecond=0) + datetime.timedelta(days=days_ahead)
            return next_monday
        elif schedule_type == ScheduleType.MONTHLY.value:
            # Ежемесячно 1-го числа в 8:00
            if now.day == 1 and now.hour < 8:
                next_month = now.replace(hour=8, minute=0, second=0, microsecond=0)
            else:
                if now.month == 12:
                    next_month = now.replace(year=now.year+1, month=1, day=1, hour=8, minute=0, second=0, microsecond=0)
                else:
                    next_month = now.replace(month=now.month+1, day=1, hour=8, minute=0, second=0, microsecond=0)
            return next_month
        
        # По умолчанию - завтра в 9:00
        return now.replace(hour=9, minute=0, second=0, microsecond=0) + datetime.timedelta(days=1)
    
    def generate_and_send_custom_report(self, report_type: str, period_days: int = 30, 
                                      admin_id: Optional[int] = None,
                                      report_format: ReportFormat = ReportFormat.PDF) -> bool:
        """
        Генерация и отправка отчета по запросу администратора
        
        Args:
            report_type: Тип отчета
            period_days: Период отчета в днях
            admin_id: ID администратора (для отправки отчета)
            report_format: Формат отчета
            
        Returns:
            bool: True, если отчет успешно сгенерирован и отправлен, иначе False
        """
        # В реальности здесь будет логика получения данных и формирования отчета
        try:
            # Заглушка для демонстрации
            report_data = {
                "report_type": report_type,
                "generated_at": datetime.datetime.now().isoformat(),
                "period_days": period_days,
                "requested_by": admin_id,
                "items": [
                    {"id": 1, "name": "Item 1", "value": 100},
                    {"id": 2, "name": "Item 2", "value": 200},
                    {"id": 3, "name": "Item 3", "value": 300}
                ]
            }
            
            # Генерация отчета
            report_title = f"Отчет {report_type.capitalize()} за {period_days} дней"
            report_content, mime_type = ReportingService.export_report(report_data, report_format, report_title)
            
            # Отправка отчета администратору
            if admin_id:
                # В реальности здесь будет логика отправки через Telegram
                logger.info(f"Report for {report_type} would be sent to admin {admin_id}")
                return True
            
            logger.info(f"Report for {report_type} generated successfully")
            return True
        except Exception as e:
            logger.error(f"Error generating report {report_type}: {e}")
            return False
    
    def update_report_schedule_sync(self, report_type: str, schedule_type: str, enabled: bool = True) -> bool:
        """
        Синхронная версия метода update_report_schedule для использования из Flask
        
        Args:
            report_type: Тип отчета
            schedule_type: Тип расписания (daily, weekly, monthly)
            enabled: Включен ли отчет
            
        Returns:
            bool: True, если обновление успешно, иначе False
        """
        return self.update_report_schedule(report_type, schedule_type, enabled)
    
    def generate_and_send_custom_report_sync(self, report_type: str, period_days: int = 30, 
                                          admin_id: Optional[int] = None,
                                          report_format: ReportFormat = ReportFormat.PDF) -> bool:
        """
        Синхронная версия метода generate_and_send_custom_report для использования из Flask
        
        Args:
            report_type: Тип отчета
            period_days: Период отчета в днях
            admin_id: ID администратора (для отправки отчета)
            report_format: Формат отчета
            
        Returns:
            bool: True, если отчет успешно сгенерирован и отправлен, иначе False
        """
        return self.generate_and_send_custom_report(report_type, period_days, admin_id, report_format)

# Синглтон для сервиса
_scheduled_reports_service_instance = None

def get_scheduled_reports_service() -> ScheduledReportsService:
    """
    Получение экземпляра сервиса запланированных отчетов
    
    Returns:
        ScheduledReportsService: Экземпляр сервиса
    """
    global _scheduled_reports_service_instance
    if _scheduled_reports_service_instance is None:
        _scheduled_reports_service_instance = ScheduledReportsService()
    return _scheduled_reports_service_instance