#!/usr/bin/env python
# coding: utf-8

"""
Упрощенный скрипт для нагрузочного тестирования системы бота Катюша
Фокусируется на ключевых метриках и не требует дополнительных библиотек
"""

import os
import sys
import time
import logging
import datetime
import random
from typing import List, Dict, Tuple, Any, Optional
import psycopg2
from psycopg2.extras import DictCursor
import concurrent.futures

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("simple_load_test_results.log")
    ]
)

logger = logging.getLogger(__name__)

# Получение параметров подключения к БД из переменных окружения
DATABASE_URL = os.environ.get("DATABASE_URL")

def get_database_connection():
    """
    Создает соединение с базой данных
    
    Returns:
        Connection: Соединение с БД PostgreSQL
    """
    try:
        conn = psycopg2.connect(DATABASE_URL)
        return conn
    except Exception as e:
        logger.error(f"Ошибка при подключении к БД: {e}")
        sys.exit(1)

def test_database_connection_speed(iterations=10):
    """
    Тестирует скорость подключения к базе данных
    
    Args:
        iterations: Количество повторений теста
        
    Returns:
        float: Среднее время установления соединения в секундах
    """
    total_time = 0
    
    for _ in range(iterations):
        start_time = time.time()
        conn = get_database_connection()
        conn.close()
        end_time = time.time()
        total_time += (end_time - start_time)
    
    return total_time / iterations

def test_simple_query_speed(query: str, params: Tuple = None, iterations: int = 100):
    """
    Тестирует скорость выполнения простого запроса
    
    Args:
        query: SQL запрос
        params: Параметры запроса
        iterations: Количество повторений
        
    Returns:
        float: Среднее время выполнения запроса в секундах
    """
    conn = get_database_connection()
    total_time = 0
    
    try:
        with conn.cursor() as cursor:
            for _ in range(iterations):
                start_time = time.time()
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)
                cursor.fetchall()
                end_time = time.time()
                total_time += (end_time - start_time)
    finally:
        conn.close()
    
    return total_time / iterations

def test_database_write_speed(users_count: int):
    """
    Тестирует скорость записи новых пользователей в базу данных
    
    Args:
        users_count: Количество пользователей для теста
        
    Returns:
        Tuple[float, float]: Общее время и время на одного пользователя
    """
    conn = get_database_connection()
    start_time = time.time()
    
    try:
        with conn.cursor() as cursor:
            # Временная таблица для тестирования
            cursor.execute("""
                CREATE TEMPORARY TABLE test_users (
                    id BIGINT PRIMARY KEY,
                    username VARCHAR(255),
                    first_name VARCHAR(255),
                    last_name VARCHAR(255),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Массовая вставка пользователей
            for i in range(users_count):
                test_id = 9000000000 + i  # Большие ID, чтобы не конфликтовать с реальными
                cursor.execute(
                    "INSERT INTO test_users (id, username, first_name, last_name) VALUES (%s, %s, %s, %s)",
                    (test_id, f"test_user_{i}", f"Test{i}", f"User{i}")
                )
            
            conn.commit()
    finally:
        conn.close()
    
    end_time = time.time()
    total_time = end_time - start_time
    per_user_time = total_time / users_count
    
    return total_time, per_user_time

def test_complex_joins():
    """
    Тестирует производительность сложных запросов с JOIN
    
    Returns:
        Dict: Статистика времени выполнения
    """
    conn = get_database_connection()
    times = []
    
    query = """
        SELECT u.id, u.username, t.amount, t.created_at 
        FROM users u
        LEFT JOIN transactions t ON u.id = t.user_id
        WHERE u.subscription_expiry IS NOT NULL
        ORDER BY t.created_at DESC
        LIMIT 100
    """
    
    try:
        with conn.cursor() as cursor:
            for _ in range(20):  # 20 повторений
                start_time = time.time()
                cursor.execute(query)
                cursor.fetchall()
                end_time = time.time()
                times.append(end_time - start_time)
    finally:
        conn.close()
    
    return {
        "min": min(times),
        "max": max(times),
        "avg": sum(times) / len(times),
        "median": sorted(times)[len(times) // 2]
    }

def test_referral_queries():
    """
    Тестирует запросы, связанные с реферальной системой
    
    Returns:
        Dict: Статистика времени выполнения
    """
    conn = get_database_connection()
    times = []
    
    # Получаем список существующих ID реферальных отношений
    referrer_ids = []
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT DISTINCT referrer_id FROM referral_relations LIMIT 10")
            for row in cursor.fetchall():
                if row[0]:
                    referrer_ids.append(row[0])
    except Exception as e:
        logger.error(f"Ошибка при получении ID рефереров: {e}")
    
    # Если не удалось получить реальные ID, используем тестовые
    if not referrer_ids:
        referrer_ids = [1000001, 1000002, 1000003]
    
    # Запрос для получения реферальной структуры
    query = """
        WITH RECURSIVE referral_tree AS (
            SELECT id, user_id, referrer_id, 1 as level
            FROM referral_relations
            WHERE referrer_id = %s
            UNION ALL
            SELECT r.id, r.user_id, r.referrer_id, rt.level + 1
            FROM referral_relations r
            JOIN referral_tree rt ON r.referrer_id = rt.user_id
            WHERE rt.level < 4
        )
        SELECT * FROM referral_tree
    """
    
    try:
        with conn.cursor() as cursor:
            for referrer_id in referrer_ids:
                start_time = time.time()
                cursor.execute(query, (referrer_id,))
                results = cursor.fetchall()
                end_time = time.time()
                times.append(end_time - start_time)
                
                logger.info(f"Реферальная структура для {referrer_id}: найдено {len(results)} записей")
    finally:
        conn.close()
    
    if not times:
        return {"error": "Нет данных для анализа"}
    
    return {
        "min": min(times),
        "max": max(times),
        "avg": sum(times) / len(times),
        "median": sorted(times)[len(times) // 2]
    }

def analyze_database_size():
    """
    Анализирует размер базы данных и таблиц
    
    Returns:
        Dict: Информация о размере БД и таблиц
    """
    conn = get_database_connection()
    results = {}
    
    try:
        with conn.cursor(cursor_factory=DictCursor) as cursor:
            # Получаем размер всей БД
            cursor.execute("""
                SELECT pg_size_pretty(pg_database_size(current_database())) as db_size,
                       pg_database_size(current_database()) as db_size_bytes
            """)
            db_size = cursor.fetchone()
            results["database_size"] = {
                "pretty": db_size["db_size"],
                "bytes": db_size["db_size_bytes"]
            }
            
            # Получаем размер каждой таблицы
            cursor.execute("""
                SELECT
                    table_name,
                    pg_size_pretty(pg_total_relation_size('"' || table_schema || '"."' || table_name || '"')) as size,
                    pg_total_relation_size('"' || table_schema || '"."' || table_name || '"') as size_bytes
                FROM information_schema.tables
                WHERE table_schema = 'public'
                ORDER BY pg_total_relation_size('"' || table_schema || '"."' || table_name || '"') DESC
            """)
            tables = cursor.fetchall()
            
            results["tables"] = []
            for table in tables:
                results["tables"].append({
                    "name": table["table_name"],
                    "size": table["size"],
                    "bytes": table["size_bytes"]
                })
            
            # Получаем количество строк в основных таблицах
            main_tables = ["users", "transactions", "referral_codes", "referral_relations"]
            results["row_counts"] = {}
            
            for table in main_tables:
                try:
                    cursor.execute(f"SELECT COUNT(*) as count FROM {table}")
                    row = cursor.fetchone()
                    results["row_counts"][table] = row["count"]
                except Exception as e:
                    logger.error(f"Ошибка при подсчете строк в таблице {table}: {e}")
                    results["row_counts"][table] = "ошибка"
    finally:
        conn.close()
    
    return results

def extrapolate_database_growth(current_size_bytes: int, current_user_count: int, target_user_count: int):
    """
    Экстраполирует рост размера базы данных при увеличении количества пользователей
    
    Args:
        current_size_bytes: Текущий размер БД в байтах
        current_user_count: Текущее количество пользователей
        target_user_count: Целевое количество пользователей
        
    Returns:
        Dict: Прогноз роста БД
    """
    # Защита от деления на ноль
    if current_user_count <= 0:
        current_user_count = 1
    
    # Расчет размера на одного пользователя (включая все связанные данные)
    size_per_user = current_size_bytes / current_user_count
    
    # Прогнозируемый размер
    projected_size_bytes = size_per_user * target_user_count
    
    # Конвертация в более читаемый формат
    if projected_size_bytes < 1024:
        projected_size_readable = f"{projected_size_bytes:.2f} B"
    elif projected_size_bytes < 1024 ** 2:
        projected_size_readable = f"{projected_size_bytes / 1024:.2f} KB"
    elif projected_size_bytes < 1024 ** 3:
        projected_size_readable = f"{projected_size_bytes / (1024 ** 2):.2f} MB"
    else:
        projected_size_readable = f"{projected_size_bytes / (1024 ** 3):.2f} GB"
    
    return {
        "current_size_bytes": current_size_bytes,
        "current_user_count": current_user_count,
        "size_per_user_bytes": size_per_user,
        "target_user_count": target_user_count,
        "projected_size_bytes": projected_size_bytes,
        "projected_size_readable": projected_size_readable
    }

def estimate_resource_requirements(user_count: int):
    """
    Оценивает требования к ресурсам для заданного количества пользователей
    
    Args:
        user_count: Количество пользователей
        
    Returns:
        Dict: Оценка требуемых ресурсов
    """
    # Приблизительные оценки на основе тестирования и опыта
    # Эти значения следует корректировать на основе реального тестирования
    
    active_ratio = 0.2  # 20% пользователей активны одновременно
    req_per_active_user_per_day = 10  # Среднее количество запросов от активного пользователя в день
    
    active_users = user_count * active_ratio
    daily_requests = active_users * req_per_active_user_per_day
    peak_factor = 3  # Пиковая нагрузка в 3 раза выше средней
    peak_qps = (daily_requests / 86400) * peak_factor  # Запросов в секунду в пиковое время
    
    # Приблизительные требования к CPU
    cpu_per_qps = 0.1  # 10 QPS на 1 ядро CPU
    required_cpu_cores = peak_qps * cpu_per_qps
    
    # Приблизительные требования к памяти
    memory_per_active_user_mb = 0.5  # 0.5 MB на активного пользователя
    required_memory_mb = active_users * memory_per_active_user_mb
    
    # Приблизительные требования к диску
    disk_per_user_mb = 2  # 2 MB на пользователя (включая историю, логи и т.д.)
    required_disk_gb = (user_count * disk_per_user_mb) / 1024
    
    # Приблизительные требования к БД
    db_connections = min(500, max(5, int(peak_qps / 2)))  # Примерная формула для количества соединений
    
    return {
        "total_users": user_count,
        "active_users": active_users,
        "daily_requests": daily_requests,
        "peak_qps": peak_qps,
        "required_cpu_cores": required_cpu_cores,
        "required_memory_mb": required_memory_mb,
        "required_memory_gb": required_memory_mb / 1024,
        "required_disk_gb": required_disk_gb,
        "db_connections": db_connections,
        "recommendations": {
            "db_instance_type": "Standard with high memory" if user_count > 500000 else "Standard",
            "app_scaling": "Horizontally scale to multiple instances",
            "cache_recommendation": "Redis for session and frequent queries" if user_count > 100000 else "Application level caching",
            "cdn_recommendation": "Yes" if user_count > 50000 else "Optional"
        }
    }

def identify_bottlenecks(test_results: Dict):
    """
    Анализирует результаты тестов и выявляет потенциальные узкие места
    
    Args:
        test_results: Результаты всех проведенных тестов
        
    Returns:
        List: Обнаруженные узкие места и рекомендации
    """
    bottlenecks = []
    
    # Анализ производительности БД
    if "db_connection_time" in test_results and test_results["db_connection_time"] > 0.1:
        bottlenecks.append({
            "component": "Database",
            "issue": "Slow connection time",
            "value": f"{test_results['db_connection_time']:.4f} seconds",
            "threshold": "0.1 seconds",
            "recommendation": "Проверьте настройки соединений PostgreSQL, возможно, стоит увеличить max_connections"
        })
    
    if "simple_query_time" in test_results and test_results["simple_query_time"] > 0.01:
        bottlenecks.append({
            "component": "Database",
            "issue": "Slow simple queries",
            "value": f"{test_results['simple_query_time']:.4f} seconds",
            "threshold": "0.01 seconds",
            "recommendation": "Оптимизируйте настройки PostgreSQL, проверьте работу индексов"
        })
    
    if "complex_joins" in test_results:
        complex_perf = test_results["complex_joins"]
        if complex_perf["avg"] > 0.5:
            bottlenecks.append({
                "component": "Database",
                "issue": "Slow complex JOIN queries",
                "value": f"{complex_perf['avg']:.4f} seconds avg",
                "threshold": "0.5 seconds",
                "recommendation": "Оптимизируйте запросы с JOIN, добавьте индексы на поля user_id и created_at"
            })
    
    if "referral_queries" in test_results:
        ref_perf = test_results["referral_queries"]
        if "avg" in ref_perf and ref_perf["avg"] > 0.5:
            bottlenecks.append({
                "component": "Database",
                "issue": "Slow recursive queries for referral tree",
                "value": f"{ref_perf['avg']:.4f} seconds avg",
                "threshold": "0.5 seconds",
                "recommendation": "Оптимизируйте рекурсивные запросы, рассмотрите возможность материализации деревьев рефералов"
            })
    
    # Анализ прогнозов роста БД
    if "db_growth" in test_results:
        for target, projection in test_results["db_growth"].items():
            if "projected_size_bytes" in projection and projection["projected_size_bytes"] > 10 * 1024 ** 3:  # > 10 GB
                bottlenecks.append({
                    "component": "Database",
                    "issue": f"Large projected database size for {target} users",
                    "value": projection["projected_size_readable"],
                    "threshold": "10 GB",
                    "recommendation": "Внедрите стратегии архивации и очистки старых данных, рассмотрите шардирование"
                })
    
    # Если узких мест не обнаружено, добавляем позитивный результат
    if not bottlenecks:
        bottlenecks.append({
            "component": "System",
            "issue": "No significant bottlenecks detected",
            "value": "All metrics within acceptable ranges",
            "threshold": "N/A",
            "recommendation": "Регулярно проводите нагрузочное тестирование при увеличении базы пользователей"
        })
    
    return bottlenecks

def generate_report(test_results: Dict, bottlenecks: List):
    """
    Генерирует отчет по результатам тестирования
    
    Args:
        test_results: Результаты тестов
        bottlenecks: Обнаруженные узкие места
        
    Returns:
        str: Текст отчета
    """
    report = []
    
    # Заголовок отчета
    report.append("=" * 80)
    report.append(f"ОТЧЕТ О НАГРУЗОЧНОМ ТЕСТИРОВАНИИ | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("=" * 80)
    report.append("")
    
    # Общая информация о БД
    if "db_info" in test_results:
        db_info = test_results["db_info"]
        report.append("ИНФОРМАЦИЯ О БАЗЕ ДАННЫХ:")
        report.append(f"Размер БД: {db_info['database_size']['pretty']}")
        
        # Таблицы по размеру
        report.append("\nТОП 5 ТАБЛИЦ ПО РАЗМЕРУ:")
        for i, table in enumerate(db_info['tables'][:5], 1):
            report.append(f"{i}. {table['name']}: {table['size']}")
        
        # Количество строк
        if "row_counts" in db_info:
            report.append("\nКОЛИЧЕСТВО СТРОК В ОСНОВНЫХ ТАБЛИЦАХ:")
            for table, count in db_info['row_counts'].items():
                report.append(f"{table}: {count:,}")
        
        report.append("")
    
    # Результаты тестов производительности
    report.append("РЕЗУЛЬТАТЫ ТЕСТОВ ПРОИЗВОДИТЕЛЬНОСТИ:")
    
    if "db_connection_time" in test_results:
        report.append(f"Время подключения к БД: {test_results['db_connection_time']:.4f} сек")
    
    if "simple_query_time" in test_results:
        report.append(f"Время выполнения простого запроса: {test_results['simple_query_time']:.4f} сек")
    
    if "db_write_speed" in test_results:
        write_speed = test_results["db_write_speed"]
        report.append(f"Скорость записи в БД: {write_speed['total_time']:.2f} сек для {write_speed['users_count']:,} пользователей")
        report.append(f"В среднем на пользователя: {write_speed['per_user_time'] * 1000:.2f} мс")
    
    if "complex_joins" in test_results:
        complex_perf = test_results["complex_joins"]
        report.append("\nПРОИЗВОДИТЕЛЬНОСТЬ ЗАПРОСОВ С JOIN:")
        report.append(f"Среднее: {complex_perf['avg']:.4f} сек, Медиана: {complex_perf['median']:.4f} сек")
        report.append(f"Мин: {complex_perf['min']:.4f} сек, Макс: {complex_perf['max']:.4f} сек")
    
    if "referral_queries" in test_results:
        ref_perf = test_results["referral_queries"]
        report.append("\nПРОИЗВОДИТЕЛЬНОСТЬ ЗАПРОСОВ К РЕФЕРАЛЬНОЙ СИСТЕМЕ:")
        if "avg" in ref_perf:
            report.append(f"Среднее: {ref_perf['avg']:.4f} сек, Медиана: {ref_perf['median']:.4f} сек")
            report.append(f"Мин: {ref_perf['min']:.4f} сек, Макс: {ref_perf['max']:.4f} сек")
        elif "error" in ref_perf:
            report.append(f"Ошибка: {ref_perf['error']}")
    
    # Прогнозы роста
    if "db_growth" in test_results:
        report.append("\nПРОГНОЗ РОСТА БАЗЫ ДАННЫХ:")
        for target, projection in test_results["db_growth"].items():
            report.append(f"Для {projection['target_user_count']:,} пользователей:")
            report.append(f"  Прогнозируемый размер: {projection['projected_size_readable']}")
            report.append(f"  Размер на одного пользователя: {projection['size_per_user_bytes'] / 1024:.2f} KB")
    
    # Рекомендации по ресурсам
    if "resource_requirements" in test_results:
        for target, req in test_results["resource_requirements"].items():
            report.append(f"\nТРЕБОВАНИЯ К РЕСУРСАМ ДЛЯ {req['total_users']:,} ПОЛЬЗОВАТЕЛЕЙ:")
            report.append(f"Активных пользователей: {req['active_users']:,.0f}")
            report.append(f"Пиковая нагрузка: {req['peak_qps']:.2f} запросов/сек")
            report.append(f"Требуемые ресурсы:")
            report.append(f"  CPU: {req['required_cpu_cores']:.2f} ядер")
            report.append(f"  Память: {req['required_memory_gb']:.2f} GB")
            report.append(f"  Диск: {req['required_disk_gb']:.2f} GB")
            report.append(f"  Соединения с БД: {req['db_connections']}")
            
            report.append("  Рекомендации:")
            for rec_type, recommendation in req['recommendations'].items():
                report.append(f"    {rec_type}: {recommendation}")
    
    # Выявленные узкие места
    report.append("\nВЫЯВЛЕННЫЕ УЗКИЕ МЕСТА И РЕКОМЕНДАЦИИ:")
    if bottlenecks:
        for i, bottleneck in enumerate(bottlenecks, 1):
            report.append(f"{i}. {bottleneck['component']} - {bottleneck['issue']}")
            report.append(f"   Значение: {bottleneck['value']}, Порог: {bottleneck['threshold']}")
            report.append(f"   Рекомендация: {bottleneck['recommendation']}")
    else:
        report.append("Критических узких мест не обнаружено.")
    
    # Заключение
    report.append("\nЗАКЛЮЧЕНИЕ:")
    
    # Определяем общий вердикт на основе обнаруженных узких мест
    critical_issues = sum(1 for b in bottlenecks if "issue" in b and b["issue"] != "No significant bottlenecks detected")
    
    if critical_issues == 0:
        report.append("Система показывает хорошую производительность и масштабируемость.")
        report.append("Рекомендуется регулярно проводить нагрузочное тестирование при увеличении базы пользователей.")
    elif critical_issues <= 2:
        report.append("Система имеет незначительные узкие места, которые могут повлиять на масштабируемость.")
        report.append("Рекомендуется внедрить предложенные оптимизации перед увеличением нагрузки.")
    else:
        report.append("Система имеет существенные узкие места, которые ограничивают масштабируемость.")
        report.append("Необходимо внедрить рекомендованные оптимизации перед увеличением базы пользователей.")
    
    # Возвращаем отчет в виде строки
    return "\n".join(report)

def run_simple_load_test():
    """
    Запускает упрощенное нагрузочное тестирование и генерирует отчет
    """
    logger.info("Запуск упрощенного нагрузочного тестирования...")
    
    test_results = {}
    
    # 1. Базовая информация о БД
    logger.info("Сбор информации о базе данных...")
    test_results["db_info"] = analyze_database_size()
    
    # Определяем текущее количество пользователей для экстраполяции
    current_user_count = test_results["db_info"]["row_counts"].get("users", 100)
    
    # 2. Тесты производительности соединения и запросов
    logger.info("Тестирование скорости подключения к БД...")
    test_results["db_connection_time"] = test_database_connection_speed()
    
    logger.info("Тестирование скорости простых запросов...")
    test_results["simple_query_time"] = test_simple_query_speed(
        "SELECT id, username FROM users LIMIT 10"
    )
    
    # 3. Тесты записи
    logger.info("Тестирование скорости записи...")
    users_to_test = min(100, max(1, current_user_count // 100))  # 1% от текущего количества, но не более 100
    total_time, per_user_time = test_database_write_speed(users_to_test)
    test_results["db_write_speed"] = {
        "total_time": total_time,
        "per_user_time": per_user_time,
        "users_count": users_to_test
    }
    
    # 4. Тесты производительности сложных запросов
    logger.info("Тестирование производительности запросов с JOIN...")
    test_results["complex_joins"] = test_complex_joins()
    
    logger.info("Тестирование запросов к реферальной системе...")
    test_results["referral_queries"] = test_referral_queries()
    
    # 5. Прогнозы роста БД
    logger.info("Анализ прогнозов роста базы данных...")
    db_size_bytes = test_results["db_info"]["database_size"]["bytes"]
    test_results["db_growth"] = {}
    
    for target_count in [100000, 1000000]:
        projection = extrapolate_database_growth(
            db_size_bytes, current_user_count, target_count
        )
        test_results["db_growth"][f"{target_count}_users"] = projection
    
    # 6. Оценка требований к ресурсам
    logger.info("Оценка требований к ресурсам...")
    test_results["resource_requirements"] = {}
    for target_count in [100000, 1000000]:
        requirements = estimate_resource_requirements(target_count)
        test_results["resource_requirements"][f"{target_count}_users"] = requirements
    
    # 7. Анализ узких мест
    logger.info("Анализ узких мест...")
    bottlenecks = identify_bottlenecks(test_results)
    
    # 8. Генерация отчета
    logger.info("Генерация отчета о нагрузочном тестировании...")
    report = generate_report(test_results, bottlenecks)
    
    # Запись отчета в файл
    report_filename = f"simple_load_test_report_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}.txt"
    with open(report_filename, "w", encoding="utf-8") as f:
        f.write(report)
    
    logger.info(f"Отчет сохранен в файл: {report_filename}")
    print(f"\nОтчет сохранен в файл: {report_filename}")
    
    # Вывод краткого резюме
    print("\nКраткое резюме нагрузочного тестирования:")
    print(f"- Текущий размер БД: {test_results['db_info']['database_size']['pretty']}")
    print(f"- Количество пользователей: {current_user_count:,}")
    
    print("\nПрогноз для масштабирования:")
    for target in ["100000_users", "1000000_users"]:
        if target in test_results["db_growth"]:
            print(f"- {target.replace('_', ' ')}: {test_results['db_growth'][target]['projected_size_readable']}")
    
    print("\nВыявленные узкие места:")
    if not bottlenecks or (len(bottlenecks) == 1 and "issue" in bottlenecks[0] and bottlenecks[0]["issue"] == "No significant bottlenecks detected"):
        print("- Критических узких мест не обнаружено")
    else:
        for bottleneck in bottlenecks:
            if "issue" in bottleneck and bottleneck["issue"] != "No significant bottlenecks detected":
                print(f"- {bottleneck['component']}: {bottleneck['issue']}")
    
    return test_results, bottlenecks, report_filename

if __name__ == "__main__":
    # Выполняем упрощенное нагрузочное тестирование
    run_simple_load_test()