#!/usr/bin/env python
# coding: utf-8

"""
Менеджер реферальной системы для работы с PostgreSQL
"""

import logging
import uuid
import string
import random
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple

from db_config import get_flask_app
from db_models import db, User, Transaction, WeeklyPayout
from new_referral_models import ReferralCode, ReferralRelation, ReferralReward

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class ReferralManager:
    """Менеджер реферальной системы для работы с PostgreSQL"""
    
    # Комиссии для уровней (1-4)
    LEVEL_COMMISSIONS = {
        1: 0.05,  # 5% для прямых рефералов
        2: 0.02,  # 2% для рефералов 2-го уровня
        3: 0.02,  # 2% для рефералов 3-го уровня
        4: 0.02   # 2% для рефералов 4-го уровня
    }
    
    # Максимальный уровень комиссии
    MAX_LEVEL = 4
    
    def __init__(self):
        self.app = get_flask_app()
    
    def generate_referral_code(self, user_id: int, min_length: int = 6, max_length: int = 12) -> str:
        """
        Генерация уникального реферального кода с улучшенным алгоритмом
        
        Args:
            user_id: ID пользователя для включения в код
            min_length: Минимальная длина кода
            max_length: Максимальная длина кода
            
        Returns:
            str: Сгенерированный код
        """
        # Списки гласных и согласных для лучшей произносимости
        vowels = 'aeiouy'
        consonants = 'bcdfghjklmnpqrstvwxz'
        
        # Запрещенные слова, которые не должны появляться в коде
        banned_words = ['sex', 'xxx', 'ass', 'fuck', 'shit', 'dick', 'cock', 'piss', 'poop']

        # Преобразуем user_id в строку и берем последние 4 цифры (или меньше)
        user_str = str(user_id)
        user_part = user_str[-min(4, len(user_str)):]
        
        # Определяем длину кода (увеличивается с ростом числа пользователей)
        with self.app.app_context():
            user_count = ReferralCode.query.count()
            # Увеличиваем длину по мере роста базы
            adaptive_length = min(max_length, min_length + (user_count // 10000))
            
            # Минимальное количество случайных символов
            rand_length = max(2, adaptive_length - len(user_part) - 1)
            
            attempt_count = 0
            while True:
                attempt_count += 1
                
                # Генерируем случайную часть, чередуя согласные и гласные
                random_part = ''
                for i in range(rand_length):
                    if i % 2 == 0:
                        random_part += random.choice(consonants)
                    else:
                        random_part += random.choice(vowels)
                
                # Префикс 'r' + часть ID + случайная часть
                code = 'r' + user_part + random_part
                
                # Проверка на запрещенные слова
                contains_banned = False
                for word in banned_words:
                    if word in code.lower():
                        contains_banned = True
                        break
                
                if contains_banned:
                    continue
                
                # Проверяем уникальность
                existing = ReferralCode.query.filter_by(code=code).first()
                if not existing:
                    return code
                
                # Если слишком много попыток, увеличиваем длину случайной части
                if attempt_count > 5:
                    rand_length += 1
    
    def get_or_create_referral_code(self, user_id: int) -> str:
        """
        Получение реферального кода пользователя, создание нового если отсутствует
        
        Args:
            user_id: ID пользователя
            
        Returns:
            str: Реферальный код
        """
        with self.app.app_context():
            # Проверяем наличие активного кода
            referral_code = ReferralCode.query.filter_by(user_id=user_id, active=True).first()
            
            if referral_code:
                return referral_code.code
            
            # Создаем новый код с обновленным алгоритмом
            new_code = self.generate_referral_code(user_id)
            referral_code = ReferralCode(
                user_id=user_id,
                code=new_code,
                active=True
            )
            db.session.add(referral_code)
            db.session.commit()
            
            return new_code
    
    def add_referral(self, user_id: int, referral_code: str) -> bool:
        """
        Добавление реферального отношения между пользователями
        
        Args:
            user_id: ID пользователя-реферала
            referral_code: Реферальный код реферера
            
        Returns:
            bool: True, если отношение успешно добавлено, False в противном случае
        """
        with self.app.app_context():
            # Проверяем существует ли такой реферальный код
            ref_code = ReferralCode.query.filter_by(code=referral_code, active=True).first()
            if not ref_code:
                logger.warning(f"Referral code {referral_code} not found or inactive")
                return False
            
            # Нельзя быть своим реферером
            if ref_code.user_id == user_id:
                logger.warning(f"User {user_id} tried to be their own referrer")
                return False
            
            # Проверяем существует ли пользователь-реферал
            user = User.query.filter_by(id=user_id).first()
            if not user:
                logger.warning(f"User {user_id} not found")
                return False
            
            # Проверяем существует ли уже реферальное отношение для этого пользователя
            existing_relation = ReferralRelation.query.filter_by(user_id=user_id).first()
            if existing_relation:
                logger.warning(f"User {user_id} already has referrer {existing_relation.referrer_id}")
                return False
            
            # Создаем реферальное отношение
            relation = ReferralRelation(
                user_id=user_id,
                referrer_id=ref_code.user_id,
                level=1  # Прямой реферал
            )
            db.session.add(relation)
            
            # Обновляем реферальные отношения для вышестоящих уровней
            try:
                self._update_referral_hierarchy(user_id, ref_code.user_id)
                db.session.commit()
                logger.info(f"Added referral relationship: {user_id} <- {ref_code.user_id}")
                return True
            except Exception as e:
                logger.error(f"Error adding referral relationship: {e}")
                db.session.rollback()
                return False
    
    def _update_referral_hierarchy(self, user_id: int, direct_referrer_id: int) -> None:
        """
        Обновление иерархии реферальных отношений с оптимизированным батчингом
        
        Args:
            user_id: ID пользователя
            direct_referrer_id: ID прямого реферера
        """
        # Используем оптимизированный алгоритм для нахождения всех вышестоящих рефереров до MAX_LEVEL
        # Запросы делаются в батчах вместо последовательных запросов
        
        # Создаем словарь для хранения связей "пользователь -> реферер"
        referral_chain = {}
        
        # Начинаем с прямого реферера
        referral_chain[1] = direct_referrer_id
        current_level_ids = [direct_referrer_id]
        
        # Проходим по уровням от 2 до MAX_LEVEL
        for level in range(2, self.MAX_LEVEL + 1):
            if not current_level_ids:
                break
                
            # Получаем рефереров для текущего уровня одним запросом (батчинг)
            referrer_relations = ReferralRelation.query.filter(
                ReferralRelation.user_id.in_(current_level_ids),
                ReferralRelation.level == 1  # Прямой реферер для каждого пользователя в цепочке
            ).all()
            
            # Если на этом уровне нет отношений, выходим из цикла
            if not referrer_relations:
                break
                
            # Подготавливаем ID для следующего уровня
            next_level_ids = []
            
            # Обрабатываем все полученные отношения
            for relation in referrer_relations:
                # Сохраняем реферера для текущего уровня
                referral_chain[level] = relation.referrer_id
                
                # Добавляем ID для следующего уровня
                next_level_ids.append(relation.referrer_id)
                
                # Создаем отношение для пользователя с реферером текущего уровня
                new_relation = ReferralRelation(
                    user_id=user_id,
                    referrer_id=relation.referrer_id,
                    level=level
                )
                db.session.add(new_relation)
            
            # Обновляем список текущих ID для следующей итерации
            current_level_ids = next_level_ids
            
        # Батчинг операций вставки - все добавленные отношения будут вставлены одним запросом
        # при вызове db.session.commit() в вызывающем методе
    
    def calculate_reward_amount(self, level: int, amount: float) -> float:
        """
        Рассчитывает сумму вознаграждения по уровню и сумме платежа
        
        Args:
            level: Уровень в реферальной иерархии
            amount: Сумма платежа
            
        Returns:
            float: Рассчитанная сумма вознаграждения
        """
        if level not in self.LEVEL_COMMISSIONS:
            return 0.0
        
        return amount * self.LEVEL_COMMISSIONS[level]
    
    def process_payment_rewards(self, user_id: int, amount: float, transaction_id: int, 
                               min_amount: float = 1.0) -> List[Dict[str, Any]]:
        """
        Начисление реферальных вознаграждений за платеж с улучшенной обработкой
        
        Args:
            user_id: ID пользователя, совершившего платеж
            amount: Сумма платежа
            transaction_id: ID транзакции платежа
            min_amount: Минимальная сумма вознаграждения для начисления
            
        Returns:
            List[Dict]: Список начисленных вознаграждений
        """
        rewards = []
        
        with self.app.app_context():
            # Проверяем, существует ли транзакция
            transaction = Transaction.query.filter_by(id=transaction_id).first()
            if not transaction:
                logger.error(f"Transaction {transaction_id} not found")
                return []
            
            # Проверяем, что за эту транзакцию еще не были начислены вознаграждения
            existing_rewards = ReferralReward.query.filter_by(source_transaction_id=transaction_id).first()
            if existing_rewards:
                logger.warning(f"Rewards for transaction {transaction_id} already exist")
                return []
            
            # Находим все реферальные отношения для этого пользователя в одном запросе (батчинг)
            relations = ReferralRelation.query.filter_by(user_id=user_id).all()
            
            # Временно сохраняем все вознаграждения без коммита
            pending_rewards = []
            
            for relation in relations:
                # Используем унифицированный метод расчета вознаграждения
                reward_amount = self.calculate_reward_amount(relation.level, amount)
                
                # Проверяем минимальную сумму вознаграждения
                if reward_amount < min_amount:
                    logger.info(f"Skipping reward for relation {relation.id}: amount {reward_amount} < min {min_amount}")
                    continue
                
                # Создаем запись о вознаграждении
                reward = ReferralReward(
                    referral_relation_id=relation.id,
                    amount=reward_amount,
                    source_transaction_id=transaction_id,
                    status="pending"
                )
                db.session.add(reward)
                pending_rewards.append(reward)
                
                rewards.append({
                    "referrer_id": relation.referrer_id,
                    "level": relation.level,
                    "amount": reward_amount
                })
            
            try:
                # Коммитим все вознаграждения в одной транзакции (атомарность)
                db.session.commit()
                logger.info(f"Created {len(rewards)} referral rewards for payment {transaction_id}")
                return rewards
            except Exception as e:
                logger.error(f"Error creating referral rewards: {e}")
                db.session.rollback()
                return []
    
    def get_pending_rewards(self, user_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Получение списка ожидающих выплат
        
        Args:
            user_id: ID пользователя (если требуются вознаграждения только для конкретного пользователя)
            
        Returns:
            List[Dict]: Список ожидающих выплат
        """
        with self.app.app_context():
            query = ReferralReward.query.filter_by(status="pending")
            
            # Если задан ID пользователя
            if user_id:
                query = query.join(ReferralRelation).filter(ReferralRelation.referrer_id == user_id)
            
            rewards = query.all()
            
            result = []
            for reward in rewards:
                relation = reward.referral_relation
                source_user = User.query.filter_by(id=relation.user_id).first()
                
                result.append({
                    "id": reward.id,
                    "referrer_id": relation.referrer_id,
                    "user_id": relation.user_id,
                    "user_name": f"{source_user.first_name or ''} {source_user.last_name or ''}".strip() if source_user else "Unknown",
                    "level": relation.level,
                    "amount": reward.amount,
                    "created_at": reward.created_at
                })
                
            return result
    
    def create_weekly_payout(self, admin_id: int, description: str) -> Optional[int]:
        """
        Создание еженедельной выплаты
        
        Args:
            admin_id: ID администратора
            description: Описание выплаты
            
        Returns:
            Optional[int]: ID созданной выплаты или None в случае ошибки
        """
        with self.app.app_context():
            try:
                payout = WeeklyPayout(
                    created_by=admin_id,
                    status="created",
                    description=description,
                    start_date=datetime.now() - timedelta(days=7),
                    end_date=datetime.now()
                )
                db.session.add(payout)
                db.session.commit()
                
                logger.info(f"Created weekly payout {payout.id}")
                return payout.id
            except Exception as e:
                logger.error(f"Error creating weekly payout: {e}")
                db.session.rollback()
                return None
    
    def assign_rewards_to_payout(self, payout_id: int, reward_ids: List[int]) -> int:
        """
        Назначение наград на выплату
        
        Args:
            payout_id: ID выплаты
            reward_ids: Список ID наград
            
        Returns:
            int: Количество назначенных наград
        """
        with self.app.app_context():
            try:
                count = 0
                payout = WeeklyPayout.query.filter_by(id=payout_id).first()
                
                if not payout:
                    logger.error(f"Payout {payout_id} not found")
                    return 0
                
                for reward_id in reward_ids:
                    reward = ReferralReward.query.filter_by(id=reward_id, status="pending").first()
                    if reward:
                        reward.status = "assigned"
                        reward.payout_id = payout_id
                        count += 1
                
                db.session.commit()
                logger.info(f"Assigned {count} rewards to payout {payout_id}")
                return count
            except Exception as e:
                logger.error(f"Error assigning rewards to payout: {e}")
                db.session.rollback()
                return 0
    
    def process_reward_transaction(self, reward_id: int, verification_code: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Проведение транзакции по награде с улучшенной защитой и атомарностью
        
        Args:
            reward_id: ID награды
            verification_code: Код подтверждения для выплаты (если используется OTP)
            
        Returns:
            Optional[Dict]: Информация о транзакции или None в случае ошибки
        """
        with self.app.app_context():
            # Начинаем транзакцию базы данных
            db_transaction = db.session.begin_nested()
            
            try:
                # Блокируем запись о награде для предотвращения конкурентных изменений
                reward = ReferralReward.query.filter_by(id=reward_id).with_for_update().first()
                
                if not reward:
                    logger.error(f"Reward {reward_id} not found")
                    return None
                
                # Проверяем, что награда в статусе, позволяющем выполнить выплату
                if reward.status not in ["pending", "assigned"]:
                    logger.warning(f"Reward {reward_id} has invalid status: {reward.status}")
                    return None
                
                # Проверяем код подтверждения (если используется)
                if verification_code is not None:
                    expected_code = self._generate_verification_code(reward)
                    if verification_code != expected_code:
                        logger.warning(f"Invalid verification code for reward {reward_id}")
                        return None
                
                relation = reward.referral_relation
                
                # Проверяем существование всех участвующих сущностей
                referrer = User.query.filter_by(id=relation.referrer_id).first()
                if not referrer:
                    logger.error(f"Referrer {relation.referrer_id} not found")
                    return None
                
                # Создаем транзакцию
                transaction = Transaction(
                    user_id=relation.referrer_id,
                    type="referral_reward",
                    amount=reward.amount,
                    status="completed",
                    description=f"Referral reward level {relation.level}",
                    related_user_id=relation.user_id
                )
                db.session.add(transaction)
                db.session.flush()  # Получаем ID транзакции
                
                # Обновляем статус награды
                reward.status = "paid"
                reward.transaction_id = transaction.id
                reward.paid_at = datetime.now()
                
                # Фиксируем транзакцию базы данных
                db_transaction.commit()
                
                # Коммитим основную сессию
                db.session.commit()
                
                logger.info(f"Processed reward {reward_id} with transaction {transaction.id}")
                return {
                    "reward_id": reward_id,
                    "transaction_id": transaction.id,
                    "amount": reward.amount,
                    "referrer_id": relation.referrer_id,
                    "status": "paid"
                }
            except Exception as e:
                logger.error(f"Error processing reward transaction: {e}")
                db_transaction.rollback()
                db.session.rollback()
                return None
    
    def _generate_verification_code(self, reward: ReferralReward) -> str:
        """
        Генерирует код подтверждения для реферального вознаграждения
        
        Args:
            reward: Объект реферального вознаграждения
            
        Returns:
            str: Сгенерированный код подтверждения
        """
        # Создаем код на основе параметров награды и секретного ключа приложения
        import hashlib
        
        # Получаем секретный ключ (в данном случае - TELEGRAM_TOKEN)
        from config import TELEGRAM_TOKEN
        secret = TELEGRAM_TOKEN if TELEGRAM_TOKEN else "default_secret"
        
        # Создаем строку с уникальными параметрами награды
        data = f"{reward.id}:{reward.referral_relation_id}:{reward.amount}:{secret}"
        
        # Хешируем и берем первые 6 символов
        hashed = hashlib.sha256(data.encode()).hexdigest()
        return hashed[:6].upper()
    
    def get_referrer_data(self, user_id: int) -> Dict[str, Any]:
        """
        Получение данных о рефералах пользователя
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Dict: Данные о рефералах пользователя
        """
        with self.app.app_context():
            # Статистика по уровням
            stats = {f"level_{i}": 0 for i in range(1, self.MAX_LEVEL + 1)}
            
            # Для каждого уровня находим все реферальные отношения
            for level in range(1, self.MAX_LEVEL + 1):
                count = ReferralRelation.query.filter_by(referrer_id=user_id, level=level).count()
                stats[f"level_{level}"] = count
            
            # Сумма заработанных вознаграждений
            total_earned = db.session.query(db.func.sum(ReferralReward.amount))\
                .join(ReferralRelation)\
                .filter(ReferralRelation.referrer_id == user_id)\
                .scalar() or 0
            
            # Сумма выплаченных вознаграждений
            paid_amount = db.session.query(db.func.sum(ReferralReward.amount))\
                .join(ReferralRelation)\
                .filter(
                    ReferralRelation.referrer_id == user_id,
                    ReferralReward.status == "paid"
                ).scalar() or 0
            
            # Сумма ожидающих выплат
            pending_amount = db.session.query(db.func.sum(ReferralReward.amount))\
                .join(ReferralRelation)\
                .filter(
                    ReferralRelation.referrer_id == user_id,
                    ReferralReward.status == "pending"
                ).scalar() or 0
            
            # Реферальный код пользователя
            referral_code = self.get_or_create_referral_code(user_id)
            
            return {
                "user_id": user_id,
                "referral_code": referral_code,
                "stats": stats,
                "total_referrals": sum(stats.values()),
                "total_earned": float(total_earned),
                "paid_amount": float(paid_amount),
                "pending_amount": float(pending_amount)
            }
    
    def get_admin_stats(self) -> Dict[str, Any]:
        """
        Получение общей статистики для администратора
        
        Returns:
            Dict: Статистика реферальной программы
        """
        with self.app.app_context():
            # Общее количество пользователей с реферальными кодами
            users_with_codes = ReferralCode.query.distinct(ReferralCode.user_id).count()
            
            # Статистика по уровням
            level_stats = {}
            for level in range(1, self.MAX_LEVEL + 1):
                count = ReferralRelation.query.filter_by(level=level).count()
                level_stats[f"level_{level}"] = count
            
            # Общая сумма вознаграждений
            total_rewards = db.session.query(db.func.sum(ReferralReward.amount)).scalar() or 0
            
            # Сумма выплаченных вознаграждений
            paid_rewards = db.session.query(db.func.sum(ReferralReward.amount))\
                .filter(ReferralReward.status == "paid").scalar() or 0
            
            # Сумма ожидающих выплат
            pending_rewards = db.session.query(db.func.sum(ReferralReward.amount))\
                .filter(ReferralReward.status == "pending").scalar() or 0
            
            # Общая статистика
            return {
                "users_with_codes": users_with_codes,
                "level_stats": level_stats,
                "total_relations": sum(level_stats.values()),
                "total_rewards": float(total_rewards),
                "paid_rewards": float(paid_rewards),
                "pending_rewards": float(pending_rewards),
                "pending_count": ReferralReward.query.filter_by(status="pending").count()
            }