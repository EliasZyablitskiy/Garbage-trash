"""
Асинхронная очередь задач для эффективной обработки выплат
"""
import asyncio
import logging
import time
import functools
from typing import Dict, Any, List, Optional, Callable, Tuple, Awaitable, TypeVar, Union, Coroutine
import traceback

logger = logging.getLogger(__name__)

# Для типизации обобщенных функций
T = TypeVar('T')
R = TypeVar('R')

class TaskQueue:
    """Асинхронная очередь задач для обработки выплат"""
    
    def __init__(self, name: str, max_workers: int = 5, max_queue_size: int = 100):
        """
        Инициализация очереди задач
        
        Args:
            name: Имя очереди (для логирования)
            max_workers: Максимальное количество параллельных обработчиков
            max_queue_size: Максимальный размер очереди
        """
        self.name = name
        self.max_workers = max_workers
        self.queue = asyncio.Queue(maxsize=max_queue_size)
        self.workers = []
        self.processing_count = 0
        self.total_processed = 0
        self.success_count = 0
        self.error_count = 0
        self.is_running = False
        self._stop_event = asyncio.Event()
        
        # Для отслеживания текущих задач
        self.active_tasks = {}
        self.task_history = []
        
    async def add_task(self, task_func: Callable[..., Awaitable[T]], *args, 
                      task_id: Optional[str] = None, priority: int = 1, **kwargs) -> str:
        """
        Добавление задачи в очередь
        
        Args:
            task_func: Асинхронная функция для выполнения
            *args: Позиционные аргументы для функции
            task_id: Уникальный ID задачи (если не указан, генерируется автоматически)
            priority: Приоритет задачи (1 - обычный, 0 - высокий)
            **kwargs: Именованные аргументы для функции
            
        Returns:
            str: ID задачи
        """
        # Если ID не указан, генерируем его
        if task_id is None:
            task_id = f"{self.name}-task-{int(time.time())}-{self.total_processed + self.queue.qsize()}"
        
        # Создаем задачу
        task = {
            "id": task_id,
            "func": task_func,
            "args": args,
            "kwargs": kwargs,
            "priority": priority,
            "created_at": time.time(),
            "status": "pending"
        }
        
        # Добавляем задачу в очередь
        await self.queue.put(task)
        
        logger.info(f"Задача {task_id} добавлена в очередь {self.name} (размер очереди: {self.queue.qsize()})")
        
        return task_id
        
    async def process_queue(self):
        """Обработка задач из очереди"""
        worker_id = len(self.workers)
        logger.info(f"Запущен обработчик {worker_id} для очереди {self.name}")
        
        while not self._stop_event.is_set():
            try:
                # Пытаемся получить задачу из очереди с таймаутом
                try:
                    task = await asyncio.wait_for(self.queue.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    # Проверяем сигнал остановки
                    continue
                
                # Получили задачу
                task_id = task["id"]
                task_func = task["func"]
                args = task["args"]
                kwargs = task["kwargs"]
                
                # Обновляем статус задачи
                task["status"] = "processing"
                task["started_at"] = time.time()
                self.active_tasks[task_id] = task
                self.processing_count += 1
                
                logger.info(f"Обработчик {worker_id} начал выполнение задачи {task_id}")
                
                try:
                    # Выполняем задачу
                    result = await task_func(*args, **kwargs)
                    
                    # Обновляем статус задачи
                    task["status"] = "completed"
                    task["completed_at"] = time.time()
                    task["result"] = result
                    task["duration"] = task["completed_at"] - task["started_at"]
                    
                    # Обновляем статистику
                    self.success_count += 1
                    
                    logger.info(f"Задача {task_id} успешно выполнена за {task['duration']:.2f} сек")
                    
                except Exception as e:
                    # В случае ошибки
                    task["status"] = "failed"
                    task["completed_at"] = time.time()
                    task["error"] = str(e)
                    task["traceback"] = traceback.format_exc()
                    task["duration"] = task["completed_at"] - task["started_at"]
                    
                    # Обновляем статистику
                    self.error_count += 1
                    
                    logger.error(f"Ошибка при выполнении задачи {task_id}: {e}")
                
                finally:
                    # Уменьшаем счетчик обрабатываемых задач
                    self.processing_count -= 1
                    self.total_processed += 1
                    
                    # Перемещаем задачу из активных в историю
                    del self.active_tasks[task_id]
                    self.task_history.append(task)
                    
                    # Если история слишком длинная, удаляем старые задачи
                    if len(self.task_history) > 1000:
                        self.task_history = self.task_history[-1000:]
                    
                    # Отмечаем задачу как выполненную в очереди
                    self.queue.task_done()
            
            except Exception as e:
                logger.error(f"Критическая ошибка в обработчике {worker_id}: {e}")
                
                # Небольшая пауза перед повторной попыткой
                await asyncio.sleep(1)
        
        logger.info(f"Обработчик {worker_id} для очереди {self.name} остановлен")
    
    async def start(self):
        """Запуск обработчиков очереди"""
        if self.is_running:
            logger.warning(f"Очередь {self.name} уже запущена")
            return
            
        logger.info(f"Запуск очереди {self.name} с {self.max_workers} обработчиками")
        
        # Сбрасываем сигнал остановки
        self._stop_event.clear()
        
        # Запускаем обработчики
        self.workers = []
        for _ in range(self.max_workers):
            worker = asyncio.create_task(self.process_queue())
            self.workers.append(worker)
            
        self.is_running = True
    
    async def stop(self, wait_for_completion: bool = True):
        """
        Остановка очереди задач
        
        Args:
            wait_for_completion: Ждать завершения всех задач в очереди
        """
        if not self.is_running:
            logger.warning(f"Очередь {self.name} не запущена")
            return
            
        logger.info(f"Остановка очереди {self.name}")
        
        # Если нужно дождаться завершения всех задач
        if wait_for_completion:
            await self.queue.join()
            
        # Отправляем сигнал остановки
        self._stop_event.set()
        
        # Ждем завершения всех обработчиков
        if self.workers:
            await asyncio.gather(*self.workers, return_exceptions=True)
            
        self.workers = []
        self.is_running = False
        
        logger.info(f"Очередь {self.name} остановлена")
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Получение статистики очереди
        
        Returns:
            Dict: Статистика очереди
        """
        return {
            "name": self.name,
            "is_running": self.is_running,
            "queue_size": self.queue.qsize(),
            "processing_count": self.processing_count,
            "total_processed": self.total_processed,
            "success_count": self.success_count,
            "error_count": self.error_count,
            "worker_count": len(self.workers),
            "active_tasks": len(self.active_tasks)
        }
    
    def get_task_info(self, task_id: str) -> Optional[Dict[str, Any]]:
        """
        Получение информации о задаче
        
        Args:
            task_id: ID задачи
            
        Returns:
            Dict: Информация о задаче или None, если задача не найдена
        """
        # Проверяем активные задачи
        if task_id in self.active_tasks:
            return self.active_tasks[task_id]
            
        # Проверяем историю задач
        for task in self.task_history:
            if task["id"] == task_id:
                return task
                
        return None


# Глобальная очередь для задач выплат
payout_queue = TaskQueue(name="payout_queue", max_workers=3)

async def enqueue_payout_task(func: Callable[..., Awaitable[T]], *args, **kwargs) -> str:
    """
    Добавление задачи выплаты в глобальную очередь
    
    Args:
        func: Асинхронная функция для выполнения
        *args: Позиционные аргументы для функции
        **kwargs: Именованные аргументы для функции
        
    Returns:
        str: ID задачи
    """
    # Проверяем, запущена ли очередь
    if not payout_queue.is_running:
        await payout_queue.start()
        
    # Добавляем задачу в очередь
    return await payout_queue.add_task(func, *args, **kwargs)

async def process_in_task_queue(task_func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[str]]:
    """
    Декоратор для выполнения функции в очереди задач
    
    Args:
        task_func: Декорируемая асинхронная функция
        
    Returns:
        Callable: Декорированная функция, которая возвращает ID задачи
    """
    @functools.wraps(task_func)
    async def wrapper(*args, **kwargs) -> str:
        return await enqueue_payout_task(task_func, *args, **kwargs)
    
    return wrapper