#!/usr/bin/env python
# coding: utf-8

"""
Новая версия централизованного сервиса проверки платежей
Предоставляет унифицированный интерфейс для верификации платежей различных типов
Поддерживает периодические проверки статусов платежей
"""

import os
import json
import logging
import hashlib
import hmac
import time
import asyncio
from enum import Enum
from datetime import datetime, timedelta
from typing import Dict, Any, Tuple, Optional, List, Union

from flask import current_app, Flask
from sqlalchemy import and_, or_, desc

from db_models import db, Transaction, User
from config import SUBSCRIPTION_DURATION_DAYS as SUBSCRIPTION_DAYS, SUBSCRIPTION_PRICE
# Импорт перенесен в методы для избежания циклических импортов
# Перенесено в методы, чтобы избежать циклических импортов

# Настройка логирования
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Создание обработчика для вывода в консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

# Создание файлового обработчика
os.makedirs('logs', exist_ok=True)
file_handler = logging.FileHandler('logs/payment_verification_v2.log')
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

# Импортируем константы из централизованного модуля
from services.payment_constants import PAYMENT_STATUS, PAYMENT_SYSTEMS

# Импортируем классы для результатов проверки платежа
from services.payment_constants import PaymentResultCode
from services.payment_result import PaymentResult

# Получение секретов из переменных окружения
ROBOKASSA_LOGIN = os.environ.get('ROBOKASSA_LOGIN', 'test_shop')
ROBOKASSA_PASSWORD1 = os.environ.get('ROBOKASSA_PASSWORD1', '')
ROBOKASSA_PASSWORD2 = os.environ.get('ROBOKASSA_PASSWORD2', '')

class PaymentVerificationServiceV2:
    """
    Улучшенный сервис верификации платежей
    """
    
    def __init__(self):
        """
        Инициализация сервиса
        """
        self.app = None
        
    def _send_payment_notification(self, payment_result: PaymentResult) -> None:
        """
        Отправка уведомления о результате проверки платежа пользователю
        
        Args:
            payment_result: Результат проверки платежа
        """
        if payment_result.user_id is None:
            payment_result.add_log("Cannot send notification: user_id is None")
            return
            
        try:
            # Получаем текущее приложение Flask
            app = current_app._get_current_object()
            if not hasattr(app, 'notification_service'):
                payment_result.add_log("Cannot send notification: notification_service not available")
                return
                
            notification_service = app.notification_service
            
            # Определяем тип уведомления в зависимости от результата проверки
            if payment_result.success:
                # Отправляем уведомление о успешном платеже через новую систему очередей
                notification_service.send_payment_verification_result(
                    user_id=payment_result.user_id,
                    payment_result=payment_result,
                    priority=True  # Высокий приоритет для платежных уведомлений
                )
                payment_result.add_log(f"Success payment notification queued for user_id={payment_result.user_id}")
            else:
                # Отправляем уведомление о неудачном платеже
                error_code = getattr(payment_result, 'result_code', PaymentResultCode.UNKNOWN)
                error_message = getattr(payment_result, 'message', 'Неизвестная ошибка')
                
                notification_service.send_payment_error_notification(
                    user_id=payment_result.user_id,
                    error_code=error_code,
                    error_message=error_message,
                    payment_details=payment_result.to_dict(),
                    priority=True  # Высокий приоритет для платежных уведомлений
                )
                payment_result.add_log(f"Error payment notification queued for user_id={payment_result.user_id}")
                
            logger.info(f"Payment notification successfully queued for user_id={payment_result.user_id}")
            
        except Exception as e:
            logger.error(f"Error sending payment notification: {str(e)}")
            payment_result.add_log(f"Failed to send payment notification: {str(e)}")
            # Добавляем расширенную информацию об ошибке в лог
            logger.exception("Detailed error while sending payment notification:")
        
    def init_app(self, app: Flask):
        """
        Инициализация приложения Flask
        
        Args:
            app: Flask-приложение
        """
        self.app = app
    
    def verify_payment_unified(self, notification_data: Dict[str, Any], payment_system: str, is_test: bool = False) -> PaymentResult:
        """
        Унифицированный метод верификации платежа для разных платежных систем
        
        Args:
            notification_data: Данные уведомления от платежной системы
            payment_system: Платежная система (из PAYMENT_SYSTEMS)
            is_test: Флаг тестового режима проверки (без проверки подписи)
            
        Returns:
            PaymentResult: Результат проверки платежа
        """
        logger.info(f"Verifying payment notification from {payment_system}")
        
        # Особая обработка тестового режима
        if is_test:
            logger.info(f"Processing payment notification in TEST mode for system: {payment_system}")
            
            # Создаем успешный тестовый результат
            if 'transaction_id' in notification_data and 'user_id' in notification_data:
                transaction_id = notification_data.get('transaction_id')
                user_id = notification_data.get('user_id')
                amount = notification_data.get('amount', '0.0')
                
                return PaymentResult(
                    success=True,
                    payment_system=payment_system,
                    transaction_id=int(transaction_id) if transaction_id else None,
                    user_id=int(user_id) if user_id else None,
                    amount=float(amount) if amount else 0.0,
                    status=notification_data.get('status', 'completed'),
                    result_code=PaymentResultCode.SUCCESS,
                    message="Test payment verification successful"
                )
            else:
                return PaymentResult.error(
                    "Test payment data missing required fields",
                    PaymentResultCode.INVALID_AMOUNT,
                    payment_system
                )
        
        # Обрабатываем платеж в зависимости от платежной системы
        if payment_system == PAYMENT_SYSTEMS['ROBOKASSA']:
            # Проверяем уведомление от Робокассы
            validation_result = self.validate_robokassa_notification(notification_data)
            return PaymentResult.from_robokassa_notification(notification_data, validation_result)
        elif payment_system == PAYMENT_SYSTEMS['SBP_LINK']:
            # Проверяем уведомление от СБП
            success, message, transaction_id = self.verify_sbp_notification(notification_data)
            validation_result = {
                'success': success,
                'message': message,
                'transaction_id': transaction_id,
                'user_id': None  # Получим из транзакции, если успешно
            }
            # Если транзакция найдена, получаем user_id
            if success and transaction_id:
                try:
                    transaction = db.session.get(Transaction, transaction_id)
                    if transaction:
                        validation_result['user_id'] = transaction.user_id
                except Exception as e:
                    logger.error(f"Error getting user_id from transaction {transaction_id}: {str(e)}")
            
            return PaymentResult.from_sbp_notification(notification_data, validation_result)
        else:
            # Неизвестная платежная система
            error_message = f"Unknown payment system: {payment_system}"
            logger.error(error_message)
            return PaymentResult.error(error_message, PaymentResultCode.UNKNOWN, payment_system)
    
    def validate_robokassa_notification(self, notification_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Проверка уведомления от Robokassa
        
        Args:
            notification_data: Данные уведомления от Robokassa
            
        Returns:
            Dict[str, Any]: Результат валидации уведомления
        """
        logger.info(f"Validating Robokassa notification: {notification_data}")
        result = {
            'success': False,
            'message': '',
            'transaction_id': None,
            'user_id': None
        }
        
        try:
            # Проверяем наличие необходимых параметров
            required_params = ['OutSum', 'InvId', 'SignatureValue']
            for param in required_params:
                if param not in notification_data:
                    result['message'] = f"Missing required parameter: {param}"
                    logger.error(result['message'])
                    return result
            
            # Получаем параметры
            out_sum = notification_data['OutSum']
            inv_id = notification_data['InvId']
            signature = notification_data['SignatureValue']
            
            # Проверяем подпись
            signature_valid = self._verify_robokassa_signature(inv_id, out_sum, signature, notification_data)
            if not signature_valid:
                result['message'] = "Invalid signature"
                logger.error(f"Invalid Robokassa signature for InvId={inv_id}")
                return result
            
            # Проверяем существование транзакции
            try:
                transaction_id = int(inv_id)
                transaction = db.session.get(Transaction, transaction_id)
                
                if not transaction:
                    result['message'] = f"Transaction not found: {transaction_id}"
                    logger.error(result['message'])
                    return result
                
                # Проверяем сумму платежа
                if abs(float(out_sum) - transaction.amount) > 0.01:  # Допускаем погрешность из-за округления
                    result['message'] = f"Amount mismatch: expected {transaction.amount}, got {out_sum}"
                    logger.error(result['message'])
                    return result
                
                # Проверяем, не обработан ли уже платеж
                if transaction.status == PAYMENT_STATUS['COMPLETED']:
                    result['message'] = f"Payment already processed: transaction_id={transaction_id}"
                    logger.info(result['message'])
                    # Считаем это успешной валидацией, но дальше не обрабатываем
                    result['success'] = True
                    result['transaction_id'] = transaction_id
                    result['user_id'] = transaction.user_id
                    return result
                
                # Все проверки прошли успешно
                result['success'] = True
                result['message'] = "Validation successful"
                result['transaction_id'] = transaction_id
                result['user_id'] = transaction.user_id
                
                logger.info(f"Robokassa notification validated successfully: InvId={inv_id}, user_id={transaction.user_id}")
                
            except ValueError:
                result['message'] = f"Invalid InvId: {inv_id}"
                logger.error(result['message'])
                return result
                
        except Exception as e:
            result['message'] = f"Error validating Robokassa notification: {str(e)}"
            logger.error(result['message'])
            
        return result
    
    def verify_sbp_notification(self, notification_data: Dict[str, Any]) -> Tuple[bool, str, Optional[int]]:
        """
        Проверка уведомления от СБП
        
        Args:
            notification_data: Данные уведомления от СБП
            
        Returns:
            Tuple[bool, str, Optional[int]]: (успех, сообщение, ID транзакции)
        """
        logger.info(f"Verifying SBP notification: {notification_data}")
        
        try:
            # Проверяем наличие необходимых параметров
            required_params = ['payment_id', 'status', 'amount']
            for param in required_params:
                if param not in notification_data:
                    return False, f"Missing required parameter: {param}", None
            
            payment_id = notification_data.get('payment_id')
            status = notification_data.get('status', '').lower()
            amount = float(notification_data.get('amount', 0))
            
            # Проверяем статус платежа
            if status not in ['success', 'completed']:
                return False, f"Payment not completed: status={status}", None
            
            # Ищем транзакцию по payment_id в метаданных
            transaction = Transaction.query.filter(
                Transaction.metadata.contains({'payment_id': payment_id})
            ).first()
            
            if not transaction:
                # Если не найдено по payment_id, попробуем поискать по order_id или другим полям
                order_id = notification_data.get('order_id')
                if order_id:
                    transaction = Transaction.query.filter(
                        Transaction.metadata.contains({'order_id': order_id})
                    ).first()
                
                # Если все еще не найдено, попробуем разобрать order_id как составной ключ
                if not transaction and order_id and '_' in order_id:
                    parts = order_id.split('_')
                    if len(parts) >= 2:
                        user_id = parts[-2]
                        order_id = parts[-1]
                        
                        # Ищем транзакцию по user_id и order_id
                        try:
                            transaction = Transaction.query.filter(
                                Transaction.user_id == int(user_id),
                                Transaction.metadata.contains({'order_id': order_id})
                            ).first()
                        except (ValueError, TypeError):
                            pass
            
            if not transaction:
                return False, f"Transaction not found for payment_id={payment_id}", None
            
            # Проверяем сумму платежа
            if abs(amount - transaction.amount) > 0.01:  # Допускаем погрешность из-за округления
                return False, f"Amount mismatch: expected {transaction.amount}, got {amount}", transaction.id
            
            # Проверяем, не обработан ли уже платеж
            if transaction.status == PAYMENT_STATUS['COMPLETED']:
                return True, f"Payment already processed: transaction_id={transaction.id}", transaction.id
            
            return True, "SBP notification verified successfully", transaction.id
            
        except Exception as e:
            logger.error(f"Error verifying SBP notification: {str(e)}")
            return False, f"Error verifying notification: {str(e)}", None
    
    def process_payment(self, payment_result: PaymentResult) -> PaymentResult:
        """
        Обработка платежа на основе результата проверки
        
        Args:
            payment_result: Объект PaymentResult с результатом проверки
            
        Returns:
            PaymentResult: Обновленный результат обработки платежа
        """
        # Обновляем статус обработки платежа
        payment_result.add_log("Starting payment processing")
        
        # Проверяем, успешен ли результат проверки
        if not payment_result.success:
            payment_result.add_log(f"Payment processing skipped: verification failed with code {payment_result.result_code.name if payment_result.result_code else 'UNKNOWN'}")
            # Отправляем уведомление о неудачной проверке платежа, если задан user_id
            self._send_payment_notification(payment_result)
            return payment_result
            
        # Начинаем детальное логирование процесса
        logger.info(f"Processing payment for transaction_id={payment_result.transaction_id}, "
                    f"user_id={payment_result.user_id}, amount={payment_result.amount}")
        payment_result.add_log(f"Processing payment for user_id={payment_result.user_id}")
        
        # Проверка существования транзакции
        if payment_result.transaction_id is None:
            payment_result.success = False
            payment_result.result_code = PaymentResultCode.PAYMENT_NOT_FOUND
            payment_result.message = "Transaction ID is missing"
            payment_result.add_log("Failed: Transaction ID is missing")
            return payment_result
        
        try:
            # Получаем транзакцию
            transaction = db.session.get(Transaction, payment_result.transaction_id)
            if not transaction:
                payment_result.success = False
                payment_result.result_code = PaymentResultCode.PAYMENT_NOT_FOUND
                payment_result.message = f"Transaction not found: {payment_result.transaction_id}"
                payment_result.add_log(payment_result.message)
                return payment_result
            
            # Проверяем, не обработан ли уже платеж
            if transaction.status == PAYMENT_STATUS['COMPLETED']:
                payment_result.add_log(f"Payment already processed: transaction_id={transaction.id}")
                return payment_result
            
            # Обновляем статус платежа
            old_status = transaction.status
            transaction.status = PAYMENT_STATUS['COMPLETED']
            transaction.updated_at = datetime.now()
            
            # Фиксируем время успешной обработки платежа
            transaction.completed_at = datetime.now()
            
            # Обновляем метаданные транзакции, если они есть в payment_result
            if payment_result.additional_data:
                try:
                    # Объединяем существующие метаданные с новыми
                    metadata = transaction.metadata if transaction.metadata else {}
                    
                    # Проверяем тип метаданных и преобразуем в словарь если необходимо
                    if not isinstance(metadata, dict):
                        metadata = {}
                    
                    # Обновляем метаданные новыми данными
                    if isinstance(payment_result.additional_data, dict):
                        metadata.update(payment_result.additional_data)
                    
                    # Добавляем информацию о верификации платежа
                    metadata['verification'] = {
                        'timestamp': datetime.now().isoformat(),
                        'payment_system': payment_result.payment_system,
                        'result_code': payment_result.result_code.name
                    }
                    transaction.metadata = metadata
                    payment_result.add_log(f"Transaction metadata updated successfully")
                except Exception as e:
                    payment_result.add_log(f"Error updating metadata: {str(e)}")
                    logger.warning(f"Ошибка при обновлении метаданных транзакции #{transaction.id}: {str(e)}")
            
            payment_result.add_log(f"Transaction status updated: {old_status} -> {PAYMENT_STATUS['COMPLETED']}")
            logger.info(f"Успешно обновлен статус транзакции #{transaction.id} для пользователя {transaction.user_id}: {old_status} -> {PAYMENT_STATUS['COMPLETED']}")
            
            # Сохраняем изменения в рамках транзакции БД
            try:
                db.session.commit()
                payment_result.add_log(f"Transaction #{transaction.id} updated in database")
            except Exception as db_error:
                db.session.rollback()
                payment_result.success = False
                payment_result.result_code = PaymentResultCode.DATABASE_ERROR
                payment_result.message = f"Database error: {str(db_error)}"
                payment_result.add_log(f"Failed to update transaction: {str(db_error)}")
                logger.error(f"Ошибка БД при обновлении транзакции #{transaction.id}: {str(db_error)}")
                return payment_result
            
            # Активируем подписку пользователя, если это платеж за подписку
            if transaction.type == 'subscription_payment':
                payment_result.add_log(f"Activating subscription for user_id={transaction.user_id}")
                subscription_result = self._activate_user_subscription(transaction.user_id, transaction.id, payment_result)
                if not subscription_result:
                    payment_result.add_log(f"Failed to activate subscription for user_id={transaction.user_id}")
                    logger.warning(f"Не удалось активировать подписку для пользователя {transaction.user_id} после успешного платежа #{transaction.id}")
            
            # Обрабатываем реферальные вознаграждения, если применимо
            try:
                self._process_referral_reward(transaction.user_id, payment_result)
                payment_result.add_log(f"Referral rewards processed for transaction #{transaction.id}")
            except Exception as ref_error:
                logger.error(f"Ошибка при обработке реферальных вознаграждений для транзакции #{transaction.id}: {str(ref_error)}")
                payment_result.add_log(f"Error processing referral rewards: {str(ref_error)}")
            
            # Отправляем уведомление о успешной оплате, если не было отправлено в _activate_user_subscription
            if transaction.type != 'subscription_payment' and transaction.user_id:
                self._send_payment_notification(transaction.user_id, transaction, payment_result)
            
            return payment_result
            
        except Exception as e:
            payment_result.success = False
            payment_result.result_code = PaymentResultCode.SYSTEM_ERROR
            payment_result.message = f"Error processing payment: {str(e)}"
            payment_result.add_log(f"Failed to process payment: {str(e)}")
            logger.error(f"Ошибка при обработке платежа: {str(e)}")
            return payment_result
    
    def update_payment_status(self, transaction_id: int, new_status: str,
                             metadata: Optional[Dict[str, Any]] = None) -> Tuple[bool, str]:
        """
        Обновление статуса платежа
        
        Args:
            transaction_id: ID транзакции
            new_status: Новый статус платежа (из PAYMENT_STATUS)
            metadata: Дополнительные метаданные для обновления
            
        Returns:
            Tuple[bool, str]: (успех, сообщение)
        """
        logger.info(f"Updating payment status for transaction_id={transaction_id} to {new_status}")
        
        try:
            # Получаем транзакцию
            transaction = db.session.get(Transaction, transaction_id)
            if not transaction:
                error_msg = f"Transaction not found: {transaction_id}"
                logger.error(error_msg)
                return False, error_msg
            
            # Сохраняем старый статус для логирования
            old_status = transaction.status
            
            # Проверяем валидность нового статуса
            if new_status not in PAYMENT_STATUS.values():
                error_msg = f"Invalid status: {new_status}"
                logger.error(error_msg)
                return False, error_msg
            
            # Обновляем статус и время обновления
            transaction.status = new_status
            transaction.updated_at = datetime.now()
            
            # Если статус "completed", обновляем также completed_at
            if new_status == PAYMENT_STATUS['COMPLETED']:
                transaction.completed_at = datetime.now()
            
            # Обновляем метаданные, если они предоставлены
            if metadata:
                # Объединяем существующие метаданные с новыми
                current_metadata = transaction.metadata or {}
                current_metadata.update(metadata)
                transaction.metadata = current_metadata
            
            # Сохраняем изменения
            db.session.commit()
            
            logger.info(f"Payment status updated for transaction_id={transaction_id}: {old_status} -> {new_status}")
            
            # Если статус изменился на "completed", выполняем дополнительные действия
            if new_status == PAYMENT_STATUS['COMPLETED'] and old_status != PAYMENT_STATUS['COMPLETED']:
                # Если это платеж за подписку, активируем подписку
                if transaction.type == 'subscription_payment':
                    subscription_success = self._activate_user_subscription(transaction.user_id, transaction.id)
                    if not subscription_success:
                        logger.warning(f"Failed to activate subscription for user_id={transaction.user_id}")
                
                # Отправляем уведомление о успешной оплате
                try:
                    # Создаем простой PaymentResult для уведомления
                    payment_result = PaymentResult.create_success(
                        transaction_id=transaction.id,
                        status=PAYMENT_STATUS['COMPLETED'],
                        message="Payment completed successfully"
                    )
                    self._send_payment_notification(transaction.user_id, transaction, payment_result)
                except Exception as notif_error:
                    logger.error(f"Error sending payment notification: {str(notif_error)}")
            
            return True, f"Status updated to {new_status}"
            
        except Exception as e:
            db.session.rollback()
            error_msg = f"Error updating payment status: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    def create_payment_transaction(self, user_id: int, amount: float, payment_method: str,
                                  description: str = "Оплата подписки",
                                  metadata: Optional[Dict[str, Any]] = None) -> Tuple[bool, str, Optional[int]]:
        """
        Создание транзакции платежа
        
        Args:
            user_id: ID пользователя
            amount: Сумма платежа
            payment_method: Метод оплаты (из PAYMENT_SYSTEMS)
            description: Описание платежа
            metadata: Дополнительные метаданные
            
        Returns:
            Tuple[bool, str, Optional[int]]: (успех, сообщение, ID транзакции)
        """
        logger.info(f"Creating payment transaction for user_id={user_id}, amount={amount}, method={payment_method}")
        
        try:
            # Проверяем существование пользователя
            user = db.session.get(User, user_id)
            if not user:
                error_msg = f"User not found: {user_id}"
                logger.error(error_msg)
                return False, error_msg, None
            
            # Проверяем валидность метода оплаты
            if payment_method not in PAYMENT_SYSTEMS.values():
                error_msg = f"Invalid payment method: {payment_method}"
                logger.error(error_msg)
                return False, error_msg, None
            
            # Создаем новую транзакцию
            transaction = Transaction(
                user_id=user_id,
                amount=amount,
                type='subscription_payment',  # По умолчанию - платеж за подписку
                status=PAYMENT_STATUS['INITIATED'],
                payment_method=payment_method,
                description=description,
                metadata=metadata or {}
            )
            
            # Генерируем уникальный order_id, если его нет в метаданных
            if not transaction.metadata.get('order_id'):
                order_id = f"{int(time.time())}_{user_id}_{hash(str(datetime.now()))}"[-20:]
                if not transaction.metadata:
                    transaction.metadata = {}
                transaction.metadata['order_id'] = order_id
            
            # Сохраняем транзакцию
            db.session.add(transaction)
            db.session.commit()
            
            logger.info(f"Payment transaction created: id={transaction.id}, user_id={user_id}, amount={amount}")
            
            return True, "Transaction created successfully", transaction.id
            
        except Exception as e:
            db.session.rollback()
            error_msg = f"Error creating payment transaction: {str(e)}"
            logger.error(error_msg)
            return False, error_msg, None
    
    def _verify_robokassa_signature(self, inv_id: str, outsum: str, signature: str, 
                                  notification_data: Optional[Dict[str, Any]] = None) -> bool:
        """
        Проверка подписи уведомления от Robokassa
        
        Args:
            inv_id: ID инвойса
            outsum: Сумма платежа
            signature: Подпись для проверки
            notification_data: Полные данные уведомления (для проверки Shp_ параметров)
            
        Returns:
            bool: True, если подпись верна, False в противном случае
        """
        logger.info(f"Verifying Robokassa signature for InvId={inv_id}, OutSum={outsum}")
        
        # Проверяем наличие секретного пароля
        if not ROBOKASSA_PASSWORD2:
            logger.error("ROBOKASSA_PASSWORD2 environment variable not set or empty")
            return False
        
        # Формируем строку для проверки подписи (без Shp_ параметров)
        check_string = f"{outsum}:{inv_id}:{ROBOKASSA_PASSWORD2}"
        
        # Добавляем Shp_ параметры, если они есть
        added_shp_params = []  # Для логирования
        if notification_data:
            # Собираем все Shp_ параметры
            shp_params = {}
            for key, value in notification_data.items():
                if key.startswith('Shp_'):
                    shp_params[key] = value
                    added_shp_params.append(key)
            
            # Сортируем Shp_ параметры по имени (регистронезависимо)
            sorted_params = sorted(shp_params.items(), key=lambda x: x[0].lower())
            
            # Добавляем отсортированные Shp_ параметры к строке проверки
            for key, value in sorted_params:
                check_string += f":{key}={value}"
        
        # Добавляем информацию о параметрах в лог
        if added_shp_params:
            logger.info(f"Added Shp_ parameters to signature check: {', '.join(added_shp_params)}")
        
        # Логируем строку для проверки подписи (без пароля для безопасности)
        safe_check_string = check_string.replace(ROBOKASSA_PASSWORD2, "********")
        logger.debug(f"Check string (before hashing): {safe_check_string}")
        
        # Вычисляем хеш
        hash_value = hashlib.md5(check_string.encode('utf-8')).hexdigest().upper()
        
        # Сравниваем вычисленный хеш с полученной подписью (регистронезависимо)
        is_valid = hash_value.upper() == signature.upper()
        
        if is_valid:
            logger.info(f"Signature is valid for InvId={inv_id}")
        else:
            logger.warning(f"Invalid signature for InvId={inv_id}")
            logger.warning(f"Expected: {hash_value.upper()}, Received: {signature.upper()}")
        
        return is_valid
    
    def _activate_user_subscription(self, user_id: int, transaction_id: Optional[int] = None, 
                                   payment_result: Optional[PaymentResult] = None) -> bool:
        """
        Активация подписки пользователя после успешного платежа
        
        Args:
            user_id: ID пользователя
            transaction_id: ID транзакции (опционально)
            payment_result: Объект PaymentResult с результатом обработки платежа (опционально)
            
        Returns:
            bool: True, если подписка успешно активирована, False в противном случае
        """
        log_prefix = f"[Activate subscription] user_id={user_id}"
        logger.info(f"{log_prefix}: Starting subscription activation")
        
        if payment_result:
            payment_result.add_log(f"Activating subscription for user_id={user_id}")
        
        try:
            # Получаем пользователя
            user = db.session.get(User, user_id)
            if not user:
                error_msg = f"{log_prefix}: User not found"
                logger.error(error_msg)
                if payment_result:
                    payment_result.add_log(error_msg)
                return False
            
            # Определяем дату окончания подписки
            now = datetime.now()
            
            # Если подписка еще активна, продлеваем ее от текущей даты окончания
            if user.subscription_expiry and user.subscription_expiry > now:
                new_expiry = user.subscription_expiry + timedelta(days=SUBSCRIPTION_DAYS)
                logger.info(f"{log_prefix}: Extending subscription from {user.subscription_expiry} to {new_expiry}")
            else:
                # Иначе устанавливаем новую дату окончания от текущей даты
                new_expiry = now + timedelta(days=SUBSCRIPTION_DAYS)
                logger.info(f"{log_prefix}: Setting new subscription expiry to {new_expiry}")
            
            # Обновляем даты подписки
            user.subscription_active = True
            user.subscription_expiry = new_expiry
            user.subscription_end = new_expiry  # Дублируем для совместимости со старым кодом
            
            # Фиксируем время последней активации подписки
            user.last_subscription_date = now
            
            # Сохраняем изменения
            db.session.commit()
            
            # Отправляем уведомление пользователю
            self._send_subscription_notification(user, payment_result)
            
            logger.info(f"{log_prefix}: Subscription activated successfully until {new_expiry}")
            if payment_result:
                payment_result.add_log(f"Subscription activated until {new_expiry}")
            
            return True
            
        except Exception as e:
            db.session.rollback()
            error_msg = f"{log_prefix}: Error activating subscription: {str(e)}"
            logger.error(error_msg)
            if payment_result:
                payment_result.add_log(f"Error activating subscription: {str(e)}")
            return False
    
    def _send_subscription_notification(self, user, payment_result=None) -> None:
        """
        Отправка уведомления о активации подписки
        
        Args:
            user: Пользователь, которому отправляется уведомление
            payment_result: Результат обработки платежа (опционально)
        """
        try:
            # Получаем сервис уведомлений
            notification_service = self._get_notification_service()
            if not notification_service:
                logger.error(f"Cannot send subscription notification: notification service not available")
                return
            
            # Форматируем дату окончания подписки
            expiry_date = user.subscription_expiry
            expiry_str = expiry_date.strftime('%d.%m.%Y') if expiry_date else 'Неизвестно'
            
            # Отправляем уведомление о успешной активации подписки
            notification_service.send_subscription_activated_notification(
                user_id=user.id,
                expiry_date=expiry_str,
                transaction_id=payment_result.transaction_id if payment_result else None
            )
            
            if payment_result:
                payment_result.add_log(f"Subscription notification sent to user_id={user.id}")
            
            logger.info(f"Subscription notification sent to user_id={user.id}")
            
        except Exception as e:
            logger.error(f"Error sending subscription notification to user_id={user.id}: {str(e)}")
            if payment_result:
                payment_result.add_log(f"Error sending subscription notification: {str(e)}")
    
    def _get_notification_service(self):
        """
        Получение сервиса уведомлений
        
        Returns:
            NotificationService: Сервис уведомлений
        """
        try:
            # Импортируем сервис уведомлений напрямую
            from services.notification_service import notification_service
            return notification_service
        except Exception as e:
            logger.error(f"Error getting notification service: {str(e)}")
            return None
    
    def _send_payment_notification(self, user_id, transaction, payment_result) -> None:
        """
        Отправка уведомления о платеже
        
        Args:
            user_id: ID пользователя
            transaction: Объект транзакции
            payment_result: Результат обработки платежа
        """
        try:
            # Получаем сервис уведомлений
            notification_service = self._get_notification_service()
            if not notification_service:
                logger.error(f"Cannot send payment notification: notification service not available")
                return
            
            # Определяем тип уведомления в зависимости от статуса транзакции
            if transaction.status == PAYMENT_STATUS['COMPLETED']:
                # Отправляем уведомление о успешном платеже
                notification_service.send_payment_success_notification(
                    user_id=user_id,
                    amount=transaction.amount,
                    transaction_id=transaction.id,
                    payment_method=transaction.payment_method
                )
                logger.info(f"Payment success notification sent to user_id={user_id}")
            elif transaction.status == PAYMENT_STATUS['FAILED']:
                # Отправляем уведомление о неудачном платеже
                notification_service.send_payment_failed_notification(
                    user_id=user_id,
                    amount=transaction.amount,
                    transaction_id=transaction.id,
                    error_message=payment_result.message if payment_result else "Платеж не прошел"
                )
                logger.info(f"Payment failed notification sent to user_id={user_id}")
            
            if payment_result:
                payment_result.add_log(f"Payment notification sent to user_id={user_id}")
            
        except Exception as e:
            logger.error(f"Error sending payment notification to user_id={user_id}: {str(e)}")
            if payment_result:
                payment_result.add_log(f"Error sending payment notification: {str(e)}")
    
    def _process_referral_reward(self, user_id, payment_result=None) -> None:
        """
        Обработка реферальных вознаграждений
        
        Args:
            user_id: ID пользователя, совершившего оплату
            payment_result: Результат обработки платежа (опционально)
        """
        log_prefix = f"[Referral reward] user_id={user_id}"
        logger.info(f"{log_prefix}: Processing referral rewards")
        
        if payment_result:
            payment_result.add_log("Processing referral rewards")
        
        try:
            # Проверяем, есть ли у пользователя реферер
            user = db.session.get(User, user_id)
            if not user or not user.referrer_id:
                logger.info(f"{log_prefix}: No referrer found, skipping reward processing")
                return
            
            # Импортируем функцию обработки комиссии для рефералов
            from services.referral_service import process_referral_commission
            
            # Обрабатываем комиссию
            result = process_referral_commission(user_id)
            
            if result and payment_result:
                payment_result.add_log(f"Referral rewards processed successfully: {result}")
            
            logger.info(f"{log_prefix}: Referral rewards processed successfully: {result}")
            
        except Exception as e:
            error_msg = f"{log_prefix}: Error processing referral rewards: {str(e)}"
            logger.error(error_msg)
            if payment_result:
                payment_result.add_log(f"Error processing referral rewards: {str(e)}")

# Функция для периодической проверки платежей
async def check_pending_payments():
    """
    Проверяет ожидающие платежи и обновляет их статусы при необходимости
    Функция вызывается по расписанию для проверки платежей в статусе PENDING
    """
    try:
        logger.info("Запуск проверки ожидающих платежей")
        
        # Создаем контекст Flask-приложения
        from flask import current_app
        
        # Получаем список ожидающих платежей
        with current_app.app_context():
            # Импортируем модели внутри контекста
            from db_models import db, Transaction
            
            # Получаем список платежей в статусе "pending"
            pending_payments = Transaction.query.filter_by(
                status=PAYMENT_STATUS['PENDING']
            ).all()
            
            logger.info(f"Найдено {len(pending_payments)} ожидающих платежей")
            
            for payment in pending_payments:
                try:
                    # Проверяем статус платежа через платежную систему
                    logger.info(f"Проверка платежа {payment.id}, метод: {payment.payment_method}")
                    
                    # Создаем экземпляр сервиса верификации
                    payment_result = None
                    
                    # В зависимости от метода платежа, выбираем нужный обработчик
                    if payment.payment_method == 'robokassa':
                        # Получаем данные платежа
                        payment_data = {
                            'inv_id': payment.external_id,
                            'outsum': str(payment.amount),
                            'user_id': str(payment.user_id),
                            'payment_method': 'robokassa'
                        }
                        
                        # Проверяем статус платежа
                        payment_result = payment_verification_service_v2.verify_payment_unified(
                            payment_data, 
                            PAYMENT_STATUS['ROBOKASSA']
                        )
                    
                    # Если получили результат проверки
                    if payment_result and payment_result.success:
                        # Обновляем статус платежа
                        payment.status = PAYMENT_STATUS['COMPLETED']
                        payment.updated_at = datetime.now()
                        
                        # Сохраняем изменения в базе данных
                        db.session.commit()
                        
                        logger.info(f"Платеж {payment.id} успешно обработан")
                        
                        # Отправляем уведомление пользователю
                        try:
                            # Импортируем сервис подписок
                            from services.subscription_service import activate_subscription
                            
                            # Активируем подписку
                            activation_result = activate_subscription(payment.user_id)
                            
                            if activation_result.success:
                                logger.info(f"Подписка для пользователя {payment.user_id} успешно активирована")
                                
                                # Отправляем уведомление через NotificationService
                                # Импортируем здесь для избежания циклических импортов
                                from services.notification_service import NotificationService
                                notification_service = NotificationService()
                                await notification_service.send_subscription_activated_notification(
                                    user_id=payment.user_id,
                                    data={
                                        'transaction_id': payment.id,
                                        'amount': payment.amount,
                                        'payment_method': payment.payment_method
                                    }
                                )
                            else:
                                logger.error(f"Ошибка активации подписки: {activation_result.message}")
                        except Exception as e:
                            logger.error(f"Ошибка при отправке уведомления: {str(e)}")
                    elif payment_result:
                        logger.info(f"Платеж {payment.id} не подтвержден: {payment_result.message}")
                    else:
                        logger.warning(f"Не удалось получить результат проверки для платежа {payment.id}")
                
                except Exception as e:
                    logger.error(f"Ошибка при проверке платежа {payment.id}: {str(e)}")
                    continue
    
    except Exception as e:
        logger.error(f"Ошибка при проверке ожидающих платежей: {str(e)}")

async def check_pending_payments():
    """
    Проверяет все платежи со статусом "PENDING" и обновляет их статус
    Эта функция запускается периодически через планировщик задач
    
    Returns:
        int: Количество обработанных платежей
    """
    try:
        logger.info("Запущена проверка ожидающих платежей")
        from flask import current_app
        import asyncio
        
        processed_count = 0
        
        # Получаем список ожидающих платежей
        with current_app.app_context():
            # Импортируем модели внутри контекста
            from db_models import db, Transaction
            # Импорт NotificationService выполняется внутри функции для избежания циклического импорта
            from services.subscription_service import activate_subscription
            
            # Используем Instance Lock чтобы избежать параллельного запуска
            from services.instance_lock_service import InstanceLockService
            lock_service = InstanceLockService()
            
            # Пытаемся захватить блокировку
            if not lock_service.acquire_lock("check_pending_payments", timeout=300):
                logger.warning("Другой процесс уже выполняет проверку платежей. Завершение.")
                return 0
            
            try:
                # Получаем транзакции в статусе PENDING, созданные более 5 минут назад
                # (чтобы дать время платежной системе обработать новые платежи)
                five_minutes_ago = datetime.now() - timedelta(minutes=5)
                
                pending_payments = Transaction.query.filter(
                    Transaction.status == PAYMENT_STATUS['PENDING'],
                    Transaction.created_at <= five_minutes_ago
                ).all()
                
                logger.info(f"Найдено {len(pending_payments)} ожидающих платежей")
                
                for payment in pending_payments:
                    try:
                        # Проверяем статус платежа через платежную систему
                        logger.info(f"Проверка платежа {payment.id}, метод: {payment.payment_method}")
                        
                        payment_result = None
                        
                        # В зависимости от метода платежа, выбираем нужный обработчик
                        if payment.payment_method == 'robokassa':
                            # Получаем данные платежа
                            payment_data = {
                                'inv_id': payment.external_id,
                                'outsum': str(payment.amount),
                                'user_id': str(payment.user_id),
                                'payment_method': 'robokassa'
                            }
                            
                            # Проверяем статус платежа
                            payment_result = payment_verification_service_v2.verify_payment_unified(
                                payment_data, 
                                PAYMENT_STATUS['ROBOKASSA']
                            )
                        
                        # Если получили результат проверки
                        if payment_result and payment_result.success:
                            # Обновляем статус платежа
                            payment.status = PAYMENT_STATUS['COMPLETED']
                            payment.updated_at = datetime.now()
                            
                            # Сохраняем изменения в базе данных
                            db.session.commit()
                            
                            logger.info(f"Платеж {payment.id} успешно обработан")
                            processed_count += 1
                            
                            # Отправляем уведомление пользователю и активируем подписку
                            try:
                                # Активируем подписку
                                activation_result = activate_subscription(payment.user_id)
                                
                                if activation_result.success:
                                    logger.info(f"Подписка для пользователя {payment.user_id} успешно активирована")
                                    
                                    # Отправляем уведомление через NotificationService
                                    # Импортируем здесь для избежания циклических импортов
                                    from services.notification_service import NotificationService
                                    notification_service = NotificationService()
                                    await notification_service.send_subscription_activated_notification(
                                        user_id=payment.user_id,
                                        data={
                                            'transaction_id': payment.id,
                                            'amount': payment.amount,
                                            'payment_method': payment.payment_method
                                        }
                                    )
                                else:
                                    logger.error(f"Ошибка активации подписки: {activation_result.message}")
                            except Exception as e:
                                logger.error(f"Ошибка при отправке уведомления: {str(e)}")
                        
                        elif payment_result and payment_result.result_code == PaymentResultCode.PAYMENT_NOT_FOUND:
                            # Платеж не найден в системе, возможно была ошибка или отмена
                            # Если платеж старше 24 часов, помечаем его как FAILED
                            one_day_ago = datetime.now() - timedelta(days=1)
                            if payment.created_at <= one_day_ago:
                                payment.status = PAYMENT_STATUS['FAILED']
                                payment.updated_at = datetime.now()
                                payment.notes = "Платеж не найден в системе после 24 часов"
                                db.session.commit()
                                logger.info(f"Платеж {payment.id} помечен как FAILED (не найден)")
                        
                        elif payment_result:
                            logger.info(f"Платеж {payment.id} не подтвержден: {payment_result.message}")
                        else:
                            logger.warning(f"Не удалось получить результат проверки для платежа {payment.id}")
                    
                    except Exception as e:
                        logger.error(f"Ошибка при проверке платежа {payment.id}: {str(e)}")
                        continue
            
            finally:
                # Освобождаем блокировку в любом случае
                lock_service.release_lock("check_pending_payments")
        
        logger.info(f"Проверка платежей завершена. Обработано: {processed_count}")
        return processed_count
        
    except Exception as e:
        logger.error(f"Ошибка при проверке ожидающих платежей: {str(e)}")
        return 0

# Создаем экземпляр сервиса
payment_verification_service_v2 = PaymentVerificationServiceV2()