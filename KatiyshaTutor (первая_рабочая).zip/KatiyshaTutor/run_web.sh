#!/bin/bash

# Запускаем веб-приложение на порту 5000
gunicorn --bind 0.0.0.0:5000 --reload app:app