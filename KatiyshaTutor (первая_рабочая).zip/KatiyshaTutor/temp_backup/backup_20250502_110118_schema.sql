-- Database Backup created on 2025-05-02T11:01:18.111200
-- Database: neondb
-- Type: Schema only
-- Created by Katiysha Bot Backup Script

-- Reset and recreate schema
BEGIN;
SET client_min_messages TO WARNING;

