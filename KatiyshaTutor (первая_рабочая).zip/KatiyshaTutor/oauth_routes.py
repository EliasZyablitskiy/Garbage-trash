#!/usr/bin/env python3
"""
Маршруты OAuth для Яндекс.Диска, интегрированные в существующий Flask-сервер
"""
import os
import sys
import requests
import json
import logging
import datetime
from flask import Blueprint, request, redirect, url_for, render_template_string

# Настройка логирования
logger = logging.getLogger(__name__)

# Создаем Blueprint
oauth_bp = Blueprint('oauth', __name__)

# Получаем переменные окружения
YANDEX_OAUTH_CLIENT_ID = os.environ.get("YANDEX_OAUTH_CLIENT_ID")
YANDEX_OAUTH_CLIENT_SECRET = os.environ.get("YANDEX_OAUTH_CLIENT_SECRET")
REPLIT_DOMAIN = os.environ.get("REPLIT_DOMAINS", "").split(",")[0]

# URL для авторизации пользователя на Яндекс.Диске
# Используем специальный URL для приложений без веб-сервера
CALLBACK_PATH = "/oauth/callback"
VERIFICATION_URI = "https://oauth.yandex.ru/verification_code"

# Попытаемся использовать различные варианты redirect_uri
# Создаем список возможных redirect_uri в порядке приоритета
REDIRECT_URIS = [
    # Специальный URI для приложений без веб-сервера
    VERIFICATION_URI,
    # Replit домен
    f"https://{REPLIT_DOMAIN}{CALLBACK_PATH}",
    # Локальное окружение для разработки
    f"https://127.0.0.1:5000{CALLBACK_PATH}",
    # Другие возможные варианты
    f"http://127.0.0.1:5000{CALLBACK_PATH}",
    f"https://localhost:5000{CALLBACK_PATH}",
    f"http://localhost:5000{CALLBACK_PATH}"
]

# URL для авторизации
# Используем верификационный код по умолчанию
REDIRECT_URI = VERIFICATION_URI
AUTH_URL = f"https://oauth.yandex.ru/authorize?response_type=code&client_id={YANDEX_OAUTH_CLIENT_ID}&redirect_uri={REDIRECT_URI}&scope=disk:read+disk:write"

# HTML шаблоны
INDEX_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Яндекс.Диск OAuth</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .container {
            background-color: #f5f5f5;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
        }
        .button {
            display: inline-block;
            background-color: #fc0;
            color: #000;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            margin-top: 20px;
        }
        .button:hover {
            background-color: #f2c200;
        }
        .success {
            color: green;
            font-weight: bold;
        }
        .error {
            color: red;
            font-weight: bold;
        }
        .debug-info {
            margin-top: 30px;
            padding: 10px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 12px;
        }
        .code {
            font-family: monospace;
            background-color: #eee;
            padding: 2px 5px;
            border-radius: 3px;
        }
        .form-group {
            margin-top: 30px;
            border-top: 1px solid #ddd;
            padding-top: 20px;
        }
        .input-field {
            padding: 8px;
            width: 100%;
            max-width: 300px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .submit-button {
            background-color: #4CAF50;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        .submit-button:hover {
            background-color: #45a049;
        }
        .steps {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin: 20px 0;
        }
        .step {
            margin-bottom: 15px;
        }
        .note {
            background-color: #fffbd8;
            border-left: 4px solid #f5c71a;
            padding: 10px;
            margin-top: 20px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <h1>Авторизация на Яндекс.Диске</h1>
    <div class="container">
        <p>Для работы с резервными копиями базы данных необходимо авторизоваться на Яндекс.Диске.</p>
        {% if error %}
        <p class="error">{{ error }}</p>
        {% endif %}
        {% if success %}
        <p class="success">{{ success }}</p>
        {% endif %}
        
        <div class="steps">
            <h3>Инструкция по авторизации:</h3>
            <div class="step">
                <strong>1.</strong> Нажмите на кнопку ниже для авторизации на Яндекс.Диске:
                <div style="margin-top: 10px;">
                    <a href="{{ auth_url }}" class="button" target="_blank">Авторизоваться на Яндекс.Диске</a>
                </div>
            </div>
            <div class="step">
                <strong>2.</strong> Войдите в свой аккаунт Яндекс и разрешите доступу приложению.
            </div>
            <div class="step">
                <strong>3.</strong> Вы получите код авторизации. Скопируйте его и вставьте в поле ниже:
            </div>
        </div>
        
        <div class="form-group">
            <form method="post" action="/oauth/manual">
                <label for="verification_code">Введите код авторизации:</label><br>
                <input type="text" id="verification_code" name="verification_code" class="input-field" required placeholder="Вставьте код здесь"><br>
                <input type="submit" value="Активировать" class="submit-button">
            </form>
        </div>
        
        <div class="note">
            <p><strong>Примечание:</strong> Если у вас возникают проблемы с авторизацией через веб-интерфейс, вы можете запустить скрипт <code>python yandex_oauth_helper.py</code> в терминале.</p>
        </div>
        
        <div class="debug-info">
            <h3>Информация для отладки</h3>
            <p>Если возникает ошибка с redirect_uri, убедитесь, что один из этих URL указан в настройках приложения Яндекс.OAuth:</p>
            <ul>
                {% for uri in redirect_uris %}
                <li><span class="code">{{ uri }}</span></li>
                {% endfor %}
            </ul>
            <p>Текущий используемый redirect_uri: <span class="code">{{ current_uri }}</span></p>
        </div>
    </div>
</body>
</html>
"""

SUCCESS_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Яндекс.Диск OAuth - Успех</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .container {
            background-color: #f5f5f5;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
        }
        .success {
            color: green;
            font-weight: bold;
        }
        .code {
            background-color: #eee;
            padding: 10px;
            border-radius: 5px;
            font-family: monospace;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <h1>Авторизация успешна!</h1>
    <div class="container">
        <p class="success">Вы успешно авторизовались на Яндекс.Диске.</p>
        <p>Токен доступа успешно сохранен в базе данных.</p>
        <p>Теперь вы можете использовать функции резервного копирования:</p>
        <ul>
            <li>Создание резервной копии: <code>python backup_database.py</code></li>
            <li>Восстановление из резервной копии: <code>python restore_database.py</code></li>
        </ul>
        <p>Вы можете закрыть эту страницу.</p>
    </div>
</body>
</html>
"""

@oauth_bp.route('/')
def index():
    """Главная страница OAuth"""
    error = request.args.get('error')
    success = request.args.get('success')
    return render_template_string(
        INDEX_TEMPLATE, 
        auth_url=AUTH_URL, 
        error=error, 
        success=success,
        redirect_uris=REDIRECT_URIS,
        current_uri=REDIRECT_URI
    )

@oauth_bp.route('/callback')
def callback():
    """Обработчик OAuth-колбэка"""
    code = request.args.get('code')
    
    if not code:
        error = request.args.get('error', 'Неизвестная ошибка')
        error_description = request.args.get('error_description', '')
        full_error = f"{error}: {error_description}" if error_description else error
        logger.error(f"Ошибка OAuth: {full_error}")
        return redirect(url_for('oauth.index', error=full_error))
    
    # Получаем токен доступа
    token_data = get_token(code)
    
    if not token_data:
        return redirect(url_for('oauth.index', error='Не удалось получить токен доступа'))
    
    # Сохраняем токен в базу данных
    if not save_token(token_data):
        return redirect(url_for('oauth.index', error='Не удалось сохранить токен в базе данных'))
    
    # Возвращаем страницу успешной авторизации
    return render_template_string(SUCCESS_TEMPLATE)

@oauth_bp.route('/manual', methods=['POST'])
def manual_code():
    """Обработчик ручного ввода кода авторизации"""
    code = request.form.get('verification_code')
    
    if not code:
        return redirect(url_for('oauth.index', error='Код авторизации не может быть пустым'))
    
    logger.info(f"Получен код авторизации через форму: {code[:5]}...")
    
    # Используем только verification_uri для ручного ввода кода
    global REDIRECT_URI
    REDIRECT_URI = VERIFICATION_URI
    
    # Получаем токен доступа
    token_data = get_token(code)
    
    if not token_data:
        return redirect(url_for('oauth.index', error='Не удалось получить токен доступа. Проверьте правильность кода.'))
    
    # Сохраняем токен в базу данных
    if not save_token(token_data):
        return redirect(url_for('oauth.index', error='Не удалось сохранить токен в базе данных'))
    
    # Возвращаем страницу успешной авторизации
    return render_template_string(SUCCESS_TEMPLATE)

def get_token(code):
    """
    Обменивает код авторизации на токен доступа.
    Пробует разные redirect_uri, если первый не сработал.
    
    Args:
        code: Код авторизации от Яндекс.OAuth
        
    Returns:
        dict: Информация о токене или None в случае ошибки
    """
    url = "https://oauth.yandex.ru/token"
    
    # Перебираем все варианты redirect_uri
    for redirect_uri in REDIRECT_URIS:
        try:
            logger.info(f"Пробуем получить токен с redirect_uri: {redirect_uri}")
            
            # Отправляем запрос на получение токена
            data = {
                "grant_type": "authorization_code",
                "code": code,
                "client_id": YANDEX_OAUTH_CLIENT_ID,
                "client_secret": YANDEX_OAUTH_CLIENT_SECRET,
                "redirect_uri": redirect_uri
            }
            
            response = requests.post(url, data=data)
            
            # Если запрос успешный, возвращаем данные
            if response.status_code == 200:
                token_data = response.json()
                logger.info(f"Токен доступа успешно получен с redirect_uri: {redirect_uri}")
                # Сохраняем успешный redirect_uri как глобальный
                global REDIRECT_URI
                REDIRECT_URI = redirect_uri
                return token_data
                
        except Exception as e:
            logger.error(f"Ошибка получения токена с {redirect_uri}: {e}")
            continue
    
    # Если ни один вариант не сработал
    logger.error("Не удалось получить токен доступа ни с одним из вариантов redirect_uri")
    return None

def save_token(token_data):
    """
    Сохраняет токен в базу данных
    
    Args:
        token_data: Информация о токене
        
    Returns:
        bool: True, если токен успешно сохранен, иначе False
    """
    try:
        # Импортируем модули для работы с БД
        from db_models import db, YandexDiskToken
        
        # Удаляем существующие токены
        YandexDiskToken.query.delete()
        
        # Создаем новый токен
        token = YandexDiskToken(
            access_token=token_data.get("access_token"),
            refresh_token=token_data.get("refresh_token"),
            token_type=token_data.get("token_type", "Bearer")
        )
        
        # Устанавливаем время истечения токена
        expires_in = token_data.get("expires_in")
        if expires_in:
            token.expires_at = datetime.datetime.now() + datetime.timedelta(seconds=expires_in)
        
        db.session.add(token)
        db.session.commit()
        
        logger.info("Токен успешно сохранен в базе данных")
        return True
    except Exception as e:
        logger.error(f"Ошибка сохранения токена: {e}")
        return False