#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для добавления колонки admin_user_id в таблицу admin_action_logs
"""

import os
import sys
import logging
from sqlalchemy import Column, BigInteger, create_engine, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Получаем DATABASE_URL из переменных окружения
DATABASE_URL = os.environ.get("DATABASE_URL")
if not DATABASE_URL:
    logger.error("DATABASE_URL environment variable not set")
    sys.exit(1)

# Создаем соединение с базой данных
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
session = Session()

def add_admin_user_id_column():
    """
    Добавляет колонку admin_user_id в таблицу admin_action_logs
    """
    try:
        # Проверяем, существует ли уже колонка admin_user_id
        check_query = text("SELECT column_name FROM information_schema.columns WHERE table_name = 'admin_action_logs' AND column_name = 'admin_user_id';")
        result = session.execute(check_query).fetchall()
        
        if result:
            logger.info("Колонка admin_user_id уже существует в таблице admin_action_logs")
            return
        
        # Добавляем колонку admin_user_id
        add_column_query = text("ALTER TABLE admin_action_logs ADD COLUMN admin_user_id BIGINT;")
        session.execute(add_column_query)
        session.commit()
        
        logger.info("Колонка admin_user_id успешно добавлена в таблицу admin_action_logs")
    except Exception as e:
        session.rollback()
        logger.error(f"Ошибка при добавлении колонки admin_user_id: {e}")
        raise

def main():
    """
    Основная функция
    """
    try:
        add_admin_user_id_column()
        logger.info("Миграция успешно выполнена")
    except Exception as e:
        logger.error(f"Ошибка при выполнении миграции: {e}")
        sys.exit(1)
    finally:
        session.close()

if __name__ == "__main__":
    main()