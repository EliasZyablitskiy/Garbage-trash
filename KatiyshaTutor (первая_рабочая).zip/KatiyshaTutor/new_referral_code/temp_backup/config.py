#!/usr/bin/env python
# coding: utf-8

"""
Configuration settings for the Katiysha bot
"""

import os
import logging

logger = logging.getLogger(__name__)

# Bot Configuration
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "")

# ProxyAPI Configuration
PROXYAPI_KEY = os.getenv("PROXYAPI_KEY", "")
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")

# Free Online OCR API
OCR_API_KEY = os.getenv("OCR_API_KEY", "")
OCR_API_URL = "https://api.free-online-ocr.com/v1/parse-image"

# Payment Configuration
PAYMENT_PROVIDER_TOKEN = os.getenv("PAYMENT_PROVIDER_TOKEN", "")
SUBSCRIPTION_PRICE = 19900  # 199 RUB in kopecks
SUBSCRIPTION_DURATION_DAYS = 30
SUBSCRIPTION_TITLE = "Ежемесячная подписка Катюша"
SUBSCRIPTION_DESCRIPTION = "Неограниченный доступ к решению математических задач с ботом Катюша"
EXTERNAL_PAYMENT_URL = "https://telegrampay.robokassa.ru/Pay/19296?culture=ru"  # Внешняя ссылка на платежный шлюз Robokassa

# Robokassa Configuration
ROBOKASSA_SECRET_KEY = os.getenv("ROBOKASSA_SECRET_KEY", "")  # Секретный ключ для проверки уведомлений от Robokassa
WEBHOOK_HOST = os.getenv("WEBHOOK_HOST", "")  # Домен сервера, на котором размещен бот (для вебхуков)

def get_base_url():
    """
    Получить базовый URL для веб-сервера
    
    Returns:
        str: Базовый URL (по умолчанию для Replit или кастомный из переменных окружения)
    """
    # Попробуем получить URL Replit, если бот запущен на Replit
    replit_url = os.getenv("REPLIT_DOMAINS", "")
    if replit_url:
        domains = replit_url.split(',')
        if domains:
            # В случае запуска на Replit возвращаем первый доступный домен
            return f"https://{domains[0]}"
    
    # Если указан кастомный домен, используем его
    if WEBHOOK_HOST:
        # Проверяем, начинается ли домен с http:// или https://
        if WEBHOOK_HOST.startswith(('http://', 'https://')):
            return WEBHOOK_HOST
        else:
            return f"https://{WEBHOOK_HOST}"
    
    # Если ничего не указано, используем локальный адрес (только для разработки)
    logger.warning("No base URL found in environment variables, using localhost")
    return "http://localhost:5000"

# Commands
COMMANDS = {
    "start": "Запустить бота",
    "help": "Показать справочную информацию",
    "solve": "Решить математическую задачу",
    "subscribe": "Купить подписку",
    "activate_subscription": "Активировать подписку после оплаты"
}

# Messages
WELCOME_MESSAGE = (
    "👋 Привет! Я Катюша, твой помощник в решении математических задач.\n\n"
    "Я могу решать математические задачи от простой арифметики до сложного матанализа. "
    "Ты можешь отправить мне задачу текстом, голосовым сообщением или фото из учебника.\n\n"
    "У тебя есть одно бесплатное решение, после чего тебе понадобится подписка за 199₽/месяц."
)

HELP_MESSAGE = (
    "🔍 *Как пользоваться ботом Катюша:*\n\n"
    "1️⃣ Отправь мне математическую задачу текстом, голосовым сообщением или фотографией\n"
    "2️⃣ Нажми 'Решить задачу', чтобы получить решение\n"
    "3️⃣ Твой первый запрос бесплатный, потом подписка за 199₽/месяц\n\n"
    "*Команды:*\n"
    "/start - Запустить бота\n"
    "/help - Показать эту справку\n"
    "/solve - Решить задачу\n"
    "/subscribe - Купить подписку\n"
    "/activate_subscription - Активировать подписку после оплаты"
)

SUBSCRIPTION_NEEDED_MESSAGE = (
    "⚠️ Ты уже использовал свое бесплатное решение. "
    "Чтобы продолжить пользоваться Катюшей, пожалуйста, приобрети подписку за 199₽/месяц."
)

SOLUTION_PROMPT = (
    "Пожалуйста, реши следующую математическую задачу пошагово, покажи весь ход решения и объясни "
    "подход. Используй только обычный текст и простые математические символы (+ - * / = < >), "
    "не используй LaTeX и сложные математические обозначения. Выражения должны быть понятны и читаемы "
    "в обычном текстовом формате. Убедись, что дал ясный окончательный ответ:\n\n{problem}"
)

PROCESSING_MESSAGE = "⏳ Обрабатываю ваш запрос... Это может занять некоторое время."
VOICE_PROCESSING_MESSAGE = "🎤 Распознаю голосовое сообщение... Это может занять некоторое время."
SEND_PROBLEM_MESSAGE = "📝 Пожалуйста, отправьте мне вашу математическую задачу текстом, голосовым сообщением или фотографией."
SUBSCRIPTION_SUCCESS_MESSAGE = "✅ Ваша подписка активирована! Теперь у вас есть неограниченный доступ к боту Катюша на один месяц."
ERROR_MESSAGE = "❌ Извините, что-то пошло не так. Пожалуйста, попробуйте позже."
OCR_ERROR_MESSAGE = "❌ Я не смог прочитать текст с вашего изображения. Пожалуйста, отправьте более четкое изображение или напишите задачу текстом."
VOICE_ERROR_MESSAGE = "❌ Я не смог распознать текст из вашего голосового сообщения. Пожалуйста, попробуйте говорить более четко или отправьте задачу текстом."
