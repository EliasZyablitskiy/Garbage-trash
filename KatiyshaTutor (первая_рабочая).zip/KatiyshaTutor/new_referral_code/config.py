﻿#!/usr/bin/env python
# coding: utf-8

"""
Configuration settings for the Katiysha bot
"""

import os
import logging

logger = logging.getLogger(__name__)

# Bot Configuration
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "")
BOT_USERNAME = os.getenv("BOT_USERNAME", "")
ADMIN_USER_ID = int(os.getenv("ADMIN_USER_ID", "0"))  # ID главного администратора

# ProxyAPI Configuration
PROXYAPI_KEY = os.getenv("PROXYAPI_KEY", "")
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")

# Free Online OCR API
OCR_API_KEY = os.getenv("OCR_API_KEY", "")
OCR_API_URL = "https://api.free-online-ocr.com/v1/parse-image"

# Payment Configuration
PAYMENT_PROVIDER_TOKEN = os.getenv("PAYMENT_PROVIDER_TOKEN", "")
SUBSCRIPTION_PRICE = 19900  # 199 RUB в копейках
SUBSCRIPTION_DURATION_DAYS = 30
SUBSCRIPTION_TITLE = "Ежемесячная подписка Катюша"
SUBSCRIPTION_DESCRIPTION = "Неограниченный доступ к решению задач с ботом Катюша"

# Robokassa Configuration
ROBOKASSA_MERCHANT_LOGIN = os.getenv("ROBOKASSA_MERCHANT_LOGIN", "")
ROBOKASSA_SECRET_KEY_1 = os.getenv("ROBOKASSA_SECRET_KEY_1", "")  # Секретный ключ #1 для оплаты
ROBOKASSA_SECRET_KEY_2 = os.getenv("ROBOKASSA_SECRET_KEY_2", "")  # Секретный ключ #2 для проверки уведомлений
ROBOKASSA_SECRET_KEY = ROBOKASSA_SECRET_KEY_2  # Для обратной совместимости
WEBHOOK_HOST = os.getenv("WEBHOOK_HOST", "")  # Домен сервера, на котором размещен бот (для вебхуков)

# Referral system rates
REFERRAL_RATE_LEVEL1 = 0.05  # 5% for level 1
REFERRAL_RATE_LEVEL2 = 0.02  # 2% for level 2
REFERRAL_RATE_LEVEL3 = 0.02  # 2% for level 3
REFERRAL_RATE_LEVEL4 = 0.01  # 1% for level 4

def get_base_url():
    """
    Получить базовый URL для веб-сервера
    
    Returns:
        str: Базовый URL (по умолчанию для Replit или кастомный из переменных окружения)
    """
    # Попробуем получить URL Replit, если бот запущен на Replit
    replit_url = os.getenv("REPLIT_DOMAINS", "")
    if replit_url:
        domains = replit_url.split(',')
        if domains:
            # В случае запуска на Replit возвращаем первый доступный домен
            return f"https://{domains[0]}"
    
    # Если указан кастомный домен, используем его
    if WEBHOOK_HOST:
        # Проверяем, начинается ли домен с http:// или https://
        if WEBHOOK_HOST.startswith(('http://', 'https://')):
            return WEBHOOK_HOST
        else:
            return f"https://{WEBHOOK_HOST}"
    
    # Если ничего не указано, используем локальный адрес (только для разработки)
    logger.warning("No base URL found in environment variables, using localhost")
    return "http://localhost:5000"

# Commands
COMMANDS = {
    "start": "Запустить бота",
    "help": "Показать справочную информацию",
    "solve": "Решить математическую задачу",
    "subscribe": "Купить подписку",
    "invite": "Пригласить друзей и заработать",
    "refcode": "Ввести реферальный код",
    "activate_subscription": "Активировать подписку после оплаты"
}

# Admin commands (not shown in bot menu)
ADMIN_COMMANDS = {
    "admin": "Открыть панель администратора",
    "admin_add": "Добавить администратора",
    "admin_remove": "Удалить администратора",
    "admin_stats": "Показать статистику",
    "admin_payout": "Сформировать выплаты",
    "admin_process_payouts": "Обработать выплаты",
    "admin_export_report": "Экспортировать отчет",
    "admin_update_rates": "Обновить ставки реферальной программы",
    "admin_user_referrals": "Показать рефералов пользователя",
    "admin_user_payout": "Выплата вознаграждения пользователю",
    "debug_admin": "Отладка прав администратора",
    "debug_database": "Просмотр содержимого базы данных",
    "debug_summary": "Сводная статистика базы данных",
    "debug_referrals": "Отладка реферальной цепочки",
    "debug_transactions": "Просмотр транзакций",
    "debug_process_rewards": "Принудительный расчет реферальных вознаграждений"
}

# Messages
WELCOME_MESSAGE = (
    "👋 Привет! Я Катюша, твой помощник в решении математических и других задач.\n\n"
    "Я могу решать математические задачи от простой арифметики до сложного матанализа и любые другие. "
    "Ты можешь отправить мне задачу:\n"
    "• Текстовым сообщением\n"
    "• Фотографией из учебника (я распознаю текст)\n"
    "• Голосовым сообщением (я переведу его в текст)\n\n"
    "🎁 У тебя есть *одно бесплатное решение*, после чего понадобится подписка.\n\n"
    "💰 Стоимость подписки всего 199₽ в месяц — меньше стоимости одной частной консультации!\n\n"
    "👥 Приглашай друзей и зарабатывай на их подписках!"
)

aHELP_MESSAGE = (
    "🔍 *Как пользоваться ботом Катюша:*\n\n"
    "1️⃣ Отправь мне математическую задачу текстом, голосовым сообщением или фотографией\n"
    "2️⃣ Нажми 'Решить задачу', чтобы получить решение\n"
    "3️⃣ Твой первый запрос бесплатный, потом подписка за 199₽/месяц\n"
    "4️⃣ Нажми 'Пригласить друга' и получи % от оплаты приглашенных пользователей\n\n"
    "*Команды:*\n"
    "/start - Запустить бота\n"
    "/help - Показать эту справку\n"
    "/solve - Решить задачу\n"
    "/subscribe - Купить подписку\n"
    "/invite - Пригласить друзей\n"
    "/activate_subscription - Активировать подписку после оплаты"
)

SUBSCRIPTION_NEEDED_MESSAGE = (
    "⚠️ Ты уже использовал свое бесплатное решение!\n\n"
    "Чтобы продолжить пользоваться Катюшей, приобрети подписку за *199₽/месяц*.\n\n"
    "Нажми кнопку «Купить подписку» чтобы перейти к оплате.\n\n"
    "💡 *Совет:* Пригласи друзей и заработай на их подписках!"
)

SOLUTION_PROMPT = (
    "Пожалуйста, реши следующую математическую задачу пошагово, покажи весь ход решения и объясни "
    "подход. Используй только обычный текст и простые математические символы (+ - * / = < >), "
    "не используй LaTeX и сложные математические обозначения. Выражения должны быть понятны и читаемы "
    "в обычном текстовом формате. Убедись, что дал ясный окончательный ответ:\n\n{problem}"
)

PROCESSING_MESSAGE = "⏳ Обрабатываю ваш запрос... Это может занять некоторое время."
VOICE_PROCESSING_MESSAGE = "🎤 Распознаю голосовое сообщение... Это может занять некоторое время."
SEND_PROBLEM_MESSAGE = "📝 Пожалуйста, отправьте мне вашу математическую задачу текстом, голосовым сообщением или фотографией."
SUBSCRIPTION_SUCCESS_MESSAGE = "✅ Ваша подписка активирована! Теперь у вас есть неограниченный доступ к боту Катюша на один месяц."
ERROR_MESSAGE = "❌ Извините, что-то пошло не так. Пожалуйста, попробуйте позже."
OCR_ERROR_MESSAGE = "❌ Я не смог прочитать текст с вашего изображения. Пожалуйста, отправьте более четкое изображение или напишите задачу текстом."
VOICE_ERROR_MESSAGE = "❌ Я не смог распознать текст из вашего голосового сообщения. Пожалуйста, попробуйте говорить более четко или отправьте задачу текстом."

# Referral system
REFERRAL_MESSAGE = (
    "👥 *Реферальная система Катюши*\n\n"
    "Приглашай друзей и получай:\n"
    "• 5% от их оплаты\n"
    "• 2% от 2-3 уровня рефералов\n"
    "• 1% от 4 уровня рефералов\n\n"
    "Вот твоя персональная реферальная ссылка:\n"
    "{referral_link}\n\n"
    "Отправь эту ссылку друзьям и начни зарабатывать!"
)

# Admin messages
ADMIN_PAYOUT_CONFIRMATION = (
    "⚠️ *Внимание!* Вы собираетесь обработать выплаты по реферальной программе.\n\n"
    "Общее количество транзакций: {transactions_count}\n"
    "Общая сумма выплат: {total_amount}₽\n\n"
    "Для подтверждения нажмите 'Подтвердить выплаты'."
)