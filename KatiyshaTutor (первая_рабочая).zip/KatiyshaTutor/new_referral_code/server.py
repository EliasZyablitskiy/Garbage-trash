#!/usr/bin/env python
# coding: utf-8

"""
Запуск веб-сервера с Flask-приложением
"""

from webhook_handler import run_webhook_server

if __name__ == "__main__":
    run_webhook_server(5000)