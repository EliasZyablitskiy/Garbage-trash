#!/usr/bin/env python
# coding: utf-8

"""
Миграция для добавления поля username в таблицу admin_users
"""

import os
import sys
import psycopg2
from sqlalchemy import text, MetaData, inspect
from db_config import get_flask_app
from db_models import db

def add_username_column():
    """
    Добавляет столбец username в таблицу admin_users
    """
    app = get_flask_app()
    
    with app.app_context():
        # Используем инспектор для проверки наличия столбца
        inspector = inspect(db.engine)
        columns = [col['name'] for col in inspector.get_columns('admin_users')]
        
        if 'username' in columns:
            print("Столбец username уже существует в таблице admin_users")
            return
            
        # Добавляем столбец напрямую через psycopg2
        try:
            # Получаем данные подключения из SQLAlchemy engine
            connection_string = db.engine.url.render_as_string(hide_password=False)
            
            # Подключаемся напрямую через psycopg2
            conn = psycopg2.connect(connection_string)
            conn.autocommit = True
            cursor = conn.cursor()
            
            # Выполняем ALTER TABLE
            cursor.execute("ALTER TABLE admin_users ADD COLUMN username VARCHAR(64) UNIQUE")
            print("Столбец username успешно добавлен в таблицу admin_users")
            
            # Закрываем соединение
            cursor.close()
            conn.close()
            
        except Exception as e:
            print(f"Ошибка при добавлении столбца username: {e}")
            raise

if __name__ == "__main__":
    add_username_column()