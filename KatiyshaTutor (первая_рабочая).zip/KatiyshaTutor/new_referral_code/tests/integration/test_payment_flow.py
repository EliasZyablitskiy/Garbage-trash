import pytest
from unittest.mock import patch, AsyncMock, MagicMock
import sys
import os

# Импортируем необходимые модули
from handlers import subscription_command
from services.payment_service import PaymentService
from webhook_handler import process_robokassa_payment

@pytest.mark.asyncio
class TestPaymentFlow:
    
    @pytest.fixture
    def mock_payment_service(self):
        """Мок для сервиса платежей"""
        with patch('handlers.payment_service') as mock_service:
            mock_service.generate_payment_url.return_value = "https://test.robokassa.ru/payment/test"
            yield mock_service
    
    @pytest.fixture
    def mock_webhook_request(self):
        """Мок для запроса вебхука от платежной системы"""
        mock_request = MagicMock()
        mock_request.args = {
            'OutSum': '100.00',
            'InvId': '12345',
            'SignatureValue': 'test_signature',
            'user_id': '123456789'
        }
        return mock_request
    
    async def test_subscription_command_generates_payment(self, mock_update, mock_context, mock_payment_service, mock_db):
        """Тест генерации ссылки на оплату подписки"""
        # Настраиваем моки
        mock_db.get_user.return_value = {'user_id': 123456789, 'username': 'test_user'}
        
        # Вызываем команду подписки
        await subscription_command(mock_update, mock_context)
        
        # Проверяем, что сервис генерации ссылки был вызван с правильными параметрами
        mock_payment_service.generate_payment_url.assert_called_once()
        args = mock_payment_service.generate_payment_url.call_args[0]
        assert args[0] == 123456789  # user_id
        
        # Проверяем, что ссылка на оплату была отправлена пользователю
        mock_update.message.reply_text.assert_called_once()
        assert "https://test.robokassa.ru/payment/test" in mock_update.message.reply_text.call_args[0][0]
    
    @patch('webhook_handler.db')
    @patch('webhook_handler.verify_robokassa_signature')
    async def test_payment_webhook_processing(self, mock_verify_signature, mock_db, mock_webhook_request):
        """Тест обработки уведомления о платеже от Robokassa"""
        # Настраиваем моки
        mock_verify_signature.return_value = True
        mock_db.get_user.return_value = {'user_id': 123456789, 'username': 'test_user', 'subscription': {'active': False}}
        mock_db.update_user_subscription = AsyncMock()
        mock_db.add_transaction = AsyncMock()
        
        # Симулируем обработку вебхука
        result = await process_robokassa_payment(mock_webhook_request)
        
        # Проверяем, что подписка была активирована
        mock_db.update_user_subscription.assert_called_once()
        # Проверяем, что транзакция была сохранена
        mock_db.add_transaction.assert_called_once()
        # Проверяем успешный ответ
        assert result == "OK12345" 