#!/usr/bin/env python
# coding: utf-8

"""
Bot initialization and configuration
"""

import logging
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
    ConversationHandler
)

import config
from handlers import (
    start_command,
    help_command,
    solve_command,
    subscribe_command,
    activate_subscription_command,
    invite_command,
    handle_text,
    handle_photo,
    handle_voice,
    handle_callback,
    error_handler,
    # Refcode handlers
    refcode_command,
    process_refcode,
    cancel_refcode,
    WAITING_REFCODE,
    # Admin commands
    admin_command,
    admin_add_command,
    admin_remove_command,
    admin_stats_command,
    admin_payout_command,
    admin_process_payouts_command,
    admin_export_report_command,
    admin_update_rates_command,
    admin_user_referrals_command,
    admin_user_payout_command,
    admin_callback_handler,
    # Debug commands
    debug_admin_command,
    debug_database_command,
    debug_database_summary_command,
    # Referral debug commands
    debug_referral_chain_command,
    debug_transactions_command,
    debug_process_rewards_command
)

logger = logging.getLogger(__name__)

async def create_bot():
    """Create and configure the bot with all necessary handlers"""
    # Получаем токен бота из конфига
    token = config.TELEGRAM_TOKEN
    if not token:
        logger.error("Bot token not found in environment variables")
        return None
    
    # Создаем приложение бота
    application = Application.builder().token(token).build()
    
    # Регистрируем обработчики команд
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("solve", solve_command))
    application.add_handler(CommandHandler("subscribe", subscribe_command))
    application.add_handler(CommandHandler("invite", invite_command))
    application.add_handler(CommandHandler("activate_subscription", activate_subscription_command))
    
    # Добавляем ConversationHandler для команды refcode
    refcode_handler = ConversationHandler(
        entry_points=[CommandHandler("refcode", refcode_command)],
        states={
            WAITING_REFCODE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, process_refcode),
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel_refcode)],
    )
    application.add_handler(refcode_handler)
    
    # Регистрируем обработчики сообщений
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    application.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    application.add_handler(MessageHandler(filters.VOICE, handle_voice))
    
    # Регистрируем обработчик колбэков для inline-клавиатур
    application.add_handler(CallbackQueryHandler(handle_callback, pattern=r"^(?!admin_).*"))
    
    # Регистрируем обработчик ошибок
    application.add_error_handler(error_handler)
    
    # Admin commands
    application.add_handler(CommandHandler("admin", admin_command))
    application.add_handler(CommandHandler("admin_add", admin_add_command))
    application.add_handler(CommandHandler("admin_remove", admin_remove_command))
    application.add_handler(CommandHandler("admin_stats", admin_stats_command))
    application.add_handler(CommandHandler("admin_payout", admin_payout_command))
    application.add_handler(CommandHandler("admin_process_payouts", admin_process_payouts_command))
    application.add_handler(CommandHandler("admin_export_report", admin_export_report_command))
    application.add_handler(CommandHandler("admin_update_rates", admin_update_rates_command))
    application.add_handler(CommandHandler("admin_user_referrals", admin_user_referrals_command))
    application.add_handler(CommandHandler("admin_user_payout", admin_user_payout_command))
    
    # Debug commands
    application.add_handler(CommandHandler("debug_admin", debug_admin_command))
    application.add_handler(CommandHandler("debug_database", debug_database_command))
    application.add_handler(CommandHandler("debug_summary", debug_database_summary_command))
    
    # Referral debug commands
    application.add_handler(CommandHandler("debug_referrals", debug_referral_chain_command))
    application.add_handler(CommandHandler("debug_transactions", debug_transactions_command))
    application.add_handler(CommandHandler("debug_process_rewards", debug_process_rewards_command))
    
    # Admin callback handler
    application.add_handler(CallbackQueryHandler(admin_callback_handler, pattern=r"^admin_.*"))
    
    # Устанавливаем команды для бота (отображаются в меню команд в Telegram)
    await application.bot.set_my_commands([
        (command, description) for command, description in config.COMMANDS.items()
    ])
    
    # Устанавливаем админские команды для администраторов
    await setup_admin_commands(application.bot)
    
    # Schedule weekly payout status check
    from apscheduler.schedulers.asyncio import AsyncIOScheduler
    from webhook_handler import update_weekly_payout_status
    
    scheduler = AsyncIOScheduler()
    scheduler.add_job(update_weekly_payout_status, 'interval', hours=12)  # Check twice a day
    scheduler.start()
    
    logger.info("Bot configured with all handlers and scheduled jobs")
    
    return application

async def setup_admin_commands(bot):
    """
    Устанавливает команды администратора для всех пользователей с правами администратора
    """
    from telegram import BotCommandScopeChat
    from database import load_database, is_admin
    
    # Получаем список администраторов
    db = load_database()
    admins = db.get("admins", [])
    
    # Добавляем супер-админа, если он есть
    super_admin_id = config.ADMIN_USER_ID
    if super_admin_id and super_admin_id not in admins:
        admins.append(super_admin_id)
    
    # Список всех команд (обычные + админские)
    all_commands = [
        (command, description) for command, description in config.COMMANDS.items()
    ] + [
        (command, description) for command, description in config.ADMIN_COMMANDS.items()
    ]
    
    # Для каждого администратора устанавливаем расширенный список команд
    admin_count = 0
    for admin_id in admins:
        try:
            # Преобразуем ID в int, если он хранится как строка
            admin_id = int(admin_id) if isinstance(admin_id, str) else admin_id
            
            # Убеждаемся, что пользователь действительно админ (дополнительная проверка)
            if is_admin(admin_id):
                await bot.set_my_commands(
                    all_commands,
                    scope=BotCommandScopeChat(chat_id=admin_id)
                )
                admin_count += 1
                logger.debug(f"Установлены админские команды для пользователя {admin_id}")
        except Exception as e:
            logger.error(f"Ошибка при установке команд для администратора {admin_id}: {e}")
    
    logger.info(f"Установлены админские команды для {admin_count} администраторов")