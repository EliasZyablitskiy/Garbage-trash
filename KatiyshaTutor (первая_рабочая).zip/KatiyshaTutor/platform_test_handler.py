#!/usr/bin/env python
# coding: utf-8

"""
Обработчик команды /test_platform для тестирования совместимости с устройством пользователя
"""

import logging
import json
from typing import Dict, Any
from datetime import datetime
import asyncio

from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes

from services.platform_detection_service import get_platform_from_update
from services.platform_tester import run_platform_tests
from services.message_formatter_service import format_adaptive_message
from services.platform_data_service import get_message_format_settings, get_emoji
from db_models import PlatformTestResult
from db_config import db

logger = logging.getLogger(__name__)

# Список ID администраторов для отправки полных отчетов
ADMIN_IDS = [5913639088]  # ID тестового пользователя

async def test_platform_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обрабатывает команду /test_platform
    Запускает тестирование совместимости с устройством пользователя
    """
    user = update.effective_user
    user_id = user.id
    
    # Получаем информацию о платформе пользователя
    platform_info = get_platform_from_update(update)
    platform_type = platform_info.get("platform", "unknown")
    platform_version = platform_info.get("version")
    
    # Сообщаем пользователю о начале тестирования
    start_message = (
        f"🔍 *Тестирование платформы*\n\n"
        f"Запуск тестирования совместимости для платформы:\n"
        f"• Тип: {platform_type}\n"
        f"• Версия: {platform_version or 'Не определена'}\n\n"
        f"Пожалуйста, подождите, это займет несколько секунд..."
    )
    
    # Форматируем сообщение с учетом платформы
    formatted_message = format_adaptive_message(
        start_message, 
        platform_type, 
        platform_version
    )
    
    # Определяем режим форматирования
    format_settings = get_message_format_settings(platform_type, platform_version)
    parse_mode = format_settings.get("preferred", "Markdown")
    
    # Отправляем первоначальное сообщение
    message = await update.message.reply_text(
        formatted_message,
        parse_mode=parse_mode
    )
    
    try:
        # Запускаем тестирование асинхронно
        test_results = await run_platform_tests(user_id, platform_info)
        
        # Готовим сообщение с результатами
        success_emoji = get_emoji("success", platform_type)
        fail_emoji = get_emoji("error", platform_type)
        info_emoji = get_emoji("info", platform_type)
        
        pass_rate = test_results.get("pass_rate", 0)
        tests_passed = test_results.get("tests_passed", 0)
        tests_total = test_results.get("tests_total", 0)
        
        # Определяем статус тестирования
        if pass_rate >= 90:
            status_text = f"{success_emoji} *Отлично!* Ваше устройство полностью совместимо с ботом."
            status_emoji = success_emoji
        elif pass_rate >= 70:
            status_text = f"{info_emoji} *Хорошо.* Ваше устройство в целом совместимо с ботом."
            status_emoji = info_emoji
        else:
            status_text = f"{fail_emoji} *Внимание!* Обнаружены проблемы совместимости с вашим устройством."
            status_emoji = fail_emoji
        
        # Формируем текст сообщения для пользователя
        result_message = (
            f"{status_emoji} *Результаты тестирования платформы*\n\n"
            f"{status_text}\n\n"
            f"• Платформа: {platform_type}\n"
            f"• Версия: {platform_version or 'Не определена'}\n"
            f"• Успешно: {tests_passed} из {tests_total} тестов\n"
            f"• Совместимость: {pass_rate}%\n\n"
        )
        
        # Добавляем специфические рекомендации в зависимости от результатов тестов
        results = test_results.get("results", {})
        
        # Проверяем результаты тестов QR-кодов
        qr_test = results.get("qr_code_generation", {})
        if qr_test.get("status") == "failed" or qr_test.get("details", {}).get("qr_compatible") is False:
            result_message += (
                f"{fail_emoji} *Проблемы с QR-кодами*\n"
                f"На вашем устройстве могут возникать проблемы при сканировании QR-кодов для оплаты.\n"
                f"Рекомендация: используйте альтернативные способы оплаты через кнопку «Помощь».\n\n"
            )
        
        # Проверяем результаты тестов сообщений
        msg_test = results.get("message_formatting", {})
        if msg_test.get("status") == "failed":
            result_message += (
                f"{fail_emoji} *Проблемы с форматированием сообщений*\n"
                f"На вашем устройстве могут некорректно отображаться форматированные сообщения.\n"
                f"Рекомендация: обновите приложение Telegram до последней версии.\n\n"
            )
        
        # Проверяем результаты тестов платежей
        payment_test = results.get("payment_settings", {})
        if payment_test.get("status") == "failed" or payment_test.get("details", {}).get("sbp_compatible") is False:
            result_message += (
                f"{fail_emoji} *Проблемы с платежами СБП*\n"
                f"На вашем устройстве могут возникать проблемы с оплатой через СБП.\n"
                f"Рекомендация: используйте оплату банковской картой.\n\n"
            )
        
        # Добавляем общие рекомендации
        result_message += (
            f"{info_emoji} *Общие рекомендации*\n"
            f"• Регулярно обновляйте приложение Telegram\n"
            f"• При проблемах с оплатой воспользуйтесь кнопкой «Помощь с оплатой»\n"
            f"• Если проблемы сохраняются, свяжитесь с поддержкой\n\n"
        )
        
        # Создаем клавиатуру с действиями
        help_button = InlineKeyboardButton("Помощь с оплатой", callback_data="payment_help")
        support_button = InlineKeyboardButton("Связаться с поддержкой", callback_data="contact_support")
        
        keyboard = InlineKeyboardMarkup([[help_button], [support_button]])
        
        # Отправляем результаты пользователю
        formatted_result = format_adaptive_message(
            result_message, 
            platform_type, 
            platform_version
        )
        
        await message.edit_text(
            formatted_result,
            reply_markup=keyboard,
            parse_mode=parse_mode
        )
        
        # Отправляем полный отчет администраторам
        await send_admin_test_report(context, user, test_results)
            
    except Exception as e:
        logger.error(f"Ошибка при тестировании платформы: {e}")
        error_message = (
            f"❌ *Ошибка при тестировании*\n\n"
            f"К сожалению, во время тестирования произошла ошибка.\n"
            f"Пожалуйста, попробуйте позже или свяжитесь с поддержкой."
        )
        
        formatted_error = format_adaptive_message(
            error_message, 
            platform_type, 
            platform_version
        )
        
        await message.edit_text(
            formatted_error,
            parse_mode=parse_mode
        )
        
        # Уведомляем администраторов об ошибке
        error_detail = f"Ошибка при тестировании платформы {platform_type} {platform_version} для пользователя {user_id}: {e}"
        for admin_id in ADMIN_IDS:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=error_detail
                )
            except Exception as admin_error:
                logger.error(f"Не удалось отправить уведомление администратору {admin_id}: {admin_error}")

async def send_admin_test_report(context: ContextTypes.DEFAULT_TYPE, user, test_results: Dict[str, Any]) -> None:
    """
    Отправляет подробный отчет о тестировании администраторам
    
    Args:
        context: Контекст обработчика Telegram
        user: Пользователь, проводивший тест
        test_results: Результаты тестирования
    """
    try:
        # Проверяем наличие администраторов
        if not ADMIN_IDS:
            return
            
        # Получаем подробную информацию
        user_id = user.id
        user_name = user.full_name
        username = user.username
        platform_type = test_results.get("platform", "unknown")
        platform_version = test_results.get("version", "unknown")
        pass_rate = test_results.get("pass_rate", 0)
        timestamp = test_results.get("timestamp", datetime.now().isoformat())
        
        # Составляем текст отчета
        report_text = (
            f"📊 *Отчет о тестировании платформы*\n\n"
            f"*Информация о пользователе:*\n"
            f"• ID: `{user_id}`\n"
            f"• Имя: {user_name}\n"
            f"• Имя пользователя: {('@' + username) if username else 'Не указано'}\n\n"
            f"*Информация о платформе:*\n"
            f"• Тип: {platform_type}\n"
            f"• Версия: {platform_version}\n"
            f"• Совместимость: {pass_rate}%\n"
            f"• Дата тестирования: {timestamp}\n\n"
            f"*Результаты тестов:*\n"
        )
        
        # Добавляем результаты каждого теста
        results = test_results.get("results", {})
        for test_name, test_data in results.items():
            status = test_data.get("status", "unknown")
            status_icon = "✅" if status == "passed" else "❌"
            
            report_text += f"{status_icon} *{test_name}*: {status.upper()}\n"
            
            # Добавляем детали тестов
            details = test_data.get("details", {})
            for key, value in details.items():
                report_text += f"  • {key}: {value}\n"
            
            # Если тест не пройден, добавляем информацию об ошибке
            if status == "failed" and "error" in test_data:
                report_text += f"  • Ошибка: {test_data['error']}\n"
                
            report_text += "\n"
        
        # Отправляем отчет каждому администратору
        for admin_id in ADMIN_IDS:
            try:
                # Если отчет получился слишком длинным, отправляем частями
                if len(report_text) > 4000:
                    # Отправляем первую часть
                    first_part = report_text[:4000] + "...\n\n*Продолжение следует...*"
                    await context.bot.send_message(
                        chat_id=admin_id,
                        text=first_part,
                        parse_mode="Markdown"
                    )
                    
                    # Отправляем оставшуюся часть
                    second_part = "*...Продолжение отчета:*\n\n" + report_text[4000:]
                    await context.bot.send_message(
                        chat_id=admin_id,
                        text=second_part,
                        parse_mode="Markdown"
                    )
                else:
                    # Отправляем весь отчет сразу
                    await context.bot.send_message(
                        chat_id=admin_id,
                        text=report_text,
                        parse_mode="Markdown"
                    )
                    
                # Отправляем также JSON с результатами для более подробного анализа
                json_results = json.dumps(test_results, indent=2, ensure_ascii=False)
                
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=f"```json\n{json_results}\n```",
                    parse_mode="Markdown"
                )
                
            except Exception as e:
                logger.error(f"Не удалось отправить отчет администратору {admin_id}: {e}")
    
    except Exception as e:
        logger.error(f"Ошибка при подготовке отчета для администраторов: {e}")