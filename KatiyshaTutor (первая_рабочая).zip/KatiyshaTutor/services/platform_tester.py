#!/usr/bin/env python
# coding: utf-8

"""
Модуль для тестирования кросс-платформенной совместимости
Позволяет проверять совместимость различных функций бота с разными платформами
и собирать статистику для анализа проблем
"""

import logging
import json
import os
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime
from PIL import Image
import asyncio

from services.platform_detection_service import (
    get_platform_from_update, 
    PLATFORM_IOS, PLATFORM_ANDROID, PLATFORM_DESKTOP, 
    PLATFORM_WEB, PLATFORM_UNKNOWN
)
from services.platform_data_service import (
    get_platform_compatibility_flags,
    get_emoji,
    get_message_format_settings,
    get_payment_settings
)
from services.message_formatter_service import format_adaptive_message
from services.payment_service import is_problematic_ios
from db_models import PlatformTestResult
from db_config import db

logger = logging.getLogger(__name__)

class PlatformTester:
    """
    Класс для тестирования совместимости с разными платформами
    """
    
    def __init__(self, user_id: int, platform_info: Dict[str, Any]):
        """
        Инициализирует тестер платформы
        
        Args:
            user_id: ID пользователя
            platform_info: Информация о платформе пользователя
        """
        self.user_id = user_id
        self.platform_info = platform_info
        self.platform_type = platform_info.get("platform", PLATFORM_UNKNOWN)
        self.platform_version = platform_info.get("version")
        self.test_results = {}
        self.tests_passed = 0
        self.tests_failed = 0
        self.total_tests = 0
        
    async def run_all_tests(self) -> Dict[str, Any]:
        """
        Запускает все тесты для данной платформы
        
        Returns:
            Dict[str, Any]: Результаты тестов
        """
        logger.info(f"Запуск тестов для платформы {self.platform_type} {self.platform_version}")
        
        # Запускаем все тесты
        results = {}
        
        # Тест 1: Форматирование сообщений
        results["message_formatting"] = await self.test_message_formatting()
        
        # Тест 2: Эмодзи
        results["emoji_compatibility"] = await self.test_emoji_compatibility()
        
        # Тест 3: Прямые СБП платежи
        results["direct_payment"] = await self.test_direct_payment()
        
        # Тест 4: Настройки платежей
        results["payment_settings"] = await self.test_payment_settings()
        
        # Тест 5: Проверка совместимости с AI
        results["ai_compatibility"] = await self.test_ai_compatibility()
        
        # Сохраняем общие результаты
        self.save_test_results(results)
        
        # Формируем итоговый отчет
        return {
            "platform": self.platform_type,
            "version": self.platform_version,
            "tests_total": self.total_tests,
            "tests_passed": self.tests_passed,
            "tests_failed": self.tests_failed,
            "pass_rate": round(self.tests_passed / self.total_tests * 100, 2) if self.total_tests > 0 else 0,
            "results": results,
            "summary": self.generate_summary(),
            "timestamp": datetime.now().isoformat()
        }
    
    async def test_message_formatting(self) -> Dict[str, Any]:
        """
        Тестирует форматирование сообщений для данной платформы
        
        Returns:
            Dict[str, Any]: Результаты теста
        """
        self.total_tests += 1
        test_result = {"status": "passed", "details": {}}
        
        try:
            # Получаем настройки форматирования
            format_settings = get_message_format_settings(self.platform_type, self.platform_version)
            
            # Проверяем поддержку Markdown
            test_md = "*Bold text* and _italic text_"
            formatted_md = format_adaptive_message(test_md, self.platform_type, self.platform_version)
            test_result["details"]["markdown_support"] = format_settings.get("markdown_support", False)
            
            # Проверяем поддержку HTML
            test_html = "<b>Bold text</b> and <i>italic text</i>"
            formatted_html = format_adaptive_message(test_html, self.platform_type, self.platform_version, 
                                                    force_html=True)
            test_result["details"]["html_support"] = format_settings.get("html_support", False)
            
            # Проверяем обработку специальных символов
            test_special = "Special symbols: < > & ' \" - # @ * _ { } ~ ` + = | \\ / !"
            formatted_special = format_adaptive_message(test_special, self.platform_type, self.platform_version)
            test_result["details"]["special_chars_handled"] = True
            
            # Проверяем предпочтительный метод форматирования
            test_result["details"]["preferred_format"] = format_settings.get("preferred", "Markdown")
            
            self.tests_passed += 1
            
        except Exception as e:
            logger.error(f"Ошибка при тестировании форматирования сообщений: {e}")
            test_result["status"] = "failed"
            test_result["error"] = str(e)
            self.tests_failed += 1
            
        return test_result
    
    async def test_emoji_compatibility(self) -> Dict[str, Any]:
        """
        Тестирует совместимость с эмодзи для данной платформы
        
        Returns:
            Dict[str, Any]: Результаты теста
        """
        self.total_tests += 1
        test_result = {"status": "passed", "details": {}}
        
        try:
            # Тестируем набор эмодзи
            emoji_tests = ["payment", "success", "help", "info", "bank", "card", "alert"]
            
            for emoji_name in emoji_tests:
                emoji = get_emoji(emoji_name, self.platform_type)
                test_result["details"][emoji_name] = emoji
            
            # Проверяем наличие замен для проблемных эмодзи
            problematic_emoji_count = sum(1 for emoji in test_result["details"].values() 
                                         if emoji != test_result["details"].get(emoji, ""))
            
            test_result["details"]["has_platform_specific_emoji"] = problematic_emoji_count > 0
            test_result["details"]["platform_emoji_count"] = problematic_emoji_count
            
            self.tests_passed += 1
            
        except Exception as e:
            logger.error(f"Ошибка при тестировании совместимости с эмодзи: {e}")
            test_result["status"] = "failed"
            test_result["error"] = str(e)
            self.tests_failed += 1
            
        return test_result
    
    async def test_direct_payment(self) -> Dict[str, Any]:
        """
        Тестирует совместимость с прямыми платежами СБП для данной платформы
        
        Returns:
            Dict[str, Any]: Результаты теста по прямым платежам
        """
        self.total_tests += 1
        test_result = {"status": "passed", "details": {}}
        
        try:
            # Проверяем флаги совместимости
            flags = get_platform_compatibility_flags(self.platform_type, self.platform_version)
            
            # Определяем, является ли iOS устройство проблемным
            problematic_ios = False
            if self.platform_type == PLATFORM_IOS:
                problematic_ios = is_problematic_ios(self.platform_version)
            
            # Проверяем настройки прямых платежей
            payment_settings = get_payment_settings(self.platform_type, self.platform_version)
            test_result["details"]["direct_payment_compatible"] = flags.get("direct_payment_compatible", True)
            test_result["details"]["problematic_ios"] = problematic_ios
            
            # Получаем метод прямого платежа для этой платформы
            payment_method = flags.get("direct_payment_method", "sbp_link")
            test_result["details"]["payment_method"] = payment_method
            test_result["details"]["payment_ui_type"] = payment_settings.get("payment_ui_type", "standard")
            
            self.tests_passed += 1
            
        except Exception as e:
            logger.error(f"Ошибка при тестировании прямых платежей СБП: {e}")
            test_result["status"] = "failed"
            test_result["error"] = str(e)
            self.tests_failed += 1
            
        return test_result
    
    async def test_payment_settings(self) -> Dict[str, Any]:
        """
        Тестирует настройки платежей для данной платформы
        
        Returns:
            Dict[str, Any]: Результаты теста
        """
        self.total_tests += 1
        test_result = {"status": "passed", "details": {}}
        
        try:
            # Получаем настройки платежей
            payment_settings = get_payment_settings(self.platform_type, self.platform_version)
            
            # Проверяем флаги совместимости
            flags = get_platform_compatibility_flags(self.platform_type, self.platform_version)
            sbp_compatible = flags.get("sbp_compatible", True)
            
            # Проверяем параметры платежей
            test_result["details"]["sbp_compatible"] = sbp_compatible
            test_result["details"]["robokassa_mobile_param"] = payment_settings.get("robokassa_mobile_param", "false")
            test_result["details"]["preferred_payment_method"] = payment_settings.get("preferred_method", "sbp")
            
            self.tests_passed += 1
            
        except Exception as e:
            logger.error(f"Ошибка при тестировании настроек платежей: {e}")
            test_result["status"] = "failed"
            test_result["error"] = str(e)
            self.tests_failed += 1
            
        return test_result
    
    async def test_ai_compatibility(self) -> Dict[str, Any]:
        """
        Тестирует совместимость с AI сервисами для данной платформы
        
        Returns:
            Dict[str, Any]: Результаты теста
        """
        self.total_tests += 1
        test_result = {"status": "passed", "details": {}}
        
        try:
            # Получаем флаги совместимости
            flags = get_platform_compatibility_flags(self.platform_type, self.platform_version)
            
            # Проверяем совместимость с разными моделями AI
            test_result["details"]["deepseek_compatible"] = flags.get("deepseek_compatible", True)
            test_result["details"]["openai_compatible"] = flags.get("openai_compatible", True)
            test_result["details"]["proxyapi_compatible"] = flags.get("proxyapi_compatible", True)
            
            # Выявляем предпочтительную модель для платформы
            if self.platform_type == PLATFORM_IOS and not flags.get("deepseek_compatible", True):
                test_result["details"]["preferred_model"] = "openai"
            else:
                test_result["details"]["preferred_model"] = "deepseek"
            
            self.tests_passed += 1
            
        except Exception as e:
            logger.error(f"Ошибка при тестировании совместимости с AI: {e}")
            test_result["status"] = "failed"
            test_result["error"] = str(e)
            self.tests_failed += 1
            
        return test_result
    
    def save_test_results(self, results: Dict[str, Any]) -> None:
        """
        Сохраняет результаты тестов в базу данных
        
        Args:
            results: Результаты тестов
        """
        try:
            # Создаем запись о результатах тестирования
            test_result = PlatformTestResult(
                user_id=self.user_id,
                platform_type=self.platform_type,
                platform_version=self.platform_version,
                tests_run=self.total_tests,
                tests_passed=self.tests_passed,
                tests_failed=self.tests_failed,
                results_json=json.dumps(results),
                timestamp=datetime.now()
            )
            
            # Сохраняем в базу данных
            with db.Session() as session:
                session.add(test_result)
                session.commit()
            
            logger.info(f"Результаты тестирования сохранены для пользователя {self.user_id}")
            
        except Exception as e:
            logger.error(f"Ошибка при сохранении результатов тестирования: {e}")
    
    def generate_summary(self) -> str:
        """
        Генерирует краткую сводку результатов тестирования
        
        Returns:
            str: Сводка результатов
        """
        if self.total_tests == 0:
            return "Тесты не были выполнены"
        
        pass_rate = round(self.tests_passed / self.total_tests * 100, 2)
        
        if pass_rate == 100:
            return f"Все тесты пройдены успешно для платформы {self.platform_type} {self.platform_version}"
        elif pass_rate >= 80:
            return f"Платформа {self.platform_type} {self.platform_version} совместима с большинством функций ({pass_rate}%)"
        elif pass_rate >= 50:
            return f"Платформа {self.platform_type} {self.platform_version} частично совместима с функциями бота ({pass_rate}%)"
        else:
            return f"Платформа {self.platform_type} {self.platform_version} имеет низкую совместимость с ботом ({pass_rate}%)"

async def run_platform_tests(user_id: int, platform_info: Dict[str, Any]) -> Dict[str, Any]:
    """
    Запускает тесты для указанной платформы
    
    Args:
        user_id: ID пользователя
        platform_info: Информация о платформе
        
    Returns:
        Dict[str, Any]: Результаты тестов
    """
    tester = PlatformTester(user_id, platform_info)
    return await tester.run_all_tests()

def generate_cross_platform_report() -> Dict[str, Any]:
    """
    Генерирует отчет о кросс-платформенной совместимости на основе накопленных данных
    
    Returns:
        Dict[str, Any]: Отчет о совместимости
    """
    try:
        report = {
            "platforms": {},
            "total_tests": 0,
            "timestamp": datetime.now().isoformat()
        }
        
        # Получаем все результаты тестов из базы данных
        with db.Session() as session:
            test_results = session.query(PlatformTestResult).all()
            
            # Группируем результаты по платформам
            platform_data = {}
            
            for result in test_results:
                platform = result.platform_type
                version = result.platform_version
                
                if platform not in platform_data:
                    platform_data[platform] = {
                        "versions": {},
                        "total_tests": 0,
                        "total_passed": 0,
                        "total_failed": 0
                    }
                
                if version not in platform_data[platform]["versions"]:
                    platform_data[platform]["versions"][version] = {
                        "tests": 0,
                        "passed": 0,
                        "failed": 0,
                        "user_count": 0
                    }
                
                # Обновляем статистику
                platform_data[platform]["versions"][version]["tests"] += result.tests_run
                platform_data[platform]["versions"][version]["passed"] += result.tests_passed
                platform_data[platform]["versions"][version]["failed"] += result.tests_failed
                platform_data[platform]["versions"][version]["user_count"] += 1
                
                platform_data[platform]["total_tests"] += result.tests_run
                platform_data[platform]["total_passed"] += result.tests_passed
                platform_data[platform]["total_failed"] += result.tests_failed
                
                report["total_tests"] += result.tests_run
            
            # Обрабатываем данные для отчета
            for platform, data in platform_data.items():
                total_passed = data["total_passed"]
                total_tests = data["total_tests"]
                
                if total_tests > 0:
                    pass_rate = round(total_passed / total_tests * 100, 2)
                else:
                    pass_rate = 0
                
                report["platforms"][platform] = {
                    "pass_rate": pass_rate,
                    "total_tests": total_tests,
                    "user_count": sum(v["user_count"] for v in data["versions"].values()),
                    "versions": {}
                }
                
                # Обрабатываем данные по версиям
                for version, version_data in data["versions"].items():
                    if version_data["tests"] > 0:
                        version_pass_rate = round(version_data["passed"] / version_data["tests"] * 100, 2)
                    else:
                        version_pass_rate = 0
                    
                    report["platforms"][platform]["versions"][version] = {
                        "pass_rate": version_pass_rate,
                        "total_tests": version_data["tests"],
                        "user_count": version_data["user_count"]
                    }
        
        return report
        
    except Exception as e:
        logger.error(f"Ошибка при генерации отчета о кросс-платформенной совместимости: {e}")
        return {"error": str(e)}