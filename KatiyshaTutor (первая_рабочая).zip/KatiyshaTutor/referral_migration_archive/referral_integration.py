#!/usr/bin/env python
# coding: utf-8

"""
Интеграционный модуль для новой реферальной системы
Этот модуль служит переходным слоем между старым и новым интерфейсом реферальной системы
"""

import logging
from typing import Dict, Any, Optional, List, Callable, Awaitable

from telegram import Update
from telegram.ext import ContextTypes

# Импортируем обработчики из новой реферальной системы
from new_referral_code.referral_handlers import (
    invite_command as new_invite_command,
    referral_stats_callback as new_referral_stats_callback,
    process_referral as new_process_referral,
    process_subscription_rewards as new_process_subscription_rewards,
    extract_referral_code as new_extract_referral_code
)

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Определяем функции-обертки для совместимости со старой системой

async def invite_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обертка для команды /invite из новой реферальной системы
    """
    logger.info(f"Using new referral system's invite_command for user {update.effective_user.id}")
    await new_invite_command(update, context)

async def referral_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обертка для отображения статистики рефералов из новой реферальной системы
    """
    logger.info(f"Using new referral system's referral_stats_callback for user {update.callback_query.from_user.id}")
    await new_referral_stats_callback(update, context)

async def process_referral(update: Update, context: ContextTypes.DEFAULT_TYPE, referral_code: str) -> None:
    """
    Обертка для обработки реферальных кодов из новой реферальной системы
    """
    logger.info(f"Using new referral system's process_referral for user {update.effective_user.id} with code {referral_code}")
    await new_process_referral(update, context, referral_code)

async def process_subscription_rewards(user_id: int, amount: float = 199.0) -> None:
    """
    Обертка для обработки вознаграждений при активации подписки из новой реферальной системы
    """
    logger.info(f"Using new referral system's process_subscription_rewards for user {user_id} with amount {amount}")
    await new_process_subscription_rewards(user_id, amount)

def extract_referral_code(start_parameter: str) -> Optional[str]:
    """
    Обертка для извлечения реферального кода из параметра start из новой реферальной системы
    """
    return new_extract_referral_code(start_parameter)

# Функции для поддержки совместимости со старыми колбэками

async def referral_payouts_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик для старого колбэка referral_payouts
    """
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "Система выплат обновлена! Пожалуйста, используйте раздел \"Награды\" через команду /rewards для получения информации о вознаграждениях."
    )

# Возвращает словарь всех доступных обработчиков для поддержки старой системы
def get_handlers() -> Dict[str, Callable[[Update, ContextTypes.DEFAULT_TYPE], Awaitable[None]]]:
    """
    Получение словаря обработчиков реферальной системы
    
    Returns:
        Dict: Словарь обработчиков {command_name: handler_function}
    """
    return {
        "invite_command": invite_command,
        "referral_stats_callback": referral_stats_callback,
        "referral_payouts_callback": referral_payouts_callback,
        "process_referral": process_referral,
        "process_subscription_rewards": process_subscription_rewards,
        "extract_referral_code": extract_referral_code
    }