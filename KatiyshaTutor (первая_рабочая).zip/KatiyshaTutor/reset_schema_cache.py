#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для перезагрузки кэша схемы SQLAlchemy после изменений в структуре БД
"""

import logging
import os
from sqlalchemy import create_engine, inspect, MetaData
from sqlalchemy.exc import SQLAlchemyError

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

# Database URL
DATABASE_URL = os.environ.get("DATABASE_URL")

def reset_sqlalchemy_schema_cache():
    """
    Перезагружает кэш схемы SQLAlchemy после изменений в структуре БД
    """
    if not DATABASE_URL:
        logger.error("DATABASE_URL не найден в переменных окружения")
        return False

    try:
        engine = create_engine(DATABASE_URL)
        
        # Получаем инспектор для исследования схемы базы данных
        inspector = inspect(engine)
        
        # Список всех таблиц, которые нужно перезагрузить
        tables = inspector.get_table_names()
        
        # Создаем объект MetaData
        metadata = MetaData()
        
        # Для каждой таблицы явно загружаем схему, чтобы обновить кэш
        for table_name in tables:
            logger.info(f"Перезагрузка схемы для таблицы: {table_name}")
            metadata.reflect(engine, only=[table_name], extend_existing=True)
        
        logger.info(f"Перезагружен кэш схем для {len(tables)} таблиц")
        return True
        
    except SQLAlchemyError as e:
        logger.error(f"Ошибка при перезагрузке кэша схем: {e}")
        return False

def main():
    """
    Основная функция
    """
    logger.info("Запуск скрипта перезагрузки кэша схемы SQLAlchemy")
    success = reset_sqlalchemy_schema_cache()
    
    if success:
        logger.info("Перезагрузка кэша схемы SQLAlchemy успешно завершена")
    else:
        logger.error("Перезагрузка кэша схемы SQLAlchemy завершилась с ошибками")

if __name__ == "__main__":
    main()