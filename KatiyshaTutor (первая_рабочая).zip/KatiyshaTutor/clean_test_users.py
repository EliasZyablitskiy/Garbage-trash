#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для удаления тестовых пользователей из базы данных
"""

import os
from datetime import datetime
from db_config import get_flask_app
from db_models import db, User, Transaction, MathProblem, WeeklyPayout, AccumulatedReward, ReferralNetwork, FraudDetectionLog

# ID пользователей, которые следует сохранить
KEEP_USER_IDS = [5913639088, 6198324744]

def check_users_status():
    """
    Проверяет статус пользователей, которых нужно сохранить
    """
    app = get_flask_app()
    
    with app.app_context():
        for user_id in KEEP_USER_IDS:
            user = User.query.get(user_id)
            if user:
                subscription_active = False
                if user.subscription_end and user.subscription_end > datetime.now():
                    subscription_active = True
                
                print(f"Пользователь ID: {user.id}")
                print(f"  Имя пользователя: {user.username or 'Не указано'}")
                print(f"  Дата регистрации: {user.created_at}")
                print(f"  Подписка активна: {subscription_active}")
                if user.subscription_end:
                    print(f"  Подписка до: {user.subscription_end}")
                print()
            else:
                print(f"Пользователь с ID {user_id} не найден в базе данных.")
                print()

def count_users():
    """
    Подсчитывает общее количество пользователей
    """
    app = get_flask_app()
    
    with app.app_context():
        total_users = User.query.count()
        users_to_keep = User.query.filter(User.id.in_(KEEP_USER_IDS)).count()
        users_to_delete = total_users - users_to_keep
        
        print(f"Всего пользователей: {total_users}")
        print(f"Пользователей для сохранения: {users_to_keep}")
        print(f"Пользователей для удаления: {users_to_delete}")
        
        return total_users, users_to_keep, users_to_delete

def list_dependent_data():
    """
    Показывает, сколько связанных данных будет удалено
    """
    app = get_flask_app()
    
    with app.app_context():
        # Зависимые данные для удаляемых пользователей
        delete_condition = ~User.id.in_(KEEP_USER_IDS)
        users_to_delete = User.query.filter(delete_condition).all()
        user_ids_to_delete = [user.id for user in users_to_delete]
        
        transactions_count = Transaction.query.filter(Transaction.user_id.in_(user_ids_to_delete)).count()
        problems_count = MathProblem.query.filter(MathProblem.user_id.in_(user_ids_to_delete)).count()
            
        accumulated_rewards_count = 0
        try:
            accumulated_rewards_count = AccumulatedReward.query.filter(AccumulatedReward.user_id.in_(user_ids_to_delete)).count()
        except Exception as e:
            print(f"Не удалось проверить таблицу AccumulatedReward: {e}")
            
        weekly_payouts_count = 0
        try:
            # Получаем имена колонок для проверки
            column_names = WeeklyPayout.__table__.columns.keys()
            if 'user_id' in column_names:
                weekly_payouts_count = WeeklyPayout.query.filter(WeeklyPayout.user_id.in_(user_ids_to_delete)).count()
            else:
                print("У WeeklyPayout нет колонки user_id")
        except Exception as e:
            print(f"Не удалось проверить таблицу WeeklyPayout: {e}")
        
        referral_networks_count = 0
        try:
            referral_networks_count = ReferralNetwork.query.filter(ReferralNetwork.user_id.in_(user_ids_to_delete)).count()
        except Exception as e:
            print(f"Не удалось проверить таблицу ReferralNetwork: {e}")
            
        fraud_logs_count = 0
        try:
            fraud_logs_count = FraudDetectionLog.query.filter(FraudDetectionLog.user_id.in_(user_ids_to_delete)).count()
        except Exception as e:
            print(f"Не удалось проверить таблицу FraudDetectionLog: {e}")
            
        print(f"Связанные данные для удаления:")
        print(f"- Транзакции: {transactions_count}")
        print(f"- Математические задачи: {problems_count}")
        print(f"- Накопленные вознаграждения: {accumulated_rewards_count}")
        print(f"- Еженедельные выплаты: {weekly_payouts_count}")
        print(f"- Сети рефералов: {referral_networks_count}")
        print(f"- Журналы обнаружения мошенничества: {fraud_logs_count}")

def confirm_deletion():
    """
    Запрашивает подтверждение удаления
    """
    response = input("Вы уверены, что хотите удалить тестовых пользователей? (да/нет): ")
    return response.lower() in ['да', 'yes', 'y', 'д']

def delete_dependent_data():
    """
    Удаляет зависимые данные пользователей
    """
    app = get_flask_app()
    
    with app.app_context():
        # Определяем ID пользователей для удаления
        delete_condition = ~User.id.in_(KEEP_USER_IDS)
        users_to_delete = User.query.filter(delete_condition).all()
        user_ids_to_delete = [user.id for user in users_to_delete]
        
        deleted_count = 0
        
        # Удаляем записи журнала обнаружения мошенничества
        try:
            deleted = FraudDetectionLog.query.filter(FraudDetectionLog.user_id.in_(user_ids_to_delete)).delete(synchronize_session=False)
            db.session.flush()
            print(f"Удалено записей журнала обнаружения мошенничества: {deleted}")
            deleted_count += deleted
        except Exception as e:
            db.session.rollback()
            print(f"Ошибка при удалении записей журнала обнаружения мошенничества: {e}")
        
        # Удаляем сети рефералов
        try:
            deleted = ReferralNetwork.query.filter(ReferralNetwork.user_id.in_(user_ids_to_delete)).delete(synchronize_session=False)
            db.session.flush()
            print(f"Удалено записей о сетях рефералов: {deleted}")
            deleted_count += deleted
        except Exception as e:
            db.session.rollback()
            print(f"Ошибка при удалении записей о сетях рефералов: {e}")
        
        # Удаляем накопленные вознаграждения
        try:
            deleted = AccumulatedReward.query.filter(AccumulatedReward.user_id.in_(user_ids_to_delete)).delete(synchronize_session=False)
            db.session.flush()
            print(f"Удалено накопленных вознаграждений: {deleted}")
            deleted_count += deleted
        except Exception as e:
            db.session.rollback()
            print(f"Ошибка при удалении накопленных вознаграждений: {e}")
        
        # Удаляем еженедельные выплаты, если у них есть колонка user_id
        try:
            column_names = [column.name for column in WeeklyPayout.__table__.columns]
            if 'user_id' in column_names:
                deleted = WeeklyPayout.query.filter(WeeklyPayout.user_id.in_(user_ids_to_delete)).delete(synchronize_session=False)
                db.session.flush()
                print(f"Удалено еженедельных выплат: {deleted}")
                deleted_count += deleted
            else:
                print("У WeeklyPayout нет колонки user_id, пропускаем")
        except Exception as e:
            db.session.rollback()
            print(f"Ошибка при удалении еженедельных выплат: {e}")
        
        # Удаляем транзакции
        try:
            deleted = Transaction.query.filter(Transaction.user_id.in_(user_ids_to_delete)).delete(synchronize_session=False)
            db.session.flush()
            print(f"Удалено транзакций: {deleted}")
            deleted_count += deleted
        except Exception as e:
            db.session.rollback()
            print(f"Ошибка при удалении транзакций: {e}")
        
        # Удаляем математические задачи
        try:
            deleted = MathProblem.query.filter(MathProblem.user_id.in_(user_ids_to_delete)).delete(synchronize_session=False)
            db.session.flush()
            print(f"Удалено математических задач: {deleted}")
            deleted_count += deleted
        except Exception as e:
            db.session.rollback()
            print(f"Ошибка при удалении математических задач: {e}")
        
        # Фиксируем изменения
        try:
            db.session.commit()
            print(f"Все зависимые данные успешно удалены ({deleted_count} записей)")
            return True
        except Exception as e:
            db.session.rollback()
            print(f"Ошибка при фиксации изменений: {e}")
            return False

def delete_test_users():
    """
    Удаляет тестовых пользователей
    """
    app = get_flask_app()
    
    with app.app_context():
        # Удаляем пользователей, кроме указанных
        delete_condition = ~User.id.in_(KEEP_USER_IDS)
        
        try:
            deleted = User.query.filter(delete_condition).delete(synchronize_session=False)
            db.session.commit()
            print(f"Удалено пользователей: {deleted}")
            return deleted
        except Exception as e:
            db.session.rollback()
            print(f"Ошибка при удалении пользователей: {e}")
            return 0

def main():
    """
    Основная функция скрипта
    """
    print("=== Проверка статуса пользователей для сохранения ===")
    check_users_status()
    print()
    
    print("=== Подсчет пользователей ===")
    total_users, users_to_keep, users_to_delete = count_users()
    print()
    
    if users_to_delete == 0:
        print("Нет пользователей для удаления.")
        return
    
    print("=== Подсчет связанных данных ===")
    list_dependent_data()
    print()
    
    if confirm_deletion():
        print("=== Удаление зависимых данных ===")
        if delete_dependent_data():
            print()
            print("=== Удаление тестовых пользователей ===")
            deleted = delete_test_users()
            
            if deleted > 0:
                print()
                print(f"Успешно удалено {deleted} тестовых пользователей.")
                print("=== Проверка результата ===")
                count_users()
    else:
        print("Операция отменена.")

if __name__ == "__main__":
    main()