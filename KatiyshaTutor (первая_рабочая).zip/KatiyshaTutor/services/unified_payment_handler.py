#!/usr/bin/env python
# coding: utf-8

"""
Унифицированный обработчик платежных уведомлений
Предоставляет централизованный механизм для проверки и обработки уведомлений от разных платежных систем
"""

import os
import logging
from typing import Dict, Any, Tuple, Optional, List, Union
from enum import Enum, auto
from flask import Flask, request, jsonify, Blueprint
from datetime import datetime

from services.payment_verification_service_v2 import payment_verification_service_v2, PaymentResultCode, PAYMENT_SYSTEMS
from services.payment_result import PaymentResult
from services.instance_lock_service import instance_lock_service
from services.notification_service import NotificationService

# Настройка логирования
logger = logging.getLogger(__name__)

class PaymentSystem(Enum):
    """Поддерживаемые платежные системы"""
    ROBOKASSA = auto()
    SBP = auto()
    YOOMONEY = auto()
    UNKNOWN = auto()

class UnifiedPaymentHandler:
    """
    Унифицированный обработчик платежных уведомлений
    Централизует логику проверки и обработки платежных уведомлений
    """

    def __init__(self):
        """Инициализация обработчика"""
        self.app = None
        self.notification_service = None

    def init_app(self, app: Flask):
        """
        Инициализация Flask-приложения
        
        Args:
            app: Flask-приложение
        """
        self.app = app
        logger.info("Unified Payment Handler initialized")

    def set_notification_service(self, notification_service: NotificationService):
        """
        Установка сервиса уведомлений
        
        Args:
            notification_service: Сервис уведомлений
        """
        self.notification_service = notification_service
    
    def detect_payment_system(self, request_data: Dict[str, Any], path: str) -> PaymentSystem:
        """
        Определение платежной системы на основе данных запроса и пути
        
        Args:
            request_data: Данные запроса
            path: Путь URL запроса
            
        Returns:
            PaymentSystem: Определенная платежная система
        """
        # Определяем систему по URL
        if 'robokassa' in path.lower():
            return PaymentSystem.ROBOKASSA
        elif 'sbp' in path.lower():
            return PaymentSystem.SBP
        elif 'yoomoney' in path.lower():
            return PaymentSystem.YOOMONEY
            
        # Если не удалось определить по URL, пробуем определить по данным запроса
        if request_data.get('InvId') and request_data.get('OutSum') and request_data.get('SignatureValue'):
            return PaymentSystem.ROBOKASSA
        elif request_data.get('payment_id') or request_data.get('order_id'):
            return PaymentSystem.SBP
        
        return PaymentSystem.UNKNOWN
    
    def get_lock_name(self, payment_system: PaymentSystem, request_data: Dict[str, Any]) -> str:
        """
        Получение имени блокировки для предотвращения параллельной обработки одного платежа
        
        Args:
            payment_system: Платежная система
            request_data: Данные запроса
            
        Returns:
            str: Имя блокировки
        """
        if payment_system == PaymentSystem.ROBOKASSA:
            return f"robokassa_payment_{request_data.get('InvId', 'unknown')}"
        elif payment_system == PaymentSystem.SBP:
            payment_id = request_data.get('payment_id', request_data.get('order_id', 'unknown'))
            return f"sbp_payment_{payment_id}"
        else:
            # Для неизвестных систем используем текущее время
            return f"unknown_payment_{datetime.now().timestamp()}"
    
    def get_payment_system_id(self, payment_system: PaymentSystem) -> str:
        """
        Получение идентификатора платежной системы для сервиса верификации
        
        Args:
            payment_system: Платежная система из enum
            
        Returns:
            str: Идентификатор платежной системы для verification_service
        """
        if payment_system == PaymentSystem.ROBOKASSA:
            return PAYMENT_SYSTEMS['ROBOKASSA']
        elif payment_system == PaymentSystem.SBP:
            return PAYMENT_SYSTEMS['SBP_LINK']
        elif payment_system == PaymentSystem.YOOMONEY:
            return PAYMENT_SYSTEMS['YOOMONEY']
        else:
            return "unknown"
    
    def handle_payment_notification(self, request_data: Dict[str, Any], path: str) -> Tuple[Dict[str, Any], int]:
        """
        Унифицированная обработка уведомления от платежной системы
        
        Args:
            request_data: Данные запроса
            path: Путь URL запроса
            
        Returns:
            Tuple[Dict[str, Any], int]: (ответ в формате JSON, HTTP-код)
        """
        # Определяем платежную систему
        payment_system = self.detect_payment_system(request_data, path)
        
        if payment_system == PaymentSystem.UNKNOWN:
            logger.warning(f"Unknown payment system notification: {path}, data: {request_data}")
            return {"success": False, "message": "Unknown payment system"}, 400
        
        # Получаем имя блокировки
        lock_name = self.get_lock_name(payment_system, request_data)
        
        # Пытаемся получить блокировку
        if not instance_lock_service.acquire_lock(lock_name, timeout=30):
            logger.warning(f"Payment processing already in progress for lock={lock_name}")
            
            # Для Robokassa возвращаем специальный формат ответа
            if payment_system == PaymentSystem.ROBOKASSA:
                inv_id = request_data.get('InvId', '')
                return f"OK{inv_id}", 200
            
            # Для других систем возвращаем JSON
            return {
                "success": True,
                "message": "Payment processing already in progress",
                "transaction_id": None
            }, 200
        
        try:
            # Получаем идентификатор платежной системы для сервиса верификации
            payment_system_id = self.get_payment_system_id(payment_system)
            
            # Проверяем уведомление через улучшенный сервис v2
            logger.info(f"Verifying payment notification for {payment_system.name}")
            payment_result = payment_verification_service_v2.verify_payment_unified(
                notification_data=request_data,
                payment_system=payment_system_id
            )
            
            # Логируем результат проверки
            logger.info(f"Payment verification result: success={payment_result.success}, " 
                      f"code={payment_result.result_code.name if payment_result.result_code else 'None'}, "
                      f"message={payment_result.message}")
            
            if not payment_result.success:
                logger.warning(f"Failed to verify {payment_system.name} notification: {payment_result.message}")
                
                # Для Robokassa возвращаем специальный формат ответа
                if payment_system == PaymentSystem.ROBOKASSA:
                    return f"ERROR: {payment_result.message}", 400
                
                # Для других систем возвращаем JSON
                return {"success": False, "message": payment_result.message}, 400
            
            # Обрабатываем платеж через сервис верификации
            process_result = payment_verification_service_v2.process_payment(payment_result)
            
            # Добавляем информацию о блокировке в лог обработки
            process_result.add_log(f"Payment processed with lock: {lock_name}")
            
            # Формируем ответ в зависимости от платежной системы
            if payment_system == PaymentSystem.ROBOKASSA:
                inv_id = request_data.get('InvId', '')
                if process_result.success:
                    logger.info(f"Successfully processed Robokassa payment: {inv_id}")
                    return f"OK{inv_id}", 200
                else:
                    logger.warning(f"Failed to process Robokassa payment: {inv_id}, but returning OK to prevent retries")
                    return f"OK{inv_id}", 200  # Всё равно OK, чтобы избежать повторных попыток
            else:
                # Для других систем возвращаем JSON с результатом
                response = {
                    "success": process_result.success,
                    "message": process_result.message,
                    "transaction_id": process_result.transaction_id
                }
                
                if process_result.success:
                    logger.info(f"Successfully processed {payment_system.name} payment")
                else:
                    logger.warning(f"Failed to process {payment_system.name} payment: {process_result.message}")
                
                return response, 200 if process_result.success else 400
        
        except Exception as e:
            logger.error(f"Error processing {payment_system.name} notification: {str(e)}", exc_info=True)
            
            # Для Robokassa возвращаем специальный формат ответа
            if payment_system == PaymentSystem.ROBOKASSA:
                return f"ERROR: {str(e)}", 500
            
            # Для других систем возвращаем JSON
            return {"success": False, "message": str(e)}, 500
        
        finally:
            # Освобождаем блокировку в любом случае
            instance_lock_service.release_lock(lock_name)
            logger.debug(f"Payment lock released: {lock_name}")

# Создаем экземпляр обработчика
unified_payment_handler = UnifiedPaymentHandler()