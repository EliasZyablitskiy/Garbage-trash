#!/usr/bin/env python
# coding: utf-8

"""
Сервис блокировок для предотвращения параллельного запуска экземпляров
Обеспечивает механизм блокировок для критических компонентов системы
"""

import os
import time
import uuid
import logging
import atexit
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from sqlalchemy.exc import SQLAlchemyError
from flask import Flask

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Singleton для сервиса блокировок
class InstanceLockService:
    """
    Сервис блокировок для предотвращения параллельного запуска экземпляров
    Использует таблицу instance_locks в базе данных для хранения информации о блокировках
    """
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(InstanceLockService, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
            
        self.app = None
        self.db = None
        self.instance_id = str(uuid.uuid4())
        self.active_locks = {}
        self.lock_timeout = 60  # Время жизни блокировки в секундах
        self._initialized = True
        
        # Регистрируем функцию очистки при завершении
        atexit.register(self.release_all_locks)
    
    def init_app(self, app: Flask):
        """
        Инициализация приложения Flask
        
        Args:
            app: Flask-приложение
        """
        self.app = app
        
        # Импортируем db здесь, чтобы избежать циклических импортов
        with app.app_context():
            from db_models import db
            self.db = db
            
            # Проверяем существование таблицы блокировок
            self._ensure_lock_table_exists()
    
    def _ensure_lock_table_exists(self):
        """
        Проверяет существование таблицы блокировок и создает ее при необходимости
        """
        try:
            # Проверяем, определена ли модель блокировки
            from db_models import InstanceLock
            
            # Если модель определена, создаем таблицу, если она не существует
            if not self.db.engine.dialect.has_table(self.db.engine, 'instance_locks'):
                logger.info("Таблица instance_locks не существует, создаем...")
                
                class InstanceLock(self.db.Model):
                    __tablename__ = 'instance_locks'
                    
                    id = self.db.Column(self.db.Integer, primary_key=True)
                    lock_name = self.db.Column(self.db.String(100), nullable=False, unique=True, index=True)
                    instance_id = self.db.Column(self.db.String(36), nullable=False)
                    created_at = self.db.Column(self.db.DateTime, default=datetime.now)
                    expires_at = self.db.Column(self.db.DateTime, nullable=False)
                    lock_metadata = self.db.Column(self.db.JSON, nullable=True)
                
                self.db.create_all()
                logger.info("Таблица instance_locks успешно создана")
            
        except Exception as e:
            logger.error(f"Ошибка при создании таблицы instance_locks: {str(e)}")
    
    def acquire_lock(self, lock_name: str, timeout: Optional[int] = None, metadata: Optional[Dict[str, Any]] = None) -> bool:
        """
        Попытка захватить блокировку
        
        Args:
            lock_name: Имя блокировки
            timeout: Таймаут блокировки в секундах (переопределяет значение по умолчанию)
            metadata: Метаданные блокировки
            
        Returns:
            bool: True, если блокировка захвачена успешно, False в противном случае
        """
        if not self.db:
            logger.error("Сервис блокировок не инициализирован")
            return False
            
        try:
            # Используем импорт внутри функции для избежания циклических импортов
            from db_models import InstanceLock
            
            # Используем контекст приложения
            with self.app.app_context():
                # Очищаем устаревшие блокировки
                self._cleanup_expired_locks()
                
                # Проверяем, существует ли уже активная блокировка
                existing_lock = InstanceLock.query.filter_by(lock_name=lock_name).first()
                
                if existing_lock:
                    # Проверяем, не истек ли срок действия блокировки
                    if existing_lock.expires_at > datetime.now():
                        # Проверяем, не принадлежит ли блокировка текущему экземпляру
                        if existing_lock.instance_id == self.instance_id:
                            # Обновляем срок действия блокировки
                            lock_timeout = timeout or self.lock_timeout
                            existing_lock.expires_at = datetime.now() + timedelta(seconds=lock_timeout)
                            self.db.session.commit()
                            
                            # Обновляем информацию в словаре активных блокировок
                            self.active_locks[lock_name] = {
                                'expires_at': existing_lock.expires_at,
                                'metadata': metadata or existing_lock.lock_metadata
                            }
                            
                            logger.debug(f"Продлена блокировка {lock_name} для экземпляра {self.instance_id}")
                            return True
                        else:
                            # Блокировка принадлежит другому экземпляру
                            logger.warning(f"Блокировка {lock_name} уже захвачена экземпляром {existing_lock.instance_id}")
                            return False
                    else:
                        # Срок действия блокировки истек, удаляем ее
                        self.db.session.delete(existing_lock)
                        self.db.session.commit()
                
                # Создаем новую блокировку
                lock_timeout = timeout or self.lock_timeout
                expires_at = datetime.now() + timedelta(seconds=lock_timeout)
                
                new_lock = InstanceLock(
                    lock_name=lock_name,
                    instance_id=self.instance_id,
                    expires_at=expires_at,
                    lock_metadata=metadata
                )
                
                self.db.session.add(new_lock)
                self.db.session.commit()
                
                # Добавляем информацию в словарь активных блокировок
                self.active_locks[lock_name] = {
                    'expires_at': expires_at,
                    'metadata': metadata
                }
                
                logger.info(f"Захвачена блокировка {lock_name} для экземпляра {self.instance_id}")
                return True
                
        except SQLAlchemyError as e:
            self.db.session.rollback()
            logger.error(f"Ошибка базы данных при захвате блокировки {lock_name}: {str(e)}")
            return False
        except Exception as e:
            logger.error(f"Ошибка при захвате блокировки {lock_name}: {str(e)}")
            return False
    
    def release_lock(self, lock_name: str) -> bool:
        """
        Освобождение блокировки
        
        Args:
            lock_name: Имя блокировки
            
        Returns:
            bool: True, если блокировка освобождена успешно, False в противном случае
        """
        if not self.db:
            logger.error("Сервис блокировок не инициализирован")
            return False
            
        try:
            # Используем импорт внутри функции для избежания циклических импортов
            from db_models import InstanceLock
            
            # Используем контекст приложения
            with self.app.app_context():
                # Находим блокировку
                lock = InstanceLock.query.filter_by(lock_name=lock_name, instance_id=self.instance_id).first()
                
                if lock:
                    # Удаляем блокировку
                    self.db.session.delete(lock)
                    self.db.session.commit()
                    
                    # Удаляем информацию из словаря активных блокировок
                    if lock_name in self.active_locks:
                        del self.active_locks[lock_name]
                    
                    logger.info(f"Освобождена блокировка {lock_name} для экземпляра {self.instance_id}")
                    return True
                else:
                    logger.warning(f"Блокировка {lock_name} не найдена или принадлежит другому экземпляру")
                    return False
                
        except SQLAlchemyError as e:
            self.db.session.rollback()
            logger.error(f"Ошибка базы данных при освобождении блокировки {lock_name}: {str(e)}")
            return False
        except Exception as e:
            logger.error(f"Ошибка при освобождении блокировки {lock_name}: {str(e)}")
            return False
    
    def release_all_locks(self):
        """
        Освобождение всех блокировок, захваченных текущим экземпляром
        
        Returns:
            bool: True, если все блокировки освобождены успешно, False в противном случае
        """
        if not self.db or not self.app:
            logger.error("Сервис блокировок не инициализирован")
            return False
            
        try:
            # Используем импорт внутри функции для избежания циклических импортов
            from db_models import InstanceLock
            
            # Используем контекст приложения
            with self.app.app_context():
                # Находим все блокировки текущего экземпляра
                locks = InstanceLock.query.filter_by(instance_id=self.instance_id).all()
                
                if locks:
                    # Удаляем все блокировки
                    for lock in locks:
                        self.db.session.delete(lock)
                    
                    self.db.session.commit()
                    
                    # Очищаем словарь активных блокировок
                    self.active_locks.clear()
                    
                    logger.info(f"Освобождены все блокировки для экземпляра {self.instance_id}")
                    return True
                else:
                    logger.info(f"Активные блокировки для экземпляра {self.instance_id} не найдены")
                    return True
                
        except SQLAlchemyError as e:
            self.db.session.rollback()
            logger.error(f"Ошибка базы данных при освобождении всех блокировок: {str(e)}")
            return False
        except Exception as e:
            logger.error(f"Ошибка при освобождении всех блокировок: {str(e)}")
            return False
    
    def is_locked(self, lock_name: str) -> bool:
        """
        Проверка, захвачена ли блокировка
        
        Args:
            lock_name: Имя блокировки
            
        Returns:
            bool: True, если блокировка захвачена, False в противном случае
        """
        if not self.db:
            logger.error("Сервис блокировок не инициализирован")
            return False
            
        try:
            # Используем импорт внутри функции для избежания циклических импортов
            from db_models import InstanceLock
            
            # Используем контекст приложения
            with self.app.app_context():
                # Находим блокировку
                lock = InstanceLock.query.filter_by(lock_name=lock_name).first()
                
                if lock and lock.expires_at > datetime.now():
                    return True
                else:
                    return False
                
        except Exception as e:
            logger.error(f"Ошибка при проверке блокировки {lock_name}: {str(e)}")
            return False
    
    def _cleanup_expired_locks(self):
        """
        Очистка устаревших блокировок
        """
        try:
            # Используем импорт внутри функции для избежания циклических импортов
            from db_models import InstanceLock
            
            # Удаляем все блокировки, срок действия которых истек
            InstanceLock.query.filter(InstanceLock.expires_at < datetime.now()).delete()
            self.db.session.commit()
            
        except SQLAlchemyError as e:
            self.db.session.rollback()
            logger.error(f"Ошибка базы данных при очистке устаревших блокировок: {str(e)}")
        except Exception as e:
            logger.error(f"Ошибка при очистке устаревших блокировок: {str(e)}")


# Создаем singleton для сервиса блокировок
instance_lock_service = InstanceLockService()