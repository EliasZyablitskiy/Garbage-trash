#!/usr/bin/env python
# coding: utf-8

"""
Модели для новой реферальной системы (PostgreSQL)
"""

import uuid
from datetime import datetime
from typing import Dict, Any, List

from db_models import db, User

class ReferralCode(db.Model):
    """Модель для хранения реферальных кодов"""
    __tablename__ = 'referral_codes'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.id'), nullable=False)
    code = db.Column(db.String(32), unique=True, nullable=False)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Отношения
    user = db.relationship("User", backref="referral_codes", overlaps="referral_codes_rel")
    
    def to_dict(self) -> Dict[str, Any]:
        """Преобразование в словарь для JSON"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "code": self.code,
            "active": self.active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }

class ReferralRelation(db.Model):
    """Модель для хранения отношений между реферером и рефералом"""
    __tablename__ = 'referral_relations'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.id'), nullable=False)
    referrer_id = db.Column(db.BigInteger, db.ForeignKey('users.id'), nullable=False)
    level = db.Column(db.Integer, default=1)
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Отношения
    user = db.relationship("User", foreign_keys=[user_id], backref="referred_by", overlaps="referred_by_rel")
    referrer = db.relationship("User", foreign_keys=[referrer_id], backref="referred_users", overlaps="referred_users_rel")
    
    def to_dict(self) -> Dict[str, Any]:
        """Преобразование в словарь для JSON"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "referrer_id": self.referrer_id,
            "level": self.level,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }

class ReferralReward(db.Model):
    """Модель для хранения начисленных реферальных вознаграждений"""
    __tablename__ = 'referral_rewards'
    
    id = db.Column(db.Integer, primary_key=True)
    referral_relation_id = db.Column(db.Integer, db.ForeignKey('referral_relations.id'), nullable=False)
    transaction_id = db.Column(db.Integer, db.ForeignKey('transactions.id'), nullable=True)
    amount = db.Column(db.Float, nullable=False)
    source_transaction_id = db.Column(db.Integer, db.ForeignKey('transactions.id'), nullable=True)
    status = db.Column(db.String(20), default="pending")  # pending, paid, cancelled
    payout_id = db.Column(db.Integer, db.ForeignKey('weekly_payouts.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Отношения
    referral_relation = db.relationship("ReferralRelation")
    transaction = db.relationship("Transaction", foreign_keys=[transaction_id])
    source_transaction = db.relationship("Transaction", foreign_keys=[source_transaction_id])
    payout = db.relationship("WeeklyPayout")
    
    def to_dict(self) -> Dict[str, Any]:
        """Преобразование в словарь для JSON"""
        return {
            "id": self.id,
            "referral_relation_id": self.referral_relation_id,
            "transaction_id": self.transaction_id,
            "amount": self.amount,
            "source_transaction_id": self.source_transaction_id,
            "status": self.status,
            "payout_id": self.payout_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }

# Добавляем отношения к существующим моделям - определяем их как только для чтения (viewonly=True)
User.referral_codes_rel = db.relationship("ReferralCode", back_populates="user", overlaps="referral_codes", viewonly=True)
User.referred_by_rel = db.relationship("ReferralRelation", foreign_keys="ReferralRelation.user_id", back_populates="user", overlaps="referred_by", viewonly=True)
User.referred_users_rel = db.relationship("ReferralRelation", foreign_keys="ReferralRelation.referrer_id", back_populates="referrer", overlaps="referred_users", viewonly=True)