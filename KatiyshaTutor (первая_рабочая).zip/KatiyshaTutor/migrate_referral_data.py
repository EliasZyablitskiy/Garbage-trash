#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для миграции данных из старой реферальной системы в новую оптимизированную версию
"""

import os
import sys
import json
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple, Set

from db_config import get_flask_app
from db_models import db, User, Transaction, WeeklyPayout
from new_referral_models import ReferralCode, ReferralRelation, ReferralReward
from new_referral_code.optimized_referral_manager import OptimizedReferralManager

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class ReferralDataMigrator:
    """Класс для миграции данных реферальной системы"""
    
    def __init__(self):
        """Инициализация миграции"""
        self.app = get_flask_app()
        self.referral_manager = OptimizedReferralManager()
        self.total_users = 0
        self.migrated_users = 0
        self.migrated_relations = 0
        self.migrated_rewards = 0
        self.errors = 0
        
    def _ensure_tables_exist(self) -> None:
        """Проверка существования необходимых таблиц"""
        with self.app.app_context():
            db.create_all()
            logger.info("Database tables checked")
            
    def migrate_all_data(self, clean_existing: bool = False) -> Dict[str, Any]:
        """
        Миграция всех данных реферальной системы
        
        Args:
            clean_existing: Очистить существующие данные перед миграцией
            
        Returns:
            Dict[str, Any]: Статистика миграции
        """
        self._ensure_tables_exist()
        
        if clean_existing:
            self._clean_existing_data()
            
        # Основные шаги миграции
        self._migrate_referral_codes()
        self._migrate_referral_relations()
        self._migrate_pending_rewards()
        
        # Возвращаем статистику
        return {
            "total_users": self.total_users,
            "migrated_users": self.migrated_users,
            "migrated_relations": self.migrated_relations,
            "migrated_rewards": self.migrated_rewards,
            "errors": self.errors,
            "success_rate": round((1 - (self.errors / max(1, self.total_users))) * 100, 2)
        }
        
    def _clean_existing_data(self) -> None:
        """Очистка существующих данных перед миграцией"""
        with self.app.app_context():
            try:
                # Удаляем созданные данные в правильном порядке (с учетом внешних ключей)
                logger.info("Cleaning existing referral data...")
                ReferralReward.query.delete()
                ReferralRelation.query.delete()
                ReferralCode.query.delete()
                db.session.commit()
                logger.info("Existing referral data cleaned")
            except Exception as e:
                db.session.rollback()
                logger.error(f"Error cleaning existing data: {e}")
                self.errors += 1
    
    def _migrate_referral_codes(self) -> None:
        """Миграция реферальных кодов пользователей"""
        with self.app.app_context():
            try:
                # Получаем всех пользователей
                users = User.query.all()
                self.total_users = len(users)
                logger.info(f"Starting migration of referral codes for {self.total_users} users")
                
                for user in users:
                    try:
                        # Проверяем, есть ли у пользователя реферальный код в старой системе
                        if hasattr(user, 'referral_code') and user.referral_code:
                            # Создаем код в новой системе с тем же значением
                            existing_code = ReferralCode.query.filter_by(user_id=user.id).first()
                            
                            if existing_code:
                                # Если код уже существует, просто обновляем его значение
                                existing_code.code = user.referral_code
                                db.session.add(existing_code)
                            else:
                                # Создаем новый код
                                new_code = ReferralCode(
                                    user_id=user.id,
                                    code=user.referral_code,
                                    active=True,
                                    created_at=datetime.now()
                                )
                                db.session.add(new_code)
                                
                            self.migrated_users += 1
                            if self.migrated_users % 100 == 0:
                                logger.info(f"Migrated {self.migrated_users} referral codes")
                        else:
                            # Для пользователей без кода создаем новый через менеджер
                            # Это инициирует автоматическое создание кода
                            self.referral_manager.get_or_create_referral_code(user.id)
                            self.migrated_users += 1
                    except Exception as e:
                        logger.error(f"Error migrating referral code for user {user.id}: {e}")
                        self.errors += 1
                
                # Сохраняем изменения
                db.session.commit()
                logger.info(f"Completed migration of referral codes for {self.migrated_users} users")
            except Exception as e:
                db.session.rollback()
                logger.error(f"Error in referral codes migration: {e}")
                self.errors += 1
    
    def _migrate_referral_relations(self) -> None:
        """Миграция реферальных отношений"""
        with self.app.app_context():
            try:
                # Получаем всех пользователей с реферерами
                users_with_referrers = User.query.filter(User.referrer_id.isnot(None)).all()
                logger.info(f"Starting migration of referral relations for {len(users_with_referrers)} users")
                
                for user in users_with_referrers:
                    try:
                        # Проверяем, есть ли уже отношение в новой системе
                        existing_relation = ReferralRelation.query.filter_by(
                            user_id=user.id, 
                            referrer_id=user.referrer_id
                        ).first()
                        
                        if not existing_relation:
                            # Создаем новое отношение
                            # Уровень по умолчанию 1, остальные уровни будут пересчитаны менеджером
                            new_relation = ReferralRelation(
                                user_id=user.id,
                                referrer_id=user.referrer_id,
                                level=1,
                                created_at=user.created_at or datetime.now()
                            )
                            db.session.add(new_relation)
                            self.migrated_relations += 1
                            
                            if self.migrated_relations % 100 == 0:
                                logger.info(f"Migrated {self.migrated_relations} referral relations")
                                db.session.commit()  # Промежуточное сохранение для длинных операций
                    except Exception as e:
                        logger.error(f"Error migrating referral relation for user {user.id}: {e}")
                        self.errors += 1
                
                # Сохраняем изменения
                db.session.commit()
                logger.info(f"Completed migration of {self.migrated_relations} referral relations")
                
                # Пересчитываем уровни реферальных отношений
                self._recalculate_referral_levels()
            except Exception as e:
                db.session.rollback()
                logger.error(f"Error in referral relations migration: {e}")
                self.errors += 1
    
    def _recalculate_referral_levels(self) -> None:
        """Пересчет уровней реферальных отношений"""
        with self.app.app_context():
            try:
                logger.info("Recalculating referral levels...")
                
                # Получаем все прямые отношения (уровень 1)
                level1_relations = ReferralRelation.query.filter_by(level=1).all()
                logger.info(f"Found {len(level1_relations)} direct referral relations")
                
                # Обрабатываем каждую цепочку рекурсивно
                processed_relations = 0
                for relation in level1_relations:
                    self._process_referral_chain(relation.referrer_id, relation.user_id, 1)
                    processed_relations += 1
                    
                    if processed_relations % 100 == 0:
                        logger.info(f"Processed {processed_relations} referral chains")
                        db.session.commit()  # Промежуточное сохранение
                
                # Сохраняем изменения
                db.session.commit()
                logger.info("Completed recalculation of referral levels")
            except Exception as e:
                db.session.rollback()
                logger.error(f"Error recalculating referral levels: {e}")
                self.errors += 1
    
    def _process_referral_chain(self, root_user_id: int, current_user_id: int, current_level: int) -> None:
        """
        Рекурсивная обработка цепочки рефералов для установки правильных уровней
        
        Args:
            root_user_id: ID корневого пользователя в цепочке
            current_user_id: ID текущего пользователя
            current_level: Текущий уровень в цепочке
        """
        if current_level >= OptimizedReferralManager.MAX_LEVEL:
            return
            
        # Получаем всех прямых рефералов текущего пользователя
        next_level_relations = ReferralRelation.query.filter_by(referrer_id=current_user_id, level=1).all()
        
        for relation in next_level_relations:
            # Создаем отношение между корневым пользователем и рефералом следующего уровня
            existing_relation = ReferralRelation.query.filter_by(
                user_id=relation.user_id,
                referrer_id=root_user_id
            ).first()
            
            new_level = current_level + 1
            
            if existing_relation:
                # Если отношение уже существует, обновляем уровень если он меньше
                if existing_relation.level > new_level:
                    existing_relation.level = new_level
                    db.session.add(existing_relation)
            else:
                # Создаем новое отношение с правильным уровнем
                new_relation = ReferralRelation(
                    user_id=relation.user_id,
                    referrer_id=root_user_id,
                    level=new_level,
                    created_at=datetime.now()
                )
                db.session.add(new_relation)
                self.migrated_relations += 1
            
            # Рекурсивно обрабатываем следующий уровень
            self._process_referral_chain(root_user_id, relation.user_id, new_level)
    
    def _migrate_pending_rewards(self) -> None:
        """Миграция ожидающих выплат"""
        with self.app.app_context():
            try:
                # Здесь нужно мигрировать неоплаченные транзакции реферальных наград
                # Получаем все транзакции реферальных вознаграждений, которые еще не выплачены
                pending_transactions = Transaction.query.filter_by(
                    type="referral_reward",
                    status="pending"
                ).all()
                
                logger.info(f"Starting migration of {len(pending_transactions)} pending referral rewards")
                
                for transaction in pending_transactions:
                    try:
                        # Проверяем доступность необходимых данных
                        if not transaction.user_id or not transaction.description:
                            logger.warning(f"Incomplete transaction data for ID {transaction.id}, skipping")
                            continue
                        
                        # Получаем ID источника вознаграждения из описания, если доступно
                        source_transaction_id = None
                        if "Transaction ID:" in transaction.description:
                            try:
                                # Извлекаем ID исходной транзакции из описания
                                source_transaction_id = int(transaction.description.split("Transaction ID:")[1].strip().split()[0])
                            except (ValueError, IndexError):
                                logger.warning(f"Could not extract source transaction ID from: {transaction.description}")
                        
                        # Получаем отношение между пользователями
                        # Сначала ищем в новой системе
                        referrer_id = None
                        level = 1
                        
                        # Пытаемся получить информацию о реферере
                        user = User.query.get(transaction.user_id)
                        if user and user.referrer_id:
                            referrer_id = user.referrer_id
                            
                            # Ищем отношение в новой системе
                            relation = ReferralRelation.query.filter_by(
                                user_id=transaction.user_id,
                                referrer_id=referrer_id
                            ).first()
                            
                            if relation:
                                level = relation.level
                            else:
                                # Если отношения нет, создаем его
                                relation = ReferralRelation(
                                    user_id=transaction.user_id,
                                    referrer_id=referrer_id,
                                    level=level,
                                    created_at=transaction.created_at or datetime.now()
                                )
                                db.session.add(relation)
                                db.session.flush()  # Получаем ID отношения
                                self.migrated_relations += 1
                        else:
                            logger.warning(f"Could not find referrer for user {transaction.user_id}, skipping reward")
                            continue
                            
                        if relation:
                            # Создаем вознаграждение в новой системе
                            reward = ReferralReward(
                                referral_relation_id=relation.id,
                                amount=transaction.amount,
                                source_transaction_id=source_transaction_id,
                                status="pending",
                                created_at=transaction.created_at or datetime.now()
                            )
                            db.session.add(reward)
                            self.migrated_rewards += 1
                            
                            if self.migrated_rewards % 50 == 0:
                                logger.info(f"Migrated {self.migrated_rewards} referral rewards")
                                db.session.commit()  # Промежуточное сохранение
                    except Exception as e:
                        logger.error(f"Error migrating reward for transaction {transaction.id}: {e}")
                        self.errors += 1
                
                # Сохраняем изменения
                db.session.commit()
                logger.info(f"Completed migration of {self.migrated_rewards} referral rewards")
            except Exception as e:
                db.session.rollback()
                logger.error(f"Error in pending rewards migration: {e}")
                self.errors += 1
    
def main():
    """Основная функция для запуска миграции"""
    import argparse
    parser = argparse.ArgumentParser(description='Referral System Data Migration')
    parser.add_argument('--clean', action='store_true', help='Clean existing referral data before migration')
    parser.add_argument('--yes', action='store_true', help='Skip confirmation prompt')
    
    args = parser.parse_args()
    
    if args.clean and not args.yes:
        confirm = input("WARNING: This will delete all existing referral data. Are you sure? (yes/no): ")
        if confirm.lower() != "yes":
            print("Migration aborted.")
            return
    
    print("Starting referral system data migration...")
    migrator = ReferralDataMigrator()
    results = migrator.migrate_all_data(clean_existing=args.clean)
    
    print("\nMigration completed!")
    print(f"Total users processed: {results['total_users']}")
    print(f"Users with migrated referral codes: {results['migrated_users']}")
    print(f"Migrated referral relations: {results['migrated_relations']}")
    print(f"Migrated pending rewards: {results['migrated_rewards']}")
    print(f"Errors encountered: {results['errors']}")
    print(f"Success rate: {results['success_rate']}%")

if __name__ == "__main__":
    main()