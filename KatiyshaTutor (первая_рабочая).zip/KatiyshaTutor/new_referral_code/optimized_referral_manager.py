#!/usr/bin/env python
# coding: utf-8

"""
Оптимизированный менеджер реферальной системы для масштабирования до 100,000+ пользователей
Улучшения включают:
- Кэширование данных о реферальной иерархии
- Оптимизированные запросы к базе данных
- Пакетная обработка вознаграждений
- Пагинация для больших выборок
"""

import logging
import uuid
import string
import random
import json
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple, Set, Union

from db_config import get_flask_app
from db_models import db, User, Transaction, WeeklyPayout
from new_referral_models import ReferralCode, ReferralRelation, ReferralReward

# Экземпляр менеджера для использования в функциях модуля
_referral_manager = None

def get_referral_manager():
    """
    Получение экземпляра менеджера реферальной системы (синглтон)
    
    Returns:
        OptimizedReferralManager: Экземпляр менеджера
    """
    global _referral_manager
    if _referral_manager is None:
        _referral_manager = OptimizedReferralManager()
    return _referral_manager

def calculate_and_distribute_rewards(user_id: int, amount: float) -> Dict[str, Any]:
    """
    Рассчитывает и распределяет реферальные вознаграждения для пользователя
    
    Args:
        user_id: ID пользователя
        amount: Сумма оплаты
        
    Returns:
        Dict[str, Any]: Результат операции с информацией о начисленных вознаграждениях
    """
    try:
        manager = get_referral_manager()
        
        with manager.app.app_context():
            # Находим существующую транзакцию для платежа
            transaction = Transaction.query.filter_by(
                user_id=user_id,
                type="subscription",
                amount=amount,
                status="success"
            ).order_by(Transaction.created_at.desc()).first()
            
            # Проверяем существование транзакции
            if not transaction:
                # Если транзакция не найдена, логируем ошибку и возвращаем информацию об ошибке
                error_message = f"Ошибка при расчете реферальных вознаграждений: не найдена транзакция для пользователя {user_id} с суммой {amount}"
                logging.error(error_message)
                return {
                    "success": False,
                    "rewards_count": 0,
                    "total_rewards": 0.0,
                    "details": [],
                    "error": error_message
                }
                
            # Начисляем реферальные вознаграждения только для подтвержденных транзакций
            rewards = manager.process_payment_rewards(
                user_id=user_id,
                amount=amount,
                transaction_id=transaction.id
            )
            
            # Форматируем результат
            return {
                "success": True,
                "rewards_count": len(rewards),
                "total_rewards": sum(reward.get("amount", 0) for reward in rewards),
                "details": rewards
            }
    except Exception as e:
        logging.error(f"Error calculating referral rewards: {e}", exc_info=True)
        return {
            "success": False,
            "rewards_count": 0,
            "total_rewards": 0.0,
            "details": [],
            "error": str(e)
        }

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class OptimizedReferralManager:
    """
    Оптимизированный менеджер реферальной системы для масштабирования до 100,000+ пользователей
    """
    
    # Комиссии для уровней (1-4)
    LEVEL_COMMISSIONS = {
        1: 0.05,  # 5% для прямых рефералов
        2: 0.02,  # 2% для рефералов 2-го уровня
        3: 0.02,  # 2% для рефералов 3-го уровня
        4: 0.02   # 2% для рефералов 4-го уровня
    }
    
    # Максимальный уровень комиссии
    MAX_LEVEL = 4
    
    # Размер партии для пакетной обработки в операциях с большими объемами данных
    BATCH_SIZE = 1000
    
    # Кэширование для часто запрашиваемых данных
    # В реальной системе следует использовать Redis или другой внешний кэш
    _cache = {
        'referral_codes': {},         # user_id -> code
        'referrer_chains': {},        # user_id -> {level -> referrer_id}
        'referral_stats': {},         # user_id -> {count, total_rewards, etc}
    }
    
    def __init__(self):
        """
        Инициализация менеджера реферальной системы
        """
        from db_config import get_flask_app
        self.app = get_flask_app()
        
        # Сбрасываем кэш при инициализации
        for cache_type in self._cache:
            self._cache[cache_type] = {}
    
    def _app_context(self):
        """
        Контекстный менеджер для работы в контексте Flask приложения
        
        Это генератор, который следует использовать с циклом for:
        ```
        for _ in self._app_context():
            # код, требующий контекста приложения
        ```
        
        Yields:
            None: Просто сигнализирует, что контекст активен
        """
        if not hasattr(self, 'app') or self.app is None:
            from db_config import get_flask_app
            self.app = get_flask_app()
        
        # Создаем контекст приложения Flask
        ctx = self.app.app_context()
        # Активируем его
        ctx.push()
        try:
            # Возвращаем управление вызывающему коду (только один раз)
            yield None
        finally:
            # Всегда выполняем при выходе из контекста
            ctx.pop()
    
    def _cache_get(self, cache_type: str, key: Union[int, str]) -> Any:
        """Получение данных из кэша"""
        cache = self._cache.get(cache_type, {})
        return cache.get(key)
    
    def _cache_set(self, cache_type: str, key: Union[int, str], value: Any, 
                  max_items: int = 10000) -> None:
        """Сохранение данных в кэш с ограничением количества элементов"""
        if cache_type not in self._cache:
            self._cache[cache_type] = {}
            
        # Контроль размера кэша - в реальном приложении следует использовать 
        # LRU или другие стратегии устаревания
        if len(self._cache[cache_type]) >= max_items:
            # Удаляем случайный элемент (в реальности нужен более продвинутый алгоритм)
            if self._cache[cache_type]:
                random_key = next(iter(self._cache[cache_type]))
                self._cache[cache_type].pop(random_key, None)
                
        self._cache[cache_type][key] = value
    
    def _cache_invalidate(self, cache_type: str, key: Union[int, str] = None) -> None:
        """Инвалидация кэша"""
        if key is None:
            # Очистка всего кэша указанного типа
            self._cache[cache_type] = {}
        else:
            # Очистка только конкретного ключа
            if cache_type in self._cache:
                self._cache[cache_type].pop(key, None)
    
    def generate_referral_code(self, user_id: int, min_length: int = 6, max_length: int = 12) -> str:
        """
        Генерация уникального реферального кода с улучшенным алгоритмом
        
        Args:
            user_id: ID пользователя для включения в код
            min_length: Минимальная длина кода
            max_length: Максимальная длина кода
            
        Returns:
            str: Сгенерированный код
        """
        # Сохраняем оригинальный алгоритм, т.к. он уже оптимизирован
        # Списки гласных и согласных для лучшей произносимости
        vowels = 'aeiouy'
        consonants = 'bcdfghjklmnpqrstvwxz'
        
        # Запрещенные слова, которые не должны появляться в коде
        banned_words = ['sex', 'xxx', 'ass', 'fuck', 'shit', 'dick', 'cock', 'piss', 'poop']

        # Преобразуем user_id в строку и берем последние 4 цифры (или меньше)
        user_str = str(user_id)
        user_part = user_str[-min(4, len(user_str)):]
        
        # Определяем длину кода (увеличивается с ростом числа пользователей)
        with self.app.app_context():
            user_count = db.session.query(db.func.count(ReferralCode.id)).scalar() or 0
            
            # Увеличиваем длину по мере роста базы
            adaptive_length = min(max_length, min_length + (user_count // 10000))
            
            # Минимальное количество случайных символов
            rand_length = max(2, adaptive_length - len(user_part) - 1)
            
            attempt_count = 0
            while True:
                attempt_count += 1
                
                # Генерируем случайную часть, чередуя согласные и гласные
                random_part = ''
                for i in range(rand_length):
                    if i % 2 == 0:
                        random_part += random.choice(consonants)
                    else:
                        random_part += random.choice(vowels)
                
                # Префикс 'r' + часть ID + случайная часть
                code = 'r' + user_part + random_part
                
                # Проверка на запрещенные слова
                contains_banned = False
                for word in banned_words:
                    if word in code.lower():
                        contains_banned = True
                        break
                
                if contains_banned:
                    continue
                
                # Проверяем уникальность
                existing = db.session.query(ReferralCode).filter_by(code=code).first()
                if not existing:
                    return code
                
                # Если слишком много попыток, увеличиваем длину случайной части
                if attempt_count > 5:
                    rand_length += 1
    
    def get_or_create_referral_code(self, user_id: int) -> str:
        """
        Получение реферального кода пользователя, создание нового если отсутствует
        
        Args:
            user_id: ID пользователя
            
        Returns:
            str: Реферальный код
        """
        # Проверяем кэш
        cached_code = self._cache_get('referral_codes', user_id)
        if cached_code:
            return cached_code
            
        with self.app.app_context():
            # Проверяем наличие активного кода
            referral_code = ReferralCode.query.filter_by(user_id=user_id, active=True).first()
            
            if referral_code:
                # Кэшируем результат
                self._cache_set('referral_codes', user_id, referral_code.code)
                return referral_code.code
            
            # Создаем новый код с обновленным алгоритмом
            new_code = self.generate_referral_code(user_id)
            referral_code = ReferralCode(
                user_id=user_id,
                code=new_code,
                active=True
            )
            db.session.add(referral_code)
            db.session.commit()
            
            # Кэшируем результат
            self._cache_set('referral_codes', user_id, new_code)
            return new_code
    
    def add_referral(self, user_id: int, referral_code: str) -> bool:
        """
        Добавление реферального отношения между пользователями
        
        Args:
            user_id: ID пользователя-реферала
            referral_code: Реферальный код реферера
            
        Returns:
            bool: True, если отношение успешно добавлено, False в противном случае
        """
        with self.app.app_context():
            # Проверяем существует ли такой реферальный код
            ref_code = ReferralCode.query.filter_by(code=referral_code, active=True).first()
            if not ref_code:
                logger.warning(f"Referral code {referral_code} not found or inactive")
                return False
            
            # Нельзя быть своим реферером
            if ref_code.user_id == user_id:
                logger.warning(f"User {user_id} tried to be their own referrer")
                return False
            
            # Проверяем существует ли пользователь-реферал
            user = User.query.filter_by(id=user_id).first()
            if not user:
                logger.warning(f"User {user_id} not found")
                return False
            
            # Проверяем существует ли уже реферальное отношение для этого пользователя
            existing_relation = ReferralRelation.query.filter_by(user_id=user_id).first()
            if existing_relation:
                logger.warning(f"User {user_id} already has referrer {existing_relation.referrer_id}")
                return False
            
            # Создаем реферальное отношение
            relation = ReferralRelation(
                user_id=user_id,
                referrer_id=ref_code.user_id,
                level=1  # Прямой реферал
            )
            db.session.add(relation)
            
            # Обновляем реферальные отношения для вышестоящих уровней
            try:
                self._update_referral_hierarchy(user_id, ref_code.user_id)
                db.session.commit()
                
                # Инвалидируем кэш для пользователя
                self._cache_invalidate('referrer_chains', user_id)
                self._cache_invalidate('referral_stats', ref_code.user_id)
                
                logger.info(f"Added referral relationship: {user_id} <- {ref_code.user_id}")
                return True
            except Exception as e:
                logger.error(f"Error adding referral relationship: {e}")
                db.session.rollback()
                return False
    
    def _get_user_referral_chain(self, user_id: int) -> Dict[int, Dict[str, Any]]:
        """
        Получение цепочки рефереров для пользователя с кэшированием
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Dict[int, Dict[str, Any]]: Словарь {уровень: {id: ID реферера, relation_id: ID отношения}}
        """
        # Проверяем кэш сначала
        cached_chain = self._cache_get('referrer_chains', user_id)
        if cached_chain:
            logger.debug(f"Found cached referral chain for user {user_id}")
            return cached_chain
        
        # Если нет в кэше, загружаем из БД
        try:
            # Используем правильный импорт из new_referral_models
            from new_referral_models import ReferralRelation
            
            relations = ReferralRelation.query.filter_by(user_id=user_id).all()
            referrer_chain = {}
            
            for relation in relations:
                referrer_chain[relation.level] = {
                    'id': relation.referrer_id, 
                    'relation_id': relation.id
                }
            
            # Сохраняем в кэш
            self._cache_set('referrer_chains', user_id, referrer_chain)
            logger.debug(f"Loaded and cached referral chain for user {user_id}: {len(referrer_chain)} levels")
            
            return referrer_chain
        except Exception as e:
            logger.error(f"Error retrieving referral chain for user {user_id}: {e}")
            return {}

    def _update_referral_hierarchy(self, user_id: int, direct_referrer_id: int) -> None:
        """
        Оптимизированное обновление иерархии реферальных отношений 
        
        Args:
            user_id: ID пользователя
            direct_referrer_id: ID прямого реферера
        """
        # Оптимизированный алгоритм с предзагрузкой данных и батчингом
        
        # Начинаем с прямого реферера
        current_level_ids = [direct_referrer_id]
        
        # Создаем словарь для хранения связей "уровень -> список рефереров"
        level_referrers = {1: [direct_referrer_id]}
        
        # Предварительно загружаем цепочки рефереров для всех рефереров первого уровня
        for level in range(2, self.MAX_LEVEL + 1):
            if not current_level_ids:
                break
                
            # Получаем всех рефереров для текущего уровня одним запросом
            referrer_relations = ReferralRelation.query.filter(
                ReferralRelation.user_id.in_(current_level_ids),
                ReferralRelation.level == 1
            ).all()
            
            if not referrer_relations:
                break
                
            # Собираем ID для следующего уровня
            next_level_ids = []
            for relation in referrer_relations:
                next_level_ids.append(relation.referrer_id)
                
            # Сохраняем рефереров для текущего уровня
            level_referrers[level] = [r.referrer_id for r in referrer_relations]
            
            # Обновляем текущие ID для следующей итерации
            current_level_ids = next_level_ids
        
        # Теперь создаем все необходимые отношения одним батчем
        relations_to_add = []
        
        for level, referrer_ids in level_referrers.items():
            if level == 1:  # Отношение 1-го уровня уже создано
                continue
                
            for referrer_id in referrer_ids:
                relation = ReferralRelation(
                    user_id=user_id,
                    referrer_id=referrer_id,
                    level=level
                )
                relations_to_add.append(relation)
        
        try:
            # Батчинг вставки - добавляем все отношения одной операцией
            if relations_to_add:
                db.session.add_all(relations_to_add)
                
            db.session.flush()
            
            # Инвалидируем кэш для обновленных пользователей
            self._cache_invalidate('referrer_chains', user_id)
            
            # Инвалидируем кэш для всех рефереров в цепочке
            for level, referrer_ids in level_referrers.items():
                for referrer_id in referrer_ids:
                    self._cache_invalidate('referral_stats', referrer_id)
            
            db.session.commit()
            logger.info(f"Updated referral hierarchy for user {user_id} with direct referrer {direct_referrer_id} and {len(relations_to_add)} additional relations")
            
            return
            
        except Exception as e:
            logger.error(f"Error updating referral hierarchy: {e}")
            db.session.rollback()
            return
    
    def calculate_reward_amount(self, level: int, amount: float) -> float:
        """
        Рассчитывает сумму вознаграждения по уровню и сумме платежа
        
        Args:
            level: Уровень в реферальной иерархии
            amount: Сумма платежа
            
        Returns:
            float: Рассчитанная сумма вознаграждения
        """
        if level not in self.LEVEL_COMMISSIONS:
            return 0.0
        
        return amount * self.LEVEL_COMMISSIONS[level]
    
    def process_payment_rewards(self, user_id: int, amount: float, transaction_id: int, 
                              min_amount: float = 1.0) -> List[Dict[str, Any]]:
        """
        Оптимизированное начисление реферальных вознаграждений за платеж с атомарными транзакциями
        
        Args:
            user_id: ID пользователя, совершившего платеж
            amount: Сумма платежа
            transaction_id: ID транзакции платежа
            min_amount: Минимальная сумма вознаграждения для начисления
            
        Returns:
            List[Dict]: Список начисленных вознаграждений
        """
        rewards = []
        
        with self.app.app_context():
            # Используем транзакции для гарантии атомарности
            try:
                # Блокируем транзакцию для чтения/записи чтобы избежать гонок данных
                transaction = Transaction.query.with_for_update().filter_by(id=transaction_id).first()
                if not transaction:
                    logger.error(f"Transaction {transaction_id} not found")
                    return []
                
                # Проверяем, существуют ли уже вознаграждения для этой транзакции - тоже с блокировкой
                existing_rewards = ReferralReward.query.filter_by(source_transaction_id=transaction_id).all()
                if existing_rewards:
                    logger.warning(f"Rewards for transaction {transaction_id} already exist")
                    # Возвращаем существующие вознаграждения в том же формате
                    result = []
                    for reward in existing_rewards:
                        # Получаем информацию о реферальном отношении
                        relation = ReferralRelation.query.filter_by(id=reward.referral_relation_id).first()
                        if relation:
                            result.append({
                                "referrer_id": relation.referrer_id,
                                "level": relation.level,
                                "amount": reward.amount
                            })
                    return result
                
                # Создаем журнал операции
                operation_log = None
                try:
                    from db_models import PayoutOperationLog
                    operation_log = PayoutOperationLog(
                        operation_type="process_payment_rewards",
                        entity_id=transaction_id,
                        entity_type="transaction",
                        source_user_id=user_id,
                        amount=amount,
                        status="started",
                        operation_metadata=json.dumps({
                            "transaction_id": transaction_id,
                            "amount": amount,
                            "min_amount": min_amount
                        })
                    )
                    db.session.add(operation_log)
                    db.session.flush()  # Получаем ID без коммита
                except Exception as e:
                    logger.warning(f"Error creating operation log (non-critical): {e}")
                
                # Двухфазная обработка: сначала рассчитываем все суммы и проверяем валидность
                # Используем кэширование для получения цепочки рефереров
                referral_chain = self._get_user_referral_chain(user_id)
                
                # Предварительная проверка - фаза 1
                reward_calculations = []
                for level, referrer_data in referral_chain.items():
                    # Рассчитываем вознаграждение
                    reward_amount = self.calculate_reward_amount(level, amount)
                    
                    # Проверяем минимальную сумму
                    if reward_amount < min_amount:
                        logger.debug(f"Reward for level {level} (user {referrer_data['id']}) is below minimum: {reward_amount} < {min_amount}")
                        
                        # Добавляем в накопленные вознаграждения и отправляем уведомление
                        try:
                            from services.accumulated_rewards_service import AccumulatedRewardsService
                            # send_notification=True для автоматической отправки уведомления
                            success, new_total = AccumulatedRewardsService.add_to_accumulated_rewards(
                                referrer_data['id'], reward_amount, send_notification=True
                            )
                            if success:
                                logger.info(f"Added small reward {reward_amount} to accumulated rewards for user {referrer_data['id']}. New total: {new_total}")
                                
                                # Проверяем, не превысила ли сумма порог
                                if new_total >= AccumulatedRewardsService.ACCUMULATION_THRESHOLD:
                                    success, reward = AccumulatedRewardsService.check_and_process_threshold(referrer_data['id'])
                                    if success and reward:
                                        logger.info(f"Created reward from accumulated amount for user {referrer_data['id']}: {reward.amount}")
                                        
                                        # Отправляем дополнительное уведомление о преобразовании накопления в награду
                                        try:
                                            from services.notification_adapter import send_reward_notification
                                            reward_success = send_reward_notification(
                                                user_id=referrer_data['id'],
                                                amount=reward.amount,
                                                level=1,  # Уровень реферала в данном случае не важен
                                                percent="накопленное"
                                            )
                                            if reward_success:
                                                logger.info(f"Sent notification about accumulated reward conversion to user {referrer_data['id']}")
                                            else:
                                                logger.warning(f"Failed to send notification about accumulated reward conversion to user {referrer_data['id']}")
                                        except Exception as notify_error:
                                            logger.warning(f"Error sending notification about accumulated reward: {notify_error}")
                            else:
                                logger.warning(f"Failed to add to accumulated rewards for user {referrer_data['id']}")
                        except Exception as e:
                            logger.warning(f"Error processing accumulated rewards for user {referrer_data['id']}: {e}")
                            
                        continue
                    
                    reward_calculations.append({
                        "referrer_id": referrer_data["id"],
                        "relation_id": referrer_data["relation_id"],
                        "level": level,
                        "amount": reward_amount
                    })
                
                # Если нет валидных вознаграждений, выходим
                if not reward_calculations:
                    if operation_log:
                        operation_log.status = "completed"
                        operation_log.operation_metadata = json.dumps({
                            "transaction_id": transaction_id,
                            "amount": amount,
                            "min_amount": min_amount,
                            "rewards_count": 0,
                            "result": "no_valid_rewards"
                        })
                        db.session.commit()
                    return []
                
                # Фаза 2: создаем все вознаграждения атомарно
                pending_rewards = []
                
                for calc in reward_calculations:
                    referrer_id = calc["referrer_id"]
                    relation_id = calc["relation_id"]
                    level = calc["level"]
                    reward_amount = calc["amount"]
                    
                    # Создаем запись о вознаграждении
                    reward = ReferralReward(
                        referral_relation_id=relation_id,
                        amount=reward_amount,
                        source_transaction_id=transaction_id,
                        status="pending"
                    )
                    pending_rewards.append(reward)
                    
                    rewards.append({
                        "referrer_id": referrer_id,
                        "level": level,
                        "amount": reward_amount
                    })
                
                # Батч-вставка всех вознаграждений
                db.session.add_all(pending_rewards)
                
                # Обновляем журнал
                if operation_log:
                    operation_log.status = "completed"
                    operation_log.operation_metadata = json.dumps({
                        "transaction_id": transaction_id,
                        "amount": amount,
                        "min_amount": min_amount,
                        "rewards_count": len(rewards),
                        "total_amount": sum(r["amount"] for r in rewards),
                        "result": "success"
                    })
                
                # Коммит всей транзакции целиком, включая вознаграждения и журнал
                db.session.commit()
                
                # Инвалидация кэша статистики для рефереров - делаем после коммита
                for reward in rewards:
                    self._cache_invalidate('referral_stats', reward["referrer_id"])
                    
                logger.info(f"Created {len(rewards)} referral rewards for payment {transaction_id}")
                return rewards
                
            except Exception as e:
                logger.error(f"Error creating referral rewards: {e}")
                db.session.rollback()
                
                # Регистрируем сбой в отдельной транзакции
                try:
                    from db_models import PayoutOperationLog
                    error_log = PayoutOperationLog(
                        operation_type="process_payment_rewards",
                        entity_id=transaction_id,
                        entity_type="transaction",
                        source_user_id=user_id,
                        amount=amount,
                        status="error",
                        operation_metadata=json.dumps({
                            "transaction_id": transaction_id,
                            "amount": amount,
                            "min_amount": min_amount,
                            "error": str(e)
                        })
                    )
                    db.session.add(error_log)
                    db.session.commit()
                except Exception as log_error:
                    logger.error(f"Failed to log payment rewards error: {log_error}")
                
                return []
    
    def get_pending_rewards(self, user_id: Optional[int] = None, 
                          page: int = 1, page_size: int = 50) -> Tuple[List[Dict[str, Any]], int]:
        """
        Получение списка ожидающих выплат с пагинацией
        
        Args:
            user_id: ID пользователя (если требуются выплаты только для конкретного пользователя)
            page: Номер страницы (начиная с 1)
            page_size: Размер страницы
            
        Returns:
            Tuple[List[Dict], int]: Список ожидающих выплат и общее количество выплат
        """
        with self.app.app_context():
            # Базовый запрос
            base_query = ReferralReward.query.filter_by(status="pending")
            
            # Если задан ID пользователя
            if user_id:
                # Подзапрос для получения всех отношений, где пользователь является реферером
                relation_subquery = db.session.query(ReferralRelation.id).filter(
                    ReferralRelation.referrer_id == user_id
                ).subquery()
                
                # Фильтруем вознаграждения по этим отношениям
                base_query = base_query.filter(
                    ReferralReward.referral_relation_id.in_(relation_subquery)
                )
            
            # Получаем общее количество записей для пагинации
            total_count = base_query.count()
            
            # Применяем пагинацию
            offset = (page - 1) * page_size
            rewards = base_query.order_by(ReferralReward.created_at.desc()).limit(page_size).offset(offset).all()
            
            # Предзагружаем связанные записи для оптимизации запросов
            relation_ids = [reward.referral_relation_id for reward in rewards]
            
            # Получаем все отношения одним запросом
            relations = ReferralRelation.query.filter(
                ReferralRelation.id.in_(relation_ids)
            ).all()
            
            # Создаем словарь для быстрого доступа
            relation_dict = {relation.id: relation for relation in relations}
            
            # Получаем все ID пользователей из отношений
            user_ids = [relation.user_id for relation in relations]
            
            # Получаем данные пользователей одним запросом
            users = User.query.filter(User.id.in_(user_ids)).all()
            user_dict = {user.id: user for user in users}
            
            # Формируем результат
            result = []
            for reward in rewards:
                relation = relation_dict.get(reward.referral_relation_id)
                if not relation:
                    continue
                    
                source_user = user_dict.get(relation.user_id)
                if not source_user:
                    continue
                    
                result.append({
                    "id": reward.id,
                    "referrer_id": relation.referrer_id,
                    "user_id": relation.user_id,
                    "user_name": f"{source_user.first_name or ''} {source_user.last_name or ''}".strip() if source_user else "Unknown",
                    "level": relation.level,
                    "amount": reward.amount,
                    "created_at": reward.created_at
                })
                
            return result, total_count
    
    def create_weekly_payout(self, admin_id: int, description: str) -> Optional[int]:
        """
        Оптимизированное создание еженедельной выплаты
        
        Args:
            admin_id: ID администратора
            description: Описание выплаты
            
        Returns:
            Optional[int]: ID созданной выплаты или None в случае ошибки
        """
        with self.app.app_context():
            try:
                # Получаем только количество и сумму ожидающих выплат, без загрузки всех данных
                total_amount = db.session.query(db.func.sum(ReferralReward.amount)).filter(
                    ReferralReward.status == "pending"
                ).scalar() or 0
                
                # Агрегируем данные для получения уникальных пользователей
                unique_users_count = db.session.query(
                    db.func.count(db.func.distinct(ReferralRelation.referrer_id))
                ).join(
                    ReferralReward, ReferralReward.referral_relation_id == ReferralRelation.id
                ).filter(
                    ReferralReward.status == "pending"
                ).scalar() or 0
                
                if total_amount == 0 or unique_users_count == 0:
                    logger.warning("No pending rewards found for weekly payout")
                    return None
                
                # Создаем данные о выплате в формате JSON
                payout_data = {
                    "period": {
                        "start": (datetime.now() - timedelta(days=7)).isoformat(),
                        "end": datetime.now().isoformat()
                    },
                    "description": description,
                    "created_by": admin_id
                }
                
                # Создаем запись о выплате
                payout = WeeklyPayout(
                    admin_id=admin_id,  # Добавляем admin_id из параметра функции
                    status="created",
                    total_amount=total_amount,
                    amount=total_amount,  # Дублируем в поле amount для совместимости
                    total_users=unique_users_count,
                    processed_users=0,
                    payout_data=payout_data
                )
                
                db.session.add(payout)
                db.session.commit()
                
                logger.info(f"Created weekly payout {payout.id} with total amount {total_amount:.2f} for {unique_users_count} users")
                return payout.id
            except Exception as e:
                logger.error(f"Error creating weekly payout: {e}")
                db.session.rollback()
                return None
    
    def get_weekly_payouts(self, page: int = 1, page_size: int = 10) -> List[Dict[str, Any]]:
        """
        Получение списка еженедельных выплат с пагинацией
        
        Args:
            page: Номер страницы (начиная с 1)
            page_size: Количество элементов на странице
            
        Returns:
            List[Dict]: Список словарей с информацией о выплатах
        """
        result = []
        
        for _ in self._app_context():
            try:
                # Вычисляем смещение для пагинации
                offset = (page - 1) * page_size
                
                # Получаем выплаты с пагинацией и сортировкой по дате создания (самые новые сверху)
                payouts = WeeklyPayout.query.order_by(WeeklyPayout.created_at.desc()) \
                    .offset(offset).limit(page_size).all()
                
                # Преобразуем в список словарей
                result = []
                for payout in payouts:
                    # Получаем пользователя, создавшего выплату (администратора)
                    admin = User.query.filter_by(id=payout.admin_id).first()
                    admin_name = admin.username if admin else "Неизвестно"
                    
                    # Формируем словарь с информацией о выплате
                    payout_dict = {
                        "id": payout.id,
                        "status": payout.status,
                        "total_amount": payout.total_amount,
                        "total_users": payout.total_users,
                        "processed_users": payout.processed_users,
                        "created_at": payout.created_at.isoformat() if payout.created_at else None,
                        "completed_at": payout.completed_at.isoformat() if payout.completed_at else None,
                        "admin_id": payout.admin_id,
                        "admin_name": admin_name,
                        "payout_data": payout.payout_data
                    }
                    result.append(payout_dict)
                
                return result
            except Exception as e:
                logger.error(f"Error getting weekly payouts: {e}")
                return []

    def get_referral_stats(self, user_id: int) -> Dict[str, Any]:
        """
        Получение статистики для реферера
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Dict: Статистика реферальной программы
        """
        # Проверяем кэш
        cached_stats = self._cache_get('referral_stats', user_id)
        if cached_stats:
            return cached_stats
            
        stats = {}
        
        for _ in self._app_context():
            # Получаем количество прямых рефералов
            direct_referrals_count = db.session.query(db.func.count()).filter(
                ReferralRelation.referrer_id == user_id,
                ReferralRelation.level == 1
            ).scalar() or 0
            
            # Получаем общее количество рефералов
            total_referrals_count = db.session.query(db.func.count()).filter(
                ReferralRelation.referrer_id == user_id
            ).scalar() or 0
            
            # Получаем общую сумму вознаграждений - используем select_from для явного указания порядка джойнов
            reward_query = db.session.query(db.func.sum(ReferralReward.amount))
            reward_query = reward_query.select_from(ReferralReward)
            reward_query = reward_query.join(ReferralRelation, ReferralReward.referral_relation_id == ReferralRelation.id)
            reward_query = reward_query.filter(ReferralRelation.referrer_id == user_id)
            total_rewards = reward_query.scalar() or 0
            
            # Получаем количество оплаченных вознаграждений
            paid_count_query = db.session.query(db.func.count())
            paid_count_query = paid_count_query.select_from(ReferralReward)
            paid_count_query = paid_count_query.join(ReferralRelation, ReferralReward.referral_relation_id == ReferralRelation.id)
            paid_count_query = paid_count_query.filter(
                ReferralRelation.referrer_id == user_id,
                ReferralReward.status == "paid"
            )
            paid_rewards_count = paid_count_query.scalar() or 0
            
            # Получаем сумму оплаченных вознаграждений
            paid_amount_query = db.session.query(db.func.sum(ReferralReward.amount))
            paid_amount_query = paid_amount_query.select_from(ReferralReward)
            paid_amount_query = paid_amount_query.join(ReferralRelation, ReferralReward.referral_relation_id == ReferralRelation.id)
            paid_amount_query = paid_amount_query.filter(
                ReferralRelation.referrer_id == user_id,
                ReferralReward.status == "paid"
            )
            paid_rewards_amount = paid_amount_query.scalar() or 0
            
            # Получаем количество ожидающих вознаграждений
            pending_count_query = db.session.query(db.func.count())
            pending_count_query = pending_count_query.select_from(ReferralReward)
            pending_count_query = pending_count_query.join(ReferralRelation, ReferralReward.referral_relation_id == ReferralRelation.id)
            pending_count_query = pending_count_query.filter(
                ReferralRelation.referrer_id == user_id,
                ReferralReward.status == "pending"
            )
            pending_rewards_count = pending_count_query.scalar() or 0
            
            # Получаем сумму ожидающих вознаграждений
            pending_amount_query = db.session.query(db.func.sum(ReferralReward.amount))
            pending_amount_query = pending_amount_query.select_from(ReferralReward)
            pending_amount_query = pending_amount_query.join(ReferralRelation, ReferralReward.referral_relation_id == ReferralRelation.id)
            pending_amount_query = pending_amount_query.filter(
                ReferralRelation.referrer_id == user_id,
                ReferralReward.status == "pending"
            )
            pending_rewards_amount = pending_amount_query.scalar() or 0
            
            stats = {
                "direct_referrals": direct_referrals_count,
                "total_referrals": total_referrals_count,
                "total_rewards": total_rewards,
                "paid_rewards": {
                    "count": paid_rewards_count,
                    "amount": paid_rewards_amount
                },
                "pending_rewards": {
                    "count": pending_rewards_count,
                    "amount": pending_rewards_amount
                }
            }
            
            # Кэшируем результат
            self._cache_set('referral_stats', user_id, stats)
            
        return stats
    
    def process_payout_batch(self, payout_id: int, batch_size: int = 100) -> Tuple[bool, str, int]:
        """
        Пакетная обработка выплат с ограничением размера пакета
        
        Args:
            payout_id: ID выплаты для обработки
            batch_size: Размер пакета обрабатываемых вознаграждений
            
        Returns:
            Tuple[bool, str, int]: (успешно, сообщение, количество обработанных)
        """
        with self.app.app_context():
            try:
                # Получаем выплату
                payout = WeeklyPayout.query.filter_by(id=payout_id).with_for_update().first()
                if not payout:
                    return False, f"Payout {payout_id} not found", 0
                    
                if payout.status not in ["created", "processing", "partial"]:
                    return False, f"Payout {payout_id} has status {payout.status}, cannot process", 0
                
                # Помечаем как обрабатываемую, если еще не помечена
                if payout.status == "created":
                    payout.status = "processing"
                    payout.processed_at = datetime.now()
                    db.session.commit()
                
                # Получаем ожидающие вознаграждения, которые не были связаны с этой выплатой
                rewards = ReferralReward.query.filter(
                    ReferralReward.status == "pending",
                    ReferralReward.payout_id.is_(None)
                ).limit(batch_size).all()
                
                if not rewards:
                    # Все вознаграждения обработаны
                    # Проверяем, осталось ли что-то ожидающее
                    remaining = ReferralReward.query.filter_by(status="pending").count()
                    if remaining == 0:
                        payout.status = "completed"
                        payout.completed_at = datetime.now()
                        db.session.commit()
                        return True, f"Payout {payout_id} completed successfully", 0
                    else:
                        return True, f"Batch completed, but {remaining} rewards still pending", 0
                
                # Группируем вознаграждения по пользователям
                user_rewards = {}
                for reward in rewards:
                    relation = reward.referral_relation
                    if not relation:
                        continue
                        
                    referrer_id = relation.referrer_id
                    if referrer_id not in user_rewards:
                        user_rewards[referrer_id] = []
                        
                    user_rewards[referrer_id].append(reward)
                
                # Обрабатываем вознаграждения по пользователям
                processed_count = 0
                for user_id, user_rewards_list in user_rewards.items():
                    # Общая сумма вознаграждений пользователя
                    total_amount = sum(reward.amount for reward in user_rewards_list)
                    
                    # Создаем транзакцию выплаты
                    transaction = Transaction(
                        user_id=user_id,
                        type="referral_reward",
                        amount=total_amount,
                        status="completed",
                        description=f"Referral reward from payout {payout_id}"
                    )
                    db.session.add(transaction)
                    db.session.flush()  # Получаем ID транзакции
                    
                    # Связываем вознаграждения с выплатой и транзакцией
                    for reward in user_rewards_list:
                        reward.payout_id = payout_id
                        reward.transaction_id = transaction.id
                        reward.status = "paid"
                        processed_count += 1
                        
                        # Инвалидация кэша
                        self._cache_invalidate('referral_stats', user_id)
                
                # Обновляем счетчики в выплате
                payout.processed_users += len(user_rewards)
                if payout.processed_transactions is None:
                    payout.processed_transactions = []
                    
                new_transactions = [t.id for t in db.session.new if isinstance(t, Transaction)]
                if hasattr(payout.processed_transactions, 'extend'):
                    payout.processed_transactions.extend(new_transactions)
                else:
                    payout.processed_transactions = new_transactions
                
                db.session.commit()
                
                logger.info(f"Processed {processed_count} rewards for {len(user_rewards)} users in payout {payout_id}")
                return True, f"Processed {processed_count} rewards for {len(user_rewards)} users", processed_count
            except Exception as e:
                db.session.rollback()
                logger.error(f"Error processing payout batch: {e}")
                return False, f"Error: {str(e)}", 0

# Экспортируем оптимизированный менеджер
referral_manager = OptimizedReferralManager()