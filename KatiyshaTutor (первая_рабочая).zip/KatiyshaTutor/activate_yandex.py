#!/usr/bin/env python
# coding: utf-8

"""
Скрипт для активации Яндекс.Диск OAuth токена
Принимает код авторизации как аргумент командной строки
"""

import os
import sys
import requests
import json
import datetime
import argparse
from getpass import getpass

# Импортируем функции из основного хелпера
from yandex_oauth_helper import exchange_code_for_token, save_token_to_file, save_token_to_database

def main():
    """
    Основная функция
    """
    parser = argparse.ArgumentParser(description='Активация Яндекс.Диск OAuth токена')
    parser.add_argument('code', help='Код авторизации (verification_code)')
    args = parser.parse_args()
    
    code = args.code
    
    if not code:
        print("Ошибка: Код авторизации не может быть пустым")
        return
    
    print("=" * 70)
    print("  Активация токена OAuth для Яндекс.Диска")
    print("=" * 70)
    
    # Получаем CLIENT_ID и CLIENT_SECRET из переменных окружения
    client_id = os.environ.get("YANDEX_OAUTH_CLIENT_ID")
    client_secret = os.environ.get("YANDEX_OAUTH_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        print("Ошибка: Необходимо установить переменные окружения YANDEX_OAUTH_CLIENT_ID и YANDEX_OAUTH_CLIENT_SECRET")
        return
    
    print(f"\nИспользуем код авторизации: {code[:5]}...")
    
    # Используем стандартный redirect_uri для verification_code
    redirect_uri = "https://oauth.yandex.ru/verification_code"
    
    # Обмениваем код на токен
    token_data = exchange_code_for_token(client_id, client_secret, code, redirect_uri)
    
    if token_data:
        # Сохраняем токен в файл
        save_token_to_file(token_data)
        
        # Пытаемся сохранить токен в базу данных
        if not save_token_to_database(token_data):
            print("Токен сохранен только в файл, но не в базу данных")
            print("Для сохранения в базу данных, необходимо запустить бота с настроенным PostgreSQL")
        
        print("\nУспешно! Теперь вы можете использовать функции резервного копирования.")
        print("Если вы хотите использовать этот токен с ботом, убедитесь, что он сохранен в базе данных.")
    else:
        print("\nОшибка: Не удалось получить токен. Проверьте правильность кода авторизации.")

if __name__ == "__main__":
    main()