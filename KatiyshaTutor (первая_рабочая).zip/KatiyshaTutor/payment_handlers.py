#!/usr/bin/env python
# coding: utf-8

"""
Обработчики команд для платежной системы бота Катюша
Предоставляет функции обработки платежных команд в Telegram-боте
"""

import logging
import asyncio
from typing import Dict, Any, Optional, Tuple, List
from datetime import datetime, timedelta

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.error import TelegramError

from db_models import User, Transaction, db
from services.payment_processor_facade import payment_processor_facade, SUBSCRIPTION_PRICE
from services.payment_verification_service import (
    payment_verification_service, 
    PAYMENT_STATUS, 
    PAYMENT_SYSTEMS
)
from services.platform_detection_service import (
    get_user_platform, 
    update_user_platform, 
    get_platform_compatibility_flags
)
from services.notification_service import (
    send_payment_notification_to_user, 
    send_payment_link_notification
)

# Настройка логирования
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Создание обработчика для вывода в консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

# Создание файлового обработчика
import os
os.makedirs('logs', exist_ok=True)
file_handler = logging.FileHandler('logs/payment_handlers.log')
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

# Базовый URL для веб-интерфейса
BASE_URL = os.environ.get('REPLIT_DOMAINS', 'localhost:5000').split(',')[0]
if not BASE_URL.startswith('http'):
    BASE_URL = f"https://{BASE_URL}"

async def handle_buy_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик команды /buy_subscription и кнопки "Купить подписку"
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    user_id = update.effective_user.id
    logger.info(f"Пользователь {user_id} запросил покупку подписки")
    
    # Определяем платформу пользователя
    platform_info = get_user_platform(user_id)
    platform_type = platform_info.get('platform_type', 'unknown') if platform_info else 'unknown'
    platform_version = platform_info.get('platform_version') if platform_info else None
    
    # Получаем флаги совместимости для платформы
    compatibility_flags = get_platform_compatibility_flags(platform_type, platform_version)
    
    # Обновляем информацию о платформе пользователя, если это необходимо
    if update.effective_message and update.effective_message.via_bot:
        await update_user_platform(
            user_id, 
            {
                'last_seen': datetime.now(),
                'via_bot': update.effective_message.via_bot.username
            }
        )
    
    # Проверяем, есть ли у пользователя активная подписка
    user = User.query.get(user_id)
    if user and user.subscription_end and user.subscription_end > datetime.now():
        # У пользователя уже есть активная подписка
        days_left = (user.subscription_end - datetime.now()).days
        await update.effective_message.reply_text(
            f"У вас уже есть активная подписка! Она действует еще {days_left} дней.\n\n"
            f"Ваша подписка истекает: {user.subscription_end.strftime('%d.%m.%Y')}."
        )
        return
    
    # Проверяем наличие незавершенных платежей
    pending_payments = Transaction.query.filter_by(
        user_id=user_id, 
        status=PAYMENT_STATUS['PENDING']
    ).order_by(Transaction.created_at.desc()).first()
    
    if pending_payments and pending_payments.payment_expires_at and pending_payments.payment_expires_at > datetime.now():
        # У пользователя есть незавершенный платеж
        # Проверяем, доступна ли платежная ссылка
        payment_link = pending_payments.metadata.get('payment_link') if pending_payments.metadata else None
        
        # Создаем клавиатуру с кнопками
        keyboard = []
        
        if payment_link:
            # Добавляем кнопку с платежной ссылкой
            keyboard.append([
                InlineKeyboardButton("💳 Оплатить", url=payment_link)
            ])
        
        # Добавляем кнопку для проверки статуса платежа
        keyboard.append([
            InlineKeyboardButton(
                "🔄 Проверить статус", 
                callback_data=f"check_payment:{pending_payments.id}"
            )
        ])
        
        # Добавляем кнопку для создания нового платежа
        keyboard.append([
            InlineKeyboardButton(
                "🆕 Создать новый платеж", 
                callback_data=f"new_payment"
            )
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Отправляем сообщение с информацией о незавершенном платеже
        await update.effective_message.reply_text(
            f"У вас уже есть незавершенный платеж на сумму {pending_payments.amount} руб.\n\n"
            f"Вы можете продолжить оплату, проверить статус или создать новый платеж.",
            reply_markup=reply_markup
        )
        return
    
    # Определяем оптимальный способ оплаты в зависимости от платформы
    payment_method = _determine_best_payment_method(platform_type, platform_version, compatibility_flags)
    
    # Создаем новый платеж
    success, message, transaction_id = payment_processor_facade.create_payment_for_user(
        user_id=user_id,
        preferred_method=payment_method
    )
    
    if not success:
        # В случае ошибки при создании платежа
        logger.error(f"Ошибка при создании платежа для пользователя {user_id}: {message}")
        await update.effective_message.reply_text(
            f"⚠️ Произошла ошибка при создании платежа: {message}\n\n"
            f"Пожалуйста, попробуйте позже или обратитесь в поддержку."
        )
        return
    
    # Платеж успешно создан, но уведомление отправляется через сервис уведомлений
    # Добавляем только кнопку для проверки статуса
    keyboard = [
        [
            InlineKeyboardButton(
                "🔄 Проверить статус платежа", 
                callback_data=f"check_payment:{transaction_id}"
            )
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Отправляем подтверждение
    await update.effective_message.reply_text(
        f"✅ Платеж успешно создан!\n\n"
        f"Проверьте сообщение с платежной ссылкой и инструкциями.\n"
        f"После оплаты подписка будет активирована автоматически.",
        reply_markup=reply_markup
    )

async def handle_check_payment_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для проверки статуса платежа
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    # Получаем ID транзакции из callback_data
    callback_data = query.data
    try:
        transaction_id = int(callback_data.split(':')[1])
    except (IndexError, ValueError):
        await query.edit_message_text("⚠️ Некорректный формат данных. Пожалуйста, попробуйте снова.")
        return
    
    logger.info(f"Пользователь {query.from_user.id} запросил проверку статуса платежа {transaction_id}")
    
    # Получаем транзакцию
    transaction = Transaction.query.get(transaction_id)
    if not transaction:
        await query.edit_message_text(
            "⚠️ Платеж не найден. Возможно, он был удален или произошла ошибка.\n\n"
            "Для создания нового платежа используйте команду /buy_subscription."
        )
        return
    
    # Проверяем, принадлежит ли транзакция пользователю
    if transaction.user_id != query.from_user.id:
        await query.edit_message_text(
            "⚠️ Ошибка доступа. Вы не можете просматривать этот платеж."
        )
        return
    
    # Обновляем статус платежа, если он просрочен
    if (transaction.status == PAYMENT_STATUS['PENDING'] and 
        transaction.payment_expires_at and 
        transaction.payment_expires_at < datetime.now()):
        payment_verification_service.update_payment_status(
            transaction.id,
            PAYMENT_STATUS['EXPIRED']
        )
        transaction = Transaction.query.get(transaction_id)
    
    # Формируем текст сообщения в зависимости от статуса
    status_text = {
        PAYMENT_STATUS['INITIATED']: "🔄 Платеж инициирован",
        PAYMENT_STATUS['PENDING']: "⏱ Ожидание оплаты",
        PAYMENT_STATUS['COMPLETED']: "✅ Оплата успешно выполнена",
        PAYMENT_STATUS['FAILED']: "❌ Ошибка при оплате",
        PAYMENT_STATUS['CANCELLED']: "❌ Платеж отменен",
        PAYMENT_STATUS['EXPIRED']: "⏰ Время ожидания истекло"
    }.get(transaction.status, "❓ Статус неизвестен")
    
    message_text = (
        f"{status_text}\n\n"
        f"📋 Информация о платеже:\n"
        f"🆔 Номер транзакции: {transaction.id}\n"
        f"💰 Сумма: {transaction.amount} руб.\n"
        f"📅 Создан: {transaction.created_at.strftime('%d.%m.%Y %H:%M')}\n"
    )
    
    if transaction.completed_at:
        message_text += f"🏁 Завершен: {transaction.completed_at.strftime('%d.%m.%Y %H:%M')}\n"
    
    if transaction.payment_expires_at and transaction.status == PAYMENT_STATUS['PENDING']:
        message_text += f"⏰ Истекает: {transaction.payment_expires_at.strftime('%d.%m.%Y %H:%M')}\n"
    
    # Создаем клавиатуру с кнопками в зависимости от статуса
    keyboard = []
    
    if transaction.status == PAYMENT_STATUS['PENDING']:
        # Добавляем кнопку с платежной ссылкой, если она есть
        payment_link = transaction.metadata.get('payment_link') if transaction.metadata else None
        if payment_link:
            keyboard.append([
                InlineKeyboardButton("💳 Оплатить", url=payment_link)
            ])
        
        # Добавляем кнопку для обновления статуса
        keyboard.append([
            InlineKeyboardButton(
                "🔄 Обновить статус", 
                callback_data=f"check_payment:{transaction.id}"
            )
        ])
        
        # Добавляем кнопку для создания нового платежа
        keyboard.append([
            InlineKeyboardButton(
                "🆕 Создать новый платеж", 
                callback_data="new_payment"
            )
        ])
    elif transaction.status == PAYMENT_STATUS['COMPLETED']:
        # Для завершенных платежей показываем только кнопку возврата
        keyboard.append([
            InlineKeyboardButton(
                "🔙 Вернуться в главное меню", 
                callback_data="return_to_main"
            )
        ])
    else:
        # Для остальных статусов (FAILED, CANCELLED, EXPIRED)
        keyboard.append([
            InlineKeyboardButton(
                "🆕 Создать новый платеж", 
                callback_data="new_payment"
            )
        ])
        
        keyboard.append([
            InlineKeyboardButton(
                "🔙 Вернуться в главное меню", 
                callback_data="return_to_main"
            )
        ])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Отправляем сообщение
    await query.edit_message_text(
        message_text,
        reply_markup=reply_markup
    )

async def handle_new_payment_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для создания нового платежа
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    logger.info(f"Пользователь {user_id} запросил создание нового платежа через колбэк")
    
    # Определяем платформу пользователя
    platform_info = get_user_platform(user_id)
    platform_type = platform_info.get('platform_type', 'unknown') if platform_info else 'unknown'
    platform_version = platform_info.get('platform_version') if platform_info else None
    
    # Получаем флаги совместимости для платформы
    compatibility_flags = get_platform_compatibility_flags(platform_type, platform_version)
    
    # Определяем оптимальный способ оплаты
    payment_method = _determine_best_payment_method(platform_type, platform_version, compatibility_flags)
    
    # Создаем новый платеж
    success, message, transaction_id = payment_processor_facade.create_payment_for_user(
        user_id=user_id,
        preferred_method=payment_method
    )
    
    if not success:
        await query.edit_message_text(
            f"⚠️ Произошла ошибка при создании платежа: {message}\n\n"
            f"Пожалуйста, попробуйте позже или обратитесь в поддержку."
        )
        return
    
    # Платеж успешно создан, но уведомление отправляется через сервис уведомлений
    # Добавляем только кнопку для проверки статуса
    keyboard = [
        [
            InlineKeyboardButton(
                "🔄 Проверить статус платежа", 
                callback_data=f"check_payment:{transaction_id}"
            )
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Отправляем подтверждение
    await query.edit_message_text(
        f"✅ Новый платеж успешно создан!\n\n"
        f"Проверьте сообщение с платежной ссылкой и инструкциями.\n"
        f"После оплаты подписка будет активирована автоматически.",
        reply_markup=reply_markup
    )

async def handle_return_to_main_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик колбэка для возврата в главное меню
    
    Args:
        update: Telegram update
        context: Telegram context
    """
    query = update.callback_query
    await query.answer()
    
    # Удаляем текущее сообщение
    await query.message.delete()
    
    # Отправляем приветственное сообщение
    await query.message.reply_text(
        "Вы вернулись в главное меню. Что бы вы хотели сделать?",
        reply_markup=_get_main_menu_keyboard(query.from_user.id)
    )

def _determine_best_payment_method(platform_type: str, platform_version: Optional[str], 
                               compatibility_flags: Dict[str, bool]) -> str:
    """
    Определение оптимального метода оплаты в зависимости от платформы
    
    Args:
        platform_type: Тип платформы
        platform_version: Версия платформы
        compatibility_flags: Флаги совместимости
        
    Returns:
        str: Метод оплаты
    """
    # Для iOS с известной проблемой совместимости
    if platform_type == 'ios' and platform_version and 'ios_16_5' in platform_version:
        return PAYMENT_SYSTEMS['SBP_MANUAL']
    
    # Для других версий iOS
    if platform_type == 'ios':
        return PAYMENT_SYSTEMS['SBP_LINK_AUTO']
    
    # Для Android
    if platform_type == 'android':
        return PAYMENT_SYSTEMS['SBP_LINK_AUTO']
    
    # Для десктопных платформ
    if platform_type in ['windows', 'macos', 'linux']:
        return PAYMENT_SYSTEMS['SBP_LINK_DESKTOP']
    
    # По умолчанию - стандартный СБП
    return PAYMENT_SYSTEMS['SBP_LINK']

def _get_main_menu_keyboard(user_id: int) -> InlineKeyboardMarkup:
    """
    Формирование клавиатуры главного меню
    
    Args:
        user_id: ID пользователя
        
    Returns:
        InlineKeyboardMarkup: Клавиатура главного меню
    """
    # Проверяем, есть ли у пользователя активная подписка
    user = User.query.get(user_id)
    has_active_subscription = False
    
    if user and user.subscription_end and user.subscription_end > datetime.now():
        has_active_subscription = True
    
    keyboard = []
    
    # Добавляем кнопку покупки подписки, если нет активной
    if not has_active_subscription:
        keyboard.append([
            InlineKeyboardButton("💳 Купить подписку", callback_data="buy_subscription")
        ])
    
    # Добавляем другие кнопки главного меню
    keyboard.append([
        InlineKeyboardButton("ℹ️ Помощь", callback_data="help"),
        InlineKeyboardButton("👥 Реферальная программа", callback_data="referral")
    ])
    
    return InlineKeyboardMarkup(keyboard)

# Функция для регистрации обработчиков
def get_payment_handlers() -> Dict[str, callable]:
    """
    Получение словаря обработчиков платежных команд
    
    Returns:
        Dict[str, callable]: Словарь обработчиков {callback_data: handler_function}
    """
    return {
        "buy_subscription": handle_buy_subscription,
        "new_payment": handle_new_payment_callback,
        "return_to_main": handle_return_to_main_callback
    }

def get_payment_dynamic_handlers() -> Dict[str, callable]:
    """
    Получение словаря динамических обработчиков платежных команд
    
    Returns:
        Dict[str, callable]: Словарь обработчиков {prefix: handler_function}
    """
    return {
        "check_payment:": handle_check_payment_callback
    }