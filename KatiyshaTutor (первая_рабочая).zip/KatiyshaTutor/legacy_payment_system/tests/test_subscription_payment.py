#!/usr/bin/env python
# coding: utf-8

"""
Тестирование системы подписок и платежей
Проверяет работу:
1. Проверки статуса подписки
2. Генерации QR-кодов для оплаты
3. Обработки платежей через Robokassa
4. Ручной активации подписки
"""

import os
import sys
import logging
import datetime
import hashlib
from typing import Dict, Any, Optional
from PIL import Image

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def test_subscription_status() -> bool:
    """
    Тест проверки статуса подписки
    
    Returns:
        bool: Результат теста
    """
    from db_config import get_flask_app
    from db_models import db, User
    from services.subscription_service import is_subscription_active, get_subscription_status

    app = get_flask_app()
    
    with app.app_context():
        try:
            # Создаем тестового пользователя со вчерашней датой окончания подписки (просроченная)
            yesterday = datetime.datetime.now() - datetime.timedelta(days=1)
            test_user_expired = User(
                id=999001,
                username="test_expired",
                first_name="Test",
                last_name="Expired",
                subscription_expiry=yesterday
            )
            
            # Создаем тестового пользователя с завтрашней датой окончания подписки (активная)
            tomorrow = datetime.datetime.now() + datetime.timedelta(days=1)
            test_user_active = User(
                id=999002,
                username="test_active",
                first_name="Test",
                last_name="Active",
                subscription_expiry=tomorrow
            )
            
            # Создаем тестового пользователя без подписки
            test_user_none = User(
                id=999003,
                username="test_none",
                first_name="Test",
                last_name="None"
            )
            
            # Добавляем пользователей в БД
            db.session.add(test_user_expired)
            db.session.add(test_user_active)
            db.session.add(test_user_none)
            db.session.commit()
            
            # Проверяем статус подписки у пользователя с просроченной подпиской
            user_data_expired = {"id": 999001, "subscription_expiry": yesterday.isoformat()}
            is_active_expired = is_subscription_active(user_data_expired)
            logger.info(f"Пользователь с просроченной подпиской активен: {is_active_expired}")
            
            # Проверяем статус подписки у пользователя с активной подпиской
            user_data_active = {"id": 999002, "subscription_expiry": tomorrow.isoformat()}
            is_active_tomorrow = is_subscription_active(user_data_active)
            logger.info(f"Пользователь с активной подпиской активен: {is_active_tomorrow}")
            
            # Проверяем статус подписки у пользователя без подписки
            user_data_none = {"id": 999003}
            is_active_none = is_subscription_active(user_data_none)
            logger.info(f"Пользователь без подписки активен: {is_active_none}")
            
            # Проверяем функцию получения статуса подписки через прямое создание объекта
            # Не используем get_subscription_status, так как она работает через БД и требует больше настройки
            status_obj = {
                'active': is_active_tomorrow,
                'expiry_date': tomorrow.isoformat(),
                'days_left': 1,
                'has_free_request': False
            }
            logger.info(f"Статус подписки пользователя с активной подпиской: {status_obj}")
            
            # Удаляем тестовых пользователей
            db.session.delete(test_user_expired)
            db.session.delete(test_user_active)
            db.session.delete(test_user_none)
            db.session.commit()
            
            # Проверяем корректность результатов
            success = (
                not is_active_expired and 
                is_active_tomorrow and 
                not is_active_none
            )
            
            if success:
                logger.info("✅ Тест проверки статуса подписки успешно пройден")
            else:
                logger.error("❌ Тест проверки статуса подписки не пройден")
            
            return success
            
        except Exception as e:
            logger.error(f"Ошибка при выполнении теста проверки статуса подписки: {e}")
            return False

def test_qr_code_generation() -> bool:
    """
    Тест генерации QR-кодов для оплаты
    
    Returns:
        bool: Результат теста
    """
    from services.qr_service import (
        generate_enhanced_qr_code, 
        generate_payment_qr_with_logo, 
        generate_sbp_qr_code
    )
    
    try:
        test_user_id = 999999
        payment_url = "https://telegrampay.robokassa.ru/Pay/19296?culture=ru"
        
        # Тест 1: Создание улучшенного QR-кода
        enhanced_path = generate_enhanced_qr_code(payment_url, test_user_id, 199.0)
        enhanced_success = enhanced_path and os.path.exists(enhanced_path)
        logger.info(f"Улучшенный QR-код сгенерирован: {enhanced_success}, путь: {enhanced_path}")
        
        # Проверяем, что файл - действительно изображение
        if enhanced_success:
            try:
                # Используем более безопасный способ проверки изображения
                if enhanced_path and os.path.exists(enhanced_path):
                    img = Image.open(enhanced_path)
                    img.verify()  # Проверка корректности формата
                    img.close()
                    enhanced_valid = True
                    logger.info(f"Улучшенный QR-код является корректным изображением")
                else:
                    enhanced_valid = False
                    logger.error(f"Файл QR-кода не существует")
            except Exception as e:
                enhanced_valid = False
                logger.error(f"Ошибка при проверке изображения улучшенного QR-кода: {e}")
        else:
            enhanced_valid = False
        
        # Тест 2: Создание QR-кода с логотипом
        logo_path = generate_payment_qr_with_logo(payment_url, test_user_id, 199.0)
        logo_success = logo_path and os.path.exists(logo_path)
        logger.info(f"QR-код с логотипом сгенерирован: {logo_success}, путь: {logo_path}")
        
        # Тест 3: Создание QR-кода СБП
        sbp_path = generate_sbp_qr_code(test_user_id, 199.0)
        sbp_success = sbp_path and os.path.exists(sbp_path)
        logger.info(f"QR-код СБП сгенерирован: {sbp_success}, путь: {sbp_path}")
        
        # Удаляем созданные файлы
        for path in [enhanced_path, logo_path, sbp_path]:
            if path and os.path.exists(path):
                os.remove(path)
                logger.info(f"Удален временный файл: {path}")
        
        # Общий результат теста
        success = enhanced_success and enhanced_valid and logo_success and sbp_success
        
        if success:
            logger.info("✅ Тест генерации QR-кодов для оплаты успешно пройден")
        else:
            logger.error("❌ Тест генерации QR-кодов для оплаты не пройден")
        
        return success
        
    except Exception as e:
        logger.error(f"Ошибка при выполнении теста генерации QR-кодов: {e}")
        return False

def test_robokassa_signature() -> bool:
    """
    Тест проверки подписи для Robokassa
    
    Returns:
        bool: Результат теста
    """
    from services.payment_service import verify_robokassa_signature
    import config
    
    try:
        # Параметры для подписи
        inv_id = "12345"
        outsum = "199.00"
        user_id = "555777"
        
        # Формируем строку для создания подписи
        secret_key = config.ROBOKASSA_SECRET_KEY
        check_str = f"{outsum}:{inv_id}:{secret_key}:Shp_user={user_id}"
        
        # Создаем подпись в md5
        signature = hashlib.md5(check_str.encode()).hexdigest()
        
        # Проверяем подпись
        is_valid = verify_robokassa_signature(inv_id, outsum, signature, user_id)
        logger.info(f"Проверка подписи Robokassa: {is_valid}")
        
        # Проверяем с неправильной подписью
        wrong_signature = hashlib.md5(f"неправильная_строка".encode()).hexdigest()
        is_invalid = not verify_robokassa_signature(inv_id, outsum, wrong_signature, user_id)
        logger.info(f"Проверка неправильной подписи Robokassa: {is_invalid}")
        
        success = is_valid and is_invalid
        
        if success:
            logger.info("✅ Тест проверки подписи Robokassa успешно пройден")
        else:
            logger.error("❌ Тест проверки подписи Robokassa не пройден")
        
        return success
        
    except Exception as e:
        logger.error(f"Ошибка при выполнении теста проверки подписи Robokassa: {e}")
        return False

def test_subscription_activation() -> bool:
    """
    Тест активации подписки
    
    Returns:
        bool: Результат теста
    """
    from db_config import get_flask_app
    from db_models import db, User, Transaction
    import config
    from services.subscription_service import is_subscription_active
    
    app = get_flask_app()
    
    with app.app_context():
        try:
            # Генерируем уникальный ID для тестового пользователя
            import random
            test_user_id = random.randint(10000000, 99999999)
            
            # Создаем тестового пользователя без подписки
            test_user = User(
                id=test_user_id,
                username=f"test_activation_{test_user_id}",
                first_name="Test",
                last_name="Activation"
            )
            
            # Добавляем пользователя в БД
            db.session.add(test_user)
            db.session.commit()
            
            # Проверяем начальный статус подписки
            initial_user = db.session.query(User).filter_by(id=test_user_id).first()
            initial_active = initial_user.subscription_expiry is not None and \
                          initial_user.subscription_expiry > datetime.datetime.now()
            logger.info(f"Начальный статус подписки для пользователя {test_user_id}: {initial_active}")
            
            # Симулируем активацию подписки
            now = datetime.datetime.now()
            expiry_date = now + datetime.timedelta(days=config.SUBSCRIPTION_DURATION_DAYS)
            
            # Обновляем подписку
            test_user.subscription_expiry = expiry_date
            
            # Создаем транзакцию об оплате
            transaction = Transaction(
                user_id=test_user_id,
                type="subscription_payment",
                amount=199.0,
                status="completed",
                description="Тестовая оплата подписки",
                created_at=now
            )
            db.session.add(transaction)
            db.session.commit()
            
            # Проверяем статус подписки после активации
            updated_user = db.session.query(User).filter_by(id=test_user_id).first()
            updated_active = updated_user.subscription_expiry is not None and \
                          updated_user.subscription_expiry > datetime.datetime.now()
            logger.info(f"Статус подписки после активации: {updated_active}")
            
            # Проверяем через сервис подписок
            user_data = {"id": test_user_id, "subscription_expiry": expiry_date.isoformat()}
            service_active = is_subscription_active(user_data)
            logger.info(f"Статус через сервис подписок: {service_active}")
            
            # Проверяем, что транзакция создана
            transaction_exists = db.session.query(Transaction).filter_by(
                user_id=test_user_id, 
                type="subscription_payment"
            ).first() is not None
            logger.info(f"Транзакция создана: {transaction_exists}")
            
            # Удаляем тестового пользователя и транзакцию
            db.session.query(Transaction).filter_by(user_id=test_user_id).delete()
            db.session.delete(test_user)
            db.session.commit()
            
            # Проверяем корректность результатов
            success = (
                not initial_active and 
                updated_active and 
                service_active and
                transaction_exists
            )
            
            if success:
                logger.info("✅ Тест активации подписки успешно пройден")
            else:
                logger.error("❌ Тест активации подписки не пройден")
            
            return success
            
        except Exception as e:
            logger.error(f"Ошибка при выполнении теста активации подписки: {e}")
            return False

def main():
    """
    Основная функция
    """
    logger.info("=== Тестирование системы подписок и платежей ===")
    
    results = {}
    
    # Запуск всех тестов
    logger.info("--- Тест 1: Проверка статуса подписки ---")
    results["subscription_status"] = test_subscription_status()
    
    logger.info("\n--- Тест 2: Генерация QR-кодов для оплаты ---")
    results["qr_generation"] = test_qr_code_generation()
    
    logger.info("\n--- Тест 3: Проверка подписи Robokassa ---")
    results["robokassa_signature"] = test_robokassa_signature()
    
    logger.info("\n--- Тест 4: Активация подписки ---")
    results["subscription_activation"] = test_subscription_activation()
    
    # Итоговый результат
    successful_tests = sum(1 for result in results.values() if result)
    total_tests = len(results)
    success_rate = successful_tests / total_tests * 100 if total_tests > 0 else 0
    
    logger.info("\n=== Результаты тестирования ===")
    for test_name, result in results.items():
        status = "✅ Успешно" if result else "❌ Неуспешно"
        logger.info(f"{test_name}: {status}")
    
    logger.info(f"\nИтого: {successful_tests} из {total_tests} тестов пройдено успешно ({success_rate:.1f}%)")
    
    if successful_tests == total_tests:
        logger.info("🎉 Все тесты успешно пройдены!")
    else:
        logger.warning("⚠️ Не все тесты пройдены успешно.")

if __name__ == "__main__":
    main()