#!/usr/bin/env python
# coding: utf-8

"""
Модуль ролей и прав доступа для административных функций
"""

import enum
import config
from typing import Set, Dict, Any, List, Optional

class AdminRole(enum.Enum):
    """Роли администраторов с различными уровнями доступа"""
    SUPER_ADMIN = "super_admin"  # Полный доступ ко всему
    FINANCE_ADMIN = "finance_admin"  # Доступ к финансовым операциям и выплатам
    MONITORING_ADMIN = "monitoring_admin"  # Доступ к мониторингу и отчетам
    SUPPORT_ADMIN = "support_admin"  # Поддержка пользователей и базовые операции

class AdminPermission(enum.Enum):
    """Права доступа для административных функций"""
    # Общие права
    VIEW_ADMIN_PANEL = "view_admin_panel"  # Просмотр админ-панели
    ACCESS_REPORTS = "access_reports"  # Доступ к отчетам
    
    # Финансовые права
    MANAGE_PAYMENTS = "manage_payments"  # Управление платежами
    CREATE_PAYOUTS = "create_payouts"  # Создание выплат
    PROCESS_PAYOUTS = "process_payouts"  # Обработка выплат
    MANAGE_SUBSCRIPTIONS = "manage_subscriptions"  # Управление подписками
    
    # Мониторинг
    VIEW_STATISTICS = "view_statistics"  # Просмотр статистики
    EXPORT_DATA = "export_data"  # Экспорт данных
    CONFIGURE_ALERTS = "configure_alerts"  # Настройка оповещений
    
    # Анти-фрод
    VIEW_ANTIFRAUD = "view_antifraud"  # Просмотр анти-фрод системы
    MANAGE_ANTIFRAUD = "manage_antifraud"  # Управление анти-фрод системой
    
    # Пользователи
    VIEW_USER_DATA = "view_user_data"  # Просмотр данных пользователя
    EDIT_USER_DATA = "edit_user_data"  # Редактирование данных пользователя
    BLOCK_USERS = "block_users"  # Блокировка пользователей
    
    # Система
    MANAGE_SETTINGS = "manage_settings"  # Управление настройками
    VIEW_LOGS = "view_logs"  # Просмотр логов
    MANAGE_ADMINS = "manage_admins"  # Управление администраторами

# Карта разрешений для каждой роли
ROLE_PERMISSIONS: Dict[AdminRole, Set[AdminPermission]] = {
    AdminRole.SUPER_ADMIN: {
        # У суперадминистратора есть все права
        permission for permission in AdminPermission
    },
    AdminRole.FINANCE_ADMIN: {
        # Базовые права для всех админов
        AdminPermission.VIEW_ADMIN_PANEL,
        AdminPermission.ACCESS_REPORTS,
        
        # Финансовые права
        AdminPermission.MANAGE_PAYMENTS,
        AdminPermission.CREATE_PAYOUTS,
        AdminPermission.PROCESS_PAYOUTS,
        AdminPermission.MANAGE_SUBSCRIPTIONS,
        
        # Ограниченный доступ к мониторингу
        AdminPermission.VIEW_STATISTICS,
        AdminPermission.EXPORT_DATA,
        
        # Ограниченный доступ к пользователям
        AdminPermission.VIEW_USER_DATA,
        
        # Просмотр логов
        AdminPermission.VIEW_LOGS,
    },
    AdminRole.MONITORING_ADMIN: {
        # Базовые права для всех админов
        AdminPermission.VIEW_ADMIN_PANEL,
        AdminPermission.ACCESS_REPORTS,
        
        # Полный доступ к мониторингу
        AdminPermission.VIEW_STATISTICS,
        AdminPermission.EXPORT_DATA,
        AdminPermission.CONFIGURE_ALERTS,
        
        # Доступ к анти-фрод системе
        AdminPermission.VIEW_ANTIFRAUD,
        
        # Ограниченный доступ к пользователям
        AdminPermission.VIEW_USER_DATA,
        
        # Просмотр логов
        AdminPermission.VIEW_LOGS,
    },
    AdminRole.SUPPORT_ADMIN: {
        # Базовые права для всех админов
        AdminPermission.VIEW_ADMIN_PANEL,
        AdminPermission.ACCESS_REPORTS,
        
        # Ограниченный доступ к статистике
        AdminPermission.VIEW_STATISTICS,
        
        # Доступ к пользователям
        AdminPermission.VIEW_USER_DATA,
        AdminPermission.EDIT_USER_DATA,
        AdminPermission.BLOCK_USERS,
        
        # Просмотр логов
        AdminPermission.VIEW_LOGS,
    }
}

# Соответствие разрешений и веб-интерфейса
WEB_PERMISSIONS = {
    'view_users': AdminPermission.VIEW_USER_DATA,
    'view_user_details': AdminPermission.VIEW_USER_DATA,
    'edit_user': AdminPermission.EDIT_USER_DATA,
    'block_users': AdminPermission.BLOCK_USERS,
    'view_transactions': AdminPermission.MANAGE_PAYMENTS,
    'view_payouts': AdminPermission.CREATE_PAYOUTS,
    'process_payouts': AdminPermission.PROCESS_PAYOUTS,
    'view_financial_stats': AdminPermission.VIEW_STATISTICS,
    'view_monitoring_stats': AdminPermission.VIEW_STATISTICS,
    'view_reports': AdminPermission.ACCESS_REPORTS,
    'generate_reports': AdminPermission.EXPORT_DATA,
    'schedule_reports': AdminPermission.CONFIGURE_ALERTS,
    'view_activity_log': AdminPermission.VIEW_LOGS,
    'manage_settings': AdminPermission.MANAGE_SETTINGS,
    'manage_admins': AdminPermission.MANAGE_ADMINS
}

# Назначенные роли для администраторов
ADMIN_ROLES = {}

def has_permission(role: AdminRole, permission: AdminPermission) -> bool:
    """
    Проверка наличия определенного разрешения у роли
    
    Args:
        role: Роль администратора
        permission: Проверяемое разрешение
        
    Returns:
        bool: True, если роль имеет указанное разрешение, иначе False
    """
    return permission in ROLE_PERMISSIONS.get(role, set())

def get_role_permissions(role: AdminRole) -> Set[AdminPermission]:
    """
    Получение всех разрешений для роли
    
    Args:
        role: Роль администратора
        
    Returns:
        Set[AdminPermission]: Множество разрешений для роли
    """
    return ROLE_PERMISSIONS.get(role, set())

def get_admin_role(admin_id: int) -> Optional[AdminRole]:
    """
    Получение роли администратора по его ID
    
    Args:
        admin_id: ID администратора
        
    Returns:
        Optional[AdminRole]: Роль администратора или None, если не администратор
    """
    # Проверяем, есть ли роль у администратора в кэше
    if admin_id in ADMIN_ROLES:
        return ADMIN_ROLES[admin_id]
    
    # Иначе определяем роль на основе конфигурации
    if admin_id in config.ADMIN_IDS:
        # Главные администраторы всегда имеют роль SUPER_ADMIN
        ADMIN_ROLES[admin_id] = AdminRole.SUPER_ADMIN
        return AdminRole.SUPER_ADMIN
    
    # Проверка дополнительных администраторов с их ролями
    if hasattr(config, 'ADMIN_ROLES_MAP') and admin_id in config.ADMIN_ROLES_MAP:
        role_name = config.ADMIN_ROLES_MAP.get(admin_id)
        try:
            role = AdminRole(role_name)
            ADMIN_ROLES[admin_id] = role
            return role
        except ValueError:
            # Если роль некорректна, даем минимальную роль SUPPORT_ADMIN
            ADMIN_ROLES[admin_id] = AdminRole.SUPPORT_ADMIN
            return AdminRole.SUPPORT_ADMIN
    
    # По умолчанию дополнительные администраторы имеют минимальную роль SUPPORT_ADMIN
    if admin_id in config.ADDITIONAL_ADMIN_IDS:
        ADMIN_ROLES[admin_id] = AdminRole.SUPPORT_ADMIN
        return AdminRole.SUPPORT_ADMIN
    
    # Если не администратор, возвращаем None
    return None

def has_role_permission(admin_id: int, permission_name: str) -> bool:
    """
    Проверка наличия разрешения у администратора для веб-интерфейса
    
    Args:
        admin_id: ID администратора
        permission_name: Строковое имя разрешения из WEB_PERMISSIONS
        
    Returns:
        bool: True, если администратор имеет разрешение, иначе False
    """
    # Получаем роль администратора
    admin_role = get_admin_role(admin_id)
    if not admin_role:
        return False
    
    # Проверяем, есть ли разрешение в веб-соответствии
    if permission_name not in WEB_PERMISSIONS:
        return False
    
    # Получаем соответствующее AdminPermission
    admin_permission = WEB_PERMISSIONS[permission_name]
    
    # Проверяем наличие разрешения у роли
    return has_permission(admin_role, admin_permission)

def get_admin_permitted_actions(admin_id: int) -> List[str]:
    """
    Получение списка разрешенных действий для администратора в веб-интерфейсе
    
    Args:
        admin_id: ID администратора
        
    Returns:
        List[str]: Список разрешенных действий
    """
    admin_role = get_admin_role(admin_id)
    if not admin_role:
        return []
    
    # Получаем все разрешения для роли
    role_permissions = get_role_permissions(admin_role)
    
    # Формируем список разрешенных действий для веб-интерфейса
    permitted_actions = []
    for web_perm, admin_perm in WEB_PERMISSIONS.items():
        if admin_perm in role_permissions:
            permitted_actions.append(web_perm)
    
    return permitted_actions